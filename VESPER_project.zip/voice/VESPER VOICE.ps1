# VESPER VOICE (no-install version): call the song out loud while you play.
# Uses Windows' own speech recognition (offline) and sends the word it hears to VESPER on this computer.
# Start it with "VESPER VOICE (PowerShell).bat". Close the window to stop.
Add-Type -AssemblyName System.Speech
$port = 47321
$words = @("intro","verse","pre chorus","pre hook","hook","chorus","bridge","break","breakdown","build","drop",
           "drop out","solo","solo section","outro","ending","next","next section","fill","stop","crash","half time",
           "jam","transition","loop","catch","keep that","start","stop song",
           "solo keys","solo piano","solo guitar","solo horns","solo sax","solo melody","solo strings","solo violin","solo arp","solo pad")
$sure = 0.55

$rec = $null
foreach ($r in [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()) {
    if ($r.Culture.Name -like "en*") { $rec = $r; break }
}
if ($rec -eq $null) {
    Write-Host "No English speech recognizer: Windows Settings > Time & Language > Speech > add English (United States)." -ForegroundColor Yellow
    Read-Host "Press Enter to close"
    exit
}
$engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine $rec
$engine.SetInputToDefaultAudioDevice()
$gb = New-Object System.Speech.Recognition.GrammarBuilder
$gb.Culture = $rec.Culture
$gb.Append((New-Object System.Speech.Recognition.GrammarBuilder "vesper"), 0, 1)
$gb.Append((New-Object System.Speech.Recognition.GrammarBuilder "go to the"), 0, 1)
$gb.Append((New-Object System.Speech.Recognition.Choices (,$words)))
$engine.LoadGrammar((New-Object System.Speech.Recognition.Grammar $gb))
$udp = New-Object System.Net.Sockets.UdpClient
$to = New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Loopback, $port)

Write-Host ""
Write-Host "  VESPER VOICE is listening. Say: hook, verse, bridge, fill, drop out, solo keys, jam, transition..." -ForegroundColor Cyan
Write-Host "  (A headset or close mic works best, so the music doesn't trigger it.)"
Write-Host ""
while ($true) {
    $result = $engine.Recognize([TimeSpan]::FromSeconds(5))
    if ($result -eq $null) { continue }
    if ($result.Confidence -lt $sure) { Write-Host ("  (not sure: " + $result.Text + ")") -ForegroundColor DarkGray; continue }
    $text = $result.Text.ToLower().Replace("vesper", "").Replace("go to the", "").Trim()
    if ($text.Length -eq 0) { continue }
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
    [void] $udp.Send($bytes, $bytes.Length, $to)
    Write-Host ("  >> " + $text.ToUpper()) -ForegroundColor Green
}
