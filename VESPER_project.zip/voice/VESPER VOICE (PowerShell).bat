@echo off
rem VESPER VOICE without installing anything: runs the PowerShell version next to this file
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0VESPER VOICE.ps1"
