// VESPER VOICE - call the song out loud while you play.
// Listens (offline, with Windows' own speech recognition) for a short list of words - hook, verse, bridge, fill,
// drop out, solo, jam, transition... - and sends each one to VESPER on this computer (127.0.0.1, port 47321).
// VESPER lines every call up with the music: the end of the phrase, the next bar or the end of the section.
// Plain C# 5 / .NET Framework 4, so it builds with the compiler every Windows has.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Speech.Recognition;
using System.Text;
using System.Windows.Forms;

namespace VesperVoice
{
    public class MainForm : Form
    {
        const int VesperPort = 47321;
        static readonly string[] Words = {
            "intro", "verse", "pre chorus", "pre hook", "hook", "chorus", "bridge", "break", "breakdown", "build", "drop",
            "drop out", "solo", "solo section", "outro", "ending", "next", "next section", "fill", "stop", "crash", "half time",
            "jam", "transition", "loop", "catch", "keep that", "start", "stop song",
            "solo keys", "solo piano", "solo guitar", "solo horns", "solo sax", "solo melody", "solo strings", "solo violin",
            "solo arp", "solo pad",
            // 1.16
            "again", "one more time", "go back", "previous", "brighter", "darker", "glide on", "glide off", "call and response", "answer", "build up", "drums out", "drums in", "drums back in", "bass out", "bass in", "bass back in", "keys out", "keys in", "keys back in", "piano out", "piano in", "piano back in", "guitar out", "guitar in", "guitar back in", "horns out", "horns in", "horns back in", "strings out", "strings in", "strings back in", "melody out", "melody in", "melody back in", "pad out", "pad in", "pad back in", "arp out", "arp in", "arp back in", "everybody out", "everybody in", "everybody back in",
            // 1.17
            "key change", "key up", "key down", "half step up", "half step down", "whole step up", "whole step down", "relative", "relative major", "relative minor", "parallel", "home key", "back to the home key", "minimal", "quiet", "normal", "loud", "jam it out" };

        SpeechRecognitionEngine engine;
        readonly UdpClient udp = new UdpClient();
        readonly Label heard = new Label();
        readonly Label status = new Label();
        readonly Label vesper = new Label();
        readonly CheckBox muteBox = new CheckBox();
        readonly CheckBox wakeBox = new CheckBox();
        readonly TrackBar sureBar = new TrackBar();
        readonly Timer pingTimer = new Timer();
        DateTime lastPong = DateTime.MinValue;

        public MainForm()
        {
            Text = "VESPER VOICE";
            ClientSize = new Size (460, 338);
            BackColor = Color.FromArgb (24, 22, 28);
            ForeColor = Color.FromArgb (236, 228, 214);
            Font = new Font ("Segoe UI", 10f);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            TopMost = true;

            heard.Text = "...";
            heard.Font = new Font ("Segoe UI", 30f, FontStyle.Bold);
            heard.TextAlign = ContentAlignment.MiddleCenter;
            heard.SetBounds (10, 10, 440, 70);
            Controls.Add (heard);

            status.Text = "Starting...";
            status.TextAlign = ContentAlignment.MiddleCenter;
            status.SetBounds (10, 84, 440, 22);
            Controls.Add (status);

            vesper.Text = "Looking for VESPER...";
            vesper.TextAlign = ContentAlignment.MiddleCenter;
            vesper.SetBounds (10, 108, 440, 22);
            Controls.Add (vesper);

            muteBox.Text = "MUTE (stop listening)";
            muteBox.SetBounds (20, 140, 200, 24);
            muteBox.CheckedChanged += delegate { status.Text = muteBox.Checked ? "Muted" : "Listening"; };
            Controls.Add (muteBox);

            wakeBox.Text = "Say \"VESPER\" first (\"vesper hook\")";
            wakeBox.SetBounds (20, 168, 300, 24);
            wakeBox.CheckedChanged += delegate { LoadGrammar(); };
            Controls.Add (wakeBox);

            var sureLabel = new Label();
            sureLabel.Text = "How sure before it acts:";
            sureLabel.SetBounds (20, 200, 180, 22);
            Controls.Add (sureLabel);
            sureBar.Minimum = 30;
            sureBar.Maximum = 90;
            sureBar.Value = 55;
            sureBar.TickFrequency = 10;
            sureBar.SetBounds (200, 196, 240, 30);
            Controls.Add (sureBar);

            var help = new Label();
            help.Text = "Words: hook / chorus, verse, pre chorus, bridge, break, build, drop, solo (keys, guitar...), outro,\n"
                      + "next, fill, stop, drop out, crash, half time, jam, transition, loop, catch, start, stop song,\n"
                      + "again, go back, drums out / drums in (any instrument, or everybody), brighter, darker,\n"
                      + "glide on / off, call and response, key change (key up / down, relative),\n"
                      + "quiet / loud / jam it out.\n"
                      + "Use a headset or close mic so the music doesn't trigger it.";
            help.ForeColor = Color.FromArgb (160, 150, 140);
            help.Font = new Font ("Segoe UI", 8f);
            help.SetBounds (10, 232, 440, 100);
            Controls.Add (help);

            pingTimer.Interval = 1500;
            pingTimer.Tick += delegate { Ping(); };
            pingTimer.Start();

            Shown += delegate { StartListening(); };
            FormClosed += delegate { try { if (engine != null) engine.Dispose(); udp.Close(); } catch { } };
        }

        void StartListening()
        {
            try
            {
                RecognizerInfo pick = null;
                foreach (var r in SpeechRecognitionEngine.InstalledRecognizers())
                    if (r.Culture.Name.StartsWith ("en", StringComparison.OrdinalIgnoreCase)) { pick = r; break; }
                if (pick == null)
                {
                    foreach (var r in SpeechRecognitionEngine.InstalledRecognizers()) { pick = r; break; }
                }
                if (pick == null)
                {
                    status.Text = "No speech recognizer: Windows Settings > Time & Language > Speech > add English";
                    return;
                }
                engine = new SpeechRecognitionEngine (pick);
                engine.SetInputToDefaultAudioDevice();
                // answer as soon as you stop talking (Windows waits about half a second by default)
                engine.EndSilenceTimeout = TimeSpan.FromMilliseconds (150);
                engine.EndSilenceTimeoutAmbiguous = TimeSpan.FromMilliseconds (300);
                LoadGrammar();
                engine.SpeechRecognized += OnRecognized;
                engine.RecognizeAsync (RecognizeMode.Multiple);
                status.Text = "Listening (" + pick.Culture.Name + ")";
            }
            catch (Exception e)
            {
                status.Text = "Can't listen: " + e.Message;
            }
        }

        void LoadGrammar()
        {
            if (engine == null) return;
            engine.UnloadAllGrammars();
            var choices = new Choices (Words);
            var gb = new GrammarBuilder();
            gb.Culture = engine.RecognizerInfo.Culture;
            if (wakeBox.Checked) gb.Append ("vesper");
            else gb.Append (new GrammarBuilder ("vesper"), 0, 1);
            gb.Append (new GrammarBuilder ("go to the"), 0, 1);
            gb.Append (choices);
            engine.LoadGrammar (new Grammar (gb));
        }

        void OnRecognized (object sender, SpeechRecognizedEventArgs e)
        {
            if (muteBox.Checked || e.Result == null) return;
            if (e.Result.Confidence * 100f < sureBar.Value)
            {
                status.Text = "Not sure (" + e.Result.Text + ")";
                return;
            }
            var words = e.Result.Text.ToLowerInvariant().Replace ("vesper", "").Replace ("go to the", "").Trim();
            if (words.Length == 0) return;
            Send (words);
            heard.Text = words.ToUpperInvariant();
            status.Text = "Sent to VESPER";
        }

        void Send (string text)
        {
            try
            {
                var bytes = Encoding.UTF8.GetBytes (text);
                udp.Send (bytes, bytes.Length, new IPEndPoint (IPAddress.Loopback, VesperPort));
            }
            catch (Exception ex) { status.Text = "Couldn't send: " + ex.Message; }
        }

        void Ping()
        {
            try
            {
                var bytes = Encoding.UTF8.GetBytes ("ping");
                udp.Send (bytes, bytes.Length, new IPEndPoint (IPAddress.Loopback, VesperPort));
                while (udp.Available > 0)
                {
                    var from = new IPEndPoint (IPAddress.Any, 0);
                    var reply = udp.Receive (ref from);
                    if (Encoding.UTF8.GetString (reply).StartsWith ("VESPER")) lastPong = DateTime.Now;
                }
            }
            catch { }
            var ok = (DateTime.Now - lastPong).TotalSeconds < 5;
            vesper.Text = ok ? "VESPER is listening" : "VESPER not found: open FL Studio with VESPER loaded";
            vesper.ForeColor = ok ? Color.FromArgb (140, 220, 150) : Color.FromArgb (230, 150, 110);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run (new MainForm());
        }
    }
}
