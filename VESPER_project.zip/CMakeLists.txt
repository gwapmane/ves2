cmake_minimum_required(VERSION 3.22)

# Static MSVC runtime so the plugin runs on any Windows PC. Must be set before project().
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
set(CMAKE_OSX_DEPLOYMENT_TARGET "10.15" CACHE STRING "Oldest macOS supported")

project(VESPER VERSION 2.0.1 LANGUAGES C CXX)
add_compile_definitions(VESPER_VERSION="${PROJECT_VERSION}")   # shown under the logos

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

option(VESPER_BUILD_PLUGIN "Build the JUCE plugin" ON)
option(VESPER_BUILD_TOOLS  "Build the chord engine self-test" ON)
option(VESPER_LINUX_CHECK  "Developer compile check on a bare Linux box" OFF)
set(VESPER_JUCE_DIR "" CACHE PATH "Use a local JUCE checkout instead of downloading one")

set(VESPER_CORE core/Theory.cpp core/Voicing.cpp core/Guitar.cpp core/Perform.cpp core/Band.cpp core/Phrases.cpp core/Grooves.cpp core/Clips.cpp core/Song.cpp core/Fills.cpp core/Rework.cpp core/Beatbox.cpp)

# ---- chord engine self-test (no JUCE needed) -----------------------------------------------
if(VESPER_BUILD_TOOLS)
    add_executable(vesper_selftest tests/selftest.cpp ${VESPER_CORE})
    target_include_directories(vesper_selftest PRIVATE core)
    if(MSVC)
        target_compile_options(vesper_selftest PRIVATE /O2 /W3 /utf-8)
    else()
        target_compile_options(vesper_selftest PRIVATE -O2 -Wall -Wextra)
    endif()
endif()

# ---- the plugin ------------------------------------------------------------------------------
if(VESPER_BUILD_PLUGIN)
    if(VESPER_JUCE_DIR)
        add_subdirectory(${VESPER_JUCE_DIR} JUCE)
    else()
        include(FetchContent)
        FetchContent_Declare(
            JUCE
            GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
            GIT_TAG        8.0.6
            GIT_SHALLOW    ON)
        FetchContent_MakeAvailable(JUCE)
    endif()

    set(VESPER_FORMATS VST3)
    if(APPLE)
        list(APPEND VESPER_FORMATS AU)
    endif()

    # TROUPE CHORD ENGINE (it was VESPER): the name FL shows is new, but the file is still VESPER.vst3 and the plugin's
    # ID codes are the same, so projects you saved with VESPER open with it and keep their settings
    juce_add_plugin(VESPER
        COMPANY_NAME "Troupe"
        PLUGIN_NAME "Troupe Chord Engine"
        BUNDLE_ID "com.VESPER.VESPER"
        PLUGIN_MANUFACTURER_CODE Vspr
        PLUGIN_CODE Vchd
        FORMATS ${VESPER_FORMATS}
        PRODUCT_NAME "VESPER"
        IS_SYNTH TRUE
        NEEDS_MIDI_INPUT TRUE
        NEEDS_MIDI_OUTPUT TRUE
        IS_MIDI_EFFECT FALSE
        EDITOR_WANTS_KEYBOARD_FOCUS FALSE
        COPY_PLUGIN_AFTER_BUILD FALSE
        VST3_CATEGORIES Instrument Generator
        AU_MAIN_TYPE kAudioUnitType_MusicDevice)

    target_sources(VESPER PRIVATE
        ${VESPER_CORE}
        plugin/PluginProcessor.cpp
        plugin/PluginEditor.cpp
        plugin/Widgets.cpp
        plugin/StylePanel.cpp
        plugin/BandPanel.cpp
        plugin/SongPanel.cpp
        plugin/ProcessorBand.cpp
        plugin/ProcessorLive.cpp
        plugin/ProcessorPerform.cpp
        plugin/ProcessorGrooves.cpp
        plugin/Rack.cpp
        plugin/SoundMenu.cpp
        plugin/Look.cpp
        plugin/Chrome.cpp)

    target_include_directories(VESPER PRIVATE core plugin)

    target_compile_definitions(VESPER PUBLIC
        JUCE_PLUGINHOST_VST3=1
        JUCE_WEB_BROWSER=0
        JUCE_USE_CURL=0
        JUCE_VST3_CAN_REPLACE_VST2=0
        JUCE_DISPLAY_SPLASH_SCREEN=0)

    if(VESPER_LINUX_CHECK)
        target_compile_definitions(VESPER PUBLIC JUCE_USE_XRANDR=0 JUCE_USE_XINERAMA=0 JUCE_USE_XCURSOR=0 JUCE_ALSA=0 JUCE_JACK=0)
        # a tiny instrument to load into VESPER's SOUND slots in the tests
        juce_add_plugin(VESPER_TESTSYNTH
            COMPANY_NAME "VESPER"
            PLUGIN_MANUFACTURER_CODE Vspr
            PLUGIN_CODE Vtst
            FORMATS VST3
            PRODUCT_NAME "VESPER TEST SYNTH"
            IS_SYNTH TRUE
            NEEDS_MIDI_INPUT TRUE
            COPY_PLUGIN_AFTER_BUILD FALSE)
        target_sources(VESPER_TESTSYNTH PRIVATE tests/testsynth.cpp)
        target_compile_definitions(VESPER_TESTSYNTH PUBLIC JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_VST3_CAN_REPLACE_VST2=0
            JUCE_USE_XRANDR=0 JUCE_USE_XINERAMA=0 JUCE_USE_XCURSOR=0)
        target_link_libraries(VESPER_TESTSYNTH PRIVATE juce::juce_audio_utils)

        add_executable(vesper_proctest tests/proctest.cpp ${VESPER_CORE}
            plugin/PluginProcessor.cpp plugin/PluginEditor.cpp plugin/Widgets.cpp plugin/StylePanel.cpp plugin/BandPanel.cpp plugin/SongPanel.cpp plugin/ProcessorBand.cpp
            plugin/ProcessorLive.cpp plugin/ProcessorPerform.cpp plugin/ProcessorGrooves.cpp plugin/Rack.cpp plugin/SoundMenu.cpp plugin/Look.cpp plugin/Chrome.cpp)
        add_dependencies(vesper_proctest VESPER_TESTSYNTH_VST3)
        target_include_directories(vesper_proctest PRIVATE core plugin)
        target_compile_definitions(vesper_proctest PRIVATE JUCE_PLUGINHOST_VST3=1
            VESPER_TESTSYNTH="${CMAKE_BINARY_DIR}/VESPER_TESTSYNTH_artefacts/${CMAKE_BUILD_TYPE}/VST3/VESPER TEST SYNTH.vst3"
            JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_USE_XRANDR=0
            JUCE_USE_XINERAMA=0 JUCE_USE_XCURSOR=0 JUCE_ALSA=0 JUCE_JACK=0 JUCE_STANDALONE_APPLICATION=1 JUCE_MODAL_LOOPS_PERMITTED=1)
        target_link_libraries(vesper_proctest PRIVATE juce::juce_audio_processors juce::juce_audio_utils juce::juce_gui_basics)

        # pictures of the editor (every tab, every theme) for checking the look
        add_executable(vesper_uishot tests/uishot.cpp ${VESPER_CORE}
            plugin/PluginProcessor.cpp plugin/PluginEditor.cpp plugin/Widgets.cpp plugin/StylePanel.cpp plugin/BandPanel.cpp plugin/SongPanel.cpp plugin/ProcessorBand.cpp
            plugin/ProcessorLive.cpp plugin/ProcessorPerform.cpp plugin/ProcessorGrooves.cpp plugin/Rack.cpp plugin/SoundMenu.cpp plugin/Look.cpp plugin/Chrome.cpp)
        target_include_directories(vesper_uishot PRIVATE core plugin)
        target_compile_definitions(vesper_uishot PRIVATE JUCE_PLUGINHOST_VST3=1 JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_USE_XRANDR=0
            JUCE_USE_XINERAMA=0 JUCE_USE_XCURSOR=0 JUCE_ALSA=0 JUCE_JACK=0 JUCE_STANDALONE_APPLICATION=1 JUCE_MODAL_LOOPS_PERMITTED=1)
        target_link_libraries(vesper_uishot PRIVATE juce::juce_audio_processors juce::juce_audio_utils juce::juce_gui_basics)
    endif()

    if(MSVC)
        target_compile_options(VESPER PRIVATE /utf-8)
    endif()


    target_link_libraries(VESPER
        PRIVATE
            juce::juce_audio_processors
            juce::juce_audio_utils
            juce::juce_gui_basics
        PUBLIC
            juce::juce_recommended_config_flags
            juce::juce_recommended_warning_flags)
endif()
