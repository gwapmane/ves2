// A tiny instrument for VESPER's tests: a sine for every note on channel 1 (or 10). Its "Gain" is saved and restored,
// so the tests can tell VESPER brought the instrument back the way it was.
#include <juce_audio_processors/juce_audio_processors.h>

#include <cmath>

class TestSynth : public juce::AudioProcessor
{
public:
    TestSynth() : AudioProcessor (BusesProperties().withOutput ("Out", juce::AudioChannelSet::stereo(), true))
    {
        addParameter (gain = new juce::AudioParameterFloat (juce::ParameterID { "gain", 1 }, "Gain", 0.0f, 1.0f, 0.5f));
    }
    const juce::String getName() const override { return "VESPER TEST SYNTH"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    bool hasEditor() const override { return false; }
    juce::AudioProcessorEditor* createEditor() override { return nullptr; }
    void prepareToPlay (double s, int) override { sr = s > 0 ? s : 44100.0; }
    void releaseResources() override {}
    void processBlock (juce::AudioBuffer<float>& b, juce::MidiBuffer& m) override
    {
        b.clear();
        for (const auto meta : m)
        {
            const auto e = meta.getMessage();
            if (e.getChannel() != 1 && e.getChannel() != 10) continue;
            if (e.isNoteOn()) on[e.getNoteNumber()] = true;
            else if (e.isNoteOff()) on[e.getNoteNumber()] = false;
        }
        const float g = gain->get() * 0.1f;
        for (int n = 0; n < 128; ++n)
        {
            if (! on[n]) continue;
            const double step = juce::MathConstants<double>::twoPi * 440.0 * std::pow (2.0, (n - 69) / 12.0) / sr;
            for (int i = 0; i < b.getNumSamples(); ++i)
            {
                const float v = g * (float) std::sin (phase[n]);
                phase[n] += step;
                for (int c = 0; c < b.getNumChannels(); ++c) b.addSample (c, i, v);
            }
        }
    }
    void getStateInformation (juce::MemoryBlock& d) override { juce::MemoryOutputStream (d, false).writeFloat (gain->get()); }
    void setStateInformation (const void* data, int size) override
    {
        if (size >= 4) *gain = juce::MemoryInputStream (data, (size_t) size, false).readFloat();
    }

private:
    juce::AudioParameterFloat* gain = nullptr;
    double sr = 44100.0;
    bool on[128] {};
    double phase[128] {};
};

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new TestSynth(); }
