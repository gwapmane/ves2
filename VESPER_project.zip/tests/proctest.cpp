// Developer test (Linux compile check only): drives the real processor with MIDI and
// snapshots the editor to PNG files.
#include <set>
#include <tuple>
#include "../plugin/PluginProcessor.h"
#include "../plugin/PluginEditor.h"
#include "../core/Beatbox.h"
#include <juce_audio_formats/juce_audio_formats.h>

#include <juce_gui_basics/juce_gui_basics.h>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <map>

using namespace vesper;

static int failures = 0;
#define CHECK(c, ...) do { if (! (c)) { ++failures; std::printf ("FAIL: "); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)

struct Out { std::vector<juce::MidiMessage> msgs; std::vector<int> pos; float peak = 0; };

static Out run (VesperProcessor& p, juce::MidiBuffer in, int blocks = 1)
{
    Out o;
    for (int b = 0; b < blocks; ++b)
    {
        juce::AudioBuffer<float> buf (2, 512);
        juce::MidiBuffer m;
        if (b == 0) m = in;
        p.processBlock (buf, m);
        for (const auto meta : m) { o.msgs.push_back (meta.getMessage()); o.pos.push_back (meta.samplePosition + b * 512); }
        o.peak = juce::jmax (o.peak, buf.getMagnitude (0, 512));
    }
    return o;
}

struct FakeHead : public juce::AudioPlayHead
{
    double ppq = 0;
    bool playing = false, rec = false;
    juce::Optional<PositionInfo> getPosition() const override
    {
        PositionInfo i;
        i.setBpm (120.0);
        i.setIsPlaying (playing);
        i.setIsRecording (rec);
        i.setPpqPosition (ppq);
        return i;
    }
};

static juce::MidiBuffer note (int n, bool on, int vel = 100, int pos = 0)
{
    juce::MidiBuffer b;
    b.addEvent (on ? juce::MidiMessage::noteOn (1, n, (juce::uint8) vel) : juce::MidiMessage::noteOff (1, n), pos);
    return b;
}

static Notes onsOf (const Out& o, int channel = 1)
{
    Notes n;
    for (auto& m : o.msgs) if (m.isNoteOn() && m.getChannel() == channel) n.add (m.getNoteNumber());
    n.sort();
    return n;
}

static void setParam (VesperProcessor& p, const char* id, float value)
{
    auto* prm = p.apvts.getParameter (id);
    prm->setValueNotifyingHost (prm->convertTo0to1 (value));
}

int main()
{
    juce::ScopedJuceInitialiser_GUI gui;
    if (std::getenv ("VESPER_SHOT_SOUNDS") != nullptr)   // a quick look at the SOUND buttons with instruments loaded
    {
        std::unique_ptr<juce::AudioProcessor> sb (createPluginFilter());
        auto& sp = dynamic_cast<VesperProcessor&> (*sb);
        sp.setPlayConfigDetails (0, 2, 48000.0, 512);
        sp.prepareToPlay (48000.0, 512);
        juce::String err;
        sp.rack.load (InstrumentRack::chordSlot, juce::File (VESPER_TESTSYNTH), err);
        sp.rack.load (InstrumentRack::trackSlot (0), juce::File (VESPER_TESTSYNTH), err);
        sp.setTrackName (0, "Omnisphere - Warm Pad");
        sp.ui.tab = 4;
        std::unique_ptr<juce::AudioProcessorEditor> ed (sp.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 8; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_sounds.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
        ed.reset();
        return 0;
    }
    std::unique_ptr<juce::AudioProcessor> base (createPluginFilter());
    auto& p = dynamic_cast<VesperProcessor&> (*base);
    p.setPlayConfigDetails (0, 2, 48000.0, 512);
    p.prepareToPlay (48000.0, 512);
    run (p, {});

    // 1. SCALE mode: middle C (MIDI 60) = the 7ths row, I chord = Cmaj7 in C major
    setParam (p, ids::humanize, 0.0f);
    auto o = run (p, note (60, true));
    Notes n = onsOf (o);
    const Chord cmaj7 = makeChord (0, "maj7");
    CHECK (n.size() >= 3, "key 60 should play a chord, got %d notes", n.size());
    for (int i = 0; i < n.size(); ++i) CHECK ((pcMask (cmaj7) >> (n[i] % 12)) & 1, "note %d is not in Cmaj7", n[i]);
    CHECK (o.peak > 0.001f, "built-in keys should make sound");
    std::printf ("key C5 (60) -> ");
    for (int i = 0; i < n.size(); ++i) std::printf ("%s ", midiName (n[i], true).c_str());
    std::printf ("\n");

    o = run (p, note (60, false));
    int offs = 0;
    for (auto& m : o.msgs) if (m.isNoteOff()) ++offs;
    CHECK (offs == n.size(), "release should turn off every note (%d of %d)", offs, n.size());

    // D on the 7ths row (62) = Dm7, G (67) = G7
    o = run (p, note (67, true));
    n = onsOf (o);
    for (int i = 0; i < n.size(); ++i) CHECK ((pcMask (makeChord (7, "7")) >> (n[i] % 12)) & 1, "key 67 should be G7");
    run (p, note (67, false));

    // 2. VARY: same key three times gives a new voicing each time
    setParam (p, ids::vary, 1.0f);
    Notes last;
    for (int k = 0; k < 6; ++k)
    {
        o = run (p, note (62, true));
        n = onsOf (o);
        if (k > 0) CHECK (! n.sameAs (last), "VARY repeated the same voicing on hit %d", k);
        last = n;
        run (p, note (62, false));
    }
    setParam (p, ids::vary, 0.0f);

    // 3. Strum spreads the notes out
    setParam (p, ids::strum, 60.0f);
    o = run (p, note (48, true), 24);
    int first = 1 << 30, lastPos = 0;
    for (size_t i = 0; i < o.msgs.size(); ++i)
        if (o.msgs[i].isNoteOn()) { first = juce::jmin (first, o.pos[i]); lastPos = juce::jmax (lastPos, o.pos[i]); }
    CHECK (lastPos - first > 2000, "strum should spread notes (spread %d samples)", lastPos - first);
    std::printf ("strum spread: %d samples\n", lastPos - first);
    run (p, note (48, false));
    setParam (p, ids::strum, 0.0f);

    // 4. Bass on channel 2
    setParam (p, ids::bassMode, 2.0f);
    o = run (p, note (60, true));
    CHECK (onsOf (o, 2).size() == 1 && onsOf (o, 2)[0] % 12 == 0, "bass C should go out on channel 2");
    run (p, note (60, false));
    setParam (p, ids::bassMode, 0.0f);

    // 5. HOLD keeps the chord after release, next chord replaces it
    setParam (p, ids::hold, 1.0f);
    run (p, note (60, true));
    o = run (p, note (60, false));
    int offsHold = 0;
    for (auto& m : o.msgs) if (m.isNoteOff()) ++offsHold;
    CHECK (offsHold == 0, "HOLD should keep the chord ringing");
    o = run (p, note (65, true));
    int offsNext = 0;
    for (auto& m : o.msgs) if (m.isNoteOff()) ++offsNext;
    CHECK (offsNext > 0, "next chord should release the held one");
    run (p, note (65, false));
    setParam (p, ids::hold, 0.0f);
    p.panic();
    run (p, {});

    // 6. PADS mode: key 48 plays pad 1, notes above pass through untouched
    p.ui.keysMode = 1;
    p.applyUiState();
    o = run (p, note (48, true));
    n = onsOf (o);
    const Chord pad1 = p.ui.palette[0].chord;
    CHECK (n.size() >= 3, "pad 1 should play");
    for (int i = 0; i < n.size(); ++i) CHECK ((pcMask (pad1) >> (n[i] % 12)) & 1, "pad 1 wrong note");
    run (p, note (48, false));
    o = run (p, note (84, true));
    CHECK (onsOf (o).size() == 1 && onsOf (o)[0] == 84, "melody note should pass through");
    run (p, note (84, false));

    // 7. Recording -> MIDI file
    p.recording = true;
    for (int k : { 48, 52, 55 })
    {
        run (p, note (k, true), 20);
        run (p, note (k, false), 2);
    }
    p.recording = false;
    const auto f = p.exportRecording();
    CHECK (f.existsAsFile(), "recording should export a MIDI file");
    {
        juce::FileInputStream in (f);
        juce::MidiFile mf;
        CHECK (mf.readFrom (in), "exported MIDI should be readable");
        int ons = 0;
        if (mf.getNumTracks() > 0)
            for (auto* e : *mf.getTrack (0)) if (e->message.isNoteOn()) ++ons;
        CHECK (ons >= 9, "recorded MIDI should hold 3 chords, got %d note-ons", ons);
        std::printf ("recorded %d note-ons to %s\n", ons, f.getFullPathName().toRawUTF8());
    }
    CHECK (p.exportChord (makeChord (2, "m9"), Lush, -1).existsAsFile(), "single chord MIDI export");

    // 7b. MIDI loop: VESPER's output routed straight back into its input (bad FL port setup)
    for (int mode = 0; mode < 4; ++mode)
    {
        std::unique_ptr<juce::AudioProcessor> lb (createPluginFilter());
        auto& lp = dynamic_cast<VesperProcessor&> (*lb);
        lp.setPlayConfigDetails (0, 2, 48000.0, 512);
        lp.prepareToPlay (48000.0, 512);
        if (mode >= 2) { setParam (lp, ids::strum, 80.0f); setParam (lp, ids::vary, 1.0f); setParam (lp, ids::bassMode, 2.0f); }
        mode %= 2;
        lp.ui.keysMode = mode;
        lp.applyUiState();
        juce::MidiBuffer feed;
        juce::AudioBuffer<float> buf (2, 512);
        { juce::MidiBuffer m; lp.processBlock (buf, m); }
        feed.addEvent (juce::MidiMessage::noteOn (1, mode == 0 ? 60 : 84, (juce::uint8) 100), 0);
        int totalOns = 0;
        uint32_t chordsBefore = 0;
        for (int b = 0; b < 400; ++b)   // ~4 seconds
        {
            juce::MidiBuffer m = feed;
            if (b == 200) m.addEvent (juce::MidiMessage::noteOff (1, mode == 0 ? 60 : 84), 10);
            if (b == 250 && mode == 0) { chordsBefore = lp.playedCounter(); m.addEvent (juce::MidiMessage::noteOn (1, 65, (juce::uint8) 90), 30); }
            if (b == 300 && mode == 0) m.addEvent (juce::MidiMessage::noteOff (1, 65), 30);
            lp.processBlock (buf, m);
            for (const auto meta : m) if (meta.getMessage().isNoteOn()) ++totalOns;
            feed = m;                    // what went out comes back in next block
        }
        std::printf ("loop test (%s mode): %d note-ons in 4 s, loop caught %u time(s)\n", mode == 0 ? "SCALE" : "PADS", totalOns, lp.loopEvents.load());
        CHECK (totalOns < 40, "MIDI loop should be contained, got %d note-ons", totalOns);
        // caught either way: dropped as VESPER's own notes the moment they come back, or by the loop guard
        if (mode == 0) CHECK (lp.playedCounter() - chordsBefore == 1, "with the loop blocked, a new key should play exactly one chord (%u)", lp.playedCounter() - chordsBefore);
        if (lp.apvts.getRawParameterValue (ids::strum)->load() > 1.0f) mode += 2;
    }

    // 7b2. MIDI loop with HOLD tracks: play a few chords hard, let go - nothing may keep ringing
    for (int variant = 0; variant < 3; ++variant)
    {
        std::unique_ptr<juce::AudioProcessor> lb (createPluginFilter());
        auto& lp = dynamic_cast<VesperProcessor&> (*lb);
        lp.setPlayConfigDetails (0, 2, 48000.0, 512);
        lp.prepareToPlay (48000.0, 512);
        lp.applyBandGenre (House);
        for (int t = 0; t < numBandParts; ++t) lp.setTrackValue (t, TpOn, 1.0f);
        if (variant >= 1) lp.setAllHold (true);
        if (variant == 2) lp.setTrackValue (2, TpMode, (float) ModeRing);
        juce::MidiBuffer feed;
        juce::AudioBuffer<float> buf (2, 512);
        int on[16][128] = {};
        static const int keys[5] = { 60, 65, 67, 69, 62 };
        for (int b = 0; b < 700; ++b)
        {
            juce::MidiBuffer m = feed;   // what went out comes back in
            const int c = b / 60;
            if (c < 5 && b % 60 == 2) m.addEvent (juce::MidiMessage::noteOn (1, keys[c], (juce::uint8) 127), 20);
            if (c < 5 && b % 60 == 50) m.addEvent (juce::MidiMessage::noteOff (1, keys[c]), 40);
            lp.processBlock (buf, m);
            for (const auto meta : m)
            {
                const auto e = meta.getMessage();
                if (e.isNoteOn()) on[e.getChannel() - 1][e.getNoteNumber()] = 1;
                else if (e.isNoteOff()) on[e.getChannel() - 1][e.getNoteNumber()] = 0;
                else if (e.isAllNotesOff()) for (int n = 0; n < 128; ++n) on[e.getChannel() - 1][n] = 0;
            }
            feed = m;
        }
        int ringing = 0, ringBass = 0;
        for (int ch = 0; ch < 16; ++ch) for (int v : on[ch]) { if (variant == 2 && ch == 1) ringBass += v; else ringing += v; }
        std::printf ("loop + HOLD (variant %d): loop caught %u time(s), %d notes still ringing after letting go\n", variant, lp.loopEvents.load(), ringing);
        CHECK (ringing == 0, "loop + HOLD variant %d: %d notes left ringing", variant, ringing);
        if (variant == 2) CHECK (ringBass == 1, "RING bass should keep exactly its last note until the next key (%d)", ringBass);
    }

    // 7b3. only the drums come back in (FL port / Patcher routing): the chord you're holding must never be cut,
    //      not even when the band starts again after a pause
    {
        std::unique_ptr<juce::AudioProcessor> db (createPluginFilter());
        auto& dp = dynamic_cast<VesperProcessor&> (*db);
        dp.setPlayConfigDetails (0, 2, 48000.0, 512);
        dp.prepareToPlay (48000.0, 512);
        dp.applyBandGenre (Trap);
        for (int t2 = 0; t2 < numBandParts; ++t2) dp.setTrackValue (t2, TpOn, 1.0f);
        juce::MidiBuffer feed;
        juce::AudioBuffer<float> buf (2, 512);
        int cutWhileHeld = 0, drumsBack = 0, chordOns = 0;
        bool held = false;
        for (int b = 0; b < 1300; ++b)
        {
            juce::MidiBuffer m;
            for (const auto meta : feed)   // only channel 10 comes back
                if (meta.getMessage().getChannel() == 10) { m.addEvent (meta.getMessage(), meta.samplePosition); ++drumsBack; }
            // hold a chord, let go, wait (the guard runs out), hold another
            if (b == 2 || b == 800) { m.addEvent (juce::MidiMessage::noteOn (1, b == 2 ? 60 : 67, (juce::uint8) 100), 10); held = true; }
            if (b == 300 || b == 1200) { m.addEvent (juce::MidiMessage::noteOff (1, b == 300 ? 60 : 67), 10); }
            dp.processBlock (buf, m);
            for (const auto meta : m)
            {
                const auto e = meta.getMessage();
                if (e.getChannel() != 1) continue;
                if (e.isNoteOn()) ++chordOns;
                if (held && (e.isNoteOff() || e.isAllNotesOff()) && b != 300 && b != 1200 && b != 2 && b != 800) ++cutWhileHeld;
            }
            if (b == 300 || b == 1200) held = false;
            feed = m;
        }
        std::printf ("drums coming back: %d drum notes fed back, %d chord notes played, %d cut while held\n", drumsBack, chordOns, cutWhileHeld);
        CHECK (drumsBack > 20 && chordOns > 0 && cutWhileHeld == 0, "drum notes coming back cut the held chord %d times", cutWhileHeld);
        CHECK (dp.loopEvents.load() == 0, "drums coming back alone shouldn't light the MIDI LOOP warning");
    }

    // 7d. SMOOTH with VARY off: the same key again plays exactly the same chord, and a long progression
    //     never sinks into a low octave
    for (int smoothOn = 0; smoothOn < 2; ++smoothOn)
    {
        std::unique_ptr<juce::AudioProcessor> sb (createPluginFilter());
        auto& sp = dynamic_cast<VesperProcessor&> (*sb);
        sp.setPlayConfigDetails (0, 2, 48000.0, 512);
        sp.prepareToPlay (48000.0, 512);
        setParam (sp, ids::vary, 0.0f);
        setParam (sp, ids::smooth, smoothOn ? 1.0f : 0.0f);
        juce::AudioBuffer<float> buf (2, 512);
        auto press = [&] (int key)
        {
            std::set<int> ons;
            for (int k = 0; k < 8; ++k)
            {
                juce::MidiBuffer m = k == 0 ? note (key, true) : (k == 4 ? note (key, false) : juce::MidiBuffer());
                sp.processBlock (buf, m);
                for (const auto meta : m)
                    if (meta.getMessage().isNoteOn() && meta.getMessage().getChannel() == 1) ons.insert (meta.getMessage().getNoteNumber());
            }
            return std::vector<int> (ons.begin(), ons.end());
        };
        static const int prog[7] = { 60, 65, 67, 62, 69, 64, 71 };
        for (int k : prog) press (k);
        const auto first = press (60);
        int changed = 0;
        for (int i = 0; i < 8; ++i) if (press (60) != first) ++changed;
        CHECK (! first.empty() && changed == 0, "SMOOTH %s: hitting the same key changed the chord %d of 8 times", smoothOn ? "on" : "off", changed);
        double lo = 1e9, hi = -1e9;
        for (int round = 0; round < 12; ++round)
            for (int k : prog)
            {
                const auto n = press (k);
                if (n.empty()) continue;
                double mean = 0;
                for (int x : n) mean += x;
                mean /= (double) n.size();
                lo = std::min (lo, mean); hi = std::max (hi, mean);
            }
        std::printf ("SMOOTH %s: chord centres stay between %.1f and %.1f over 84 chords\n", smoothOn ? "on" : "off", lo, hi);
        CHECK (hi - lo <= 14.0, "SMOOTH %s: chords wandered %.1f semitones", smoothOn ? "on" : "off", hi - lo);
    }

    // 7e. SOUND slots: a real VST3 instrument played inside VESPER
    {
        const juce::File synth (VESPER_TESTSYNTH);
        CHECK (synth.exists(), "the test instrument should be built (%s)", synth.getFullPathName().toRawUTF8());
        std::unique_ptr<juce::AudioProcessor> hb (createPluginFilter());
        auto& hp = dynamic_cast<VesperProcessor&> (*hb);
        {   // FL switches every output on (stereo)
            auto lay = hp.getBusesLayout();
            for (auto& b : lay.outputBuses) b = juce::AudioChannelSet::stereo();
            hp.setBusesLayout (lay);
        }
        hp.setRateAndBufferSizeDetails (48000.0, 512);
        hp.prepareToPlay (48000.0, 512);
        CHECK (hp.getBusCount (false) == 17 && hp.getTotalNumOutputChannels() == 34, "17 stereo outputs (main, chords, 15 tracks): %d / %d",
               hp.getBusCount (false), hp.getTotalNumOutputChannels());
        juce::String err;
        const bool ok = hp.rack.load (InstrumentRack::chordSlot, synth, err);
        CHECK (ok && hp.rack.name (InstrumentRack::chordSlot) == "VESPER TEST SYNTH", "load an instrument for the chords: %s", err.toRawUTF8());
        juce::AudioBuffer<float> buf (hp.getTotalNumOutputChannels(), 512);
        auto run = [&] (juce::MidiBuffer m, int& chordOutNotes, float& mainLevel, float& chordsLevel)
        {
            hp.processBlock (buf, m);
            for (const auto meta : m) if (meta.getMessage().isNoteOn() && meta.getMessage().getChannel() == 1) ++chordOutNotes;
            mainLevel = std::max (mainLevel, hp.getBusBuffer (buf, false, 0).getMagnitude (0, 512));
            chordsLevel = std::max (chordsLevel, hp.getBusBuffer (buf, false, 1).getMagnitude (0, 512));
        };
        int outNotes = 0; float mainLv = 0, chordLv = 0;
        run (note (60, true), outNotes, mainLv, chordLv);
        for (int b = 0; b < 6; ++b) run (juce::MidiBuffer(), outNotes, mainLv, chordLv);
        run (note (60, false), outNotes, mainLv, chordLv);
        std::printf ("SOUND slot: chord through the instrument: main %.3f, chords out %.3f, MIDI notes still sent %d\n", mainLv, chordLv, outNotes);
        CHECK (mainLv > 0.01f && chordLv < 1e-6f && outNotes == 0, "the chord plays inside VESPER (main %.3f) and isn't sent out as MIDI too (%d)", mainLv, outNotes);

        // its own output
        hp.rack.ownOutput[(size_t) InstrumentRack::chordSlot].store (1);
        outNotes = 0; mainLv = 0; chordLv = 0;
        run (note (62, true), outNotes, mainLv, chordLv);
        for (int b = 0; b < 6; ++b) run (juce::MidiBuffer(), outNotes, mainLv, chordLv);
        run (note (62, false), outNotes, mainLv, chordLv);
        CHECK (chordLv > 0.01f && mainLv < 1e-6f, "own output: the chords play on CHORDS OUT only (main %.3f, chords %.3f)", mainLv, chordLv);
        for (int b = 0; b < 30; ++b) { juce::MidiBuffer m; hp.processBlock (buf, m); }   // let it go quiet

        // the drums track plays the same instrument; its notes leave the MIDI out, the other tracks' don't
        hp.rack.ownOutput[(size_t) InstrumentRack::chordSlot].store (0);
        hp.rack.unload (InstrumentRack::chordSlot);
        int drumTrack = -1;
        for (int t2 = 0; t2 < hp.numTracks.load(); ++t2) if (hp.trackType (t2) == BDrums) drumTrack = t2;
        CHECK (drumTrack >= 0, "a drums track");
        hp.rack.load (InstrumentRack::trackSlot (drumTrack), synth, err);
        setParam (hp, ids::track (drumTrack, "On").toRawUTF8(), 1.0f);
        int ch10 = 0, ch1 = 0; float lv = 0;
        for (int b = 0; b < 400; ++b)
        {
            juce::MidiBuffer m = b == 1 ? note (60, true) : (b == 380 ? note (60, false) : juce::MidiBuffer());
            hp.processBlock (buf, m);
            for (const auto meta : m)
                if (meta.getMessage().isNoteOn()) { if (meta.getMessage().getChannel() == 10) ++ch10; if (meta.getMessage().getChannel() == 1) ++ch1; }
            lv = std::max (lv, buf.getMagnitude (0, 0, 512));
        }
        std::printf ("SOUND slot on the drums track: drum notes still sent %d, chord notes sent %d, level %.3f\n", ch10, ch1, lv);
        CHECK (ch10 == 0 && ch1 > 0 && lv > 0.01f, "drums play inside VESPER (sent %d), chords still go out as MIDI (%d)", ch10, ch1);

        // saved with the project: instrument, its own settings, where it plays, the track names
        if (auto* gp = hp.rack.loaded (InstrumentRack::trackSlot (drumTrack)) ? (juce::AudioProcessorParameter*) nullptr : nullptr) (void) gp;
        hp.rack.ownOutput[(size_t) InstrumentRack::trackSlot (drumTrack)].store (1);
        hp.setTrackName (0, "Omnisphere - Warm Pad");
        juce::MemoryBlock st;
        hp.getStateInformation (st);
        std::unique_ptr<juce::AudioProcessor> hb2 (createPluginFilter());
        auto& hp2 = dynamic_cast<VesperProcessor&> (*hb2);
        hp2.setStateInformation (st.getData(), (int) st.getSize());
        CHECK (hp2.rack.loaded (InstrumentRack::trackSlot (drumTrack)) && hp2.rack.ownOutput[(size_t) InstrumentRack::trackSlot (drumTrack)].load() == 1
               && ! hp2.rack.loaded (InstrumentRack::chordSlot), "the instrument comes back with the project");
        CHECK (hp2.trackName (0) == "Omnisphere - Warm Pad", "track names come back with the project");
        const int ch0 = (int) hp2.trackValue (0, TpCh);
        setParam (hp2, ids::track (0, "On").toRawUTF8(), 1.0f);
        CHECK (hp2.channelName (ch0).contains ("Omnisphere - Warm Pad"), "MIDI exports use the track name (%s)", hp2.channelName (ch0).toRawUTF8());

        // removing a track: the ones below move up with their name and SOUND
        hp2.setTrackName (1, "Analog Lab - Bass");
        hp2.removeTrack (0);
        CHECK (hp2.trackName (0) == "Analog Lab - Bass", "names move up when a track is removed (%s)", hp2.trackName (0).toRawUTF8());
        CHECK (hp2.rack.loaded (InstrumentRack::trackSlot (drumTrack - 1)) && ! hp2.rack.loaded (InstrumentRack::trackSlot (drumTrack)),
               "the SOUND moves up with its track");

        // a saved instrument that's gone shows as MISSING instead of breaking the project
        juce::XmlElement fake ("SOUNDS");
        auto* e = fake.createNewChildElement ("SLOT");
        e->setAttribute ("index", 3); e->setAttribute ("name", "Omnisphere"); e->setAttribute ("file", "/nowhere/Omnisphere.vst3");
        hp2.rack.fromXml (fake);
        CHECK (! hp2.rack.loaded (3) && hp2.rack.missing (3) == "Omnisphere", "a missing instrument is remembered by name");
        std::printf ("SOUND slots: instruments found on this computer: %d\n", InstrumentRack::installedInstruments().size());
    }

    // 7c. no loop: two fast chords at the same velocity both still play
    {
        std::unique_ptr<juce::AudioProcessor> nb (createPluginFilter());
        auto& np = dynamic_cast<VesperProcessor&> (*nb);
        np.setPlayConfigDetails (0, 2, 48000.0, 512);
        np.prepareToPlay (48000.0, 512);
        setParam (np, ids::humanize, 0.0f);
        run (np, {});
        const auto before = np.playedCounter();
        run (np, note (60, true));
        run (np, note (64, true));   // E on the 7ths row, its note 64 was just sent by the Cmaj7 above
        run (np, note (67, true));
        CHECK (np.playedCounter() - before == 3, "fast playing without a loop must not be filtered (%u chords)", np.playedCounter() - before);
        CHECK (np.loopEvents.load() == 0, "no loop should be reported in normal playing");
        // stabbing the same chord 16 times, 8th notes at 120 bpm, same velocity every time
        const auto before2 = np.playedCounter();
        for (int k = 0; k < 16; ++k)
        {
            run (np, note (64, true));
            for (int b = 0; b < 10; ++b) run (np, {});
            run (np, note (64, false));
            for (int b = 0; b < 10; ++b) run (np, {});
        }
        CHECK (np.playedCounter() - before2 == 16, "repeated stabs must all play (%u of 16)", np.playedCounter() - before2);
        CHECK (np.loopEvents.load() == 0, "stabs must not look like a loop");
    }

    // 7d. AUTO REC follows FL's record button and keeps the song position
    {
        std::unique_ptr<juce::AudioProcessor> ab (createPluginFilter());
        auto& ap = dynamic_cast<VesperProcessor&> (*ab);
        ap.setPlayConfigDetails (0, 2, 48000.0, 512);
        ap.prepareToPlay (48000.0, 512);
        FakeHead head;
        ap.setPlayHead (&head);
        // an old manual take that should be replaced
        ap.recording = true;
        run (ap, note (60, true));
        run (ap, note (60, false));
        ap.recording = false;
        const double beatsPerBlock = 512.0 / (48000.0 * 60.0 / 120.0);
        auto step = [&] (juce::MidiBuffer m) { run (ap, m); head.ppq += beatsPerBlock; };
        head.playing = head.rec = true;
        head.ppq = 0;
        step ({});
        CHECK (ap.recording.load(), "AUTO REC should start when FL records");
        while (head.ppq < 8.0) step ({});            // bar 3
        const double chordAt = head.ppq;
        step (note (64, true));
        for (int b = 0; b < 40; ++b) step ({});
        step (note (64, false));
        head.rec = false;
        step ({});
        CHECK (! ap.recording.load(), "AUTO REC should stop when FL stops recording");
        CHECK (ap.takeSynced.load(), "take should be marked as synced to the song");
        const auto f = ap.exportRecording();
        juce::FileInputStream in (f);
        juce::MidiFile mf;
        mf.readFrom (in);
        double firstTick = -1;
        int ons = 0;
        for (int tr = 0; tr < mf.getNumTracks(); ++tr)
            for (auto* e : *mf.getTrack (tr))
                if (e->message.isNoteOn()) { if (firstTick < 0 || e->message.getTimeStamp() < firstTick) firstTick = e->message.getTimeStamp(); ++ons; }
        std::printf ("auto-rec take: %d note-ons, first at tick %.0f (chord played at beat %.3f = tick %.0f)\n", ons, firstTick, chordAt, chordAt * 960.0);
        CHECK (std::abs (firstTick - chordAt * 960.0) < 30.0, "synced take should keep the song position");
        CHECK (ons >= 3 && ons <= 6, "only the new take should be in the file (%d)", ons);
        ap.setPlayHead (nullptr);
    }

    // 7e. PLAYING STYLES: every style, synced to a fake FL transport at 120 bpm
    {
        struct Ev { int64_t t; juce::MidiMessage m; };
        auto session = [&] (std::function<void (VesperProcessor&)> setup, std::function<void (VesperProcessor&, int, juce::MidiBuffer&)> perBlock,
                            int blocks, std::vector<Ev>& evs, bool playingHost = true)
        {
            std::unique_ptr<juce::AudioProcessor> b (createPluginFilter());
            auto& sp = dynamic_cast<VesperProcessor&> (*b);
            sp.setPlayConfigDetails (0, 2, 48000.0, 512);
            sp.prepareToPlay (48000.0, 512);
            FakeHead head;
            head.playing = playingHost;
            sp.setPlayHead (&head);
            setParam (sp, ids::humanize, 0.0f);
            setup (sp);
            for (int blk = 0; blk < blocks; ++blk)
            {
                juce::MidiBuffer m;
                perBlock (sp, blk, m);
                juce::AudioBuffer<float> buf (2, 512);
                sp.processBlock (buf, m);
                for (const auto meta : m) evs.push_back ({ (int64_t) blk * 512 + meta.samplePosition, meta.getMessage() });
                head.ppq += 512.0 / 24000.0;
            }
            sp.setPlayHead (nullptr);
        };
        auto stuck = [] (const std::vector<Ev>& evs)
        {
            int on[16][128] = {};
            for (auto& e : evs)
            {
                if (e.m.isNoteOn()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 1;
                else if (e.m.isNoteOff()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 0;
            }
            int n = 0;
            for (auto& ch : on) for (int v : ch) n += v;
            return n;
        };
        auto holdChord = [] (int key, int pressAt, int releaseAt)
        {
            return [key, pressAt, releaseAt] (VesperProcessor&, int blk, juce::MidiBuffer& m)
            {
                if (blk == pressAt) m.addEvent (juce::MidiMessage::noteOn (1, key, (juce::uint8) 100), 100);
                if (blk == releaseAt) m.addEvent (juce::MidiMessage::noteOff (1, key), 100);
            };
        };

        int okStyles = 0;
        for (int r = 0; r < numRhythms; ++r)
        {
            std::vector<Ev> evs;
            session ([r] (VesperProcessor& sp) { setParam (sp, rhythmInfo (r).id, 1.0f); }, holdChord (60, 10, 200), 260, evs);
            int ons = 0;
            std::vector<int64_t> hitTimes;
            for (auto& e : evs)
                if (e.m.isNoteOn())
                {
                    ++ons;
                    if (hitTimes.empty() || e.t - hitTimes.back() > 50) hitTimes.push_back (e.t);
                }
            const int left = stuck (evs);
            CHECK (ons >= 3, "%s: only %d notes", rhythmInfo (r).name, ons);
            CHECK (left == 0, "%s: %d stuck notes after release", rhythmInfo (r).name, left);
            // after the first hit, every hit sits on the style's grid (straight styles)
            const double stepSamples = rateBeats (rhythmDefaultRate (r)) * 24000.0;
            int offGrid = 0;
            for (size_t i = 1; i < hitTimes.size(); ++i)
            {
                const double rel = (double) hitTimes[i] / stepSamples;
                if (std::abs (rel - std::round (rel)) * stepSamples > 3.0) ++offGrid;
            }
            CHECK (offGrid == 0, "%s: %d hits off the grid", rhythmInfo (r).name, offGrid);
            if (ons >= 3 && left == 0 && offGrid == 0) ++okStyles;
        }
        std::printf ("playing styles: %d of %d play in time with no stuck notes\n", okStyles, (int) numRhythms);

        // pulse at 1/8 for two beats holds exactly 4 hits; SOFT is quieter; STACCATO is shorter
        auto pulseStats = [&] (std::function<void (VesperProcessor&)> extra, int& hits, double& avgVel, double& avgLen)
        {
            std::vector<Ev> evs;
            session ([&extra] (VesperProcessor& sp) { setParam (sp, rhythmInfo (RPulse).id, 1.0f); extra (sp); },
                     holdChord (60, 0, 94), 140, evs);
            std::map<int, int64_t> start;
            hits = 0; avgVel = 0; avgLen = 0;
            int lens = 0, ons = 0;
            int64_t lastHit = -1000;
            for (auto& e : evs)
            {
                const int n = e.m.getNoteNumber();
                if (e.m.isNoteOn()) { start[n] = e.t; avgVel += e.m.getVelocity(); ++ons; if (e.t - lastHit > 50) { ++hits; lastHit = e.t; } }
                else if (e.m.isNoteOff() && start.count (n)) { avgLen += (double) (e.t - start[n]); ++lens; start.erase (n); }
            }
            avgVel /= juce::jmax (1, ons);
            avgLen /= juce::jmax (1, lens);
        };
        int h1, h2, h3; double v1, v2, v3, l1, l2, l3;
        pulseStats ([] (VesperProcessor&) {}, h1, v1, l1);
        pulseStats ([] (VesperProcessor& sp) { setParam (sp, feelInfo (FSoft).id, 1.0f); }, h2, v2, l2);
        pulseStats ([] (VesperProcessor& sp) { setParam (sp, feelInfo (FStaccato).id, 1.0f); }, h3, v3, l3);
        std::printf ("pulse: %d hits in 2 beats, vel %.0f (soft %.0f), length %.0f samples (staccato %.0f)\n", h1, v1, v2, l1, l3);
        CHECK (h1 == 4 || h1 == 5, "pulse at 1/8 should hit 4 times in 2 beats (%d)", h1);
        CHECK (v2 < v1 - 15, "SOFT should be clearly quieter");
        CHECK (l3 < l1 * 0.7, "STACCATO should be shorter");

        // SWING moves the off-beats later
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { setParam (sp, rhythmInfo (RPulse).id, 1.0f); setParam (sp, timingInfo (TSwing).id, 1.0f); },
                     holdChord (60, 0, 94), 120, evs);
            std::vector<int64_t> hits;
            for (auto& e : evs) if (e.m.isNoteOn() && (hits.empty() || e.t - hits.back() > 50)) hits.push_back (e.t);
            CHECK (hits.size() >= 3 && (hits[1] - hits[0]) > (hits[2] - hits[1]), "SWING should make the off-beat late");
        }

        // upper extension: hold a chord, press EXT (on-screen pad), notes appear above, release, they stop
        {
            std::vector<Ev> evs;
            int chordTop = 0;
            session ([] (VesperProcessor&) {},
                     [] (VesperProcessor& sp, int blk, juce::MidiBuffer& m)
                     {
                         if (blk == 2) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                         if (blk == 20) sp.uiExt (true);
                         if (blk == 60) sp.uiExt (false);
                         if (blk == 80) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                     }, 100, evs);
            std::vector<int> chord, ext;
            for (auto& e : evs)
                if (e.m.isNoteOn()) (e.t < 20 * 512 ? chord : ext).push_back (e.m.getNoteNumber());
            for (int n : chord) chordTop = juce::jmax (chordTop, n);
            bool above = ! ext.empty();
            for (int n : ext) above = above && n > chordTop;
            CHECK (above, "EXT should add notes above the chord (%d ext notes)", (int) ext.size());
            int extOffs = 0;
            for (auto& e : evs) if (e.m.isNoteOff() && e.t >= 60 * 512 && e.t < 61 * 512) ++extOffs;
            CHECK (extOffs == (int) ext.size(), "releasing EXT should stop just the extension (%d of %d)", extOffs, (int) ext.size());
            CHECK (stuck (evs) == 0, "EXT left stuck notes");
            std::printf ("EXT over Cmaj7: ");
            for (int n : ext) std::printf ("%s ", midiName (n, true).c_str());
            std::printf ("\n");
        }

        // EXT as a waterfall: cascades down in time
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { setParam (sp, ids::extMode, (float) ExtWaterfall); },
                     [] (VesperProcessor& sp, int blk, juce::MidiBuffer& m)
                     {
                         if (blk == 2) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                         if (blk == 20) sp.uiExt (true);
                         if (blk == 90) sp.uiExt (false);
                         if (blk == 100) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                     }, 120, evs);
            std::vector<int> cascade;
            for (auto& e : evs) if (e.m.isNoteOn() && e.t >= 20 * 512) cascade.push_back (e.m.getNoteNumber());
            bool falling = cascade.size() >= 4;
            for (size_t i = 1; i < cascade.size(); ++i) falling = falling && cascade[i] < cascade[i - 1];
            CHECK (falling, "EXT waterfall should fall note by note (%d notes)", (int) cascade.size());
            CHECK (stuck (evs) == 0, "EXT waterfall left stuck notes");
            std::printf ("EXT waterfall: ");
            for (int n : cascade) std::printf ("%s ", midiName (n, true).c_str());
            std::printf ("\n");
        }

        // STYLES ON EXT: the extension joins an arpeggio
        {
            std::vector<Ev> evs;
            int maxNote = 0, maxBefore = 0;
            session ([] (VesperProcessor& sp) { setParam (sp, rhythmInfo (RArpUp).id, 1.0f); setParam (sp, ids::extStyles, 1.0f); },
                     [] (VesperProcessor& sp, int blk, juce::MidiBuffer& m)
                     {
                         if (blk == 2) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                         if (blk == 60) sp.uiExt (true);
                         if (blk == 140) sp.uiExt (false);
                         if (blk == 150) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                     }, 170, evs);
            for (auto& e : evs)
                if (e.m.isNoteOn()) { if (e.t < 60 * 512) maxBefore = juce::jmax (maxBefore, e.m.getNoteNumber()); else if (e.t < 140 * 512) maxNote = juce::jmax (maxNote, e.m.getNoteNumber()); }
            CHECK (maxNote > maxBefore, "with STYLES ON EXT the arpeggio should climb into the extension");
            CHECK (stuck (evs) == 0, "STYLES ON EXT left stuck notes");
        }

        // learn a controller key as the EXT button, then use it
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { sp.learnArmed.store (true); },
                     [] (VesperProcessor&, int blk, juce::MidiBuffer& m)
                     {
                         if (blk == 1) m.addEvent (juce::MidiMessage::noteOn (1, 120, (juce::uint8) 100), 0);
                         if (blk == 2) m.addEvent (juce::MidiMessage::noteOff (1, 120), 0);
                         if (blk == 5) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                         if (blk == 10) m.addEvent (juce::MidiMessage::noteOn (1, 120, (juce::uint8) 100), 0);
                         if (blk == 30) m.addEvent (juce::MidiMessage::noteOff (1, 120), 0);
                         if (blk == 40) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                     }, 50, evs);
            int beforeExt = 0, withExt = 0;
            for (auto& e : evs) if (e.m.isNoteOn()) (e.t < 10 * 512 ? beforeExt : withExt) += 1;
            CHECK (beforeExt >= 3 && withExt >= 1, "learned key should trigger the extension (%d / %d)", beforeExt, withExt);
            CHECK (stuck (evs) == 0, "learned EXT left stuck notes");
        }

        // SWELL sends rising expression
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { setParam (sp, feelInfo (FSwell).id, 1.0f); }, holdChord (60, 2, 120), 130, evs);
            int first = -1, last = -1;
            for (auto& e : evs) if (e.m.isController() && e.m.getControllerNumber() == 11 && e.m.getChannel() == 1) { if (first < 0) first = e.m.getControllerValue(); last = e.m.getControllerValue(); }
            CHECK (first >= 0 && last > first + 60, "SWELL should ramp CC11 up (%d -> %d)", first, last);
        }

        // transport stopped: styles still run on VESPER's own clock
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { setParam (sp, rhythmInfo (RArpUpDown).id, 1.0f); }, holdChord (60, 3, 100), 120, evs, false);
            int ons = 0;
            for (auto& e : evs) if (e.m.isNoteOn()) ++ons;
            CHECK (ons >= 8 && stuck (evs) == 0, "styles should play with FL stopped (%d notes)", ons);
        }
    }

    // 7f. BAND: in time with FL, on its own channels, follows the chords, stops cleanly, links to copies
    {
        struct Ev { int64_t t; juce::MidiMessage m; };
        struct Rig
        {
            std::unique_ptr<juce::AudioProcessor> base { createPluginFilter() };
            VesperProcessor& p = dynamic_cast<VesperProcessor&> (*base);
            FakeHead head;
            std::vector<Ev> evs;
            Rig (int genre, bool playing)
            {
                p.setPlayConfigDetails (0, 2, 48000.0, 512);
                p.prepareToPlay (48000.0, 512);
                head.playing = playing;
                p.setPlayHead (&head);
                setParam (p, ids::humanize, 0.0f);
                p.applyBandGenre (genre);
            }
            ~Rig() { p.setPlayHead (nullptr); }
            void block (int blk, juce::MidiBuffer m)
            {
                juce::AudioBuffer<float> buf (2, 512);
                p.processBlock (buf, m);
                for (const auto meta : m) evs.push_back ({ (int64_t) blk * 512 + meta.samplePosition, meta.getMessage() });
                head.ppq += 512.0 / 24000.0;
            }
        };
        auto stuckNotes = [] (const std::vector<Ev>& evs)
        {
            int on[16][128] = {};
            for (auto& e : evs)
            {
                if (e.m.isNoteOn()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 1;
                else if (e.m.isNoteOff()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 0;
            }
            int n = 0;
            for (auto& ch : on) for (int v : ch) n += v;
            return n;
        };
        auto at = [] (int key, bool on, int pos = 0)
        {
            juce::MidiBuffer m;
            m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), pos);
            return m;
        };
        constexpr int beat = 24000;   // samples per beat at 120 bpm / 48 kHz

        // A. FL playing: drums on the grid, parts on their channels, a chord change moves the bass
        {
            Rig r (House, true);
            r.p.recording = true;
            for (int blk = 0; blk < 800; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                auto event = [&] (int64_t sample, int key, bool on) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                event (1124, 60, true);                 // Cmaj7, a hair after beat 1
                event (8 * beat, 69, true);             // Am7 on bar 3
                event (8 * beat + 10, 60, false);
                event (16 * beat, 69, false);           // let go on bar 5
                r.block (blk, m);
            }
            int kicks = 0, offGrid = 0, bassC = 0, bassA = 0, mel = 0, wrongCh = 0, keysCh2 = 0;
            for (auto& e : r.evs)
            {
                if (! e.m.isNoteOn()) continue;
                const int ch = e.m.getChannel(), n = e.m.getNoteNumber();
                if (ch == 10 && n == Band::Kick) { ++kicks; if (e.t > 2000 && e.t % beat != 0 && e.t % (16 * beat) < 15 * beat) ++offGrid; }   // fills live in the last beat of a phrase
                if (ch == 2) { if (e.t < 8 * beat && n % 12 == 0) ++bassC; if (e.t >= 8 * beat && e.t < 16 * beat && n % 12 == 9) ++bassA; }
                if (ch == 2 && e.t >= 8 * beat && e.t < 16 * beat && n % 12 != 9 && n % 12 != 4 && n % 12 != 0) ++keysCh2;
                if (ch == 3) ++mel;
                if (ch != 1 && ch != 2 && ch != 3 && ch != 10) ++wrongCh;
            }
            std::printf ("band (house): %d kicks, %d bass on C, %d bass on A, %d melody notes\n", kicks, bassC, bassA, mel);
            CHECK (kicks >= 15 && offGrid == 0, "house kicks should land on the beat (%d kicks, %d off grid)", kicks, offGrid);
            CHECK (bassC > 0 && bassA > 0 && keysCh2 == 0, "bass should follow the chords on channel 2 (C %d, A %d, other %d)", bassC, bassA, keysCh2);
            CHECK (mel > 4 && wrongCh == 0, "melody on channel 3 and nothing on stray channels (%d, %d)", mel, wrongCh);
            // the take: one named track per part, every part as its own file
            {
                const auto f = r.p.exportRecording();
                juce::FileInputStream in (f);
                juce::MidiFile mf;
                CHECK (in.openedOk() && mf.readFrom (in), "take file should read back");
                juce::StringArray names;
                int mixed = 0, overlaps = 0, total = 0;
                for (int tr = 1; tr < mf.getNumTracks(); ++tr)
                {
                    int ch = 0;
                    bool on[128] = {};
                    for (auto* e : *mf.getTrack (tr))
                    {
                        const auto& m = e->message;
                        if (m.isTrackNameEvent()) names.add (m.getTextFromTextMetaEvent());
                        if (! (m.isNoteOn() || m.isNoteOff())) continue;
                        if (ch == 0) ch = m.getChannel();
                        if (m.getChannel() != ch) ++mixed;
                        if (m.isNoteOn()) { if (on[m.getNoteNumber()]) ++overlaps; on[m.getNoteNumber()] = true; ++total; }
                        else on[m.getNoteNumber()] = false;
                    }
                }
                std::printf ("take file: %d tracks (%s), %d notes\n", mf.getNumTracks(), names.joinIntoString (", ").toRawUTF8(), total);
                CHECK (mf.getNumTracks() == 5 && names.contains ("Chords") && names.contains ("Bass") && names.contains ("Melody") && names.contains ("Drums"),
                       "take should have a track per part");
                CHECK (mixed == 0 && overlaps == 0 && total > 50, "tracks should be clean (%d mixed, %d overlapping)", mixed, overlaps);
                const auto dir = r.p.exportPartsFolder();
                const auto files = dir.findChildFiles (juce::File::findFiles, false, "*.mid");
                CHECK (files.size() == 5, "SAVE PARTS should write 4 parts + all parts (%d)", files.size());
                dir.deleteRecursively();
            }
            int late = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn() && e.t > 16 * beat + beat / 2) ++late;
            CHECK (late == 0 && stuckNotes (r.evs) == 0 && ! r.p.bandPlaying.load(), "band should stop cleanly after you let go (%d late, %d stuck)", late, stuckNotes (r.evs));
        }

        // B. a chord that lands just after a band step still makes that step
        {
            Rig r (House, true);
            const int64_t press = 8 * beat + 1200;   // 25 ms late
            for (int blk = 0; blk < 420; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                if (blk == 0) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                if (press >= t0 && press < t0 + 512) m.addEvent (juce::MidiMessage::noteOn (1, 65, (juce::uint8) 100), (int) (press - t0));
                r.block (blk, m);
            }
            int64_t firstF = -1;
            for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 2 && e.t >= press && e.m.getNoteNumber() % 12 == 5) { firstF = e.t; break; }
            CHECK (firstF >= press && firstF < press + 600, "bass should catch a slightly late chord right away (%lld after)", (long long) (firstF - press));
        }

        // C. FL stopped: your first chord is bar 1, the band starts right there
        {
            Rig r (House, false);
            const int64_t press = 5 * 512 + 200;
            for (int blk = 0; blk < 200; ++blk) r.block (blk, blk == 5 ? at (60, true, 200) : juce::MidiBuffer());
            int64_t firstKick = -1;
            for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 10 && e.m.getNoteNumber() == Band::Kick) { firstKick = e.t; break; }
            CHECK (firstKick == press, "free-running band should start on the chord (kick at %lld, chord at %lld)", (long long) firstKick, (long long) press);
            int kicks = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 10 && e.m.getNoteNumber() == Band::Kick) { ++kicks; CHECK ((e.t - press) % beat == 0, "free kicks off the beat"); }
            CHECK (kicks >= 3, "free-running kicks (%d)", kicks);
        }

        // D0. a long take with FL playing: the drums play the same amount every bar (no flood after the
        //     first phrase), with FL running straight on and with FL looping 4 bars
        for (int g : { (int) Trap, (int) Reggaeton })
            for (int loop4 = 0; loop4 < 5; ++loop4)   // 2 = everything VESPER sends comes back in (FL port loop), 3 = FL stopped,
            {                                         // 4 = MELODY on the chords' channel (1)
                Rig r (g, loop4 != 3);
                if (loop4 == 4) r.p.setTrackValue (0, TpCh, 1.0f);
                juce::MidiBuffer feed;
                for (int part = 0; part < numBandParts; ++part) setParam (r.p, ids::track (part, "On").toRawUTF8(), 1.0f);
                const int blocksPerBar = 96000 / 512;
                for (int blk = 0; blk < blocksPerBar * 20; ++blk)
                {
                    juce::MidiBuffer m;
                    if (loop4 == 2) m = feed;
                    if (blk == 1) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                    const auto before = r.evs.size();
                    r.block (blk, m);
                    if (loop4 == 1 && r.head.ppq >= 16.0) r.head.ppq -= 16.0;   // FL's loop jumps back to bar 1
                    feed.clear();
                    for (size_t k = before; k < r.evs.size(); ++k) feed.addEvent (r.evs[k].m, (int) (r.evs[k].t % 512));
                }
                std::vector<int> perBar (20, 0), chordOffs (20, 0);
                std::set<int> chordNotes;   // the chord you're holding: what the same key plays on channel 1 with the melody elsewhere
                {
                    Rig ref (g, true);
                    for (int part = 0; part < numBandParts; ++part) setParam (ref.p, ids::track (part, "On").toRawUTF8(), 1.0f);
                    for (int blk = 0; blk < 4; ++blk) ref.block (blk, blk == 1 ? at (60, true) : juce::MidiBuffer());
                    for (auto& e : ref.evs) if (e.m.isNoteOn() && e.m.getChannel() == 1) chordNotes.insert (e.m.getNoteNumber());
                }
                for (auto& e : r.evs)
                {
                    const int b = (int) (e.t / 96000);
                    if (b >= 20) continue;
                    if (e.m.isNoteOn() && e.m.getChannel() == 10 && e.m.getVelocity() > 0) ++perBar[(size_t) b];
                    if (e.m.isNoteOff() && e.m.getChannel() == 1 && chordNotes.count (e.m.getNoteNumber())) ++chordOffs[(size_t) b];
                }
                int lo = 1 << 30, hi = 0;
                for (int b = 1; b < 20; ++b) { lo = std::min (lo, perBar[(size_t) b]); hi = std::max (hi, perBar[(size_t) b]); }
                std::printf ("long take %s%s: drum notes per bar", genreShort (g), loop4 == 1 ? " (FL looping 4 bars)" : loop4 == 2 ? " (MIDI fed back)" : loop4 == 3 ? " (FL stopped)" : loop4 == 4 ? " (MELODY on CH 1)" : "");
                for (int b = 0; b < 20; ++b) std::printf (" %d", perBar[(size_t) b]);
                std::printf ("  | chord offs");
                for (int b = 0; b < 20; ++b) std::printf (" %d", chordOffs[(size_t) b]);
                std::printf ("\n");
                CHECK (hi <= lo * 3 + 8, "%s%s: drums flood (%d..%d per bar)", genreShort (g), loop4 ? " looping" : "", lo, hi);
                int cut = 0;
                for (int b = 1; b < 20; ++b) cut += chordOffs[(size_t) b];
                CHECK (cut == 0, "%s%s: the held chord got cut %d times", genreShort (g), loop4 ? " looping" : "", cut);
            }

        // D. NEVER stop mode keeps going after you let go, STOP ends it
        {
            Rig r (Trap, true);
            setParam (r.p, ids::bandStop, 2.0f);
            for (int blk = 0; blk < 400; ++blk)
            {
                juce::MidiBuffer m;
                if (blk == 1) m = at (60, true);
                if (blk == 20) m = at (60, false);
                if (blk == 300) r.p.stopBandFromUi();
                r.block (blk, m);
            }
            int after = 0, afterStop = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn()) { if (e.t > 40 * 512 && e.t < 300 * 512) ++after; if (e.t > 301 * 512) ++afterStop; }
            CHECK (after > 10 && afterStop == 0 && stuckNotes (r.evs) == 0, "NEVER mode should keep playing until STOP (%d, %d, stuck %d)", after, afterStop, stuckNotes (r.evs));
        }

        // E. every genre, every part on: no stuck notes, nothing out of MIDI range
        for (int g = 0; g < numGenres; ++g)
        {
            Rig r (g, true);
            for (int part = 0; part < numBandParts; ++part) setParam (r.p, ids::track (part, "On").toRawUTF8(), 1.0f);
            static const int keys[4] = { 62, 67, 60, 69 };
            for (int blk = 0; blk < 820; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                for (int c = 0; c < 4; ++c)
                {
                    const int64_t on = (int64_t) c * 4 * beat + 300, off = (int64_t) (c + 1) * 4 * beat + 200;
                    if (on >= t0 && on < t0 + 512) m.addEvent (juce::MidiMessage::noteOn (1, keys[c], (juce::uint8) 100), (int) (on - t0));
                    if (off >= t0 && off < t0 + 512) m.addEvent (juce::MidiMessage::noteOff (1, keys[c]), (int) (off - t0));
                }
                r.block (blk, m);
            }
            int ons = 0, chans = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn()) { ++ons; chans |= 1 << (e.m.getChannel() - 1); }
            CHECK (stuckNotes (r.evs) == 0, "%s band: %d stuck notes", genreShort (g), stuckNotes (r.evs));
            CHECK (ons > 100, "%s band: only %d notes", genreShort (g), ons);
            CHECK ((chans & 0x23e) == 0x23e, "%s band: every part should play on its channel (0x%x)", genreShort (g), chans);
        }

        // G. HOLD: a track plays exactly what you press, on its own channel, and lets go with the key
        {
            Rig r (House, true);
            setParam (r.p, ids::track (3, "On").toRawUTF8(), 1.0f);              // strings, channel 5
            setParam (r.p, ids::track (3, "Mode").toRawUTF8(), (float) ModeHold);
            for (int blk = 0; blk < 200; ++blk)
                r.block (blk, blk == 2 ? at (60, true) : (blk == 120 ? at (60, false) : juce::MidiBuffer()));
            Notes chord, held;
            int heldOns = 0;
            for (auto& e : r.evs)
                if (e.m.isNoteOn())
                {
                    if (e.m.getChannel() == 1 && e.t < 3 * 512) chord.add (e.m.getNoteNumber());
                    if (e.m.getChannel() == 5) { held.add (e.m.getNoteNumber()); ++heldOns; }
                }
            chord.unique(); held.unique();
            CHECK (held.sameAs (chord) && heldOns == chord.size(), "HOLD strings should play the chord once, as pressed (%d notes, %d hits, chord %d)", held.size(), heldOns, chord.size());
            int offAt = -1;
            for (auto& e : r.evs) if (e.m.isNoteOff() && e.m.getChannel() == 5) { offAt = (int) (e.t / 512); break; }
            CHECK (offAt == 120 && stuckNotes (r.evs) == 0, "HOLD should let go with the key (block %d)", offAt);
        }

        // H. RING: one hit per key, ringing past the key-up until the next key; FL stopping ends it
        {
            Rig r (House, true);
            setParam (r.p, ids::track (2, "Mode").toRawUTF8(), (float) ModeRing);   // bass, channel 2
            for (int blk = 0; blk < 300; ++blk)
            {
                juce::MidiBuffer m;
                if (blk == 2) m = at (60, true);
                if (blk == 10) m = at (60, false);
                if (blk == 100) m = at (65, true);
                if (blk == 110) m = at (65, false);
                if (blk == 250) r.head.playing = false;
                r.block (blk, m);
            }
            int ons = 0, cOff = -1, fOff = -1;
            for (auto& e : r.evs)
            {
                if (e.m.getChannel() != 2) continue;
                if (e.m.isNoteOn()) ++ons;
                if (e.m.isNoteOff() && e.m.getNoteNumber() % 12 == 0 && cOff < 0) cOff = (int) (e.t / 512);
                if (e.m.isNoteOff() && e.m.getNoteNumber() % 12 == 5 && fOff < 0) fOff = (int) (e.t / 512);
            }
            CHECK (ons == 2 && cOff == 100 && fOff == 250 && stuckNotes (r.evs) == 0,
                   "RING bass: 2 hits, C rings until F (%d), F until FL stops (%d), %d hits", cOff, fOff, ons);
        }

        // I. key strips: the bass sits out on E, VESPER's own chords sit out on D (the band keeps going)
        {
            Rig r (House, true);
            r.p.trackKeys[2].store (1 << 4);
            r.p.chordKeys.store (1 << 2);
            for (int blk = 0; blk < 700; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                auto event = [&] (int64_t sample, int key, bool on) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                event (300, 60, true);   event (4 * beat, 60, false);
                event (4 * beat, 64, true);   event (8 * beat, 64, false);
                event (8 * beat, 62, true);   event (12 * beat, 62, false);
                r.block (blk, m);
            }
            int bassOnC = 0, bassOnE = 0, chordsOnD = 0, drumsOnD = 0, bassOnD = 0;
            for (auto& e : r.evs)
            {
                if (! e.m.isNoteOn()) continue;
                const bool inC = e.t < 4 * beat, inE = e.t >= 4 * beat + 200 && e.t < 8 * beat, inD = e.t >= 8 * beat + 200 && e.t < 12 * beat;
                if (e.m.getChannel() == 2) { if (inC) ++bassOnC; if (inE) ++bassOnE; if (inD) ++bassOnD; }
                if (e.m.getChannel() == 1 && inD) ++chordsOnD;
                if (e.m.getChannel() == 10 && inD) ++drumsOnD;
            }
            CHECK (bassOnC > 0 && bassOnE == 0 && bassOnD > 0, "key strip: bass should sit out on E only (C %d, E %d, D %d)", bassOnC, bassOnE, bassOnD);
            CHECK (chordsOnD == 0 && drumsOnD > 0, "chord key strip: no chords on D but the band plays (chords %d, drums %d)", chordsOnD, drumsOnD);
            CHECK (stuckNotes (r.evs) == 0, "key strips: stuck notes");
        }

        // J. STACK: one note per key in the key's own octave, stacked 3rds in the key, octaves
        {
            Rig r (House, false);
            r.p.apvts.getParameter (ids::bandOn)->setValueNotifyingHost (0.0f);
            auto play = [&] (int key)
            {
                r.evs.clear();
                r.block (0, at (key, true));
                r.block (1, at (key, false));
                Notes n;
                for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 1) n.add (e.m.getNoteNumber());
                n.unique();
                return n;
            };
            setParam (r.p, ids::stack, (float) StackSingle);
            Notes a = play (60), b = play (67), c = play (74);
            CHECK (a.size() == 1 && a[0] == 60 && b.size() == 1 && b[0] == 67 && c.size() == 1 && c[0] == 74,
                   "STACK single: keys should play themselves in C major (%d %d %d)", a.size() ? a[0] : -1, b.size() ? b[0] : -1, c.size() ? c[0] : -1);
            setParam (r.p, ids::stack, (float) Stack3rds);
            setParam (r.p, ids::stackNotes, 1.0f);   // 3 notes
            a = play (62);
            CHECK (a.size() == 3 && a[0] == 62 && a[1] == 65 && a[2] == 69, "STACK 3rds x3 on D should be D F A");
            setParam (r.p, ids::stack, (float) StackOctaves);
            setParam (r.p, ids::stackNotes, 0.0f);
            a = play (60);
            CHECK (a.size() == 2 && a[0] == 60 && a[1] == 72, "STACK octaves on C should be C + C an octave up");
            setParam (r.p, ids::stack, 0.0f);
            a = play (60);
            CHECK (a.size() >= 3, "STACK chord should be back to the whole chord");
        }

        // K. tracks: add one (it gets a new instrument and a free channel), remove one (the rest move up)
        {
            Rig r (House, true);
            CHECK (r.p.numTracks.load() == defaultBandTracks, "6 tracks to start");
            CHECK (r.p.addTrack(), "add a track");
            CHECK (r.p.numTracks.load() == 7 && r.p.trackType (6) == BKeys && (int) r.p.trackValue (6, TpCh) == 7 && r.p.trackValue (6, TpOn) > 0.5f,
                   "new track 7 should be KEYS on channel 7 (type %d ch %d)", r.p.trackType (6), (int) r.p.trackValue (6, TpCh));
            for (int i = 0; i < 20; ++i) r.p.addTrack();
            CHECK (r.p.numTracks.load() == maxBandTracks, "15 tracks at most");
            uint32_t chans = 1;
            for (int t = 0; t < maxBandTracks; ++t) chans |= 1u << ((int) r.p.trackValue (t, TpCh) - 1);
            CHECK (chans == 0xffff, "15 tracks + chords should use all 16 channels (0x%x)", chans);
            for (int t = 0; t < maxBandTracks; ++t) r.p.setTrackValue (t, TpOn, 1.0f);
            for (int blk = 0; blk < 300; ++blk) r.block (blk, blk == 2 ? at (60, true) : (blk == 250 ? at (60, false) : juce::MidiBuffer()));
            uint32_t played = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn()) played |= 1u << (e.m.getChannel() - 1);
            CHECK ((played & 0xffff) == 0xffff, "every channel should play with 15 tracks on (0x%x)", played);
            CHECK (stuckNotes (r.evs) == 0, "15 tracks: stuck notes");
            r.p.setTrackType (7, BDrums);
            CHECK (r.p.trackType (7) == BDrums && (int) std::lround (r.p.trackValue (7, TpMode)) == ModeJam, "retype a track");
            const int ch2 = (int) r.p.trackValue (1, TpCh);
            r.p.removeTrack (0);
            CHECK (r.p.numTracks.load() == 14 && r.p.trackType (0) == BCounter && (int) r.p.trackValue (0, TpCh) == ch2,
                   "removing track 1 should move track 2 up");
            r.p.setAllHold (true);
            CHECK (r.p.allHold(), "ALL HOLD");
            r.p.setAllHold (false);
            CHECK (! r.p.allHold(), "ALL HOLD off");
        }

        // L. a project saved with VESPER 1.5 (six fixed parts) loads into tracks 1-6
        {
            juce::XmlElement old ("PARAMS");
            auto add = [&old] (const juce::String& id, double v) { auto* e = old.createNewChildElement ("PARAM"); e->setAttribute ("id", id); e->setAttribute ("value", v); };
            add ("bBassOn", 1.0); add ("bBassStyle", 7.0); add ("bBassCh", 9.0);
            add ("bDrmOn", 1.0); add ("bDrmStyle", 1.0);
            add ("bMelOn", 0.0); add ("bandRole", 0.0);
            auto* u = old.createNewChildElement ("VESPER_UI");
            u->setAttribute ("seedbBass", "12345");
            juce::MemoryBlock mb;
            juce::AudioProcessor::copyXmlToBinary (old, mb);
            Rig r (Soul, false);
            r.p.addTrack();
            r.p.setTrackType (2, BPad);
            r.p.setStateInformation (mb.getData(), (int) mb.getSize());
            CHECK (r.p.numTracks.load() == 6 && r.p.trackType (2) == BBass && r.p.trackValue (2, TpOn) > 0.5f
                   && (int) r.p.trackValue (2, TpStyle) == 7 && (int) r.p.trackValue (2, TpCh) == 9 && r.p.bandSeed[2].load() == 12345u
                   && r.p.trackType (5) == BDrums && (int) r.p.trackValue (5, TpStyle) == 1,
                   "old project: bass should be track 3 (808, ch 9), drums track 6");
        }

        // M. HOLD stress: real playing (legato overlaps, repeats, fast changes, mode clicks while holding).
        //    Whenever no key is down, nothing may be sounding on a HOLD channel.
        for (int scenario = 0; scenario < 6; ++scenario)
        {
            Rig r (House, true);
            r.p.setAllHold (true);                                   // melody 3, counter 4, bass 2, strings 5, horns 6 -> HOLD
            for (int t = 0; t < numBandParts; ++t) r.p.setTrackValue (t, TpOn, 1.0f);
            if (scenario == 1) r.p.setTrackValue (3, TpCh, 1.0f);   // a HOLD track sharing the chords' channel
            if (scenario == 2) setParam (r.p, ids::hold, 1.0f);       // VESPER's own HOLD too
            if (scenario == 3) setParam (r.p, ids::stack, (float) StackSingle);
            if (scenario == 4) { r.p.setTrackValue (1, TpCh, 5.0f); r.p.setTrackValue (4, TpCh, 5.0f); }   // two HOLD tracks on one channel
            if (scenario == 5) setParam (r.p, rhythmInfo (RArpUpDown).id, 1.0f);   // a playing style on the chords
            juce::Random rnd (1234 + scenario);
            std::map<int64_t, std::vector<std::pair<int, bool>>> plan;   // sample -> (key, down)
            int64_t tcur = 2000;
            int prevKey = -1;
            for (int i = 0; i < 160; ++i)
            {
                const int key = rnd.nextInt (5) == 0 && prevKey >= 0 ? prevKey : 48 + rnd.nextInt (36);
                plan[tcur].push_back ({ key, true });
                const int64_t len = 2000 + rnd.nextInt (30000);
                int64_t next = tcur + len;
                const int style = rnd.nextInt (3);                       // 0 legato overlap, 1 gap, 2 same time
                int64_t release = style == 0 ? next + rnd.nextInt (6000) : (style == 1 ? next - rnd.nextInt (1500) - 1 : next);
                if (key == prevKey) release = std::max<int64_t> (release, tcur + 10);
                plan[release].push_back ({ key, false });
                prevKey = key;
                tcur = next;
            }
            const int64_t end = tcur + 48000;
            std::map<int, int> down;   // key -> times down
            int on[16][128] = {};
            int orphanChecks = 0, orphans = 0;
            const int blocks = (int) (end / 512) + 1;
            for (int blk = 0; blk < blocks; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                for (auto it = plan.lower_bound (t0); it != plan.end() && it->first < t0 + 512; ++it)
                    for (auto& ev : it->second)
                        m.addEvent (ev.second ? juce::MidiMessage::noteOn (1, ev.first, (juce::uint8) (scenario >= 3 ? 127 : 90 + rnd.nextInt (37))) : juce::MidiMessage::noteOff (1, ev.first),
                                    (int) (it->first - t0));
                if (scenario == 0 && blk % 97 == 50) r.p.setTrackValue (3, TpMode, (float) ((blk / 97) % 3));   // click JAM / HOLD / RING while playing
                const size_t before = r.evs.size();
                for (const auto meta : m)
                {
                    const auto mm = meta.getMessage();
                    if (mm.isNoteOn()) ++down[mm.getNoteNumber()];
                    else if (mm.isNoteOff()) down[mm.getNoteNumber()] = 0;
                }
                r.block (blk, m);
                for (size_t i = before; i < r.evs.size(); ++i)
                {
                    const auto& e = r.evs[i].m;
                    if (e.isNoteOn()) on[e.getChannel() - 1][e.getNoteNumber()] = 1;
                    else if (e.isNoteOff()) on[e.getChannel() - 1][e.getNoteNumber()] = 0;
                }
                bool anyDown = false;
                for (auto& d : down) if (d.second > 0) anyDown = true;
                if (! anyDown && scenario != 2 && scenario != 0)
                {
                    ++orphanChecks;
                    int sounding = 0;
                    for (int ch : { 2, 3, 4, 5, 6 }) for (int n = 0; n < 128; ++n) sounding += on[ch - 1][n];
                    if (sounding > 0) { ++orphans; if (orphans < 4) std::printf ("  scenario %d block %d: %d HOLD notes still on with no key down\n", scenario, blk, sounding); }
                }
            }
            if (scenario == 2)
            {
                // VESPER's own HOLD keeps the last chord on purpose: the next chord or PANIC ends it
                r.p.panic();
                r.block (blocks, {});
            }
            std::printf ("HOLD stress %d: %d checks, %d with notes left ringing, %d stuck at the end, loop guard tripped %u times\n", scenario, orphanChecks, orphans, stuckNotes (r.evs), r.p.loopEvents.load());
            CHECK (r.p.loopEvents.load() == 0, "HOLD stress %d: the loop guard tripped without a loop", scenario);
            CHECK (orphans == 0 && stuckNotes (r.evs) == 0, "HOLD stress %d: notes left ringing (%d) / stuck (%d)", scenario, orphans, stuckNotes (r.evs));
        }

        // N. YOUR MIDI: a drum file plays as written, a bassline in A minor follows C major chords
        {
            const auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("vesper_midi_test");
            dir.deleteRecursively();
            dir.createDirectory();
            auto writeMid = [] (const juce::File& f, std::vector<std::array<int, 4>> notes, int ch)   // start16, len16, note, vel
            {
                juce::MidiMessageSequence seq;
                for (auto& n : notes)
                {
                    auto on = juce::MidiMessage::noteOn (ch, n[2], (juce::uint8) n[3]); on.setTimeStamp (n[0] * 240.0);
                    auto off = juce::MidiMessage::noteOff (ch, n[2]); off.setTimeStamp ((n[0] + n[1]) * 240.0);
                    seq.addEvent (on); seq.addEvent (off);
                }
                seq.updateMatchedPairs();
                juce::MidiFile mf; mf.setTicksPerQuarterNote (960); mf.addTrack (seq);
                juce::FileOutputStream os (f); mf.writeTo (os);
            };
            writeMid (dir.getChildFile ("my beat 1.mid"), { { 0, 1, 36, 110 }, { 3, 1, 36, 90 }, { 8, 1, 38, 120 }, { 10, 1, 36, 100 }, { 2, 1, 42, 80 }, { 6, 1, 42, 80 } }, 10);
            writeMid (dir.getChildFile ("my beat 2.mid"), { { 0, 1, 36, 110 }, { 8, 1, 39, 120 } }, 10);
            writeMid (dir.getChildFile ("bass Am.mid"), { { 0, 4, 33, 100 }, { 4, 2, 45, 90 }, { 8, 4, 40, 100 }, { 12, 4, 43, 90 } }, 1);

            Rig r (House, true);
            r.p.loadTrackMidi (5, { dir.getFullPathName() + "/my beat 1.mid", dir.getFullPathName() + "/my beat 2.mid" });   // drums
            r.p.setTrackCycle (5, 1);
            r.p.loadTrackMidi (2, { dir.getChildFile ("bass Am.mid").getFullPathName() });                                   // bass
            CHECK (r.p.trackMidiCount (5) == 2 && r.p.trackMidiCount (2) == 1, "MIDI loaded (%d, %d)", r.p.trackMidiCount (5), r.p.trackMidiCount (2));
            for (int blk = 0; blk < 400; ++blk)
            {
                juce::MidiBuffer m;
                if (blk == 1) m = at (60, true);           // Cmaj7
                if (blk == 190) m = at (65, true);         // Fmaj7
                if (blk == 191) m = at (60, false);
                if (blk == 380) m = at (65, false);
                r.block (blk, m);
            }
            int kicks = 0, snares = 0, claps = 0, bassC = 0, bassF = 0, bassOut = 0;
            for (auto& e : r.evs)
            {
                if (! e.m.isNoteOn()) continue;
                const int n = e.m.getNoteNumber();
                if (e.m.getChannel() == 10) { if (n == 36) ++kicks; if (n == 38) ++snares; if (n == 39) ++claps; }
                if (e.m.getChannel() == 2)
                {
                    const bool inC = e.t < 190 * 512;
                    const int pc = n % 12;
                    if (inC && pc == 0) ++bassC;
                    if (! inC && pc == 5) ++bassF;
                    const int cm = inC ? pcMask (makeChord (0, "maj7")) : pcMask (makeChord (5, "maj7"));
                    if (! ((poolMask (0, 0) | cm) >> pc & 1)) ++bassOut;
                }
            }
            std::printf ("your MIDI: %d kicks, %d snares, %d claps; bass roots C %d, F %d, out of key %d\n", kicks, snares, claps, bassC, bassF, bassOut);
            CHECK (kicks > 4 && snares > 0 && claps > 0, "both drum files should play, a new one every bar");
            CHECK (bassC > 0 && bassF > 0 && bassOut == 0, "the A minor bassline should follow C then F, in key");
            CHECK (stuckNotes (r.evs) == 0, "your MIDI: stuck notes");
            juce::MemoryBlock st;
            r.p.getStateInformation (st);
            Rig r2 (House, true);
            r2.p.setStateInformation (st.getData(), (int) st.getSize());
            CHECK (r2.p.trackMidiCount (5) == 2 && r2.p.trackCycle (5) == 1, "MIDI files come back with the project");
            dir.deleteRecursively();
        }

        // 1.16 REWORK: your drum bar, reworked - the kick on the one and the snare on 2 every bar, new details; at 0 it's
        // exactly the file; with the snare locked the snare is exactly as written (no ghosts)
        {
            const auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("vesper_rework_test");
            dir.deleteRecursively();
            dir.createDirectory();
            {
                juce::MidiMessageSequence seq;
                auto put = [&] (int step, int n, int vel)
                {
                    auto on = juce::MidiMessage::noteOn (10, n, (juce::uint8) vel); on.setTimeStamp (step * 240.0);
                    auto off = juce::MidiMessage::noteOff (10, n); off.setTimeStamp (step * 240.0 + 120.0);
                    seq.addEvent (on); seq.addEvent (off);
                };
                put (0, 36, 112); put (8, 36, 104); put (10, 36, 80); put (4, 38, 115); put (12, 38, 115);
                for (int s = 0; s < 16; s += 2) put (s, 42, 82);
                seq.updateMatchedPairs();
                juce::MidiFile mf; mf.setTicksPerQuarterNote (960); mf.addTrack (seq);
                juce::FileOutputStream os (dir.getChildFile ("groove.mid")); mf.writeTo (os);
            }
            auto play = [&] (int genre, int amount, int lock, std::vector<Ev>& evsOut)
            {
                Rig r (genre, true);
                r.p.loadTrackMidi (5, { dir.getChildFile ("groove.mid").getFullPathName() });
                r.p.trackRework[5].store (amount);
                r.p.trackReworkLock[5].store (lock);
                for (int blk = 0; blk < 1520; ++blk) r.block (blk, blk == 1 ? at (60, true) : juce::MidiBuffer());
                evsOut = r.evs;
            };
            const int bar = 4 * beat;
            auto bars = [&] (const std::vector<Ev>& evs)
            {
                std::vector<std::multiset<std::pair<int, int>>> out (8);
                for (auto& e : evs)
                {
                    const int64_t t = e.t + 300;   // a hair early still counts as on the beat
                    if (e.m.isNoteOn() && e.m.getChannel() == 10 && t / bar < 8)
                        out[(size_t) (t / bar)].insert ({ (int) ((t % bar) / 600), e.m.getNoteNumber() });
                }
                return out;
            };
            for (int genre : { Trap, Soul, House, Afro, Funk })
            {
                std::vector<Ev> evs;
                play (genre, 100, 0, evs);
                const auto b = bars (evs);
                std::set<std::multiset<std::pair<int, int>>> different;
                int bones = 0, checked = 0;
                for (int i = 1; i < 8; ++i)
                {
                    different.insert (b[(size_t) i]);
                    if ((i + 1) % 4 == 0) continue;   // phrase ends: fills
                    ++checked;
                    const bool one = b[(size_t) i].count ({ 0, 36 }) > 0;
                    const bool two = b[(size_t) i].count ({ 40, 38 }) > 0;   // beat 2 = 24000 samples = 40 x 600
                    if (one && two) ++bones;
                }
                std::printf ("REWORK %s at 100%%: %d of %d bars kept the kick on one and the snare on 2; %d different bars of 7\n",
                             genreShort (genre), bones, checked, (int) different.size());
                CHECK (bones == checked, "REWORK %s: the bones moved (%d of %d)", genreShort (genre), bones, checked);
                CHECK (different.size() >= 3, "REWORK %s: every pass should have new details (%d different bars)", genreShort (genre), (int) different.size());
            }
            {
                std::vector<Ev> evs;
                play (Soul, 0, 0, evs);
                const auto b = bars (evs);
                int same = 0;
                for (int i : { 2, 5, 6 }) if (b[(size_t) i] == b[1]) ++same;
                CHECK (same == 3 && b[1].size() == 13, "REWORK 0: exactly the file every bar (%d same, %d notes)", same, (int) b[1].size());
            }
            {
                std::vector<Ev> evs;
                play (Soul, 100, 1 << PieceSnare, evs);
                const auto b = bars (evs);
                int ok = 0;
                for (int i = 1; i < 8; ++i)
                {
                    std::multiset<int> snares;
                    for (auto& h : b[(size_t) i]) if (h.second == 38 || h.second == 40) snares.insert (h.first);
                    if (snares == std::multiset<int> { 40, 120 }) ++ok;
                }
                CHECK (ok == 7, "REWORK with the snare locked: the snare exactly as written (%d of 7 bars)", ok);
                std::printf ("REWORK: at 0 the file plays as written; a locked snare never moves (%d of 7 bars)\n", ok);
            }
            dir.deleteRecursively();
        }

        // 1.19 BAND LAYOUTS: TRAP - ALL ARPS sets the band up in one click; the bass track keeps its channel (your routing)
        {
            Rig r (Pop, true);
            int bassTrack = -1;
            for (int t = 0; t < r.p.numTracks.load(); ++t) if (r.p.trackType (t) == BBass) bassTrack = t;
            const int bassCh = bassTrack >= 0 ? (int) r.p.trackValue (bassTrack, TpCh) : -1;
            r.p.applyBandLayout (Trap, 0);
            std::multiset<int> want, got;
            const auto& L = bandLayout (Trap, 0);
            for (int k = 0; k < L.numParts; ++k) want.insert (L.parts[k].type);
            std::set<int> chans;
            bool clash = false;
            for (int t = 0; t < r.p.numTracks.load(); ++t)
                if (r.p.trackValue (t, TpOn) > 0.5f)
                {
                    got.insert (r.p.trackType (t));
                    const int ch = (int) r.p.trackValue (t, TpCh);
                    if (! bandTypeIsDrums (r.p.trackType (t)) && ! chans.insert (ch).second) clash = true;
                }
            std::printf ("band layout: TRAP %s - %d tracks on, the bass track's channel %d -> %d, the 808 style %s\n", L.name, (int) got.size(), bassCh,
                         bassTrack >= 0 ? (int) r.p.trackValue (bassTrack, TpCh) : -1, bassTrack >= 0 ? bandStyleName (BBass, (int) r.p.trackValue (bassTrack, TpStyle)) : "-");
            CHECK (got == want, "BAND LAYOUT: the tracks on should be exactly the layout's");
            CHECK (bassTrack >= 0 && (int) r.p.trackValue (bassTrack, TpCh) == bassCh && (int) r.p.trackValue (bassTrack, TpStyle) == 7,
                   "BAND LAYOUT: the bass track keeps its channel and plays the 808");
            CHECK (! clash, "BAND LAYOUT: two pitched tracks on the same channel");
            for (int blk = 0; blk < 400; ++blk) r.block (blk, blk == 1 ? at (60, true) : juce::MidiBuffer());
        }

        // 1.20 HOME CHANNELS: a track a layout adds or changes goes to its instrument's own channel (keys 7, pad 8, arp 9,
        // the second arp 14...), so one FL template with a sound on every channel fits every layout
        {
            Rig r (Pop, true);
            auto check = [&] (int genre, int idx)
            {
                r.p.applyBandLayout (genre, idx);
                std::map<int, std::set<int>> chOfType;
                std::set<int> chans;
                bool clash = false;
                for (int t = 0; t < r.p.numTracks.load(); ++t)
                    if (r.p.trackValue (t, TpOn) > 0.5f && ! bandTypeIsDrums (r.p.trackType (t)))
                    {
                        const int ch = (int) r.p.trackValue (t, TpCh);
                        chOfType[r.p.trackType (t)].insert (ch);
                        if (! chans.insert (ch).second) clash = true;
                    }
                bool home = true;
                juce::String shown;
                for (auto& [type, set] : chOfType)
                {
                    int h[3];
                    const int nh = bandHomeChannels (type, h);
                    std::set<int> want;
                    for (int k = 0; k < juce::jmin (nh, (int) set.size()); ++k) want.insert (h[k]);
                    if (type != BBass && (int) set.size() <= nh && set != want) home = false;   // the bass keeps the channel it had
                    for (int c : set) shown << bandTypeName (type) << " " << c << "  ";
                }
                std::printf ("home channels: %s %s - %s\n", genreShort (genre), bandLayout (genre, idx).name, shown.toRawUTF8());
                CHECK (home && ! clash, "HOME CHANNELS: %s %s", genreShort (genre), bandLayout (genre, idx).name);
            };
            check (Trap, 0);   // ALL ARPS: arps on 9, 14, 15
            check (Soul, 0);   // SLOW JAM: keys 7, strings 5, melody 3, pad 8
            check (Rock, 1);   // INDIE: guitars on 11 and 13
            check (Cinematic, 1);   // DARK SCORE: strings on 5 and 12
            for (int blk = 0; blk < 200; ++blk) r.block (blk, blk == 1 ? at (60, true) : juce::MidiBuffer());
        }

        // 1.21 BEATBOX: a WAV of you beatboxing a bar (boom ts pf ts boom boom pf ts, and a last boom on the next one)
        // dropped on the drum track plays as that beat, on the song's tempo, and is saved as a MIDI file
        {
            Rig r (Pop, true);
            for (int blk = 0; blk < 4; ++blk) r.block (blk, {});   // VESPER knows the song's tempo (120)
            const double sr = 44100, step = 60.0 / 120.0 / 4.0;
            const std::vector<std::pair<int, int>> pat = { { 0, BbKick }, { 2, BbHat }, { 4, BbSnare }, { 6, BbHat }, { 8, BbKick },
                                                           { 10, BbKick }, { 12, BbSnare }, { 14, BbHat }, { 16, BbKick } };
            juce::AudioBuffer<float> buf (2, (int) (sr * 3.0));
            buf.clear();
            juce::Random rnd (7);
            for (auto& [slot, kind] : pat)
            {
                const double t0 = 0.31 + slot * step + (rnd.nextFloat() - 0.5) * 0.02;
                const double dur = kind == BbKick ? 0.25 : kind == BbSnare ? 0.2 : 0.08, tau = kind == BbKick ? 0.09 : kind == BbSnare ? 0.06 : 0.018;
                double ph = 0, l1 = 0, l2 = 0;
                for (int i = 0; i < (int) (dur * sr); ++i)
                {
                    const double t = i / sr, env = std::exp (-t / tau) * juce::jmin (1.0, (dur - t) / 0.03);
                    const double nz = rnd.nextFloat() * 2 - 1;
                    double v;
                    if (kind == BbKick) { ph += 2 * juce::MathConstants<double>::pi * (55 + 120 * std::exp (-t / 0.02)) / sr; v = 0.9 * std::sin (ph); }
                    else if (kind == BbSnare) { l1 += 0.5 * (nz - l1); l2 += 0.12 * (l1 - l2); v = 1.2 * (l1 - l2); }
                    else { l1 += 0.6 * (nz - l1); v = 0.5 * (nz - l1); }
                    const int j = (int) ((t0 + t) * sr);
                    if (j < buf.getNumSamples()) for (int c = 0; c < 2; ++c) buf.addSample (c, j, (float) (0.3 * env * v));
                }
            }
            const auto wavFile = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("vesper_beatbox_test.wav");
            wavFile.deleteFile();
            {
                juce::WavAudioFormat wav;
                std::unique_ptr<juce::AudioFormatWriter> w (wav.createWriterFor (new juce::FileOutputStream (wavFile), sr, 2, 16, {}, 0));
                CHECK (w != nullptr, "BEATBOX: couldn't write the test WAV");
                if (w != nullptr) w->writeFromAudioSampleBuffer (buf, 0, buf.getNumSamples());
            }
            int drum = -1;
            for (int t = 0; t < r.p.numTracks.load() && drum < 0; ++t) if (bandTypeIsDrums (r.p.trackType (t))) drum = t;
            r.p.trackRework[(size_t) drum].store (0);
            const auto note = r.p.loadBeatbox (drum == 0 ? 1 : 0, wavFile);   // dropped on the wrong track: it finds the drums
            std::printf ("BEATBOX drop: %s\n", note.replace ("\n", " / ").toRawUTF8());
            CHECK (note.contains ("BEATBOX heard") && r.p.trackMidiCount (drum) == 1, "BEATBOX: the drop should load the beat (%s)", note.toRawUTF8());
            const auto saved = VesperProcessor::beatboxFolder().findChildFiles (juce::File::findFiles, false, "BEATBOX *.mid");
            CHECK (! saved.isEmpty(), "BEATBOX: the beat should be saved as a MIDI file");
            for (int blk = 4; blk < 1300; ++blk) r.block (blk, blk == 5 ? at (60, true) : juce::MidiBuffer());
            const int bar = 4 * beat, sixteenth = beat / 4;
            std::vector<std::multiset<std::pair<int, int>>> bars (6);
            for (auto& e : r.evs)
            {
                const int64_t t = e.t + 400;
                if (e.m.isNoteOn() && e.m.getChannel() == 10 && t / bar < 6) bars[(size_t) (t / bar)].insert ({ (int) ((t % bar) / sixteenth), e.m.getNoteNumber() });
            }
            const std::multiset<std::pair<int, int>> want { { 0, 36 }, { 2, 42 }, { 4, 38 }, { 6, 42 }, { 8, 36 }, { 10, 36 }, { 12, 38 }, { 14, 42 } };
            int right = 0;
            for (int b : { 1, 2 }) if (bars[(size_t) b] == want) ++right;
            juce::String got;
            for (auto& h : bars[1]) got << h.first << ":" << h.second << " ";
            std::printf ("BEATBOX: %d of 2 bars play your beat exactly (bar 2: %s)\n", right, got.toRawUTF8());
            CHECK (right == 2, "BEATBOX: the drum track should play the beatboxed bar (%s)", got.toRawUTF8());
            for (auto& f : saved) f.deleteFile();
            wavFile.deleteFile();
        }

        // 1.20 TO LOOPS A-D: the chord set's rows become loops A-D and play the pads' chords with nothing held down - in
        // SCALE mode too - exactly what pressing those pads at those bars plays; and the loops come back with the project
        {
            const int beatS = beat;
            auto chordBars = [&] (const std::vector<Ev>& evs, int firstBeat)
            {
                std::vector<std::set<int>> out (8);
                for (auto& e : evs)
                    if (e.m.isNoteOn() && e.m.getChannel() == 1)
                    {
                        const int64_t b = (e.t + beatS / 8) / beatS - firstBeat;   // a sample early still counts as on the bar
                        if (b >= 0 && b < 32) out[(size_t) (b / 4)].insert (e.m.getNoteNumber());
                    }
                return out;
            };
            auto setup = [&] (Rig& r, int mode)
            {
                for (int t = 0; t < r.p.numTracks.load(); ++t) r.p.setTrackValue (t, TpOn, 0.0f);   // just the chords
                setParam (r.p, ids::vary, 0.0f);
                r.p.ui.keysMode = mode;
                r.p.setPalette (buildChordSet (r.p.ui.keyRoot, r.p.ui.scale, Soul, 1));
                r.p.applyUiState();
            };
            Rig a (Soul, true);
            setup (a, 0);   // SCALE mode
            CHECK (a.p.chordRowsToLoops ({ 0, 1, 2, 3 }), "TO LOOPS: should take the rows");
            a.block (0, {});
            CHECK (a.p.looper.filled.load() == 15u, "TO LOOPS: loops A-D should all be filled (%u)", a.p.looper.filled.load());
            a.p.goToSection (0);
            for (int blk = 1; blk < 1700; ++blk) a.block (blk, {});
            Rig b (Soul, true);
            setup (b, 1);   // PADS mode, the same pads pressed by hand at the same bars
            std::vector<std::pair<int64_t, juce::MidiMessage>> presses;
            for (int k = 0; k < 8; ++k)
            {
                const int pad = k % 4;
                const int64_t on = (int64_t) (4 + 4 * k) * beatS, off = (int64_t) ((4 + 4 * k + 4) * beatS - 0.02 * beatS);
                presses.push_back ({ on, juce::MidiMessage::noteOn (1, 48 + pad, (juce::uint8) (pad == 0 ? 104 : 96)) });
                presses.push_back ({ off, juce::MidiMessage::noteOff (1, 48 + pad) });
            }
            for (int blk = 0; blk < 1700; ++blk)
            {
                juce::MidiBuffer m;
                for (auto& [t, msg] : presses) if (t / 512 == blk) m.addEvent (msg, (int) (t % 512));
                b.block (blk, m);
            }
            const auto la = chordBars (a.evs, 4), lb = chordBars (b.evs, 4);
            int same = 0, distinct = 0;
            for (int k = 0; k < 8; ++k) if (la[(size_t) k] == lb[(size_t) k] && ! la[(size_t) k].empty()) ++same;
            for (int k = 1; k < 4; ++k) if (la[(size_t) k] != la[(size_t) (k - 1)]) ++distinct;
            std::printf ("TO LOOPS: SCALE mode, nothing held: %d of 8 bars play exactly the pads' chords, %d chord changes in the loop\n",
                         same, distinct);
            if (same != 8)
            {
                juce::String evs0, ons;
                for (auto& e : a.p.looper.sec[0].evs) evs0 << juce::String (e.beat, 2) << "/" << (int) e.note << "/" << (int) e.vel << " ";
                int64_t lastT = -1;
                for (auto& e : a.evs)
                    if (e.m.isNoteOn() && e.m.getChannel() == 1 && e.t < 40 * beatS && e.t != lastT) { ons << juce::String ((double) e.t / beatS, 2) << " "; lastT = e.t; }
                std::printf ("  loop A events: %s\n  chord note-ons at beats: %s\n", evs0.toRawUTF8(), ons.toRawUTF8());
            }
            if (same != 8)
                for (int k = 0; k < 8; ++k)
                {
                    juce::String sa, sb;
                    for (int x : la[(size_t) k]) sa << x << " ";
                    for (int x : lb[(size_t) k]) sb << x << " ";
                    std::printf ("  bar %d: loop [%s]  pads [%s]\n", k, sa.toRawUTF8(), sb.toRawUTF8());
                }
            CHECK (same == 8 && distinct == 3, "TO LOOPS: the loop should play the pads' chords (%d of 8, %d changes)", same, distinct);
            // the loops come back with the project
            juce::MemoryBlock mb;
            a.p.getStateInformation (mb);
            Rig c (Soul, false);
            c.p.setStateInformation (mb.getData(), (int) mb.getSize());
            const auto& ev0 = c.p.looper.sec[0].evs;
            CHECK (c.p.looper.filled.load() == 15u && ! ev0.empty() && ev0[0].pad == 1 && ev0[0].ch == Looper::padChannel,
                   "TO LOOPS: the pad loops should come back with the project");
        }

        // 1.18 DRUM PARTS: kick.mid, snare.mid, hats.mid, 808.mid from FL's channel rack, every one on C5, dropped on the
        // drum track together: one groove, each on its pad; the 808 goes to the bass track. And one FL export with a
        // track per channel does the same.
        {
            const auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("vesper_parts_test");
            dir.deleteRecursively();
            dir.createDirectory();
            auto seqOf = [] (std::initializer_list<int> steps, int note, const char* trackName)
            {
                juce::MidiMessageSequence seq;
                if (trackName != nullptr) seq.addEvent (juce::MidiMessage::textMetaEvent (3, trackName));
                for (int bar = 0; bar < 2; ++bar)
                    for (int s : steps)
                    {
                        auto on = juce::MidiMessage::noteOn (1, note, (juce::uint8) 100); on.setTimeStamp ((bar * 16 + s) * 240.0);
                        auto off = juce::MidiMessage::noteOff (1, note); off.setTimeStamp ((bar * 16 + s) * 240.0 + 120.0);
                        seq.addEvent (on); seq.addEvent (off);
                    }
                seq.updateMatchedPairs();
                return seq;
            };
            auto write = [&] (const char* file, std::vector<juce::MidiMessageSequence> tracks)
            {
                juce::MidiFile mf; mf.setTicksPerQuarterNote (960);
                for (auto& t : tracks) mf.addTrack (t);
                juce::FileOutputStream os (dir.getChildFile (file)); mf.writeTo (os);
                return dir.getChildFile (file).getFullPathName();
            };
            const juce::StringArray files { write ("Kick.mid", { seqOf ({ 0, 8, 10 }, 60, "Pattern 1") }), write ("Snare.mid", { seqOf ({ 4, 12 }, 60, nullptr) }),
                                            write ("Hi Hat.mid", { seqOf ({ 0, 2, 4, 6, 8, 10, 12, 14 }, 60, nullptr) }), write ("808.mid", { seqOf ({ 0, 10 }, 36, nullptr) }) };
            const auto oneExport = write ("my beat.mid", { seqOf ({ 0, 8, 10 }, 60, "Kick"), seqOf ({ 4, 12 }, 60, "Clap"), seqOf ({ 0, 2, 4, 6, 8, 10, 12, 14 }, 60, "HH") });
            auto run = [&] (const juce::StringArray& what, std::map<int, int>& drumNotes, int& bassFiles)
            {
                Rig r (Trap, true);
                r.p.loadTrackMidi (5, what);
                int bassTrack = -1;
                for (int t = 0; t < r.p.numTracks.load(); ++t) if (r.p.trackType (t) == BBass) bassTrack = t;
                bassFiles = bassTrack >= 0 ? r.p.trackMidiCount (bassTrack) : -1;
                for (int blk = 0; blk < 800; ++blk) r.block (blk, blk == 1 ? at (60, true) : juce::MidiBuffer());
                for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 10) ++drumNotes[e.m.getNoteNumber()];
            };
            std::map<int, int> a, b;
            int bassA = 0, bassB = 0;
            run (files, a, bassA);
            run ({ oneExport }, b, bassB);
            std::printf ("drum parts: kick %d, snare %d, hat %d, C5 %d; the bass track took %d files | one export: kick %d, clap %d, hat %d, C5 %d\n",
                         a[36], a[38], a[42], a[60], bassA, b[36], b[39], b[42], b[60]);
            CHECK (a[36] > 0 && a[38] > 0 && a[42] > 0 && a[60] == 0, "DRUM PARTS: each file on its pad (kick %d snare %d hat %d C5 %d)", a[36], a[38], a[42], a[60]);
            CHECK (bassA > 0, "DRUM PARTS: the 808 should go to the bass track");
            CHECK (b[36] > 0 && b[39] > 0 && b[42] > 0 && b[60] == 0, "DRUM PARTS: one FL export, by its track names (kick %d clap %d hat %d C5 %d)", b[36], b[39], b[42], b[60]);
            dir.deleteRecursively();
        }

        // 1.16 "drums out" / "drums in": the drums sit out from the next bar, the bass keeps going, then they come back
        {
            Rig r (Pop, true);
            CHECK (r.p.voiceCommand ("drums out") && r.p.voiceCommand ("bass back in") && r.p.voiceCommand ("everybody out")
                   && r.p.voiceCommand ("one more time") && r.p.voiceCommand ("go back") && r.p.voiceCommand ("brighter")
                   && r.p.voiceCommand ("glide off") && r.p.voiceCommand ("call and response"), "VOICE: the new words");
            const int bar = 4 * beat;
            for (int blk = 0; blk < 1500; ++blk)
            {
                if (blk == 300) r.p.command (VesperProcessor::CmdOut, BDrums);
                if (blk == 900) r.p.command (VesperProcessor::CmdIn, BDrums);
                r.block (blk, blk == 1 ? at (60, true) : juce::MidiBuffer());
            }
            const int64_t outFrom = ((int64_t) 300 * 512 / bar + 1) * bar, outTo = (int64_t) 900 * 512;
            const int64_t inFrom = ((int64_t) 900 * 512 / bar + 1) * bar;
            int drumsOut = 0, bassOut = 0, drumsBack = 0;
            for (auto& e : r.evs)
            {
                if (! e.m.isNoteOn()) continue;
                if (e.t >= outFrom && e.t < outTo) { if (e.m.getChannel() == 10) ++drumsOut; if (e.m.getChannel() == 2) ++bassOut; }
                if (e.t >= inFrom && e.m.getChannel() == 10) ++drumsBack;
            }
            std::printf ("DRUMS OUT: %d drum notes while out (bass %d), %d after DRUMS IN\n", drumsOut, bassOut, drumsBack);
            CHECK (drumsOut == 0 && bassOut > 0 && drumsBack > 0, "DRUMS OUT / IN (%d, %d, %d)", drumsOut, bassOut, drumsBack);
            int drumOn[128] = {}, hanging = 0;   // nothing left ringing on the drums while they're out
            for (auto& e : r.evs)
            {
                if (e.t >= outTo || e.m.getChannel() != 10) continue;
                if (e.m.isNoteOn()) drumOn[e.m.getNoteNumber()] = 1; else if (e.m.isNoteOff()) drumOn[e.m.getNoteNumber()] = 0;
            }
            for (int v : drumOn) hanging += v;
            CHECK (hanging == 0, "DRUMS OUT: %d drum notes left ringing", hanging);
        }

        // F. a band copy set to ONLY BASS plays the exact same bass line; the main VESPER leaves it out
        {
            auto script = [&] (int blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                auto event = [&] (int64_t sample, int key, bool on) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                event (0, 60, true);
                event (8 * beat, 69, true);
                event (8 * beat + 5, 60, false);
                event (12 * beat, 65, true);
                event (12 * beat + 5, 69, false);
                event (16 * beat, 65, false);
                return m;
            };
            auto bassOf = [] (const std::vector<Ev>& evs)
            {
                std::vector<std::pair<int64_t, int>> v;
                for (auto& e : evs) if (e.m.isNoteOn() && e.m.getChannel() == 2) v.push_back ({ e.t, e.m.getNoteNumber() });
                return v;
            };
            std::vector<std::pair<int64_t, int>> reference;
            {
                Rig solo (Funk, true);
                for (int blk = 0; blk < 800; ++blk) solo.block (blk, script (blk));
                reference = bassOf (solo.evs);
            }
            for (int order = 0; order < 2; ++order)
            {
                Rig lead (Funk, true), copy (Funk, true);
                setParam (copy.p, ids::bandRole, 3.0f);   // ONLY BASS
                for (int blk = 0; blk < 800; ++blk)
                {
                    if (order == 0) { lead.block (blk, script (blk)); copy.block (blk, {}); }
                    else            { copy.block (blk, {}); lead.block (blk, script (blk)); }
                }
                const auto leadBass = bassOf (lead.evs), copyBass = bassOf (copy.evs);
                int copyOther = 0;
                for (auto& e : copy.evs) if (e.m.isNoteOn() && e.m.getChannel() != 2) ++copyOther;
                int matched = 0;
                for (auto& ref : reference)
                    for (auto& c : copyBass)
                        if (c.second == ref.second && c.first >= ref.first && c.first - ref.first <= (order == 0 ? 0 : 512)) { ++matched; break; }
                if (std::getenv ("VDEBUG"))
                {
                    for (auto& ref : reference) std::printf ("  ref %lld %d\n", (long long) ref.first, ref.second);
                    for (auto& c : copyBass) std::printf ("  copy %lld %d\n", (long long) c.first, c.second);
                }
                std::printf ("band copy (%s first): %d of %d bass notes match, main VESPER bass notes: %d\n",
                             order == 0 ? "main" : "copy", matched, (int) reference.size(), (int) leadBass.size());
                CHECK (reference.size() > 10 && matched == (int) reference.size(), "band copy should play the same bass line (%d of %d)", matched, (int) reference.size());
                CHECK (leadBass.size() <= 1 && copyOther == 0, "main VESPER should leave the bass to the copy (%d, %d)", (int) leadBass.size(), copyOther);
                CHECK (stuckNotes (lead.evs) == 0 && stuckNotes (copy.evs) == 0, "band copy: stuck notes");
            }
        }

        // O. LOOPER, SECTIONS, THE LISTENING DRUMMER, BAND FEEL, SURPRISE SIT-OUTS, MAKE IT A SONG
        {
            juce::Thread::sleep (700);   // the band copies above have let go of their tracks
            auto pcsIn = [] (const std::vector<Ev>& evs, int64_t a, int64_t b)
            {
                std::set<int> s;
                for (auto& e : evs) if (e.m.isNoteOn() && e.m.getChannel() == 1 && e.t >= a && e.t < b) s.insert (e.m.getNoteNumber() % 12);
                return s;
            };
            auto countIn = [] (const std::vector<Ev>& evs, int ch, int note, int64_t a, int64_t b)
            {
                int n = 0;
                for (auto& e : evs) if (e.m.isNoteOn() && e.m.getChannel() == ch && (note < 0 || e.m.getNoteNumber() == note) && e.t >= a && e.t < b) ++n;
                return n;
            };
            // record A (2 bars: C then E), it loops; record B (G), switch back to A on the bar line
            auto session = [&] (bool listens, bool feel)
            {
                auto r = std::make_unique<Rig> (House, true);
                r->p.drummerListens.store (listens);
                r->p.bandFeel.store (feel);
                r->p.looper.bars.store (2);
                for (int blk = 0; blk < 1600; ++blk)
                {
                    juce::MidiBuffer m;
                    const int64_t t0 = (int64_t) blk * 512;
                    auto event = [&] (int64_t sample, int key, bool on) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                    if (blk == 0) r->p.goToSection (0);                    // A is empty: it arms
                    event (300, 60, true);  event (4 * beat - 200, 60, false);
                    event (4 * beat, 64, true);  event (8 * beat - 200, 64, false);
                    if (t0 <= 16 * beat && 16 * beat < t0 + 512) r->p.goToSection (1);   // B is empty: record it
                    event (16 * beat + 300, 67, true);  event (24 * beat - 200, 67, false);
                    if (t0 <= 26 * beat && 26 * beat < t0 + 512) r->p.goToSection (0);   // back to A on the next bar line (28)
                    r->block (blk, m);
                }
                return r;
            };
            auto r = session (false, false);
            auto& L = r->p.looper;
            const auto c1 = pcsIn (r->evs, 0, 4 * beat), e1 = pcsIn (r->evs, 4 * beat, 8 * beat);
            const auto c2 = pcsIn (r->evs, 8 * beat, 12 * beat), e2 = pcsIn (r->evs, 12 * beat, 16 * beat);
            const auto g2 = pcsIn (r->evs, 24 * beat, 28 * beat - 100), a3 = pcsIn (r->evs, 28 * beat, 32 * beat - 100);
            const auto g1 = pcsIn (r->evs, 16 * beat, 24 * beat);
            std::printf ("looper: state %d section %d filled %u, loop A replays %s, B %s, back to A %s\n", L.state.load(), L.section.load(),
                         L.filled.load(), (c1 == c2 && e1 == e2) ? "yes" : "no", g2 == g1 ? "yes" : "no", a3 == c1 ? "yes" : "no");
            CHECK (! c1.empty() && c1 != e1 && c1 == c2 && e1 == e2, "looper: A should play back exactly what was played");
            CHECK (! g1.empty() && g2 == g1, "looper: B should loop right after recording it");
            if (a3 != c1)
            {
                auto show = [] (const std::set<int>& x) { juce::String o; for (int v : x) o << v << ","; return o; };
                std::printf ("  c1 %s e1 %s g1 %s a3 %s\n", show (c1).toRawUTF8(), show (e1).toRawUTF8(), show (g1).toRawUTF8(), show (a3).toRawUTF8());
                for (auto& e : r->evs) if (e.m.getChannel() == 1 && e.t >= 26 * beat && e.t < 32 * beat && (e.m.isNoteOn() || e.m.isNoteOff()))
                    std::printf ("    %.3f %s %d\n", e.t / (double) beat, e.m.isNoteOn() ? "on" : "off", e.m.getNoteNumber());
            }
            CHECK (a3 == c1 && L.section.load() == 0 && L.filled.load() == 3u && L.playing(), "looper: back to A on the bar line");
            // stop it: everything lets go
            L.cmd.store (3);
            for (int blk = 1600; blk < 1700; ++blk) r->block (blk, {});
            r->p.stopBandFromUi();
            for (int blk = 1700; blk < 1720; ++blk) r->block (blk, {});
            CHECK (stuckNotes (r->evs) == 0 && ! L.busy(), "looper: stuck notes after stopping");

            // the listening drummer: a crash on the change (beat 28) and a fill into it
            auto d = session (true, false);
            const int crash = countIn (d->evs, 10, Band::Crash, 28 * beat - 200, 28 * beat + 400), crash0 = countIn (r->evs, 10, Band::Crash, 28 * beat - 200, 28 * beat + 400);
            // the fill: snare, rim, clap or toms (any of them, 1 or 2 beats) before the change, not the groove's own
            auto fillHits = [&] (const auto& evs)
            {
                int n = 0;
                for (auto& e : evs)
                    if (e.m.isNoteOn() && e.m.getChannel() == 10 && e.t >= 26 * beat && e.t < 28 * beat)
                    {
                        const int k = e.m.getNoteNumber();
                        if (k == 37 || k == 38 || k == 39 || k == 40 || k == 41 || k == 43 || k == 45 || k == 47 || k == 48 || k == 50 || k == 63 || k == 64) ++n;
                    }
                return n;
            };
            const int fill = fillHits (d->evs), fill0 = fillHits (r->evs);
            std::printf ("drummer listens: crash %d (off %d), fill hits before the change %d (off %d)\n", crash, crash0, fill, fill0);
            CHECK (crash >= 1 && crash0 == 0, "drummer listens: crash on the new section");
            CHECK (fill >= 3 && fill != fill0, "drummer listens: a fill into the change (%d vs %d)", fill, fill0);

            // band feel: the bass sits back (about 0.07 of a 16th = 420 samples here)
            auto f = session (false, true);
            std::vector<int64_t> a, b;
            for (auto& e : r->evs) if (e.m.isNoteOn() && e.m.getChannel() == 2) a.push_back (e.t);
            for (auto& e : f->evs) if (e.m.isNoteOn() && e.m.getChannel() == 2) b.push_back (e.t);
            int late = 0, matched = 0;
            for (auto t : a)
                for (auto u : b)
                    if (u >= t && u - t < 1200) { ++matched; if (u - t >= 300 && u - t <= 540) ++late; break; }
            std::printf ("band feel: %d of %d bass notes sit back (%d / %d bass notes)\n", late, matched, (int) a.size(), (int) b.size());
            CHECK (matched > 10 && late >= matched * 8 / 10, "band feel: the bass should sit back (%d of %d)", late, matched);

            // surprise sit-outs: the bass skips some chords, plays others
            {
                Rig s (House, true);
                int bass = -1;
                for (int t = 0; t < s.p.numTracks.load(); ++t) if (s.p.trackType (t) == BBass) bass = t;
                CHECK (bass >= 0, "surprise: House should have a bass");
                if (bass >= 0) s.p.trackSurprise[(size_t) bass].store (40);
                const int keys[12] = { 60, 62, 64, 65, 67, 69, 71, 72, 62, 65, 69, 67 };
                for (int blk = 0; blk < 2300; ++blk)
                {
                    juce::MidiBuffer m;
                    const int64_t t0 = (int64_t) blk * 512;
                    auto event = [&] (int64_t sample, int key, bool on) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                    for (int i = 0; i < 12; ++i) { event (i * 4 * beat + 300, keys[i], true); event ((i + 1) * 4 * beat - 100, keys[i], false); }
                    s.block (blk, m);
                }
                int out = 0, in = 0;
                for (int i = 0; i < 12; ++i)
                {
                    const int n = countIn (s.evs, 2, -1, i * 4 * beat + 400, (i + 1) * 4 * beat - 200);
                    (n == 0 ? out : in) += 1;
                }
                std::printf ("surprise sit-outs (40%%): bass sat out %d of 12 chords\n", out);
                s.p.stopBandFromUi();
                for (int blk = 2300; blk < 2340; ++blk) s.block (blk, {});
                CHECK (out >= 2 && in >= 4, "surprise: the bass should sit some chords out, not all (%d out, %d in)", out, in);
                CHECK (stuckNotes (s.evs) == 0, "surprise: stuck notes");
            }

            // section keys: learn one, it never sounds, pressing it switches
            {
                Rig k (House, true);
                k.p.looper.bars.store (1);
                k.p.sectionLearn.store (1);
                k.block (0, at (48, true));
                k.block (1, at (48, false));
                CHECK (k.p.sectionKey[1].load() == 48 && k.p.sectionLearn.load() < 0, "section key: learned");
                k.block (2, at (48, true));     // B is empty: it arms B
                k.block (3, at (48, false));
                k.block (4, {});
                CHECK (k.p.looper.section.load() == 1 && k.p.looper.state.load() == Looper::Armed, "section key: B armed (%d, %d)",
                       k.p.looper.section.load(), k.p.looper.state.load());
                CHECK (countIn (k.evs, 1, -1, 0, 5 * 512) == 0, "section key: the key itself must not play a chord");
            }

            // the loops, toggles and keys come back with the project
            {
                r->p.trackSurprise[0].store (40);
                r->p.sectionKey[2].store (50);
                r->p.ui.hidePreview = true;
                r->p.ui.skin = "C:/skins/night.png";
                r->p.drummerListens.store (true);
                juce::MemoryBlock st;
                r->p.getStateInformation (st);
                std::unique_ptr<juce::AudioProcessor> b2 (createPluginFilter());
                auto& q = dynamic_cast<VesperProcessor&> (*b2);
                q.setStateInformation (st.getData(), (int) st.getSize());
                const bool same = q.looper.sec[0].evs.size() == L.sec[0].evs.size() && q.looper.sec[1].evs.size() == L.sec[1].evs.size()
                                  && std::abs (q.looper.sec[0].len - 8.0) < 1e-9 && ! q.looper.sec[0].evs.empty();
                CHECK (same && q.looper.filled.load() == 3u && q.looper.bars.load() == 2, "state: loops should come back");
                CHECK (q.trackSurprise[0].load() == 40 && q.sectionKey[2].load() == 50 && q.drummerListens.load() && ! q.bandFeel.load(),
                       "state: surprise / section keys / toggles should come back");
                CHECK (q.ui.hidePreview && ! q.ui.hideNext && q.ui.skin == "C:/skins/night.png", "state: hidden panels and skin should come back");
            }

            // SONG: a whole R&B song played through over live chords - sections in order, who plays in every bar,
            // the moments (a STOP really stops, a DROP drops the beat), then it ends by itself
            {
                Rig s (HipHop, true);
                setParam (s.p, ids::bandStop, 2.0f);   // the band keeps going between chords
                {
                    int pick = 1;
                    for (int n = 1; n <= 400; ++n)
                    {
                        const auto pl = makeSongPlan (HipHop, n, s.p.songLineup());
                        bool st = false, dr = false;
                        for (const auto& sec : pl.sections) for (int m : sec.moment) { st |= m == MomStop; dr |= m == MomDrop; }
                        if (st && dr && pl.totalBars() <= 90) { pick = n; break; }
                    }
                    s.p.newSong (pick);
                }
                const auto plan = s.p.songPlanCopy();
                std::printf ("song: %s (%d bars)\n", plan.describe().c_str(), plan.totalBars());
                const int songBlocks = (int) ((8.0 + 4.0 * plan.totalBars()) * beat / 512) + 40;
                std::vector<std::pair<int, int>> where;   // (section, bar) after every block
                const int keys[4] = { 60, 65, 69, 67 };
                for (int blk = 0; blk < songBlocks; ++blk)
                {
                    juce::MidiBuffer m;
                    const int64_t t0 = (int64_t) blk * 512;
                    for (int bar = 0; bar < 4 * 80; ++bar)
                    {
                        const int64_t on = (int64_t) bar * 4 * beat + 200, off = (int64_t) (bar + 1) * 4 * beat - 300;
                        if (on >= t0 && on < t0 + 512) m.addEvent (juce::MidiMessage::noteOn (1, keys[bar % 4], (juce::uint8) 100), (int) (on - t0));
                        if (off >= t0 && off < t0 + 512) m.addEvent (juce::MidiMessage::noteOff (1, keys[bar % 4]), (int) (off - t0));
                    }
                    if (blk == 2) s.p.songOn.store (true);
                    s.block (blk, m);
                    where.push_back ({ s.p.songSecNow.load(), s.p.songBarNow.load() });
                }
                // the order the sections played in, and where each bar started
                std::vector<int> order;
                std::map<std::pair<int, int>, double> barStart;
                for (size_t blk = 0; blk < where.size(); ++blk)
                {
                    const auto w = where[blk];
                    if (w.first < 0) continue;
                    if (order.empty() || order.back() != w.first) order.push_back (w.first);
                    if (w.second >= 0 && ! barStart.count (w)) barStart[w] = std::ceil ((double) blk * 512.0 / beat / 4.0 - 1e-9) * 4.0;
                }
                bool inOrder = (int) order.size() == (int) plan.sections.size();
                for (size_t i = 0; i < order.size(); ++i) inOrder = inOrder && order[i] == (int) i;
                CHECK (inOrder, "song: every section in order (%d of %d)", (int) order.size(), (int) plan.sections.size());
                CHECK (! s.p.songOn.load() && s.p.songSecNow.load() < 0, "song: it ends by itself");
                // who plays: the bass sits out the bars the plan leaves it out of
                int bassTrack = -1;
                for (int t = 0; t < s.p.numTracks.load(); ++t) if (s.p.trackType (t) == BBass) bassTrack = t;
                int bassInOff = 0, bassInOn = 0, offBars = 0, stopBars = 0, stopLeaks = 0, dropBars = 0, dropLeaks = 0;
                for (auto& [key, start] : barStart)
                {
                    const auto& sec = plan.sections[(size_t) key.first];
                    const uint16_t mask = sec.mask[(size_t) key.second];
                    const int moment = sec.moment[(size_t) key.second];
                    const int64_t a = (int64_t) (start * beat) + 300, b = (int64_t) ((start + 4.0) * beat) - 300;
                    int bass = 0, late = 0, drums = 0;
                    for (auto& e : s.evs)
                    {
                        if (! e.m.isNoteOn() || e.t < a || e.t >= b) continue;
                        if (e.m.getChannel() == 2) ++bass;
                        if (e.m.getChannel() != 1 && e.t >= (int64_t) ((start + 3.0) * beat) + 300) ++late;
                        if (e.m.getChannel() == 10 && e.m.getNoteNumber() != Band::Crash) ++drums;
                    }
                    if (bassTrack >= 0 && ! ((mask >> bassTrack) & 1u)) { ++offBars; bassInOff += bass; }
                    else bassInOn += bass;
                    if (moment == MomStop) { ++stopBars; stopLeaks += late; }
                    if (moment == MomDrop) { ++dropBars; dropLeaks += drums; }
                }
                std::printf ("song: bass in %d bars it's left out of: %d notes (%d where it plays); %d STOP bars (%d notes after beat 4), %d DROP bars (%d drum hits)\n",
                             offBars, bassInOff, bassInOn, stopBars, stopLeaks, dropBars, dropLeaks);
                CHECK (bassInOff == 0 && bassInOn > 0, "song: the bass follows the plan (%d where it's out)", bassInOff);
                CHECK (stopBars > 0 && dropBars > 0 && stopLeaks == 0 && dropLeaks == 0, "song: STOP and DROP (%d, %d)", stopLeaks, dropLeaks);
                {
                    juce::MidiBuffer m;
                    for (int k : keys) m.addEvent (juce::MidiMessage::noteOff (1, k), 0);
                    s.block (songBlocks, m);
                }
                s.p.stopBandFromUi();
                for (int blk = songBlocks + 1; blk < songBlocks + 60; ++blk) s.block (blk, {});
                CHECK (stuckNotes (s.evs) == 0, "song: stuck notes at the end");
            }

            // DJ: tap a section and it starts on the next bar line; LOOP SECTION stays there; a STOP pad stops the band
            // on beat 4 even with no song playing; FOLLOW ME goes to the ending when your hands stop
            {
                Rig d (Trap, true);
                setParam (d.p, ids::bandStop, 2.0f);
                d.p.newSong (12);
                d.p.switchAt.store (0);   // CALLS LAND AT: the next bar (the phrase-end timing is checked below)
                const auto plan = d.p.songPlanCopy();
                int jumped = -1, jumpedBar = -1;
                double jumpBeat = -1, tapBeat = -1;
                int loopFirst = -1, loopWrapped = 0;
                for (int blk = 0; blk < 1400; ++blk)
                {
                    juce::MidiBuffer m;
                    if (blk == 1) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                    if (blk == 3) d.p.songOn.store (true);
                    if (blk == 300) { d.p.songJump.store (3); tapBeat = blk * 512.0 / beat; }
                    if (blk == 500) d.p.songLoopSection.store (true);
                    d.block (blk, m);
                    if (jumped < 0 && blk > 300 && d.p.songSecNow.load() == 3) { jumped = blk; jumpedBar = d.p.songBarNow.load(); jumpBeat = blk * 512.0 / beat; }
                    if (blk == 520) loopFirst = d.p.songSecNow.load();
                    if (blk > 520 && d.p.songSecNow.load() == loopFirst && d.p.songBarNow.load() == 0) loopWrapped = 1;
                    if (blk > 520 && d.p.songSecNow.load() != loopFirst) loopWrapped = -1000;
                }
                std::printf ("DJ: section 3 started %.2f beats after the tap (bar %d); looping section %d: %s\n",
                             jumpBeat - tapBeat, jumpedBar, loopFirst, loopWrapped > 0 ? "stayed and came round" : "no");
                CHECK (jumped > 0 && jumpedBar == 0 && jumpBeat - tapBeat <= 4.05, "DJ: a tapped section starts on the next bar line");
                CHECK (loopWrapped > 0 || plan.sections[(size_t) juce::jmax (0, loopFirst)].bars * 4 * beat > (1400 - 520) * 512,
                       "DJ: LOOP SECTION stays in the section");
            }
            {   // 1.15: a section you call lands at the END OF THE PHRASE (the default), with a fill into it
                Rig e (Trap, true);
                setParam (e.p, ids::bandStop, 2.0f);
                e.p.newSong (12);
                int jumped = -1, barBefore = -1, secBefore = -1, barsBefore = 0;
                double tapBeat = -1, jumpBeat = -1;
                const auto plan = e.p.songPlanCopy();
                for (int blk = 0; blk < 1600 && jumped < 0; ++blk)
                {
                    juce::MidiBuffer m;
                    if (blk == 1) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                    if (blk == 3) e.p.songOn.store (true);
                    if (blk == 300) { e.p.command (VesperProcessor::CmdGoTo, 3); tapBeat = blk * 512.0 / beat; }   // well into the bar
                    const int sb = e.p.songSecNow.load(), bb = e.p.songBarNow.load();
                    e.block (blk, m);
                    if (blk > 300 && e.p.songSecNow.load() == 3 && sb != 3)
                    {
                        jumped = blk;
                        jumpBeat = blk * 512.0 / beat;
                        barBefore = bb;
                        secBefore = sb;
                        barsBefore = sb >= 0 && sb < (int) plan.sections.size() ? plan.sections[(size_t) sb].bars : 0;
                    }
                }
                std::printf ("phrase end: the called section started %.2f beats after the call, after bar %d of %d\n", jumpBeat - tapBeat, barBefore + 1, barsBefore);
                CHECK (jumped > 0 && ((barBefore + 1) % 4 == 0 || barBefore + 1 >= barsBefore) && jumpBeat - tapBeat <= 16.05,
                       "CALLS LAND AT the end of the phrase (after bar %d of section %d)", barBefore + 1, secBefore);
            }
            {   // 1.18 SPICE: turned down, the chord you play comes out plainer (a triad); in the middle, exactly as written
                auto playAt = [&] (int spice) -> PlayedInfo
                {
                    Rig r (Soul, true);
                    r.p.ui.keysMode = 1;   // PADS: pad 1 is the genre's I chord (a maj9 in R&B)
                    r.p.ui.spice = spice;
                    r.p.applyUiState();
                    for (int blk = 0; blk < 40; ++blk) r.block (blk, blk == 2 ? at (48, true) : juce::MidiBuffer());
                    PlayedInfo info;
                    r.p.getLastPlayed (info);
                    return info;
                };
                const auto plain = playAt (10), asWritten = playAt (50);
                std::printf ("spice: pad 1 at SPICE 10 = %s (%d notes), at 50 = %s (%d notes)\n", chordName (plain.chord, false).c_str(), plain.notes.size(),
                             chordName (asWritten.chord, false).c_str(), asWritten.notes.size());
                CHECK (plain.chord.valid() && chordIntervals (plain.chord).size() == 3, "SPICE 10: pad 1 should play a triad (%s)", chordName (plain.chord, false).c_str());
                CHECK (asWritten.chord.valid() && chordIntervals (asWritten.chord).size() >= 4, "SPICE 50: pad 1 as written (%s)", chordName (asWritten.chord, false).c_str());
            }
            {   // 1.17 KEY CHANGE: the chord you're holding moves up a half step on the line, and the band's bass with it
                Rig r (Pop, true);
                r.p.switchAt.store (0);   // the next bar
                PlayedInfo before, after;
                int bassBefore = -1, bassAfter = -1;
                for (int blk = 0; blk < 600; ++blk)
                {
                    if (blk == 150) { r.p.getLastPlayed (before); r.p.command (VesperProcessor::CmdKeyChange, KeyUpHalf); }
                    r.block (blk, blk == 1 ? at (60, true) : juce::MidiBuffer());
                }
                r.p.getLastPlayed (after);
                for (auto& e : r.evs)
                    if (e.m.isNoteOn() && e.m.getChannel() == 2)
                    {
                        if (e.t < 150 * 512) bassBefore = e.m.getNoteNumber() % 12;
                        else if (e.t > 260 * 512) bassAfter = e.m.getNoteNumber() % 12;
                    }
                std::printf ("key change: %s -> %s (%s), bass %d -> %d\n", chordName (before.chord, false).c_str(), chordName (after.chord, false).c_str(),
                             r.p.keyNowText().toRawUTF8(), bassBefore, bassAfter);
                CHECK (before.chord.valid() && after.chord.valid() && after.chord.root == (before.chord.root + 1) % 12 && after.chord.quality == before.chord.quality,
                       "KEY CHANGE: the held chord should move up a half step (%s -> %s)", chordName (before.chord, false).c_str(), chordName (after.chord, false).c_str());
                CHECK (r.p.keyShiftShown.load() == 1, "KEY CHANGE: the screen should say up 1");
                CHECK (bassBefore < 0 || bassAfter < 0 || bassAfter != bassBefore, "KEY CHANGE: the bass should move too (%d -> %d)", bassBefore, bassAfter);
            }
            {   // 1.17 SONG SETUP: QUIET plays softer than LOUD; JAM keeps the drums moving bar to bar, MINIMAL doesn't add any
                auto run = [&] (int feel, double& vel, int& drumBars, int& fills)
                {
                    Rig r (Trap, true);
                    r.p.setSongFeel (feel);
                    r.p.newSong (12);
                    for (int blk = 0; blk < 3200; ++blk)
                    {
                        juce::MidiBuffer m;
                        if (blk == 1) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                        if (blk == 3) r.p.songOn.store (true);
                        r.block (blk, m);
                    }
                    const int bar = 4 * beat;
                    std::map<int, std::multiset<std::pair<int, int>>> perBar;
                    double sum = 0; int n = 0;
                    for (auto& e : r.evs)
                    {
                        if (! e.m.isNoteOn()) continue;
                        if (e.m.getChannel() == 10) { if (e.t >= 4 * beat) perBar[(int) ((e.t - 4 * beat) / bar)].insert ({ (int) (((e.t - 4 * beat) % bar) / 1500), e.m.getNoteNumber() }); }
                        else if (e.m.getChannel() != 1) { sum += e.m.getVelocity(); ++n; }
                    }
                    std::set<std::multiset<std::pair<int, int>>> kinds;
                    for (auto& [b, hits] : perBar) if (b < 16) kinds.insert (hits);
                    vel = n > 0 ? sum / n : 0.0;
                    drumBars = (int) kinds.size();
                    fills = 0;
                    for (auto& [b, hits] : perBar) if (b < 16) for (auto& h : hits) if (h.second >= 41 && h.second <= 50 && h.second != 42 && h.second != 44 && h.second != 46) ++fills;
                };
                double vq = 0, vl = 0, vm = 0, vj = 0;
                int dq = 0, dl = 0, dm = 0, dj = 0, fq = 0, fl = 0, fm = 0, fj = 0;
                run (FeelQuiet, vq, dq, fq);
                run (FeelLoud, vl, dl, fl);
                run (FeelMinimal, vm, dm, fm);
                run (FeelJam, vj, dj, fj);
                std::printf ("song setup: band velocity QUIET %.0f / LOUD %.0f; different drum bars of 16: MINIMAL %d, JAM %d; tom hits MINIMAL %d, JAM %d\n",
                             vq, vl, dm, dj, fm, fj);
                CHECK (vq + 8.0 < vl, "SONG SETUP: QUIET should play softer than LOUD (%.0f vs %.0f)", vq, vl);
                CHECK (dj > dm, "SONG SETUP: JAM should vary the drums more than MINIMAL (%d vs %d)", dj, dm);
            }
            {   // 1.17 LEARN MY CHORDS: a section with no loop yet waits for you, records what you play, then plays it for you
                Rig r (Pop, true);
                r.p.learnChords.store (true);
                r.p.looper.bars.store (2);
                r.p.newSong (12);
                int armed = -1;
                for (int blk = 0; blk < 1300; ++blk)
                {
                    juce::MidiBuffer m;
                    if (blk == 3) r.p.songOn.store (true);
                    if (blk == 200) { armed = r.p.looper.state.load(); m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0); }
                    if (blk == 380) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                    if (blk == 400) m.addEvent (juce::MidiMessage::noteOn (1, 62, (juce::uint8) 100), 0);
                    if (blk == 540) m.addEvent (juce::MidiMessage::noteOff (1, 62), 0);
                    r.block (blk, m);
                }
                std::printf ("learn my chords: armed %d, loop A %s, looper %s\n", armed, (r.p.looper.filled.load() & 1u) ? "recorded" : "empty",
                             r.p.looper.playing() ? "playing it" : "not playing");
                CHECK (armed == Looper::Armed, "LEARN: the first section's empty loop should be waiting for you (%d)", armed);
                CHECK ((r.p.looper.filled.load() & 1u) != 0 && r.p.looper.playing(), "LEARN: the loop should be recorded and playing");
            }
            {   // 1.16 LATE CATCH: a call that comes in just after the phrase line (under a beat late) still makes that line
                Rig e (Trap, true);
                setParam (e.p, ids::bandStop, 2.0f);
                e.p.newSong (12);
                int secAfter = -1, barAfter = -1, secBefore = -1;
                for (int blk = 0; blk < 240; ++blk)
                {
                    juce::MidiBuffer m;
                    if (blk == 1) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                    if (blk == 3) e.p.songOn.store (true);
                    // the song starts on beat 4 (block 188); block 220 is about two thirds of a beat after that line
                    if (blk == 220) { secBefore = e.p.songSecNow.load(); e.p.command (VesperProcessor::CmdGoTo, 3); }
                    e.block (blk, m);
                    if (blk == 220) { secAfter = e.p.songSecNow.load(); barAfter = e.p.songBarNow.load(); }
                }
                std::printf ("late catch: called 0.7 beats after the phrase line: section %d -> %d (bar %d)\n", secBefore, secAfter, barAfter);
                CHECK (secBefore == 0 && secAfter == 3 && barAfter == 0, "LATE CATCH: a call just after the line should still make it (%d -> %d, bar %d)", secBefore, secAfter, barAfter);
            }
            {
                Rig pad (Funk, true);
                setParam (pad.p, ids::bandStop, 2.0f);
                int64_t stopBarStart = -1;
                for (int blk = 0; blk < 1100; ++blk)
                {
                    juce::MidiBuffer m;
                    if (blk == 1) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                    // tap STOP early in bar 5 (beats 16-20): it should land on that bar's beat 4
                    if (blk * 512 >= 16 * beat + 3000 && stopBarStart < 0) { pad.p.momentTap.store (MomStop); stopBarStart = 16 * beat; }
                    pad.block (blk, m);
                }
                int late = 0, before = 0;
                for (auto& e : pad.evs)
                {
                    if (! e.m.isNoteOn() || e.m.getChannel() == 1) continue;
                    if (e.t >= stopBarStart + 3 * beat + 300 && e.t < stopBarStart + 4 * beat - 300) ++late;
                    if (e.t >= stopBarStart && e.t < stopBarStart + 3 * beat) ++before;
                }
                std::printf ("STOP pad (no song): %d band notes in beats 1-3, %d after beat 4\n", before, late);
                if (late > 0)
                    for (auto& e : pad.evs)
                        if (e.m.isNoteOn() && e.m.getChannel() != 1 && e.t >= stopBarStart + 3 * beat + 300 && e.t < stopBarStart + 4 * beat - 300)
                            std::printf ("   late: ch %d note %d at beat %.3f\n", e.m.getChannel(), e.m.getNoteNumber(), (double) e.t / beat);
                CHECK (before > 0 && late == 0, "STOP pad: the band stops on beat 4 (%d after)", late);
            }
            {
                Rig f (Pop, true);
                setParam (f.p, ids::bandStop, 2.0f);
                f.p.newSong (3);
                f.p.followMe.store (true);
                const auto plan = f.p.songPlanCopy();
                int lastSeen = -1, endedAt = -1;
                for (int blk = 0; blk < 6500; ++blk)
                {
                    juce::MidiBuffer m;
                    // a few bars of playing, then the hands come off the keys
                    for (int bar = 0; bar < 6; ++bar)
                    {
                        const int64_t on = (int64_t) bar * 4 * beat + 200, off = (int64_t) (bar + 1) * 4 * beat - 300;
                        if (on >= (int64_t) blk * 512 && on < (int64_t) blk * 512 + 512) m.addEvent (juce::MidiMessage::noteOn (1, 60 + (bar % 2) * 5, (juce::uint8) 90), (int) (on - (int64_t) blk * 512));
                        if (off >= (int64_t) blk * 512 && off < (int64_t) blk * 512 + 512) m.addEvent (juce::MidiMessage::noteOff (1, 60 + (bar % 2) * 5), (int) (off - (int64_t) blk * 512));
                    }
                    if (blk == 2) f.p.songOn.store (true);
                    f.block (blk, m);
                    if (f.p.songSecNow.load() >= 0) lastSeen = f.p.songSecNow.load();
                    if (endedAt < 0 && blk > 10 && ! f.p.songOn.load()) endedAt = blk;
                }
                const int outro = (int) plan.sections.size() - 1;
                std::printf ("FOLLOW ME: hands off after 6 bars -> went to %s, song over after %.0f bars\n",
                             lastSeen >= 0 ? plan.sections[(size_t) lastSeen].label.c_str() : "-", endedAt * 512.0 / beat / 4.0);
                CHECK (lastSeen == outro && endedAt > 0 && endedAt * 512.0 / beat / 4.0 < 6 + 8 + plan.sections.back().bars + 2,
                       "FOLLOW ME: no hands -> the ending, then it stops");
            }
            // the song as you shaped it comes back with the project
            {
                Rig k (Soul, true);
                k.p.newSong (77);
                k.p.editSong ([] (SongPlan& pl) { pl.sections[1].mask[2] = 0x0005; pl.sections[1].moment[3] = MomHalf; });
                k.p.songLoopSection.store (true);
                juce::MemoryBlock st;
                k.p.getStateInformation (st);
                std::unique_ptr<juce::AudioProcessor> b2 (createPluginFilter());
                auto& q = dynamic_cast<VesperProcessor&> (*b2);
                q.setStateInformation (st.getData(), (int) st.getSize());
                const auto a = k.p.songPlanCopy(), b = q.songPlanCopy();
                CHECK (b.number == 77 && a.describe() == b.describe() && b.sections[1].mask[2] == 0x0005 && b.sections[1].moment[3] == MomHalf
                       && q.songLoopSection.load(), "song: the shaped song should come back with the project");
            }
        }

        // P. MIDI CABLE: FL hands the cable straight back to VESPER (its channel selected while recording). The chords,
        // the band and the drums must come out exactly as if nothing came back - first echo included, legato key changes too.
        {
            auto script = [&] (int blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                auto event = [&] (int64_t sample, int key, bool on, int vel) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) vel) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                event (4 * beat + 300, 60, true, 100);                    // the 1 after a bar of count-in
                event (8 * beat + 100, 64, true, 90);                     // the next key while still holding the first
                event (8 * beat + 1500, 60, false, 0);                    // ...then letting go of the first
                event (12 * beat, 65, true, 96); event (12 * beat + 900, 64, false, 0);
                event (16 * beat - 300, 65, false, 0);
                return m;
            };
            auto take = [&] (bool echo)
            {
                auto r = std::make_unique<Rig> (House, true);
                r->p.cableTestMode = true;
                for (int blk = 0; blk < 900; ++blk)
                {
                    auto m = script (blk);
                    if (echo && blk >= 2)   // what went out two blocks ago comes back in
                        for (auto& e : r->evs)
                            if (e.t >= (int64_t) (blk - 2) * 512 && e.t < (int64_t) (blk - 1) * 512 && (e.m.isNoteOn() || e.m.isNoteOff()))
                                m.addEvent (e.m, (int) (e.t - (int64_t) (blk - 2) * 512));
                    r->block (blk, m);
                }
                r->p.stopBandFromUi();
                for (int blk = 900; blk < 940; ++blk) r->block (blk, {});
                return r;
            };
            auto clean = take (false), looped = take (true);
            auto sig = [] (const std::vector<Ev>& evs)
            {
                std::vector<std::tuple<int64_t, int, int, bool>> v;
                for (auto& e : evs) if (e.m.isNoteOn() || e.m.isNoteOff()) v.emplace_back (e.t, e.m.getChannel(), e.m.getNoteNumber(), e.m.isNoteOn());
                return v;
            };
            const auto a = sig (clean->evs), b = sig (looped->evs);
            size_t same = 0;
            while (same < a.size() && same < b.size() && a[same] == b[same]) ++same;
            std::printf ("cable echo: %d events clean, %d with the echo coming back, identical for the first %d, loop warnings %u\n",
                         (int) a.size(), (int) b.size(), (int) same, looped->p.loopEvents.load());
            if (same < a.size() && same < b.size())
                std::printf ("  first difference at %.3f beats: ch %d note %d\n", std::get<0> (b[same]) / (double) beat, std::get<1> (b[same]), std::get<2> (b[same]));
            CHECK (a.size() > 40 && a == b, "cable echo: VESPER must play exactly the same with its notes coming back");
            CHECK (looped->p.loopEvents.load() == 0, "cable echo: no loop clean-up (it cuts your chords)");
            CHECK (stuckNotes (looped->evs) == 0, "cable echo: stuck notes");

            // VESPER SELECTED in FL's channel rack: FL feeds the cable into the selected channel too - VESPER's own notes
            // come back relabelled as channel 1 (your keyboard's), and your keys can arrive twice (the lock + the
            // selection), with FL cutting the first copy. All of it must play exactly like the clean take.
            auto takeSelected = [&] (bool relabel, bool doubled)
            {
                auto r = std::make_unique<Rig> (House, true);
                r->p.cableTestMode = true;
                for (int blk = 0; blk < 900; ++blk)
                {
                    juce::MidiBuffer m;
                    for (const auto meta : script (blk))
                    {
                        const auto e = meta.getMessage();
                        m.addEvent (e, meta.samplePosition);
                        if (doubled && e.isNoteOn())
                        {
                            m.addEvent (e, meta.samplePosition);                                            // the second copy
                            m.addEvent (juce::MidiMessage::noteOff (1, e.getNoteNumber()), juce::jmin (511, meta.samplePosition + 1));   // FL cutting the first
                        }
                        if (doubled && e.isNoteOff()) m.addEvent (e, meta.samplePosition);
                    }
                    if (relabel && blk >= 2)
                        for (auto& e : r->evs)
                            if (e.t >= (int64_t) (blk - 2) * 512 && e.t < (int64_t) (blk - 1) * 512 && (e.m.isNoteOn() || e.m.isNoteOff()))
                            {
                                auto x = e.m;
                                x.setChannel (1);
                                m.addEvent (x, (int) (e.t - (int64_t) (blk - 2) * 512));
                            }
                    r->block (blk, m);
                }
                r->p.stopBandFromUi();
                for (int blk = 900; blk < 940; ++blk) r->block (blk, {});
                return r;
            };
            for (int mode = 0; mode < 3; ++mode)
            {
                const bool relabel = mode != 1, doubled = mode != 0;
                auto sel = takeSelected (relabel, doubled);
                const auto c = sig (sel->evs);
                size_t same2 = 0;
                while (same2 < a.size() && same2 < c.size() && a[same2] == c[same2]) ++same2;
                const char* what = mode == 0 ? "its notes back as ch 1" : mode == 1 ? "every key twice" : "both";
                std::printf ("cable, VESPER selected (%s): %d events (clean %d), identical for the first %d, ignored %u\n",
                             what, (int) c.size(), (int) a.size(), (int) same2, sel->p.cableIgnored.load());
                if (same2 < a.size() && same2 < c.size())
                    std::printf ("  first difference at %.3f beats: ch %d note %d %s (clean: ch %d note %d %s)\n", std::get<0> (c[same2]) / (double) beat,
                                 std::get<1> (c[same2]), std::get<2> (c[same2]), std::get<3> (c[same2]) ? "on" : "off",
                                 std::get<1> (a[same2]), std::get<2> (a[same2]), std::get<3> (a[same2]) ? "on" : "off");
                CHECK (a == c, "cable, VESPER selected (%s): must play exactly like the clean take", what);
                CHECK (stuckNotes (sel->evs) == 0 && sel->p.loopEvents.load() == 0, "cable, VESPER selected (%s): stuck notes / loop clean-up", what);
            }
            // the channel rule: nothing goes out on the keyboard's channel, and keys on any other channel are ignored
            int onCh1 = 0;
            for (auto& e : looped->evs) if ((e.m.isNoteOn() || e.m.isNoteOff()) && e.m.getChannel() == 1) ++onCh1;
            CHECK (onCh1 == 0, "cable: nothing may go out on the keyboard's channel (%d)", onCh1);
            Rig k (House, true);
            k.p.cableTestMode = true;
            const auto note = k.p.keepKeyboardChannelFree();
            const int chordsNow = (int) k.p.apvts.getRawParameterValue (ids::chordCh)->load();
            std::printf ("cable: %s\n", note.toRawUTF8());
            CHECK (chordsNow != 1 && note.isNotEmpty(), "cable: the chords should move off channel 1 (%d)", chordsNow);
            k.block (0, {});
            { juce::MidiBuffer m; m.addEvent (juce::MidiMessage::noteOn (3, 60, (juce::uint8) 100), 0); k.block (1, m); }
            for (int blk = 2; blk < 40; ++blk) k.block (blk, {});
            int onsWrong = 0;
            for (auto& e : k.evs) if (e.m.isNoteOn()) ++onsWrong;
            { juce::MidiBuffer m; m.addEvent (juce::MidiMessage::noteOff (3, 60), 0); m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 10); k.block (40, m); }
            for (int blk = 41; blk < 120; ++blk) k.block (blk, {});
            int onsRight = 0, onCh1b = 0;
            for (auto& e : k.evs) if (e.m.isNoteOn()) { ++onsRight; if (e.m.getChannel() == 1) ++onCh1b; }
            CHECK (onsWrong == 0 && onsRight > 0 && onCh1b == 0, "cable: keys only from channel 1, nothing out on it (%d, %d, %d)", onsWrong, onsRight, onCh1b);
            // fast repeats at one velocity (a keyboard without velocity) - chord keys and a SPLIT right hand - must never trip a guard
            {
                Rig f (House, true);
                f.p.cableTestMode = true;
                f.p.keepKeyboardChannelFree();
                f.p.ui.split = true;
                f.p.ui.splitNote = 60;
                f.p.applyUiState();
                f.block (0, {});
                int pressed = 0;
                for (int blk = 1; blk < 700; ++blk)
                {
                    juce::MidiBuffer m;
                    if (blk % 6 == 1) { m.addEvent (juce::MidiMessage::noteOn (1, (blk / 6) % 2 ? 64 : 72, (juce::uint8) 127), 0); ++pressed; }
                    if (blk % 6 == 4) m.addEvent (juce::MidiMessage::noteOff (1, (blk / 6) % 2 ? 64 : 72), 0);
                    if (blk % 24 == 1) m.addEvent (juce::MidiMessage::noteOn (1, 48, (juce::uint8) 127), 5);
                    if (blk % 24 == 13) m.addEvent (juce::MidiMessage::noteOff (1, 48), 5);
                    f.block (blk, m);
                }
                int rightHand = 0;
                const int chordsCh = (int) f.p.apvts.getRawParameterValue (ids::chordCh)->load();
                for (auto& e : f.evs) if (e.m.isNoteOn() && e.m.getChannel() == chordsCh && (e.m.getNoteNumber() == 64 || e.m.getNoteNumber() == 72)) ++rightHand;
                std::printf ("cable: %d fast right-hand notes pressed, %d played, loop warnings %u\n", pressed, rightHand, f.p.loopEvents.load());
                CHECK (rightHand >= pressed && f.p.loopEvents.load() == 0, "cable: fast repeats must all play, no loop guard (%d of %d)", rightHand, pressed);
                {   // let go of everything first
                    juce::MidiBuffer m;
                    for (int n : { 48, 64, 72 }) m.addEvent (juce::MidiMessage::noteOff (1, n), 0);
                    f.block (700, m);
                }
                f.p.stopBandFromUi();
                for (int blk = 701; blk < 800; ++blk) f.block (blk, {});
                if (stuckNotes (f.evs) != 0)
                {
                    int on[16][128] = {};
                    for (auto& e : f.evs) { if (e.m.isNoteOn()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 1; else if (e.m.isNoteOff()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 0; }
                    for (int c = 0; c < 16; ++c) for (int n = 0; n < 128; ++n) if (on[c][n]) std::printf ("   stuck: ch %d note %d\n", c + 1, n);
                    if (std::getenv ("VDEBUG"))
                        for (auto& e : f.evs) if ((e.m.isNoteOn() || e.m.isNoteOff()) && e.m.getChannel() == chordsCh && e.t > 600 * 512)
                            std::printf ("   %lld %s %d\n", (long long) e.t, e.m.isNoteOn() ? "on " : "off", e.m.getNoteNumber());
                }
                CHECK (stuckNotes (f.evs) == 0, "cable: fast repeats left notes stuck");
            }
        }
    }

    // 8. state round trip
    p.ui.keyRoot = 7;
    p.ui.genre = Jazz;
    p.ui.palette[3].chord = makeChord (1, "7#9", 5);
    juce::MemoryBlock mb;
    p.getStateInformation (mb);
    std::unique_ptr<juce::AudioProcessor> base2 (createPluginFilter());
    auto& p2 = dynamic_cast<VesperProcessor&> (*base2);
    p2.setStateInformation (mb.getData(), (int) mb.getSize());
    CHECK (p2.ui.keyRoot == 7 && p2.ui.genre == Jazz && p2.ui.keysMode == 1, "state should restore key/genre/mode");
    CHECK (p2.ui.palette[3].chord == makeChord (1, "7#9", 5), "state should restore edited pads");

    // 9. editor screenshots (all three tabs, all themes)
    p.ui.keyRoot = 0;
    p.ui.genre = Soul;
    p.ui.keysMode = 0;
    p.setPalette (buildPalette (0, 0, Soul, 0));
    run (p, note (74, true));   // a 9th-row chord so the panels have something to show
    setParam (p, rhythmInfo (RArpUp).id, 1.0f);
    setParam (p, rhythmInfo (RWaterfall).id, 1.0f);
    setParam (p, feelInfo (FAccentTop).id, 1.0f);
    setParam (p, timingInfo (TSwing).id, 1.0f);
    p.extTrigType.store (2);
    p.extTrigNum.store (64);
    p.applyBandGenre (Trap);
    run (p, note (74, false));
    run (p, note (74, true));
    for (int tab = 0; tab < 5; ++tab)
    {
        p.ui.tab = tab;
        p.ui.theme = tab == 1 ? 1 : 0;
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_" + juce::String (tab) + ".png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
        std::printf ("editor tab %d -> %s (%dx%d)\n", tab, out.getFullPathName().toRawUTF8(), img.getWidth(), img.getHeight());
    }

    {
        p.ui.tab = 0;
        p.ui.theme = 2;
        p.ui.keysMode = 1;
        p.applyUiState();
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_pads.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
    }
    {
        // SPLIT: chords on the left, your own notes on the right
        std::unique_ptr<juce::AudioProcessor> sb (createPluginFilter());
        auto& sp = dynamic_cast<VesperProcessor&> (*sb);
        sp.setPlayConfigDetails (0, 2, 48000.0, 512);
        sp.prepareToPlay (48000.0, 512);
        setParam (sp, ids::humanize, 0.0f);
        sp.ui.split = true;
        sp.ui.splitNote = 60;
        sp.applyUiState();
        run (sp, {});

        auto so = run (sp, note (64, true, 90));
        int ons = 0, onNote = -1, onCh = -1, onVel = -1;
        for (auto& m : so.msgs) if (m.isNoteOn()) { ++ons; onNote = m.getNoteNumber(); onCh = m.getChannel(); onVel = m.getVelocity(); }
        CHECK (ons == 1 && onNote == 64 && onCh == 1 && onVel == 90, "split: right hand E should play just E (got %d notes, note %d ch %d vel %d)", ons, onNote, onCh, onVel);
        so = run (sp, note (48, true));
        Notes sn = onsOf (so);
        CHECK (sn.size() >= 3, "split: left hand C should play a chord, got %d notes", sn.size());
        for (int i = 0; i < sn.size(); ++i) CHECK ((pcMask (makeChord (0, "")) >> (sn[i] % 12)) & 1, "split: left C (triads row) should be C major");
        // settings change while the right-hand key is down: its note-off still lands
        sp.ui.split = false;
        sp.applyUiState();
        so = run (sp, note (64, false));
        int offs = 0;
        for (auto& m : so.msgs) if (m.isNoteOff() && m.getNoteNumber() == 64) ++offs;
        CHECK (offs == 1, "split: E must be released after split was switched off (%d offs)", offs);
        so = run (sp, note (48, false));
        offs = 0;
        for (auto& m : so.msgs) if (m.isNoteOff()) ++offs;
        CHECK (offs == sn.size(), "split: releasing the left key should end the chord (%d of %d)", offs, sn.size());

        // right hand on channel 5, an octave up, snapped into C major
        sp.ui.split = true;
        sp.ui.rightCh = 5;
        sp.ui.rightOct = 1;
        sp.ui.rightSnap = true;
        sp.applyUiState();
        so = run (sp, note (61, true));
        onNote = onCh = -1; ons = 0;
        for (auto& m : so.msgs) if (m.isNoteOn()) { ++ons; onNote = m.getNoteNumber(); onCh = m.getChannel(); }
        CHECK (ons == 1 && onNote == 72 && onCh == 5, "split: C# +1 oct snapped should be C on ch 5 (got %d on ch %d)", onNote, onCh);
        so = run (sp, note (61, false));
        offs = 0;
        for (auto& m : so.msgs) if (m.isNoteOff() && m.getNoteNumber() == 72 && m.getChannel() == 5) ++offs;
        CHECK (offs == 1, "split: snapped note should turn off on ch 5");

        // left hand chord family: 9THS under the split
        sp.ui.leftRow = 6;
        sp.applyUiState();
        so = run (sp, note (48, true));
        sn = onsOf (so);
        bool hasNinth = false;
        for (int i = 0; i < sn.size(); ++i) { hasNinth |= sn[i] % 12 == 2; CHECK ((pcMask (makeChord (0, "maj9")) >> (sn[i] % 12)) & 1, "split: 9THS family C should be Cmaj9"); }
        CHECK (hasNinth, "split: 9THS family chord should have the 9th");
        run (sp, note (48, false));

        // PADS mode: the octave left of the split plays pads 13-24
        sp.ui.keysMode = 1;
        sp.ui.padBank = 1;
        sp.applyUiState();
        so = run (sp, note (48, true));
        sn = onsOf (so);
        const auto pad13 = sp.ui.palette[12].chord;
        CHECK (sn.size() >= 3, "split pads: key 48 should play pad 13");
        for (int i = 0; i < sn.size(); ++i) CHECK ((pcMask (pad13) >> (sn[i] % 12)) & 1, "split pads: note %d not in pad 13", sn[i]);
        run (sp, note (48, false));

        // learn the split point from the next key
        sp.splitLearnArmed.store (true);
        const auto before = sp.splitLearnCount.load();
        so = run (sp, note (55, true));
        int any = 0;
        for (auto& m : so.msgs) if (m.isNoteOn()) ++any;
        CHECK (sp.splitLearned.load() == 55 && sp.splitLearnCount.load() == before + 1 && any == 0,
               "split learn: key 55 should be learned silently");
        run (sp, note (55, false));
        std::printf ("split keyboard: ok\n");

        // the editor with split on (screenshot)
        sp.ui.keysMode = 0; sp.ui.leftRow = -1; sp.ui.rightCh = 0; sp.ui.rightOct = 0; sp.ui.rightSnap = false; sp.ui.tab = 1;
        sp.ui.splitNote = 60; sp.ui.leftRow = 5;
        sp.applyUiState();
        std::unique_ptr<juce::AudioProcessorEditor> ed (sp.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_split.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
    }
    {
        // the BAND tab with more tracks, HOLD / RING and key strips
        p.addTrack();
        p.addTrack();
        p.setTrackValue (3, TpMode, (float) ModeHold);
        p.setTrackValue (7, TpMode, (float) ModeRing);
        p.trackKeys[2].store ((1 << 4) | (1 << 11));
        p.chordKeys.store (1 << 9);
        setParam (p, ids::bandSwing, 33.0f);
        p.ui.tab = 4;
        p.ui.theme = 0;
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_band_tracks.png");
        {
            p.ui.songTab = true;
            p.ui.tab = 5;
            p.newSong (42);
            std::unique_ptr<juce::AudioProcessorEditor> ed2 (p.createEditor());
            ed2->setVisible (true);
            for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
            auto img2 = ed2->createComponentSnapshot (ed2->getLocalBounds(), true, 1.0f);
            juce::File out2 ("/tmp/claude-0/shot_song.png");
            out2.deleteFile();
            juce::FileOutputStream os2 (out2);
            juce::PNGImageFormat png2;
            png2.writeImageToStream (img2, os2);
            p.ui.tab = 4;
        }
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
    }
    {
        // a fresh VESPER's BAND tab: every part off
        std::unique_ptr<juce::AudioProcessor> fb (createPluginFilter());
        auto& fp = dynamic_cast<VesperProcessor&> (*fb);
        fp.ui.tab = 4;
        std::unique_ptr<juce::AudioProcessorEditor> ed (fp.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_band_off.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
    }
    // ---- 1.15: the cable on, the chords on the keyboard's channel (so they go out somewhere nobody listens), a KEYS track
    // on HOLD: the HOLD track plays the chord exactly as styled - the strum, the style's rhythm and the EXT notes
    {
        auto holdRig = [] (VesperProcessor& p)
        {
            p.prepareToPlay (48000.0, 512);
            p.cableTestMode = true;
            p.keyboardCh.store (1);
            setParam (p, ids::chordCh, 1.0f);
            for (int t = 0; t < vesper::maxBandTracks; ++t) setParam (p, ids::track (t, "On").toRawUTF8(), 0.0f);
            setParam (p, ids::track (0, "Type").toRawUTF8(), (float) vesper::BKeys);
            setParam (p, ids::track (0, "Mode").toRawUTF8(), (float) vesper::ModeHold);
            setParam (p, ids::track (0, "Ch").toRawUTF8(), 5.0f);
            setParam (p, ids::track (0, "On").toRawUTF8(), 1.0f);
            run (p, {}, 2);
        };
        auto positionsOn = [] (const Out& o, int ch)
        {
            std::set<int> at;
            for (size_t i = 0; i < o.msgs.size(); ++i) if (o.msgs[i].isNoteOn() && o.msgs[i].getChannel() == ch) at.insert (o.pos[i]);
            return at;
        };
        {   // STRUM: the HOLD track's notes roll in, one after another
            VesperProcessor p;
            holdRig (p);
            setParam (p, ids::strum, 60.0f);
            const auto o = run (p, note (60, true), 12);
            const auto at = positionsOn (o, 5);
            CHECK (at.size() >= 3, "HOLD follows the strum: the keys track's notes should roll in (%d different times)", (int) at.size());
        }
        {   // PLAIN HOLD: the old way - all at once
            VesperProcessor p;
            holdRig (p);
            p.setTrackFlag (0, VesperProcessor::FlagPlainHold, true);
            setParam (p, ids::strum, 60.0f);
            const auto o = run (p, note (60, true), 12);
            const auto at = positionsOn (o, 5);
            CHECK (at.size() == 1, "PLAIN HOLD: all at once (%d different times)", (int) at.size());
        }
        {   // a STYLE (PULSE): the HOLD track repeats the chord in rhythm, not one long chord
            VesperProcessor p;
            holdRig (p);
            setParam (p, vesper::rhythmInfo (vesper::RPulse).id, 1.0f);
            const auto o = run (p, note (60, true), 200);
            int ons = 0;
            for (auto& m : o.msgs) if (m.isNoteOn() && m.getChannel() == 5) ++ons;
            CHECK (ons >= 12, "HOLD follows the style: PULSE should keep striking the chord on the keys track (%d notes)", ons);
        }
        {   // EXT: the extension notes come out on the HOLD track too
            VesperProcessor p;
            holdRig (p);
            auto o = run (p, note (60, true), 4);
            const auto before = onsOf (o, 5);
            p.uiExt (true);
            o = run (p, {}, 6);
            const auto added = onsOf (o, 5);
            CHECK (before.size() >= 3 && added.size() >= 1, "HOLD follows EXT: extension notes on the keys track (%d then %d)", before.size(), added.size());
        }
        std::printf ("HOLD tracks follow the chord's style, strum and EXT (with the cable on)\n");
    }

    std::printf (failures == 0 ? "PROCESSOR TESTS PASSED\n" : "%d FAILURES\n", failures);
    return failures == 0 ? 0 : 1;
}
