// VESPER chord engine self-test: builds with plain g++, no JUCE.
#include "../core/Theory.h"
#include "../core/Voicing.h"
#include "../core/Guitar.h"
#include "../core/Perform.h"
#include "../core/Band.h"
#include "../core/Song.h"
#include "../core/Fills.h"
#include "../core/Rework.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <set>
#include <vector>
#include <string>

using namespace vesper;

static int failures = 0;
#define CHECK(cond, ...) do { if (! (cond)) { ++failures; if (failures < 40) { std::printf ("FAIL: "); std::printf (__VA_ARGS__); std::printf ("\n"); } } } while (0)

static std::string notesStr (const Notes& n)
{
    std::string s;
    for (int i = 0; i < n.size(); ++i) s += midiName (n[i], false) + " ";
    return s;
}

int main()
{
    // 1. qualities
    CHECK (numQualities() >= 75, "only %d chord types", numQualities());
    for (int q = 0; q < numQualities(); ++q)
    {
        CHECK (! qualities()[(size_t) q].iv.empty(), "empty quality %d", q);
        for (int q2 = q + 1; q2 < numQualities(); ++q2)
            CHECK (qualities()[(size_t) q].suffix != qualities()[(size_t) q2].suffix, "duplicate suffix %s", qualities()[(size_t) q].suffix.c_str());
    }

    // 2. voicings: every chord, every root, every style, every variant
    long voicings = 0, missingThird = 0;
    for (int q = 0; q < numQualities(); ++q)
        for (int r = 0; r < 12; ++r)
        {
            Chord c; c.root = r; c.quality = q;
            const int mask = pcMask (c);
            const int rel = tonesMask (c);
            int third = -1;
            for (int x : { 4, 3, 5, 2 }) if ((rel >> x) & 1) { third = (x + r) % 12; break; }
            for (int s = 0; s < numStyles; ++s)
            {
                const int nv = numVariants (c, s);
                CHECK (nv >= 1, "no variants");
                for (int v = 0; v < nv; ++v)
                {
                    const Notes n = fitToCenter (buildVoicing (c, s, v), 60);
                    ++voicings;
                    CHECK (n.size() >= 2, "%s %s v%d: too few notes", chordName (c, false).c_str(), styleName (s), v);
                    bool hasThird = third < 0;
                    for (int i = 0; i < n.size(); ++i)
                    {
                        CHECK (n[i] >= 0 && n[i] <= 127, "note out of range");
                        CHECK ((mask >> (n[i] % 12)) & 1, "%s %s v%d: wrong note %s", chordName (c, false).c_str(), styleName (s), v, midiName (n[i], false).c_str());
                        if (n[i] % 12 == third) hasThird = true;
                        for (int j = i + 1; j < n.size(); ++j) CHECK (n[i] != n[j], "duplicate note");
                    }
                    if (! hasThird && s != PowerRock && s != Quartal) ++missingThird;
                    if (s == Close || s == Open)
                        for (int pc = 0; pc < 12; ++pc)
                            if ((mask >> pc) & 1)
                            {
                                bool found = false;
                                for (int i = 0; i < n.size(); ++i) if (n[i] % 12 == pc) found = true;
                                CHECK (found, "%s %s missing a chord tone", chordName (c, false).c_str(), styleName (s));
                            }
                }
            }
        }
    CHECK (missingThird == 0, "%ld voicings lost their 3rd", missingThird);
    std::printf ("voicings checked: %ld\n", voicings);

    // 3. guitar shapes
    int noShape = 0, shapes = 0;
    for (int q = 0; q < numQualities(); ++q)
        for (int r = 0; r < 12; ++r)
        {
            Chord c; c.root = r; c.quality = q;
            Shape s[maxShapes];
            const int n = findShapes (c, s, maxShapes);
            shapes += n;
            if (n == 0) { ++noShape; std::printf ("  no guitar shape: %s\n", chordName (c, false).c_str()); }
            for (int i = 0; i < n; ++i)
            {
                const Notes notes = shapeNotes (s[i]);
                CHECK (notes.size() >= 3, "guitar shape too thin");
                CHECK (notes[0] % 12 == r, "%s guitar shape bass is not the root", chordName (c, false).c_str());
                for (int k = 0; k < notes.size(); ++k) CHECK ((pcMask (c) >> (notes[k] % 12)) & 1, "guitar wrong note");
                CHECK (s[i].highestFret() - s[i].lowestFret() <= 3 || s[i].lowestFret() == 0, "guitar stretch too wide");
            }
        }
    CHECK (noShape == 0, "%d chords with no guitar shape", noShape);
    std::printf ("guitar shapes: %d\n", shapes);

    // slash chord guitar shape
    {
        const Chord ce = makeChord (0, "", 4);
        Shape s[maxShapes];
        const int n = findShapes (ce, s, maxShapes);
        CHECK (n > 0 && shapeNotes (s[0])[0] % 12 == 4, "C/E guitar shape should have E in the bass");
    }

    // 4. scale maps
    for (int sc = 0; sc < numScales(); ++sc)
        for (int key = 0; key < 12; ++key)
            for (int g = 0; g < numGenres; ++g)
            {
                const ScaleMap m = buildScaleMap (key, sc, g);
                int white = 0, filled = 0;
                const auto& iv = scales()[(size_t) sc].iv;
                const int whitePos[] = { 0, 2, 4, 5, 7, 9, 11 };
                for (int note = 0; note < 128; ++note)
                {
                    const int pc = note % 12;
                    const bool isWhite = pc == 0 || pc == 2 || pc == 4 || pc == 5 || pc == 7 || pc == 9 || pc == 11;
                    const auto& slot = m.keys[(size_t) note];
                    if (isWhite)
                    {
                        // a white key may only be empty when no chord type at all fits on that degree
                        int w = 0;
                        while (whitePos[w] != pc) ++w;
                        const int degreeRoot = key + iv[(size_t) (w % (int) iv.size())];
                        bool anyFits = false;
                        for (int q = 0; q < numQualities(); ++q) { Chord c; c.root = degreeRoot % 12; c.quality = q; if (fitsScale (c, key, sc)) anyFits = true; }
                        ++white;
                        if (slot.chord.valid() || ! anyFits) ++filled;
                    }
                    if (slot.chord.valid() && ! slot.outside)
                        CHECK (fitsScale (slot.chord, key, sc), "%s key %d: %s on note %d isn't in the scale", scales()[(size_t) sc].name.c_str(), key, chordName (slot.chord, false).c_str(), note);
                }
                CHECK (filled == white, "%s key %d: %d of %d white keys empty", scales()[(size_t) sc].name.c_str(), key, white - filled, white);
            }

    {
        const ScaleMap m = buildScaleMap (0, 0, Soul);
        std::printf ("C major, scale map:\n");
        for (int row = 0; row < numRows; ++row)
        {
            std::printf ("  %-7s ", rowName (row));
            for (int p = 0; p < 12; ++p)
            {
                const int note = rowBaseNote (row) + p;
                if (note > 127) break;
                const auto& s = m.keys[(size_t) note];
                std::printf ("%-10s", s.chord.valid() ? (chordName (s.chord, false) + (s.outside ? "*" : "")).c_str() : "-");
            }
            std::printf (" (+%d more)\n", (int) m.overflow[(size_t) row].size());
        }
        std::printf ("  every chord in C major: %d\n", (int) m.allInKey.size());
    }

    // 5. palettes
    for (int g = 0; g < numGenres; ++g)
        for (int sc = 0; sc < numScales(); ++sc)
            for (int key = 0; key < 12; ++key)
                for (uint32_t seed = 0; seed < 4; ++seed)
                {
                    const Palette p = buildPalette (key, sc, g, seed);
                    for (int i = 0; i < paletteSize; ++i)
                        CHECK (p[(size_t) i].chord.valid(), "%s palette slot %d invalid", genreShort (g), i);
                }
    {
        const Palette p = buildPalette (0, 0, Soul, 0);
        std::printf ("Soul palette in C: ");
        for (const auto& c : p) std::printf ("%s ", chordName (c.chord, false).c_str());
        std::printf ("\n");
    }

    // 6. triads
    {
        const Chord c = makeChord (0, "maj9");
        const auto t = triadsIn (c, false);
        std::printf ("Triads in Cmaj9: ");
        for (const auto& x : t) std::printf ("%s ", x.name.c_str());
        std::printf ("\n");
        CHECK (t.size() >= 3, "Cmaj9 should hold C, Em, G triads");
        const Notes inv1 = triadNotes (t[0], 1, 4);
        CHECK (inv1.size() == 3 && inv1[0] == 52 && inv1[1] == 55 && inv1[2] == 60, "C triad 1st inversion octave 4 should be E4 G4 C5, got %s", notesStr (inv1).c_str());
    }

    // 7. suggestions
    {
        const ScaleMap m = buildScaleMap (0, 0, Soul);
        const auto s = suggestNext (makeChord (7, "7"), 0, 0, m.allInKey);
        CHECK (! s.empty() && s[0].chord.root == 0, "G7 should resolve to C");
        std::printf ("After G7: ");
        for (const auto& x : s) std::printf ("%s (%s)  ", chordName (x.chord, false).c_str(), x.why.c_str());
        std::printf ("\n");
    }

    // 8. names and numerals
    CHECK (chordName (makeChord (10, "m7b5"), true) == "Bbm7b5", "name");
    CHECK (romanNumeral (makeChord (11, "m7b5"), 0) == "viiø", "numeral %s", romanNumeral (makeChord (11, "m7b5"), 0).c_str());
    CHECK (romanNumeral (makeChord (10, "7"), 0) == "bVII", "numeral bVII");
    CHECK (midiName (60, false) == "C5", "FL naming");

    // 9. vary always changes the voicing, smooth moves little
    {
        Rng rng;
        const Chord c = makeChord (2, "m9");
        Notes last = chooseVoicing (c, Lush, -1, 60, false, Notes(), false, Notes(), Soul, rng).notes;
        for (int i = 0; i < 50; ++i)
        {
            const auto p = chooseVoicing (c, Lush, -1, 60, i % 2 == 0, last, true, last, Soul, rng);
            CHECK (! p.notes.sameAs (last), "vary repeated the same voicing");
            last = p.notes;
        }
        const Notes a = chooseVoicing (makeChord (0, "maj7"), Close, -1, 60, false, Notes(), false, Notes(), Soul, rng).notes;
        const Notes b = chooseVoicing (makeChord (5, "maj7"), Close, -1, 60, true, a, false, Notes(), Soul, rng).notes;
        int move = 0;
        for (int i = 0; i < a.size() && i < b.size(); ++i) move += std::abs (a[i] - b[i]);
        std::printf ("Cmaj7 %s-> Fmaj7 %s(moved %d)\n", notesStr (a).c_str(), notesStr (b).c_str(), move);
        CHECK (move <= 8, "smooth voice leading moved too far");
        const Notes v = buildVoicing (makeChord (0, "13"), UpperStructure, 0);
        std::printf ("C13 upper structure: %s\n", notesStr (v).c_str());
    }

    // 10. playing styles: every rhythm plays sensible notes for a whole cycle
    {
        Rng rng;
        for (int withBass = 0; withBass < 2; ++withBass)
            for (int r = 0; r < numRhythms; ++r)
            {
                PatternInput in;
                in.upper.add (60); in.upper.add (64); in.upper.add (67); in.upper.add (71);
                in.bass = withBass ? 36 : -1;
                in.poolMask = scaleMask (0, 0);
                if (rhythmNeedsBass (r) && in.bass < 0) in.bass = 36;
                const int len = rhythmLength (r, in);
                CHECK (len >= 1 && len <= 64, "%s: odd length %d", rhythmInfo (r).name, len);
                int hits = 0, memory = -1;
                for (int k = 0; k < 64; ++k)
                {
                    const Hit h = rhythmStep (r, k, in, rng, memory);
                    if (! h.rest) ++hits;
                    for (int i = 0; i < h.notes.size(); ++i) CHECK (h.notes[i] >= 0 && h.notes[i] <= 127, "%s note out of range", rhythmInfo (r).name);
                    if (rhythmOneShot (r) && k >= len) CHECK (h.rest, "%s should stop after one pass", rhythmInfo (r).name);
                }
                CHECK (hits > 0, "%s never plays", rhythmInfo (r).name);
            }
        // waterfall goes down, rising goes up
        PatternInput in;
        for (int x : { 60, 64, 67, 71 }) in.upper.add (x);
        int mem = -1;
        const int w0 = rhythmStep (RWaterfall, 0, in, rng, mem).notes[0], w1 = rhythmStep (RWaterfall, 1, in, rng, mem).notes[0];
        const int r0 = rhythmStep (RRising, 0, in, rng, mem).notes[0], r1 = rhythmStep (RRising, 1, in, rng, mem).notes[0];
        CHECK (w0 > w1 && w0 > 71, "waterfall should start above the chord and fall (%d, %d)", w0, w1);
        CHECK (r1 > r0, "rising should climb");
        std::printf ("waterfall over Cmaj7: ");
        for (int k = 0; k < rhythmLength (RWaterfall, in); ++k) std::printf ("%s ", midiName (rhythmStep (RWaterfall, k, in, rng, mem).notes[0], false).c_str());
        std::printf ("\n");
    }

    // 11. upper extensions stay above the chord and in the key
    {
        const char* chords[][2] = { { "0", "maj7" }, { "2", "m7" }, { "4", "m7" }, { "5", "maj7" }, { "7", "7" }, { "9", "m7" }, { "11", "m7b5" } };
        for (int type = 0; type < numExtTypes; ++type)
            for (auto& cs : chords)
            {
                const Chord c = makeChord (std::atoi (cs[0]), cs[1]);
                Rng rr;
                const Notes v = chooseVoicing (c, Lush, -1, 60, false, Notes(), false, Notes(), Soul, rr).notes;
                const Notes e = upperExtension (c, v, type, 0, 0);
                CHECK (! e.empty(), "%s %s: no extension", chordName (c, false).c_str(), extTypeName (type));
                for (int i = 0; i < e.size(); ++i)
                {
                    CHECK (e[i] > v.highest(), "%s %s: extension below the chord", chordName (c, false).c_str(), extTypeName (type));
                    CHECK ((scaleMask (0, 0) >> (e[i] % 12)) & 1, "%s %s: %s is outside C major", chordName (c, false).c_str(), extTypeName (type), midiName (e[i], false).c_str());
                }
                if (type == ExtTensions)
                {
                    std::printf ("  %s + ", chordName (c, false).c_str());
                    for (int i = 0; i < e.size(); ++i) std::printf ("%s ", noteName (e[i], false).c_str());
                    std::printf ("\n");
                }
            }
    }

    // 12. band: every genre, every part, every style
    {
        const Chord prog[4] = { makeChord (2, "m7"), makeChord (7, "7"), makeChord (0, "maj7"), makeChord (9, "m7") };
        const int key = scaleMask (0, 0);
        long total = 0;
        for (int part = 0; part < numBandTypes; ++part)
            for (int style = 0; style < bandNumStyles (part); ++style)
                for (uint32_t seed = 1; seed <= 3; ++seed)
                {
                    Band band;
                    BandConfig bc;
                    bc.phraseBars = 4;
                    bc.numTracks = maxBandTracks;
                    for (int t = 0; t < maxBandTracks; ++t) { bc.part[(size_t) t].type = bandDefaultType (t); bc.part[(size_t) t].channel = bandDefaultChannel (t); }
                    const int track = 7;   // any slot can be any type
                    auto& pc = bc.part[(size_t) track];
                    pc.type = part; pc.on = true; pc.style = style; pc.seed = seed; pc.channel = 9;
                    if (part == BCounter) { bc.part[0].type = BMelody; bc.part[0].on = true; bc.part[0].seed = seed; bc.part[0].channel = 3; }
                    int notes = 0, inKey = 0, firstOnsets = 0, againOnsets = 0;
                    bool onsets[2][16] = {};
                    for (int64_t stp = 0; stp < 16 * 16; ++stp)
                    {
                        const int bar = (int) (stp / 16);
                        Harmony h;
                        h.chord = prog[bar % 4];
                        h.id = bar;
                        BandEvent ev[Band::maxEventsPerStep];
                        const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                        CHECK (n >= 0 && n <= Band::maxEventsPerStep, "too many events");
                        for (int i = 0; i < n; ++i)
                        {
                            const auto& e = ev[i];
                            if (e.part != track) continue;
                            CHECK (e.channel == pc.channel, "%s: wrong channel", bandPartName (part));
                            if (e.isCC) { CHECK (e.note == 11 && e.velocity >= 0 && e.velocity <= 127, "bad CC"); continue; }
                            ++notes; ++total;
                            CHECK (e.note >= 0 && e.note <= 127 && e.velocity >= 1 && e.velocity <= 127, "%s %s: bad note", bandPartName (part), bandStyleName (part, style));
                            CHECK (e.length > 0.0f || e.length == -1.0f, "%s %s: bad length", bandPartName (part), bandStyleName (part, style));
                            CHECK (e.offset >= 0.0f && e.offset < 4.0f, "%s %s: bad offset %f", bandPartName (part), bandStyleName (part, style), e.offset);
                            if (bandTypeIsDrums (part)) CHECK (Band::isDrumNote (e.note), "%s %s: %d isn't a GM drum", bandPartName (part), bandStyleName (part, style), e.note);
                            else
                            {
                                if (e.length > 0.0f && e.length < 0.3f) --notes;   // grace notes may be chromatic
                                else if ((key >> (e.note % 12)) & 1 || (pcMask (prog[bar % 4]) >> (e.note % 12)) & 1) ++inKey;
                                if (part == BBass) CHECK (e.note >= 20 && e.note <= 64, "BASS %s: note %d out of range", bandStyleName (part, style), e.note);
                                if (part == BMelody) CHECK (e.note >= 48 && e.note <= 100, "MELODY %s: note %d out of range", bandStyleName (part, style), e.note);
                                if (part == BGuitar) CHECK (e.note >= 38 && e.note <= 80, "GUITAR %s: note %d out of range", bandStyleName (part, style), e.note);
                                if (part == BKeys || part == BPad || part == BArp) CHECK (e.note >= 40 && e.note <= 100, "%s %s: note %d out of range", bandPartName (part), bandStyleName (part, style), e.note);
                            }
                            if (part == BMelody && (bar == 0 || bar == 4) && e.offset < 0.01f) onsets[bar == 4][stp % 16] = true;
                        }
                    }
                    const bool needsMelody = part == BCounter && (style == 0 || style == 1 || style == 5);
                    const bool sparsePiece = bandTypePiece (part) >= 0 && part != BKick && part != BHats;   // a groove may not use this piece
                    CHECK (notes > 4 || (needsMelody && notes > 0) || sparsePiece, "%s %s seed %u: only %d notes", bandPartName (part), bandStyleName (part, style), seed, notes);
                    if (! bandTypeIsDrums (part) && notes > 0)
                    {
                        const float frac = (float) inKey / (float) notes;
                        const bool bluesy = (part == BMelody && (style == 2 || style == 3 || style == 5 || style == 9)) || (part == BHorns && style == 2);
                        CHECK (frac >= (bluesy ? 0.6f : 0.8f), "%s %s seed %u: only %.0f%% of notes in key", bandPartName (part), bandStyleName (part, style), seed, frac * 100.0f);
                    }
                    (void) firstOnsets; (void) againOnsets; (void) onsets;
                }

        // the phrase library: every phrase parses, lines up with its bar lines, and plays in range
        {
            const auto& lib = phraseLibrary();
            CHECK (lib.size() >= 130, "phrase library has %d phrases", (int) lib.size());
            for (int set = 0; set < numPhraseSets; ++set)
                CHECK (phrasesInSet (set).size() >= 4, "phrase set %s has only %d phrases", phraseSetName (set), (int) phrasesInSet (set).size());
            // a hook comes back: the melody's opening phrase returns within 8 bars
            for (int style = 0; style < bandNumStyles (BMelody); ++style)
            {
                Band band;
                BandConfig bc;
                bc.part[BMelody].on = true; bc.part[BMelody].style = style; bc.part[BMelody].seed = 3; bc.part[BMelody].density = 0.8f;
                std::vector<std::string> barRhythm;
                for (int64_t stp = 0; stp < 16 * 12; ++stp)
                {
                    if (stp % 16 == 0) barRhythm.push_back ("");
                    Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                    BandEvent ev[Band::maxEventsPerStep];
                    const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                    for (int i = 0; i < n; ++i) if (! ev[i].isCC) barRhythm.back() += std::to_string (stp % 16) + ",";
                }
                bool repeats = false;
                for (size_t a = 0; a < barRhythm.size(); ++a)
                    for (size_t b = a + 1; b < barRhythm.size(); ++b)
                        if (! barRhythm[a].empty() && barRhythm[a] == barRhythm[b]) repeats = true;
                CHECK (repeats, "MELODY %s: no phrase ever comes back", bandStyleName (BMelody, style));
            }
        }

        // different seeds = different lines; same seed = the same line
        auto melody = [&] (uint32_t seed)
        {
            Band band;
            BandConfig bc;
            bc.part[BMelody].on = true;
            bc.part[BMelody].seed = seed;
            std::string out;
            for (int64_t stp = 0; stp < 64; ++stp)
            {
                Harmony h;
                h.chord = prog[(stp / 16) % 4];
                h.id = (int) (stp / 16);
                BandEvent ev[Band::maxEventsPerStep];
                const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                for (int i = 0; i < n; ++i) out += std::to_string (stp) + ":" + std::to_string (ev[i].note) + " ";
            }
            return out;
        };
        CHECK (melody (7) == melody (7), "same seed should give the same melody");
        CHECK (melody (7) != melody (8), "different seeds should give different melodies");

        for (int g = 0; g < numGenres; ++g)
        {
            const BandGenrePreset bp = bandGenrePreset (g);
            CHECK (bp.lineup != 0, "%s: empty band lineup", genreShort (g));
            for (int part = 0; part < numBandTypes; ++part)
                CHECK (bp.style[part] >= 0 && bp.style[part] < bandNumStyles (part), "%s preset style out of range", genreShort (g));
        }

        // GROOVES: every genre's list from the groove bank - real drummers, your loops, the genre's own rules - every
        // one different, named, simple to busy; a split kit plays exactly what the full kit plays
        {
            int totalHits = 0, live = 0, total = 0;
            for (int g = 0; g < numGenres; ++g)
            {
                const int n = numGrooves (g);
                CHECK (genreHasLoops (g) && n >= 40 && n <= maxGroovesPerGenre, "%s: %d grooves", genreShort (g), n);
                std::set<std::string> shapes, names;
                int lastBusy = -1, noKick = 0;
                for (int i = 0; i < n; ++i)
                {
                    const Groove& gr = groove (g, i);
                    ++total;
                    live += gr.live;
                    CHECK (gr.bars == 4, "%s groove %d: %d bars", genreShort (g), i, gr.bars);
                    if (i > 0) CHECK (gr.busy >= lastBusy, "%s grooves should go from simple to busy", genreShort (g));   // #1 = the genre's signature groove
                    if (i > 0) lastBusy = gr.busy;
                    if (i == 0)
                    {
                        bool kickOnOne = false;
                        for (const auto& h : gr.hits) kickOnOne |= h.piece == PieceKick && h.step == 0 && h.off == 0.0f;
                        CHECK (kickOnOne, "%s: groove 1 should start with a kick on the 1", genreShort (g));
                    }
                    names.insert (gr.name);
                    std::string shape;
                    bool kick = false;
                    for (const auto& h : gr.hits)
                    {
                        CHECK (h.step >= 0 && h.step < gr.bars * 16 && h.off >= 0.0f && h.off < 1.0f && std::abs (h.feel) <= 0.5f,
                               "%s groove %d: bad step", genreShort (g), i);
                        CHECK (Band::isDrumNote (h.note) && h.vel >= 1 && h.vel <= 127, "%s groove %d: bad note %d", genreShort (g), i, h.note);
                        shape += std::to_string ((int) std::lround ((h.step + h.off) * 12.0f)) + ":" + std::to_string (h.note) + ",";
                        kick |= h.piece == PieceKick;
                        ++totalHits;
                    }
                    noKick += ! kick;
                    shapes.insert (shape);
                    const int rel = grooveRelated (g, i, 3);
                    CHECK (rel >= 0 && rel < n && grooveRelated (g, i, 0) == i && grooveRelated (g, i, 3) == rel, "%s: CHANGE picks", genreShort (g));
                    CHECK (grooveNear (g, i, 0) != i, "%s groove %d: its closest groove is itself", genreShort (g), i);
                }
                CHECK ((int) shapes.size() == n, "%s: only %d different grooves", genreShort (g), (int) shapes.size());
                CHECK ((int) names.size() == n, "%s: only %d different names", genreShort (g), (int) names.size());
                CHECK (noKick <= n / 10, "%s: %d grooves without a kick", genreShort (g), noKick);
                CHECK (grooveLabel (g, 6).substr (0, 4) == "007 ", "groove labels: %s", grooveLabel (g, 6).c_str());
            }
            CHECK (live >= 900, "grooves played by real drummers: %d", live);
            {
                bool dembow = false;
                for (int i = 0; i < numGrooves (Reggaeton) && ! dembow; ++i)
                {
                    const auto& gr = groove (Reggaeton, i);
                    int hit = 0;
                    for (const auto& h : gr.hits) if (h.step < 16 && (h.piece == PieceSnare || h.piece == PieceClap) && h.off == 0.0f && (h.step == 3 || h.step == 6 || h.step == 11 || h.step == 14)) ++hit;
                    dembow = hit == 4;
                }
                CHECK (dembow, "reggaeton: a dembow snare (3, 6, 11, 14)");
                int trapRolls = 0;
                for (int i = 0; i < numGrooves (Trap); ++i) for (const auto& h : groove (Trap, i).hits) if (h.piece == PieceHats && h.off > 0.0f) { ++trapRolls; break; }
                CHECK (trapRolls >= 100, "trap grooves with hat rolls: %d", trapRolls);
            }
            std::printf ("Grooves: %d in %d genres (%d played by real drummers), %d hits\n", total, (int) numGenres, live, totalHits);

            for (int g : { (int) Trap, (int) Soul, (int) Afro, (int) Cinematic })
                for (int gi : { 0, 17, 49 })
                {
                    auto collect = [&] (bool split)
                    {
                        Band band;
                        BandConfig bc;
                        bc.genre = g; bc.groove = gi; bc.phraseBars = 4;
                        if (split)
                        {
                            bc.numTracks = 8;
                            for (int t = 0; t < 8; ++t) { auto& c = bc.part[(size_t) t]; c.type = BKick + t; c.on = true; c.channel = 10; c.style = 0; }
                        }
                        else
                        {
                            bc.numTracks = 1;
                            auto& c = bc.part[0]; c.type = BDrums; c.on = true; c.channel = 10; c.style = drumGrooveStyle;
                        }
                        std::multiset<std::string> hits;
                        for (int64_t stp = 0; stp < 16 * 8; ++stp)
                        {
                            Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                            BandEvent ev[Band::maxEventsPerStep];
                            const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                            for (int k = 0; k < n; ++k)
                                if (! ev[k].isCC) hits.insert (std::to_string (stp) + ":" + std::to_string (ev[k].note) + ":" + std::to_string ((int) (ev[k].offset * 100)));
                        }
                        return hits;
                    };
                    const auto full = collect (false), split = collect (true);
                    CHECK (full == split && full.size() > 30, "%s groove %d: the split kit should play exactly what the full kit plays (%d vs %d hits)",
                           genreShort (g), gi, (int) full.size(), (int) split.size());
                }
        }

        // drum patterns are straight: with SWING and FEEL at 0 nothing is pushed late (rolls, triplets and the neo-soul
        // lazy snare are part of the pattern); with SWING up, the off-beats move
        for (int style = 0; style < bandNumStyles (BDrums); ++style)
            for (int swingOn = 0; swingOn < 2; ++swingOn)
            {
                Band band;
                BandConfig bc;
                bc.part[0].type = BDrums; bc.part[0].on = true; bc.part[0].style = style; bc.part[0].channel = 10;
                bc.part[0].density = 0.8f; bc.part[0].complexity = 0.8f;
                bc.swing = swingOn ? 0.25f : 0.0f;
                bc.feel = 0.0f;
                int late = 0, offbeats = 0, swung = 0;
                for (int64_t stp = 0; stp < 16 * 8; ++stp)
                {
                    Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                    BandEvent ev[Band::maxEventsPerStep];
                    const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                    for (int i = 0; i < n; ++i)
                    {
                        const float o = ev[i].offset;
                        const bool roll = std::abs (o * 24.0f - std::round (o * 24.0f)) < 0.05f;   // on the 32nd / triplet grid
                        const bool lazy = style == 9 && std::abs (o - 0.12f) < 0.01f;
                        if (! swingOn && o > 0.001f && ! roll && ! lazy) ++late;
                        if (stp % 4 == 2) { ++offbeats; if (o >= 0.49f) ++swung; }
                    }
                }
                if (! swingOn) CHECK (late == 0, "DRUMS %s: %d hits swung with SWING at 0", bandStyleName (BDrums, style), late);
                else CHECK (offbeats == 0 || swung == offbeats, "DRUMS %s: SWING didn't move the off-beats (%d of %d)", bandStyleName (BDrums, style), swung, offbeats);
            }

        // FEEL at 100%: the loops' push and drag comes through (hits off the grid); at 0% it's gone
        {
            int offGrid[2] = { 0, 0 };
            for (int f = 0; f < 2; ++f)
            {
                Band band;
                BandConfig bc;
                bc.genre = Soul;
                for (int i = 0; i < numGrooves (Soul); ++i) if (groove (Soul, i).live) { bc.groove = i; break; }   // a real drummer's groove
                bc.part[0].type = BDrums; bc.part[0].on = true; bc.part[0].style = drumGrooveStyle; bc.part[0].channel = 10;
                bc.part[0].density = 0.8f; bc.part[0].complexity = 0.8f;
                bc.feel = f ? 1.0f : 0.0f;
                for (int64_t stp = 0; stp < 16 * 8; ++stp)
                {
                    Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                    BandEvent ev[Band::maxEventsPerStep];
                    const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                    for (int i = 0; i < n; ++i)
                        if (std::abs (ev[i].offset * 24.0f - std::round (ev[i].offset * 24.0f)) > 0.1f) ++offGrid[f];
                }
            }
            CHECK (offGrid[0] == 0 && offGrid[1] > 10, "FEEL: off-grid hits %d at 0%%, %d at 100%%", offGrid[0], offGrid[1]);
        }

        // CHANGE: every 4 bars the drums move to another groove, and every drum track agrees
        {
            Band band;
            BandConfig bc;
            bc.genre = Trap; bc.groove = 10; bc.grooveChange = 4;
            bc.part[0].type = BKick; bc.part[0].on = true; bc.part[0].channel = 10;
            bc.part[1].type = BHats; bc.part[1].on = true; bc.part[1].channel = 10;
            std::set<int> seen;
            for (int64_t stp = 0; stp < 16 * 32; ++stp)
            {
                Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                BandEvent ev[Band::maxEventsPerStep];
                band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                if (stp % 16 == 0)
                {
                    const int expect = grooveRelated (Trap, 10, stp / 16 / 4);
                    CHECK (band.grooveNow == expect, "CHANGE: bar %d plays %d, expected %d", (int) (stp / 16), band.grooveNow, expect);
                    seen.insert (band.grooveNow);
                }
            }
            CHECK (seen.size() >= 4 && seen.count (10), "CHANGE every 4 bars should move around (%d grooves)", (int) seen.size());
        }

        // every track full: 15 tracks never overflow a step, and two tracks of one type both play
        {
            Band band;
            BandConfig bc;
            bc.numTracks = maxBandTracks;
            for (int t = 0; t < maxBandTracks; ++t)
            {
                auto& c = bc.part[(size_t) t];
                c.type = bandDefaultType (t); c.on = true; c.channel = bandDefaultChannel (t); c.seed = (uint32_t) (t + 3); c.density = 1.0f; c.complexity = 1.0f;
                c.style = bandNumStyles (c.type) - 1;
            }
            int perTrack[maxBandTracks] = {};
            for (int64_t stp = 0; stp < 16 * 8; ++stp)
            {
                Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                BandEvent ev[Band::maxEventsPerStep];
                const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                CHECK (n < Band::maxEventsPerStep, "15 tracks filled a whole step (%d events)", n);
                for (int i = 0; i < n; ++i)
                {
                    CHECK (ev[i].part >= 0 && ev[i].part < maxBandTracks, "bad track index");
                    CHECK (ev[i].channel == bc.part[(size_t) ev[i].part].channel, "track %d: wrong channel", ev[i].part);
                    if (! ev[i].isCC) ++perTrack[ev[i].part];
                }
            }
            for (int t = 0; t < maxBandTracks; ++t) CHECK (perTrack[t] > 0, "track %d (%s) never played", t + 1, bandTypeName (bc.part[(size_t) t].type));
            // HOLD / RING tracks don't jam
            bc.part[2].mode = ModeHold;
            bc.part[6].mode = ModeRing;
            Band b2;
            int held = 0;
            for (int64_t stp = 0; stp < 32; ++stp)
            {
                Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                BandEvent ev[Band::maxEventsPerStep];
                const int n = b2.step (bc, h, stp, ev, Band::maxEventsPerStep);
                for (int i = 0; i < n; ++i) if (ev[i].part == 2 || ev[i].part == 6) ++held;
            }
            CHECK (held == 0, "HOLD / RING tracks shouldn't play patterns");
        }

        // HOLD notes: bass takes the bottom (down low), melody the top, pads everything
        {
            Notes played; played.add (60); played.add (64); played.add (67); played.add (71);
            const Chord cm = makeChord (0, "maj7");
            BandPartConfig c;
            c.type = BBass;
            Notes b = bandHoldNotes (c, played, cm);
            CHECK (b.size() == 1 && b[0] % 12 == 0 && b[0] >= 28 && b[0] <= 52, "HOLD bass should be a low C");
            c.type = BMelody;
            b = bandHoldNotes (c, played, cm);
            CHECK (b.size() == 1 && b[0] == 71, "HOLD melody should be the top note");
            c.type = BPad; c.octave = 1;
            b = bandHoldNotes (c, played, cm);
            CHECK (b.size() == 4 && b[0] == 72, "HOLD pad should be the whole chord, an octave up");
            c.type = BDrums;
            CHECK (bandHoldNotes (c, played, cm).empty(), "drums don't HOLD");
            Harmony h; h.key = 4;
            BandPartConfig k; k.keyMask = 1u << 4;
            CHECK (h.sitsOut (k), "key strip: E is muted");
            h.key = -1;
            CHECK (! h.sitsOut (k), "mouse clicks always play");
        }
        {
            int r = -1; bool m = false;
            CHECK (keyFromName ("Dark Melody F#m 140bpm", r, m) && r == 6 && m, "key from name: F#m");
            CHECK (keyFromName ("loop_Bb_major", r, m) && r == 10 && ! m, "key from name: Bb major");
            CHECK (! keyFromName ("A beat 90bpm", r, m), "a lone 'A' is not a key");
            std::vector<ClipNote> am;
            for (int k : { 57, 60, 64, 69, 62, 65, 64, 57, 59, 60 }) { ClipNote n; n.note = k; n.len = 2; am.push_back (n); }
            detectKey (am, r, m);
            CHECK (r == 9 && m, "A minor notes should read as A minor (got %d %s)", r, m ? "minor" : "major");
        }
        {
            // an MPC-layout trap beat: kick on pad 1 (36), clap on pad 4 (39)... but hats on pad 6 (41) and snare on pad 2 (37)
            MidiClip c;
            auto addN = [&c] (float st, int n) { ClipNote cn; cn.start = st; cn.len = 0.5f; cn.note = n; c.notes.push_back (cn); };
            for (int s : { 0, 7, 10 }) addN ((float) s, 36);
            for (int s : { 4, 12 }) addN ((float) s, 37);
            for (int s = 0; s < 16; s += 2) addN ((float) s, 41);
            addN (6.0f, 43);
            mapDrumRoles (c);
            int k = 0, sn = 0, hh = 0;
            for (auto& n : c.notes) { if (n.note == 36) ++k; if (n.note == 38) ++sn; if (n.note == 42) ++hh; }
            CHECK (k == 3 && sn == 2 && hh == 8, "drum roles: kick %d snare %d hats %d", k, sn, hh);
        }
        {
            // a dembow on standard notes (snare never on 2 / 4, no hats) stays as it is
            MidiClip c;
            auto addN = [&c] (float st, int n) { ClipNote cn; cn.start = st; cn.len = 0.5f; cn.note = n; c.notes.push_back (cn); };
            for (int s : { 0, 4, 8, 12 }) addN ((float) s, 36);
            for (int s : { 2, 3, 6, 10, 11, 14 }) addN ((float) s, 38);
            addN (5.0f, 37);
            mapDrumRoles (c);
            int sn = 0, rim = 0;
            for (auto& n : c.notes) { if (n.note == 38) ++sn; if (n.note == 37) ++rim; }
            CHECK (sn == 6 && rim == 1, "dembow roles kept: snare %d rim %d", sn, rim);
        }
        int styles = 0;
        for (int t = 0; t < numBandTypes; ++t) styles += bandNumStyles (t);
        std::printf ("Band: %d genres, %d types, %d styles, %ld notes generated in the test\n", numGenres, (int) numBandTypes, styles, total);
    }

    // 13. SONG: every genre has thousands of different songs; every one is a sane length, every bar knows who plays
    {
        BandConfig bc;
        const int lineup[] = { BMelody, BBass, BDrums, BPad, BCounter, BHorns, BHats, BKeys };
        bc.numTracks = 8;
        for (int t = 0; t < 8; ++t) { bc.part[(size_t) t].type = lineup[t]; bc.part[(size_t) t].on = true; }
        long songs = 0;
        for (int g = 0; g < numGenres; ++g)
        {
            std::set<std::string> shapes;
            std::set<uint64_t> takes;
            int drumlessBreaks = 0, breaks = 0, layered = 0, sections = 0;
            for (int n = 1; n <= 400; ++n)
            {
                const auto plan = makeSongPlan (g, n, bc);
                ++songs;
                const int bars = plan.totalBars();
                CHECK (plan.sections.size() >= 4 && bars >= 24 && bars <= 260, "song %s #%d: %d sections, %d bars", genreName (g), n, (int) plan.sections.size(), bars);
                CHECK (plan.sections.front().type == SecIntro && plan.sections.back().type == SecOutro, "song %s #%d should start with an intro and end with an outro", genreName (g), n);
                shapes.insert (plan.describe());
                uint64_t h = 1469598103934665603ull;
                for (const auto& sec : plan.sections)
                {
                    ++sections;
                    CHECK ((int) sec.mask.size() == sec.bars && (int) sec.moment.size() == sec.bars, "song %s #%d: bar tables", genreName (g), n);
                    for (int b = 0; b < sec.bars; ++b) { h = (h ^ (sec.mask[(size_t) b] * 31u + sec.moment[(size_t) b])) * 1099511628211ull; }
                    if (sec.type == SecBreak)
                    {
                        ++breaks;
                        if (((sec.mask[0] >> 2) & 1u) == 0) ++drumlessBreaks;   // track 2 = DRUMS
                    }
                    if (sec.bars >= 8 && sec.mask.front() != sec.mask.back()) ++layered;
                }
                takes.insert (h);
            }
            CHECK ((int) takes.size() >= 300, "%s: only %d different songs in 400", genreName (g), (int) takes.size());
            CHECK (breaks == 0 || drumlessBreaks * 10 >= breaks * 9, "%s: breakdowns should drop the beat (%d of %d)", genreName (g), drumlessBreaks, breaks);
            CHECK (layered * 5 >= sections, "%s: sections should build and thin out, not sit still (%d of %d)", genreName (g), layered, sections);
            if (g == HipHop || g == House || g == Soul || g == Blues) std::printf ("song shapes, %s: %d different layouts, e.g. %s\n", genreName (g), (int) shapes.size(), makeSongPlan (g, 7, bc).describe().c_str());
        }
        std::printf ("Songs: %ld checked across %d genres\n", songs, numGenres);
    }

    // ---- FILLS: thousands per genre, all in time and in range, sized for what comes next
    {
        long total = 0;
        for (int g = 0; g < numGenres; ++g)
        {
            std::set<uint32_t> distinct;
            for (int size = 0; size < numFillSizes; ++size)
                for (uint32_t seed = 1; seed <= 600; ++seed)
                {
                    FillHit hits[maxFillHits];
                    FillInfo info;
                    const int beats = fillBeatsFor (size, seed);
                    const int n = makeFill (g, size, beats, seed, hits, maxFillHits, info);
                    CHECK (n > 0, "fill %s size %d seed %u is empty", genreName (g), size, seed);
                    for (int i = 0; i < n; ++i)
                    {
                        CHECK (hits[i].step >= -0.3f && hits[i].step < beats * 4.0f, "fill %s: a hit outside the fill (%f)", genreName (g), hits[i].step);
                        CHECK (hits[i].vel >= 1 && hits[i].vel <= 127, "fill %s: velocity %d", genreName (g), hits[i].vel);
                        CHECK (i == 0 || hits[i].step >= hits[i - 1].step, "fill %s: hits out of order", genreName (g));
                    }
                    distinct.insert (fillSignature (hits, n));
                    ++total;
                }
            CHECK ((int) distinct.size() >= 1000, "%s: only %d different fills in 2400", genreName (g), (int) distinct.size());
        }
        CHECK (fillSizeFor (SecHook, SecVerse, true) == FillBig, "a fill into the hook should be big");
        CHECK (fillSizeFor (SecBreak, SecHook, true) == FillOut, "a fill into a break should fall away");
        CHECK (fillSizeFor (SecVerse, SecVerse, false) == FillSmall, "a fill inside a section should be small");
        std::printf ("Fills: %ld built, every genre over 1000 different\n", total);
    }

    // ---- MELODY LINES: every hand-written line comes in versions, and LIKE / SKIP steer what plays
    {
        const auto& lib = phraseLibrary();
        int written = 0;
        for (int i = 0; i < (int) lib.size(); ++i)
        {
            const auto& ph = lib[(size_t) i];
            if (ph.base == i) ++written;
            CHECK (ph.base >= 0 && ph.base <= i && lib[(size_t) ph.base].base == ph.base, "phrase %d: bad base", i);
            CHECK (ph.bars >= 1 && ph.bars <= 8 && ! ph.notes.empty(), "phrase %d: %d bars, %d notes", i, ph.bars, (int) ph.notes.size());
            float last = -1.0f;
            for (const auto& n : ph.notes)
            {
                CHECK (n.start >= 0.0f && n.start < 16.0f * ph.bars && n.dur > 0.0f, "phrase %d (%s): a note outside it", i, phraseVariantName (ph.variant));
                CHECK (n.start >= last - 1e-4f, "phrase %d (%s): notes out of order", i, phraseVariantName (ph.variant));
                last = n.start;
            }
        }
        CHECK ((int) lib.size() >= written * 5, "only %d lines from %d hand-written ones", (int) lib.size(), written);
        // the dice: different seeds pick different ideas; a skipped line never comes back
        BandConfig bc;
        BandPartConfig pc;
        pc.on = true; pc.type = BMelody; pc.style = 0;
        Band band;
        std::set<int> bases;
        for (uint32_t seed = 1; seed <= 40; ++seed)
        {
            band.reset();
            pc.seed = seed * 2654435761u | 1u;
            bc.part[0] = pc;
            bc.numTracks = 1;
            Harmony h; h.chord = makeChord (0, "maj7"); h.id = 1; h.keyRoot = 0; h.scale = 0;
            BandEvent ev[Band::maxEventsPerStep];
            for (int64_t s = 0; s < 64; ++s) band.step (bc, h, s, ev, Band::maxEventsPerStep);
            if (band.phraseNow[0] >= 0) bases.insert (lib[(size_t) band.phraseNow[0]].base);
        }
        CHECK ((int) bases.size() >= 4, "the melody dice only reached %d different ideas in 40 rolls", (int) bases.size());
        int skippedId = -1;
        for (int i = 0; i < (int) lib.size(); ++i) if (lib[(size_t) i].set == phraseSetFor (BMelody, 0)) { skippedId = i; break; }
        if (skippedId >= 0)
        {
            setPhraseRating (skippedId, -1);
            int hits = 0;
            for (uint32_t seed = 1; seed <= 60; ++seed)
            {
                band.reset();
                pc.seed = seed * 40503u | 1u;
                bc.part[0] = pc;
                Harmony h; h.chord = makeChord (0, "maj7"); h.id = 1;
                BandEvent ev[Band::maxEventsPerStep];
                for (int64_t s = 0; s < 64; ++s) band.step (bc, h, s, ev, Band::maxEventsPerStep);
                if (band.phraseNow[0] >= 0 && lib[(size_t) band.phraseNow[0]].base == lib[(size_t) skippedId].base) ++hits;
            }
            CHECK (hits == 0, "a skipped line still played %d times", hits);
            clearPhraseRatings();
        }
        std::printf ("Melody lines: %d hand-written, %d with their versions; the dice reached %d ideas in 40 rolls\n",
                     written, (int) lib.size(), (int) bases.size());
    }

    // ---- SONG SHAPES and editing
    {
        BandConfig bc;
        bc.numTracks = 4;
        bc.part[0].type = BDrums; bc.part[1].type = BBass; bc.part[2].type = BKeys; bc.part[3].type = BMelody;
        for (int g = 0; g < numGenres; ++g)
            for (const auto& sh : songShapes (g))
            {
                const auto plan = makeSongFromShape (g, 3, bc, sh);
                CHECK (plan.sections.size() == sh.parts.size(), "shape %s: %d sections for %d parts", sh.name.c_str(), (int) plan.sections.size(), (int) sh.parts.size());
                for (const auto& sec : plan.sections)
                    CHECK ((int) sec.mask.size() == sec.bars && (int) sec.moment.size() == sec.bars, "shape %s: bar tables", sh.name.c_str());
                SongShape back;
                CHECK (songShapeFromText (songShapeText (plan), back) && back.parts.size() == sh.parts.size(), "shape %s: text round trip", sh.name.c_str());
            }
        for (int ty = 0; ty < numSongSectionTypes; ++ty)
        {
            const auto sec = songMakeSection (Pop, ty, -1, bc, 9u);
            CHECK (sec.type == ty && sec.bars > 0 && (int) sec.mask.size() == sec.bars, "a new %s section", songSectionName (ty));
        }
        CHECK (songSectionTypeFromName ("chorus") == SecHook && songSectionTypeFromName ("Pre-Chorus") == SecPre, "section names");
        std::printf ("Song shapes: every genre's shapes build and save\n");
    }

    // ---- REWORK: your drum MIDI, same bones, new details
    {
        std::vector<ClipNote> bar;
        auto add = [&] (float s, int note, int vel) { ClipNote c; c.start = s; c.len = 0.5f; c.note = note; c.vel = vel; bar.push_back (c); };
        add (0, 36, 110); add (6, 36, 84); add (8, 36, 104); add (10, 36, 78);
        add (4, 38, 112); add (12, 38, 112);
        for (int s = 0; s < 16; s += 2) add ((float) s, 42, 80);
        ClipNote out[160];
        const int n0 = reworkDrumBar (bar.data(), (int) bar.size(), Pop, 0.0f, 0, 7u, false, out, 160);
        bool same = n0 == (int) bar.size();
        for (int i = 0; same && i < n0; ++i) same = out[i].start == bar[(size_t) i].start && out[i].note == bar[(size_t) i].note && out[i].vel == bar[(size_t) i].vel;
        CHECK (same, "REWORK at 0 changed the bar");
        auto key = [] (const ClipNote& c) { return std::to_string ((int) std::lround (c.start * 100)) + "/" + std::to_string (c.note) + "/" + std::to_string (c.vel); };
        int changed = 0, runs = 0;
        for (int g = 0; g < numGenres; ++g)
            for (int a = 1; a <= 4; ++a)
                for (uint32_t seed = 1; seed <= 12; ++seed)
                {
                    const float amount = (float) a * 0.25f;
                    const bool end = seed % 3 == 0;
                    const int n = reworkDrumBar (bar.data(), (int) bar.size(), g, amount, 0, seed * 7919u + (uint32_t) g, end, out, 160);
                    ++runs;
                    CHECK (n > 0 && n <= 160, "REWORK %s: %d notes", genreShort (g), n);
                    bool kickOne = false, snare4 = false, snare12 = false, sorted = true, sane = true;
                    std::multiset<std::string> was, now;
                    for (const auto& c : bar) was.insert (key (c));
                    for (int i = 0; i < n; ++i)
                    {
                        const auto& c = out[i];
                        now.insert (key (c));
                        if (i > 0 && c.start < out[i - 1].start) sorted = false;
                        if (c.start < 0.0f || c.start >= 16.0f || c.note < 0 || c.note > 127 || c.vel < 1 || c.vel > 127) sane = false;
                        if (drumPieceOf (c.note) == PieceKick && c.start < 0.01f) kickOne = true;
                        if (drumPieceOf (c.note) == PieceSnare && std::abs (c.start - 4.0f) < 0.01f) snare4 = true;
                        if (drumPieceOf (c.note) == PieceSnare && std::abs (c.start - 12.0f) < 0.01f) snare12 = true;
                    }
                    if (now != was) ++changed;
                    CHECK (sorted && sane, "REWORK %s %.2f: notes out of order or out of range", genreShort (g), amount);
                    CHECK (kickOne, "REWORK %s %.2f: the kick on the one moved", genreShort (g), amount);
                    CHECK (snare4 && (snare12 || end), "REWORK %s %.2f: the backbeat moved", genreShort (g), amount);
                    // locked kick + snare: exactly as written
                    const uint16_t lock = (uint16_t) ((1u << PieceKick) | (1u << PieceSnare));
                    const int nl = reworkDrumBar (bar.data(), (int) bar.size(), g, amount, lock, seed * 31u, true, out, 160);
                    std::multiset<std::string> lockedWas, lockedNow;
                    for (const auto& c : bar) if (drumPieceOf (c.note) == PieceKick || drumPieceOf (c.note) == PieceSnare) lockedWas.insert (key (c));
                    for (int i = 0; i < nl; ++i) if (drumPieceOf (out[i].note) == PieceKick || drumPieceOf (out[i].note) == PieceSnare) lockedNow.insert (key (out[i]));
                    CHECK (lockedWas == lockedNow, "REWORK %s %.2f: a locked kick / snare changed", genreShort (g), amount);
                }
        CHECK (changed > runs * 3 / 4, "REWORK hardly changes anything (%d of %d)", changed, runs);
        std::printf ("Rework: %d drum bars reworked, %d came out new, the bones and the locks held\n", runs, changed);
    }

    // ---- KEY CHANGE: chords and notes into a new key; the moves; SONG SETUP's feels
    {
        auto name = [] (const Chord& c) { return chordName (c, false); };
        const Chord C = makeChord (0, ""), G7 = makeChord (7, "7"), F = makeChord (5, ""), Dm7 = makeChord (2, "m7"), Fmaj7 = makeChord (5, "maj7");
        CHECK (name (moveChordKey (C, 0, 0, 1, 0)) == "C#" || name (moveChordKey (C, 0, 0, 1, 0)) == "Db", "KEY: C up a half step");
        CHECK (name (moveChordKey (Dm7, 0, 0, 10, 0)) == "Cm7", "KEY: Dm7 down a whole step = %s", name (moveChordKey (Dm7, 0, 0, 10, 0)).c_str());
        // C major -> its relative minor (A minor): each chord keeps its place in the key
        CHECK (name (moveChordKey (C, 0, 0, 9, 1)) == "Am", "KEY: I in C -> i in A minor = %s", name (moveChordKey (C, 0, 0, 9, 1)).c_str());
        CHECK (name (moveChordKey (G7, 0, 0, 9, 1)) == "Em7", "KEY: V7 in C -> v7 in A minor = %s", name (moveChordKey (G7, 0, 0, 9, 1)).c_str());
        CHECK (name (moveChordKey (F, 0, 0, 9, 1)) == "Dm", "KEY: IV in C -> iv in A minor = %s", name (moveChordKey (F, 0, 0, 9, 1)).c_str());
        CHECK (name (moveChordKey (Fmaj7, 0, 0, 0, 1)) == "Fm7", "KEY: IVmaj7 in C -> iv7 in C minor = %s", name (moveChordKey (Fmaj7, 0, 0, 0, 1)).c_str());
        // a borrowed chord (outside the key) just moves with the key
        const Chord Bb = makeChord (10, "");
        CHECK (name (moveChordKey (Bb, 0, 0, 2, 0)) == "C", "KEY: bVII moves with the key = %s", name (moveChordKey (Bb, 0, 0, 2, 0)).c_str());
        // every chord VESPER can play survives a move to every key and scale (valid, and its root in the new place)
        int bad = 0;
        for (int q = 0; q < numQualities(); ++q)
            for (int root = 0; root < 12; ++root)
                for (int to : { 0, 1 })
                {
                    Chord c; c.root = root; c.quality = q;
                    const Chord m = moveChordKey (c, 0, 0, to == 0 ? 9 : 0, 1);
                    if (! m.valid() || m.root < 0 || m.root > 11) ++bad;
                }
        CHECK (bad == 0, "KEY: %d chords came out broken", bad);
        CHECK (moveNoteKey (64, 0, 0, 9, 1) == 60, "KEY: E (the 3rd of C) -> C (the 3rd of A minor): %d", moveNoteKey (64, 0, 0, 9, 1));
        CHECK (moveNoteKey (64, 0, 0, 2, 0) == 66, "KEY: up a whole step");
        int sh = 0, sc = -1;
        applyKeyMove (KeyUpHalf, 0, sh, sc);   CHECK (sh == 1 && sc == -1, "KEY MOVE: up a half step");
        applyKeyMove (KeyRelative, 0, sh, sc); CHECK (sh == -2 && sc == 1, "KEY MOVE: to the relative minor (%d, %d)", sh, sc);
        applyKeyMove (KeyRelative, 0, sh, sc); CHECK (sh == 1 && sc == -1, "KEY MOVE: back to the relative major (%d, %d)", sh, sc);
        applyKeyMove (KeyParallel, 0, sh, sc); CHECK (sh == 1 && sc == 1, "KEY MOVE: parallel minor (%d, %d)", sh, sc);
        applyKeyMove (KeyHome, 0, sh, sc);     CHECK (sh == 0 && sc == -1, "KEY MOVE: home");
        for (int i = 0; i < 30; ++i) applyKeyMove (KeyUpHalf, 0, sh, sc);
        CHECK (sh >= -11 && sh <= 11, "KEY MOVE: climbing stays in range (%d)", sh);
        // feels: MINIMAL adds nothing, JAM the most
        const auto mn = songFeelDials (FeelMinimal), jm = songFeelDials (FeelJam), nm = songFeelDials (FeelNormal);
        CHECK (mn.drums == 0.0f && mn.band == 0.0f && mn.fills == 0.0f && ! mn.moments, "FEEL: MINIMAL should add nothing");
        CHECK (jm.drums > nm.drums && jm.band > nm.band && jm.fills > nm.fills && jm.busy > nm.busy, "FEEL: JAM should be the most");
        CHECK (songFeelDials (FeelQuiet).level < nm.level && songFeelDials (FeelLoud).level > nm.level, "FEEL: QUIET / LOUD levels");
        std::printf ("Key change: same key, relative and parallel moves keep every chord in its place; feels from MINIMAL to JAM\n");
    }

    // ---- CHORD PALETTES: chord sets per genre, SPICE, VOICE SETS
    {
        auto name = [] (const Chord& c) { return chordName (c, false); };
        // every set of every genre, major and minor: 24 real chords
        int sets = 0, badPads = 0, thin = 0;
        for (int g = 0; g < numGenres; ++g)
            for (int scale : { 0, 1 })
            {
                const int n = numChordSets (g, scale);
                if (n < 3) { ++thin; std::printf ("  only %d chord sets: %s %s\n", n, genreShort (g), scale == 0 ? "major" : "minor"); }
                for (int i = 1; i < n; ++i)
                {
                    ++sets;
                    const auto p = buildChordSet (5, scale, g, i);
                    for (const auto& card : p) if (! card.chord.valid()) ++badPads;
                    CHECK (! chordSetName (g, scale, i).empty(), "CHORD SETS: a set without a name");
                }
            }
        CHECK (badPads == 0, "CHORD SETS: %d pads didn't make a chord (a typo in a set)", badPads);
        CHECK (thin == 0, "CHORD SETS: every genre needs at least two sets of its own in major and in minor");
        {   // the first row of THE HITS in C is C G Am F
            int hits = -1;
            for (int i = 1; i < numChordSets (Pop, 0); ++i) if (chordSetName (Pop, 0, i) == "THE HITS") hits = i;
            const auto p = buildChordSet (0, 0, Pop, hits);
            CHECK (hits > 0 && name (p[0].chord) == "C" && name (p[1].chord) == "G" && name (p[2].chord) == "Am" && name (p[3].chord) == "F",
                   "CHORD SETS: THE HITS should start C G Am F");
        }
        // SPICE: below the middle the chords get plainer; at the middle and up, exactly as written
        auto simp = [&] (const char* suffix, float spice) { return name (simplifyChord (makeChord (0, suffix), spice)); };
        CHECK (simp ("maj9", 0.6f) == "Cmaj9" && simp ("maj9", 0.3f) == "Cmaj7" && simp ("maj9", 0.1f) == "C", "SPICE: maj9 -> maj7 -> triad (%s %s)", simp ("maj9", 0.3f).c_str(), simp ("maj9", 0.1f).c_str());
        CHECK (simp ("m11", 0.3f) == "Cm7" && simp ("m11", 0.1f) == "Cm", "SPICE: m11 (%s, %s)", simp ("m11", 0.3f).c_str(), simp ("m11", 0.1f).c_str());
        CHECK (simp ("13sus4", 0.3f) == "C7sus4" && simp ("13sus4", 0.1f) == "Csus4", "SPICE: 13sus4 (%s, %s)", simp ("13sus4", 0.3f).c_str(), simp ("13sus4", 0.1f).c_str());
        CHECK (simp ("7#9", 0.3f) == "C7" && simp ("7#9", 0.1f) == "C", "SPICE: 7#9 (%s, %s)", simp ("7#9", 0.3f).c_str(), simp ("7#9", 0.1f).c_str());
        CHECK (simp ("m7b5", 0.3f) == "Cm7b5" && simp ("m7b5", 0.1f) == "Cdim", "SPICE: m7b5 (%s, %s)", simp ("m7b5", 0.3f).c_str(), simp ("m7b5", 0.1f).c_str());
        CHECK (simp ("6/9", 0.3f) == "C6" && simp ("5", 0.1f) == "C5", "SPICE: 6/9 -> 6, power chords stay (%s, %s)", simp ("6/9", 0.3f).c_str(), simp ("5", 0.1f).c_str());
        int broken = 0;
        for (int q = 0; q < numQualities(); ++q)
            for (float s : { 0.1f, 0.3f })
            {
                Chord c; c.root = 2; c.quality = q;
                const auto o = simplifyChord (c, s);
                if (! o.valid() || o.root != 2) ++broken;
            }
        CHECK (broken == 0, "SPICE: %d chords came out broken", broken);
        // VOICE SETS: every genre has its own, and the first one starts on the genre's usual voicing
        for (int g = 0; g < numGenres; ++g)
        {
            CHECK (numVoiceSets (g) >= 4, "VOICE SETS: %s has only %d", genreShort (g), numVoiceSets (g));
            CHECK (voiceSetFor (g, 0).styles[0] == genreDefaultStyle (g), "VOICE SETS: %s's first set should start on its usual voicing", genreShort (g));
            CHECK (std::string (voiceSetFor (g, numVoiceSets (g) - 1).name) == "COLORFUL", "VOICE SETS: %s's last set is COLORFUL", genreShort (g));
        }
        // VARY with a voice set: climbing the C major scale (each chord played twice), the top note never jumps far,
        // and the same chord comes back differently
        auto climb = [&] (int genre, int set, float spice, int& maxLeap, int& repeatsDifferent)
        {
            const char* roots[8] = { "", "m", "m", "", "", "m", "dim", "" };
            const int pcs[8] = { 0, 2, 4, 5, 7, 9, 11, 0 };
            Rng rng;
            Notes prev, last;
            int prevRoot = -1;
            maxLeap = 0;
            repeatsDifferent = 0;
            for (int pass = 0; pass < 3; ++pass)
                for (int i = 0; i < 8; ++i)
                    for (int rep = 0; rep < 2; ++rep)
                    {
                        const Chord c = makeChord (pcs[i], roots[i]);
                        const auto pick = chooseVoicing (c, voiceSetFor (genre, set).styles[0], -1, 60, true, prev, true, rep == 1 ? last : Notes(), genre, rng, set, spice, prevRoot);
                        prevRoot = c.root;
                        if (! prev.empty()) maxLeap = std::max (maxLeap, std::abs (pick.notes.highest() - prev.highest()));
                        if (rep == 1 && ! pick.notes.sameAs (last)) ++repeatsDifferent;
                        prev = pick.notes;
                        last = pick.notes;
                    }
        };
        int leapCalm = 0, diffCalm = 0, leapWild = 0, diffWild = 0;
        climb (Soul, 0, 0.2f, leapCalm, diffCalm);
        climb (Soul, numVoiceSets (Soul) - 1, 1.0f, leapWild, diffWild);
        std::printf ("Voice sets: climbing C major with VARY on - SILK at SPICE 20: top note moves at most %d, %d of 24 repeats re-voiced; "
                     "COLORFUL at SPICE 100: at most %d, %d of 24\n", leapCalm, diffCalm, leapWild, diffWild);
        CHECK (leapCalm <= 7, "VOICE SETS: at low SPICE the top note should move smoothly (it jumped %d)", leapCalm);
        CHECK (diffCalm >= 20, "VOICE SETS: a repeated chord should come back re-voiced (%d of 24)", diffCalm);
        std::printf ("Chord palettes: %d chord sets across %d genres, SPICE simplifies every chord, every genre has its voice sets\n", sets, (int) numGenres);
    }

    // ---- DRUM PARTS: FL channel-rack MIDI, one sound per file, all on C5
    {
        struct NameCase { const char* name; int note; };
        const NameCase names[] = { { "Kick", 36 }, { "kick 2", 36 }, { "BD_Hard", 36 }, { "Snare", 38 }, { "SNR_01", 38 }, { "Hi Hat", 42 },
                                   { "HH", 42 }, { "ClosedHat", 42 }, { "OpenHat", 46 }, { "Open Hat 2", 46 }, { "Clap", 39 }, { "Rim", 37 },
                                   { "Perc 1", 63 }, { "808", -2 }, { "Sub Bass", -2 }, { "Low Tom", 45 }, { "Shaker", 70 },
                                   { "Tambourine", 54 }, { "Crash", 49 }, { "Pattern 3", -1 }, { "Channel 7", -1 } };
        for (const auto& c : names)
            CHECK (drumNoteForName (c.name) == c.note, "DRUM PARTS: \"%s\" should be %d, got %d", c.name, c.note, drumNoteForName (c.name));
        auto part = [] (const char* name, std::initializer_list<int> steps, int note = 60)
        {
            DrumPart p;
            p.name = name;
            for (int bar = 0; bar < 2; ++bar)
                for (int s : steps) { ClipNote n; n.start = (float) (bar * 16 + s); n.len = 0.5f; n.note = note; n.vel = 100; p.notes.push_back (n); }
            return p;
        };
        std::vector<DrumPart> parts { part ("Kick", { 0, 8, 10 }), part ("Snare", { 4, 12 }), part ("Hi Hat", { 0, 2, 4, 6, 8, 10, 12, 14 }),
                                      part ("808", { 0, 10 }, 36) };
        CHECK (looksLikeDrumParts (parts), "DRUM PARTS: four one-sound files should count as parts");
        std::vector<ClipNote> bass;
        const auto m = mergeDrumParts (parts, "MY BEAT", &bass);
        auto count = [&] (int note) { int n = 0; for (const auto& c : m.notes) if (c.note == note) ++n; return n; };
        CHECK (count (36) == 6 && count (38) == 4 && count (42) == 16 && count (60) == 0, "DRUM PARTS: kick %d snare %d hat %d, C5 left %d",
               count (36), count (38), count (42), count (60));
        CHECK (bass.size() == 4, "DRUM PARTS: the 808 should go to the bass (%d notes)", (int) bass.size());
        CHECK (m.bars == 2, "DRUM PARTS: two bars (%d)", m.bars);
        // no names: by how they play
        std::vector<DrumPart> anon { part ("Channel 1", { 0, 8 }), part ("Channel 2", { 4, 12 }), part ("Channel 3", { 0, 2, 4, 6, 8, 10, 12, 14 }) };
        const auto a = mergeDrumParts (anon, "X");
        int k = 0, s = 0, h = 0;
        for (const auto& c : a.notes) { if (c.note == 36) ++k; if (c.note == 38) ++s; if (c.note == 42) ++h; }
        CHECK (k == 4 && s == 4 && h == 16, "DRUM PARTS: unnamed parts by how they play (kick %d snare %d hat %d)", k, s, h);
        // two whole loops are not parts
        DrumPart loopA = part ("Loop A", { 0, 8 }, 36), loopB = part ("Loop A", { 4, 12 }, 38), loopC = part ("Loop A", { 2, 6 }, 42);
        DrumPart full1; full1.name = "loop 1"; for (auto* p : { &loopA, &loopB, &loopC }) full1.notes.insert (full1.notes.end(), p->notes.begin(), p->notes.end());
        DrumPart full2 = full1; full2.name = "loop 2";
        CHECK (! looksLikeDrumParts ({ full1, full2 }), "DRUM PARTS: two full loops aren't parts");
        std::printf ("Drum parts: kick / snare / hat / 808 files on C5 land on their pads (the 808 on the bass); unnamed ones by how they play\n");
    }

    // ---- BAND LAYOUTS: every genre has its own, every part is a real instrument and style
    {
        int total = 0;
        for (int g = 0; g < numGenres; ++g)
        {
            CHECK (numBandLayouts (g) >= 3, "LAYOUTS: %s has only %d", genreShort (g), numBandLayouts (g));
            for (int i = 0; i < numBandLayouts (g); ++i)
            {
                const auto& L = bandLayout (g, i);
                ++total;
                CHECK (L.numParts >= 3 && L.numParts <= 8, "LAYOUTS: %s %s has %d parts", genreShort (g), L.name, L.numParts);
                for (int k = 0; k < L.numParts; ++k)
                {
                    const auto& P = L.parts[k];
                    CHECK (P.type >= 0 && P.type < numBandTypes, "LAYOUTS: %s %s part %d: no such instrument", genreShort (g), L.name, k);
                    CHECK (P.style < bandNumStyles (P.type), "LAYOUTS: %s %s part %d: no such style", genreShort (g), L.name, k);
                    CHECK (P.octave >= -2 && P.octave <= 2 && P.level > 0.0f && P.level <= 1.0f, "LAYOUTS: %s %s part %d: octave / level", genreShort (g), L.name, k);
                }
            }
        }
        std::printf ("Band layouts: %d across %d genres\n", total, (int) numGenres);
    }

    std::printf (failures == 0 ? "ALL TESTS PASSED\n" : "%d FAILURES\n", failures);
    return failures == 0 ? 0 : 1;
}
