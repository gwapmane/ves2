// Pictures of the editor for checking the look: vesper_uishot [outdir] [scale]
// Writes ui_<tab>_<theme>.png for the tabs and themes, at the given pixel scale (2 = retina-sharp).
#include "../plugin/PluginProcessor.h"
#include "../plugin/PluginEditor.h"
#include "../core/Theory.h"
#include "../plugin/Chrome.h"
#include "../plugin/Look.h"
#include <cstdio>

using namespace vesper;

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();

int main (int argc, char** argv)
{
    juce::ScopedJuceInitialiser_GUI gui;
    const juce::String dir = argc > 1 ? juce::String (argv[1]) : juce::String ("/tmp/claude-0/ui");
    const float scale = argc > 2 ? (float) std::atof (argv[2]) : 1.0f;
    juce::File (dir).createDirectory();
    {   // a close-up of the knob, and the emblem, on the face
        juce::Image img (juce::Image::RGB, 900, 300, true);
        juce::Graphics g (img);
        const auto& t = themeFor (1);
        g.fillAll (t.panel);
        troupe::drawKnob (g, { 20.0f, 30.0f, 240.0f, 240.0f }, 0.3f, -2.4f, 2.4f, t, true);
        troupe::drawKnob (g, { 290.0f, 30.0f, 240.0f, 240.0f }, 0.8f, -2.4f, 2.4f, t, true);
        troupe::drawKnob (g, { 560.0f, 120.0f, 38.0f, 38.0f }, 0.5f, -2.4f, 2.4f, t, true);
        troupe::drawEmblem (g, { 620.0f, 60.0f, 270.0f, 84.0f });
        juce::File out (dir + "/knob.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat().writeImageToStream (img, os);
    }
    std::unique_ptr<juce::AudioProcessor> base (createPluginFilter());
    auto& p = dynamic_cast<VesperProcessor&> (*base);
    p.setPlayConfigDetails (0, 2, 48000.0, 512);
    p.prepareToPlay (48000.0, 512);
    p.applyBandGenre (Soul);
    struct Shot { int tab, theme; };
    const Shot shots[] = { { 1, 3 }, { 1, 1 }, { 1, 2 }, { 0, 0 }, { 4, 3 }, { 5, 1 } };
    for (const auto& sh : shots)
    {
        p.ui.tab = sh.tab;
        p.ui.theme = sh.theme;
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (30);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, scale);
        juce::File out (dir + "/ui_" + juce::String (sh.tab) + "_" + juce::String (sh.theme) + ".png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat().writeImageToStream (img, os);
        std::printf ("%s (%dx%d)\n", out.getFullPathName().toRawUTF8(), img.getWidth(), img.getHeight());
    }
    if (argc > 3)
    {   // your own picture as the background (MENU > Skin), inside the chrome
        p.ui.tab = 1;
        p.ui.theme = 3;
        p.ui.skin = juce::String (argv[3]);
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (30);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, scale);
        juce::File out (dir + "/ui_skin.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat().writeImageToStream (img, os);
        std::printf ("%s\n", out.getFullPathName().toRawUTF8());
    }
    return 0;
}
