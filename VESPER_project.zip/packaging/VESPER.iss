; Inno Setup script: builds VESPER-Setup.exe from the collected build folder. (VESPER only -
; VESPER DRUMS has its own project and its own VESPER-DRUMS-Setup.exe.)
#ifndef SrcDir
  #define SrcDir "dist"
#endif
#ifndef AppVer
  #define AppVer "2.0.0"
#endif

[Setup]
AppId=VESPER
AppName=Troupe Chord Engine
AppVersion={#AppVer}
AppVerName=Troupe Chord Engine {#AppVer}
AppPublisher=Troupe
DefaultDirName={commoncf64}\VST3
DisableDirPage=yes
DisableProgramGroupPage=yes
OutputBaseFilename=Troupe-Chord-Engine-Setup
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
UninstallFilesDir={commonappdata}\VESPER
Compression=lzma2
SolidCompression=yes

[InstallDelete]
Type: filesandordirs; Name: "{commoncf64}\VST3\VESPER.vst3"

[Files]
Source: "{#SrcDir}\VESPER.vst3\*"; DestDir: "{commoncf64}\VST3\VESPER.vst3"; Flags: recursesubdirs createallsubdirs ignoreversion
; VESPER VOICE (call the song out loud): the SONG tab's VOICE button opens it from here
Source: "{#SrcDir}\VESPER VOICE\*"; DestDir: "{commonpf64}\VESPER VOICE"; Flags: recursesubdirs createallsubdirs ignoreversion skipifsourcedoesntexist

[Icons]
Name: "{commonprograms}\VESPER VOICE"; Filename: "{commonpf64}\VESPER VOICE\VESPER VOICE.exe"; Check: HasVoiceExe
Name: "{commonprograms}\VESPER VOICE"; Filename: "{commonpf64}\VESPER VOICE\VESPER VOICE (PowerShell).bat"; Check: not HasVoiceExe

[Messages]
FinishedLabel=Troupe Chord Engine {#AppVer} is installed (it replaces VESPER). In FL Studio: Options > Manage plugins > Find installed plugins. It shows up under Generators as Troupe Chord Engine.

[Code]
function HasVoiceExe: Boolean;
begin
  Result := FileExists(ExpandConstant('{commonpf64}\VESPER VOICE\VESPER VOICE.exe'));
end;
