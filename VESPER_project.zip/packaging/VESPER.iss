; Inno Setup script: builds VESPER-Setup.exe from the collected build folder. (VESPER only -
; VESPER DRUMS has its own project and its own VESPER-DRUMS-Setup.exe.)
#ifndef SrcDir
  #define SrcDir "dist"
#endif
#ifndef AppVer
  #define AppVer "1.15.0"
#endif

[Setup]
AppId=VESPER
AppName=VESPER
AppVersion={#AppVer}
AppVerName=VESPER {#AppVer}
AppPublisher=VESPER
DefaultDirName={commoncf64}\VST3
DisableDirPage=yes
DisableProgramGroupPage=yes
OutputBaseFilename=VESPER-Setup
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
UninstallFilesDir={commonappdata}\VESPER
Compression=lzma2
SolidCompression=yes

[InstallDelete]
Type: filesandordirs; Name: "{commoncf64}\VST3\VESPER.vst3"

[Files]
Source: "{#SrcDir}\VESPER.vst3\*"; DestDir: "{commoncf64}\VST3\VESPER.vst3"; Flags: recursesubdirs createallsubdirs ignoreversion

[Messages]
FinishedLabel=VESPER {#AppVer} is installed. In FL Studio: Options > Manage plugins > Find installed plugins. It shows up under Generators.
