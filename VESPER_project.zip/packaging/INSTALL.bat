@echo off
setlocal EnableExtensions
title VESPER installer
cd /d "%~dp0"

rem ---- Windows needs admin rights to put plugins in Program Files ----
fltmc >nul 2>&1
if errorlevel 1 (
    echo Asking Windows for permission to install VESPER...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SRC=%~dp0VESPER.vst3"
set "DEST=%CommonProgramFiles%\VST3"

if not exist "%SRC%\" (
    echo.
    echo  Could not find VESPER.vst3 next to this installer.
    echo  Unzip the whole download first ^(right-click the zip ^> Extract All^),
    echo  then double-click INSTALL.bat inside the unzipped folder.
    echo.
    pause
    exit /b 1
)

if not exist "%DEST%" mkdir "%DEST%"
if exist "%DEST%\VESPER.vst3" rmdir /s /q "%DEST%\VESPER.vst3"
xcopy "%SRC%" "%DEST%\VESPER.vst3\" /E /I /Y /Q >nul
if errorlevel 1 (
    echo.
    echo  Copy failed. Close FL Studio and run INSTALL.bat again.
    echo.
    pause
    exit /b 1
)

rem ---- VESPER VOICE: the SONG tab's VOICE button opens it from Program Files ----
if exist "%~dp0VESPER VOICE\" (
    if exist "%ProgramFiles%\VESPER VOICE" rmdir /s /q "%ProgramFiles%\VESPER VOICE"
    xcopy "%~dp0VESPER VOICE" "%ProgramFiles%\VESPER VOICE\" /E /I /Y /Q >nul
)

echo.
echo  ==========================================================
echo   VESPER is installed in:  %DEST%
echo  ==========================================================
echo.
echo   1. Open FL Studio
echo   2. Options ^> Manage plugins ^> Find installed plugins
echo   3. VESPER shows up under Generators (instruments)
echo.
echo   VESPER DRUMS is a separate download with its own installer.
echo   To play YOUR sounds with VESPER, see READ-ME-FIRST.txt
echo.
pause
