// VESPER band: up to 15 tracks that play along with the chords you play, each on its own MIDI
// channel. Every track has a TYPE (melody, counter-melody, bass, strings, horns, drums, pad, keys,
// arp, guitar), so a slot can be any instrument and you can double up (two string lines, no drums...).
// Pure C++ (no JUCE), fixed-size state, no heap on the play path.
//
// How it stays musical: each track builds a one-bar "plan" (rhythm + melodic intentions) from its
// seed. Plans repeat across a phrase in an A A' B A shape, so you get hooks and riffs instead of
// random notes, while the actual pitches are worked out against whatever chord is playing.
#pragma once

#include "Theory.h"
#include "Phrases.h"
#include "Grooves.h"
#include "Clips.h"

namespace vesper
{
enum BandType { BMelody = 0, BCounter, BBass, BStrings, BHorns, BDrums, BPad, BKeys, BArp, BGuitar,
                // one piece of the kit each, all following the band's GROOVE
                BKick, BSnare, BClap, BHats, BOpenHat, BPerc, BCymbal, BTom, numBandTypes };
using BandPart = BandType;                     // older name

static constexpr int numBandParts = 6;         // the original six parts (old projects load into tracks 1-6)
static constexpr int maxBandTracks = 15;       // + the chords = all 16 MIDI channels
static constexpr int defaultBandTracks = 6;

// how a track plays
enum BandMode
{
    ModeJam = 0,    // plays its style along with your chords
    ModeHold,       // plays exactly what you press (in its own octave), for as long as you hold it
    ModeRing,       // one hit per key you press, ringing until you press the next key
    numBandModes
};

const char* bandTypeName (int type);           // "MELODY"
inline const char* bandPartName (int type) { return bandTypeName (type); }
const char* bandTypeShort (int type);          // "Melody" (file / track names)
const char* bandPartId (int part);             // the original six parts' parameter prefixes ("bMel"), for old projects
int bandDefaultType (int track);               // what a fresh track starts as
int bandDefaultChannel (int track);            // default MIDI channel per track (chords are on 1)
int bandNumStyles (int type);
int bandMaxStyles();                           // the most styles any type has
const char* bandStyleName (int type, int style);
const char* bandStyleBlurb (int type, int style);
inline bool bandTypeIsDrums (int type) { return type == BDrums || (type >= BKick && type <= BTom); }
inline int bandTypePiece (int type) { return (type >= BKick && type <= BTom) ? type - BKick : -1; }   // DrumPiece, -1 = not a kit piece
static constexpr int drumGrooveStyle = 19;     // DRUMS styles from here on play the band's GROOVE (normal, half time, double time)
inline bool bandTypeCanHold (int type) { return ! bandTypeIsDrums (type); }

// GENRE on the BAND tab: every type's style and feel for one of VESPER's genres (Theory.h)
struct BandGenrePreset
{
    int style[numBandTypes];
    int lineup;               // bit per type: the parts that genre usually uses
    float density[numBandTypes], complexity[numBandTypes];
};
BandGenrePreset bandGenrePreset (int genre);

struct BandPartConfig
{
    bool on = false;
    int type = BMelody;
    int mode = ModeJam;
    int style = 0;
    uint32_t seed = 1;
    float density = 0.5f, complexity = 0.5f;
    int octave = 0;           // -2 .. +2
    float level = 0.8f;
    int channel = 1;          // MIDI channel this track plays on
    int dyn = 0;              // dynamics for phrase lines: 0 off, 1 CC1, 2 CC11, 3 both
    uint16_t keyMask = 0;     // controller keys (C..B, any octave) this track sits out on
    int surprise = 0;         // SURPRISE: % chance this track sits a chord out (picked fresh on every chord)
};

struct BandConfig
{
    std::array<BandPartConfig, maxBandTracks> part {};
    int numTracks = defaultBandTracks;
    int phraseBars = 4;       // 1, 2, 4 or 8
    float swing = 0.0f;       // 0 .. 0.5 of a 16th (the SWING knob; the patterns themselves are straight)
    int genre = 0;            // the band's GENRE (which grooves)
    int groove = 0;           // GROOVE: 0 .. numGrooves (genre) - 1
    float feel = 1.0f;        // FEEL: 1 = the loops' own push and drag, 0 = right on the grid
    int grooveChange = 0;     // CHANGE: a new related groove every this many bars (0 = keep the one picked)
    float vary = 0.0f;        // VARY: 0 = the groove exactly as it is, 1 = something a little different every time round
    std::array<const ClipSet*, maxBandTracks> clips {};   // YOUR MIDI per track (nullptr = play the style)
};

struct Harmony
{
    Chord chord;
    Notes voicing;            // what the chord part is playing (sorted)
    int keyRoot = 0, scale = 0;
    int id = -1;              // changes every time a new chord is struck
    int key = -1;             // the controller key that struck it (0..11), -1 = a mouse click
    bool valid() const { return chord.valid(); }
    bool sitsOut (const BandPartConfig& c) const
    {
        if (key >= 0 && ((c.keyMask >> key) & 1u)) return true;
        if (c.surprise <= 0 || id < 0) return false;
        uint32_t x = (uint32_t) id * 2654435761u ^ (c.seed * 40503u + 0x9e3779b9u);   // the same answer all through one chord
        x ^= x >> 15; x *= 2246822519u; x ^= x >> 13;
        return (int) (x % 100u) < c.surprise;
    }
};

struct BandEvent
{
    int part = 0;             // track index
    int channel = 1;
    int note = 60;            // CC number when isCC
    int velocity = 100;       // CC value when isCC
    float offset = 0.0f;      // start, in 16th steps after this step's grid time
    float length = 1.0f;      // in 16th steps; < 0 = ring until the chord changes
    bool isCC = false;
};

// HOLD / RING tracks: the notes a track plays for what you're pressing (`played` = VESPER's own
// chord or stack notes, sorted). Bass takes the bottom note, melody the top, counter the one under it.
Notes bandHoldNotes (const BandPartConfig&, const Notes& played, const Chord&);

class Band
{
public:
    static constexpr int maxEventsPerStep = 160;

    void reset();
    // Call once per 16th step (absStep counts 16ths from the song start, or from when the band
    // started when FL is stopped). Returns how many events were written.
    int step (const BandConfig&, const Harmony&, int64_t absStep, BandEvent* out, int maxOut);

    // GM drum notes used by the drum part
    enum Drum { Kick = 36, Rim = 37, Snare = 38, Clap = 39, ClosedHat = 42, LowTom = 45, PedalHat = 44,
                OpenHat = 46, MidTom = 47, Crash = 49, HighTom = 50, Ride = 51, Tambourine = 54, Cowbell = 56,
                Conga = 63, LowConga = 64, Shaker = 70, Claves = 75 };
    static bool isDrumNote (int n);

private:
    struct PlanEv
    {
        int8_t step = 0;
        float off = 0.0f, len = 1.0f;
        int8_t accent = 0;
        int8_t spec = 0;          // what to play (see Band.cpp)
        int8_t a = 0, b = 0;      // spec arguments
    };

    struct PartState
    {
        int last = -1;            // last note played (voice leading)
        int dir = 1;              // melodic direction
        Notes voice;              // last chord voicing (strings / horns / keys / guitar)
        int64_t planBar = -1;
        int planKey = -1;
        int count = 0;
        std::array<PlanEv, 96> plan {};
        int harmonyId = -1;
        int cycle = 0;            // ostinato position

        // phrase player (hand-written lines)
        int phrase = -1;          // index into phraseLibrary(), -1 = between phrases
        int64_t phraseStart = 0, nextPhrase = 0;
        int slot = 0, noteIdx = 0, lastIdx = -1, lastVel = 80;
        int letterA = -1;
        float ccLast = -1;
        uint32_t seedSeen = 0;    // the track's DICE: a new seed = a new line (and not the same idea again)
        int lastBase = -1;
        uint32_t ratingSeen = 0;  // LIKE / SKIP: a line you skip stops right away
    };

    void buildPlan (int track, const BandPartConfig&, const BandConfig&, int64_t bar);
    int phraseStep (int track, int set, const BandPartConfig&, const BandConfig&, const Harmony&, int64_t absStep,
                    BandEvent* out, int maxOut);
    int pickPhrase (int set, const BandPartConfig&, const BandConfig&, uint32_t salt, int avoid, int avoidBase = -1) const;
    int resolve (int track, const PlanEv&, const BandPartConfig&, const Harmony&, int64_t bar, BandEvent* out, int maxOut);
    int clipStep (int track, const ClipSet&, const BandPartConfig&, const BandConfig&, const Harmony&, int64_t absStep, BandEvent* out, int maxOut);
public:
    std::array<int, maxBandTracks> clipNow {};   // which of a track's files is playing (for the display)
    std::array<int, maxBandTracks> phraseNow {}; // the phrase a track is playing (-1 = none), for LIKE / SKIP
    int grooveNow = -1;                          // the groove the drums are on (CHANGE moves it), -1 = no drums yet
private:

    std::array<PartState, maxBandTracks> st {};
    int melodyTrack = -1;     // the melody the counter-melody follows (first melody track that's playing)
    int melodyNote = -1;
    float melodyLen = 0.0f, melodyOff = 0.0f;
    bool melodyHit = false;
};
} // namespace vesper
