#include "Clips.h"
#include "Grooves.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <map>

namespace vesper
{
static int pcOfC (int x) { return ((x % 12) + 12) % 12; }

bool keyFromName (const std::string& raw, int& root, bool& minor)
{
    // split into words: "Dark_Melody_F#m_140bpm" -> dark melody f#m 140bpm
    std::vector<std::string> w;
    std::string cur;
    for (char c : raw)
    {
        if (std::isalnum ((unsigned char) c) || c == '#') cur += c;
        else { if (! cur.empty()) w.push_back (cur); cur.clear(); }
    }
    if (! cur.empty()) w.push_back (cur);
    static const int base[7] = { 9, 11, 0, 2, 4, 5, 7 };   // A B C D E F G
    for (size_t i = 0; i < w.size(); ++i)
    {
        const std::string& t = w[i];
        if (t.empty()) continue;
        const char L = (char) std::toupper ((unsigned char) t[0]);
        if (L < 'A' || L > 'G') continue;
        size_t p = 1;
        int r = base[L - 'A'];
        if (p < t.size() && (t[p] == '#')) { ++r; ++p; }
        else if (p < t.size() && t[p] == 'b' && (t.size() == 2 || t.substr (p, 3) != "bpm")) { --r; ++p; }
        std::string rest = t.substr (p);
        for (auto& c : rest) c = (char) std::tolower ((unsigned char) c);
        bool m = false, ok = false;
        if (rest == "m" || rest == "min" || rest == "minor") { m = true; ok = true; }
        else if (rest == "maj" || rest == "major" || rest == "m7" || rest == "min7") { m = rest[0] == 'm' && rest != "maj" && rest != "major"; ok = true; }
        else if (rest.empty())
        {
            // a bare note name counts when the next word says the mode, or it has a sharp / flat, or follows "key"
            const std::string next = i + 1 < w.size() ? w[i + 1] : "";
            std::string nl = next;
            for (auto& c : nl) c = (char) std::tolower ((unsigned char) c);
            if (nl == "minor" || nl == "min" || nl == "m") { m = true; ok = true; }
            else if (nl == "major" || nl == "maj") ok = true;
            else if (p > 1) ok = true;
            else if (i > 0)
            {
                std::string prev = w[i - 1];
                for (auto& c : prev) c = (char) std::tolower ((unsigned char) c);
                ok = prev == "key";
            }
        }
        if (ok) { root = pcOfC (r); minor = m; return true; }
    }
    return false;
}

void detectKey (const std::vector<ClipNote>& notes, int& root, bool& minor)
{
    // Krumhansl-Schmuckler: how long each pitch class sounds, against the major / minor key profiles
    static const double maj[12] = { 6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88 };
    static const double mnr[12] = { 6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17 };
    double h[12] = {};
    int lowest = 128;
    for (const auto& n : notes) lowest = std::min (lowest, n.note);
    for (const auto& n : notes)
    {
        double wgt = std::max (0.25, (double) n.len);
        if (n.note <= lowest + 7) wgt *= 1.5;             // the bass says a lot about the key
        h[pcOfC (n.note)] += wgt;
    }
    double best = -1e9;
    root = 0; minor = false;
    for (int r = 0; r < 12; ++r)
        for (int mode = 0; mode < 2; ++mode)
        {
            const double* prof = mode ? mnr : maj;
            double mx = 0, my = 0;
            for (int i = 0; i < 12; ++i) { mx += h[(r + i) % 12]; my += prof[i]; }
            mx /= 12; my /= 12;
            double sxy = 0, sxx = 0, syy = 0;
            for (int i = 0; i < 12; ++i)
            {
                const double a = h[(r + i) % 12] - mx, b = prof[i] - my;
                sxy += a * b; sxx += a * a; syy += b * b;
            }
            const double c = (sxx > 0 && syy > 0) ? sxy / std::sqrt (sxx * syy) : 0;
            if (c > best) { best = c; root = r; minor = mode == 1; }
        }
}

void finishClip (MidiClip& c)
{
    std::sort (c.notes.begin(), c.notes.end(), [] (const ClipNote& a, const ClipNote& b) { return a.start < b.start; });
    if (c.notes.empty()) { c.bars = 1; return; }
    // start on the bar where the first note is (exports often start late)
    const float shift = std::floor (c.notes.front().start / 16.0f) * 16.0f;
    float end = 0;
    for (auto& n : c.notes)
    {
        n.start -= shift;
        n.len = std::max (0.1f, n.len);
        end = std::max (end, n.start + std::min (n.len, 4.0f));
    }
    int bars = std::max (1, (int) std::ceil (end / 16.0f - 0.02f));
    int b = 1;
    while (b < bars && b < 32) b *= 2;   // 1, 2, 4, 8, 16, 32 bars
    c.bars = std::min (b, 32);
    // notes past the end (a long last note) are cut at the loop point
    c.notes.erase (std::remove_if (c.notes.begin(), c.notes.end(), [&c] (const ClipNote& n) { return n.start >= (float) (c.bars * 16); }), c.notes.end());
    if (! keyFromName (c.name, c.keyRoot, c.minor)) detectKey (c.notes, c.keyRoot, c.minor);
}

static uint32_t mixC (uint32_t a, uint32_t b)
{
    a ^= b + 0x9e3779b9u + (a << 6) + (a >> 2);
    a ^= a >> 16; a *= 0x7feb352du; a ^= a >> 15; a *= 0x846ca68bu; a ^= a >> 16;
    return a;
}

int clipIndexAt (const ClipSet& s, uint32_t seed, int64_t bar)
{
    const int n = (int) s.clips.size();
    if (n <= 1) return 0;
    const int64_t cyc = std::max (1, s.cycleBars);
    const int64_t c = bar >= 0 ? bar / cyc : (bar - cyc + 1) / cyc;
    const int idx = (int) (mixC (seed, (uint32_t) c) % (uint32_t) n);
    // never the same file twice in a row
    const int prev = (int) (mixC (seed, (uint32_t) (c - 1)) % (uint32_t) n);
    return idx == prev ? (idx + 1) % n : idx;
}

void mapDrumRoles (MidiClip& c)
{
    struct St { int hits = 0, down = 0, back = 0, three = 0, off8 = 0; };
    std::map<int, St> st;
    for (const auto& n : c.notes)
    {
        auto& s = st[n.note];
        const int p = ((int) std::floor (n.start)) % 16;
        ++s.hits;
        if (p == 0) ++s.down;
        if (p == 4 || p == 12) ++s.back;
        if (p == 8) ++s.three;
        if (p % 4 == 2) ++s.off8;
    }
    if (st.empty()) return;
    // already standard? (a kick, a snare or clap and a hat on their usual notes)
    // already on standard drum notes? (a kick on 35/36, the backbeat on a snare / clap note, the busiest
    // other sound on a hat / ride / shaker note)
    bool allGm = st.count (35) || st.count (36);
    for (auto& kv : st) if (kv.first < 35 || kv.first > 81) allGm = false;
    int busiest = -1, backbeat = -1;
    for (auto& kv : st)
    {
        if (kv.first == 35 || kv.first == 36) continue;
        if (busiest < 0 || kv.second.hits > st[busiest].hits) busiest = kv.first;
        if (kv.second.back + kv.second.three > 0 && (backbeat < 0 || kv.second.back > st[backbeat].back)) backbeat = kv.first;
    }
    auto oneOf = [] (int n, std::initializer_list<int> ns) { for (int x : ns) if (x == n) return true; return false; };
    // (a snare that's the busiest sound is fine when it isn't sharing the backbeat with another note:
    // reggaeton / dembow snares skip 2 and 4 entirely and hit everywhere else)
    const bool snareBusy = busiest >= 0 && oneOf (busiest, { 37, 38, 39, 40 }) && (backbeat < 0 || backbeat == busiest);
    if (allGm && (busiest < 0 || st[busiest].hits < 4 || snareBusy || oneOf (busiest, { 42, 44, 46, 51, 53, 54, 69, 70, 82 }))
        && (backbeat < 0 || oneOf (backbeat, { 37, 38, 39, 40 })))
        return;

    std::map<int, int> to;
    auto pick = [&] (auto score) -> int
    {
        int best = -1; double bs = -1e9;
        for (auto& kv : st)
        {
            if (to.count (kv.first)) continue;
            const double sc = score (kv.first, kv.second);
            if (sc > bs) { bs = sc; best = kv.first; }
        }
        return best;
    };
    // the kick: the lowest note that hits the downbeat (it's the lowest pad in nearly every layout)
    const int kick = pick ([] (int note, const St& s) { return (s.down > 0 ? 1000.0 : 0.0) - note; });
    if (kick >= 0) to[kick] = 36;
    // the snare: mostly on the backbeat (a hat that also lands on 2 and 4 hits everywhere else too)
    const int snare = pick ([] (int, const St& s) { return s.hits > 0 ? (s.back * 4.0 + s.three * 2.0) * (double) (s.back + s.three) / s.hits : 0.0; });
    if (snare >= 0 && (st[snare].back + st[snare].three) > 0) to[snare] = 38;
    const int hat = pick ([] (int, const St& s) { return (double) s.hits; });
    if (hat >= 0 && st[hat].hits >= 4) to[hat] = 42;
    const int open = pick ([] (int, const St& s) { return s.hits > 0 ? (double) s.off8 / s.hits * 2.0 + s.off8 * 0.5 : -1.0; });
    if (open >= 0 && st[open].off8 > 0 && st[open].off8 * 2 >= st[open].hits) to[open] = 46;
    // a second backbeat sound: the clap
    const int clap = pick ([] (int, const St& s) { return s.hits > 0 ? (s.back * 3.0 + s.three * 1.5) * (double) (s.back + s.three) / s.hits : 0.0; });
    if (clap >= 0 && (st[clap].back + st[clap].three) > 0) to[clap] = 39;
    static const int percNotes[] = { 63, 64, 37, 54, 70, 56, 75, 60, 61, 49, 51, 45, 47, 50 };
    size_t pi = 0;
    for (auto& kv : st)
        if (! to.count (kv.first)) to[kv.first] = percNotes[std::min (pi++, sizeof (percNotes) / sizeof (int) - 1)];
    for (auto& n : c.notes) n.note = to[n.note];
}

int drumPieceOf (int note)
{
    switch (note)
    {
        case 35: case 36: return PieceKick;
        case 38: case 40: return PieceSnare;
        case 39: return PieceClap;
        case 42: case 44: return PieceHats;
        case 46: return PieceOpenHat;
        case 49: case 51: case 52: case 53: case 55: case 57: case 59: return PieceCymbal;
        case 41: case 43: case 45: case 47: case 48: case 50: return PieceTom;
        default: return PiecePerc;
    }
}

//==============================================================================
// DRUM PARTS
const std::vector<DrumNoteInfo>& drumNoteMap()
{
    static const std::vector<DrumNoteInfo> m {
        { "KICK", 36 }, { "RIM", 37 }, { "SNARE", 38 }, { "CLAP", 39 }, { "CLOSED HAT", 42 }, { "PEDAL HAT", 44 },
        { "OPEN HAT", 46 }, { "LOW TOM", 45 }, { "MID TOM", 47 }, { "HIGH TOM", 50 }, { "CRASH", 49 }, { "RIDE", 51 },
        { "TAMBOURINE", 54 }, { "PERC 1", 63 }, { "PERC 2", 64 }, { "SHAKER", 70 } };
    return m;
}

namespace
{
std::string lowerWords (const std::string& in)
{
    // "OpenHat_02.mid" -> " open hat 02 " (camel case and separators split into words)
    std::string out = " ";
    char prev = ' ';
    for (char ch : in)
    {
        const unsigned char u = (unsigned char) ch;
        if (std::isupper (u) && std::islower ((unsigned char) prev)) out += ' ';
        if (std::isalpha (u)) out += (char) std::tolower (u);
        else if (std::isdigit (u)) { if (std::isalpha ((unsigned char) prev)) out += ' '; out += ch; }
        else out += ' ';
        prev = ch;
    }
    out += ' ';
    return out;
}
bool hasWord (const std::string& w, const char* word) { return w.find (std::string (" ") + word + " ") != std::string::npos; }
bool hasPart (const std::string& w, const char* part) { return w.find (part) != std::string::npos; }
} // namespace

int drumNoteForName (const std::string& name)
{
    const auto w = lowerWords (name);
    if (hasPart (w, "808") || hasWord (w, "bass") || hasWord (w, "sub") || hasPart (w, "bassline")) return -2;
    if (hasPart (w, "kick") || hasWord (w, "kik") || hasWord (w, "kck") || hasWord (w, "bd") || hasPart (w, "bassdrum")) return 36;
    if (hasPart (w, "open") || hasWord (w, "oh") || hasWord (w, "ohh") || hasPart (w, "openhat")) return 46;
    if (hasPart (w, "pedal")) return 44;
    if (hasPart (w, "hat") || hasWord (w, "hh") || hasWord (w, "hihat") || hasWord (w, "ch") || hasWord (w, "chh") || hasPart (w, "closed")) return 42;
    if (hasPart (w, "rim") || hasPart (w, "stick")) return 37;
    if (hasPart (w, "snare") || hasWord (w, "snr") || hasWord (w, "sd") || hasWord (w, "sn")) return 38;
    if (hasPart (w, "clap") || hasWord (w, "clp") || hasWord (w, "cp") || hasPart (w, "snap")) return 39;
    if (hasPart (w, "crash") || hasPart (w, "cymbal") || hasWord (w, "cym")) return 49;
    if (hasPart (w, "ride")) return 51;
    if (hasPart (w, "tom"))
    {
        if (hasPart (w, "low") || hasPart (w, "floor")) return 45;
        if (hasPart (w, "high") || hasWord (w, "hi")) return 50;
        return 47;
    }
    if (hasPart (w, "shak") || hasWord (w, "shk")) return 70;
    if (hasPart (w, "tamb")) return 54;
    if (hasPart (w, "perc") || hasPart (w, "conga") || hasPart (w, "bongo") || hasPart (w, "cowbell") || hasPart (w, "block")
        || hasPart (w, "click") || hasPart (w, "fx") || hasPart (w, "vox") || hasPart (w, "chant")) return 63;
    return -1;
}

namespace
{
int distinctNotes (const std::vector<ClipNote>& v)
{
    std::vector<int> n;
    for (const auto& c : v) if (std::find (n.begin(), n.end(), c.note) == n.end()) n.push_back (c.note);
    return (int) n.size();
}
} // namespace

bool looksLikeDrumParts (const std::vector<DrumPart>& parts)
{
    int withNotes = 0, single = 0;
    for (const auto& p : parts)
    {
        if (p.notes.empty()) continue;
        ++withNotes;
        if (distinctNotes (p.notes) <= 2) ++single;
    }
    return withNotes >= 2 && single * 4 >= withNotes * 3;   // three in four (or more) are one sound each
}

MidiClip mergeDrumParts (const std::vector<DrumPart>& parts, const std::string& name, std::vector<ClipNote>* bassOut)
{
    MidiClip out;
    out.name = name;
    std::vector<bool> taken (128, false);
    int percs = 0;
    std::vector<const DrumPart*> unknown;
    auto place = [&] (const DrumPart& p, int note)
    {
        if (distinctNotes (p.notes) > 2)
        {   // a whole kit in one part: its own notes, sorted out the usual way
            MidiClip c;
            c.notes = p.notes;   // (not moved in time: it lines up with the other parts)
            mapDrumRoles (c);
            for (const auto& n : c.notes) { out.notes.push_back (n); taken[(size_t) std::clamp (n.note, 0, 127)] = true; }
            return;
        }
        // one sound (two notes = a flam or an accent pad): every hit on its pad, the higher note a touch softer
        int hi = -1;
        for (const auto& n : p.notes) hi = std::max (hi, n.note);
        for (auto n : p.notes)
        {
            if (distinctNotes (p.notes) == 2 && n.note == hi) n.vel = std::max (1, n.vel - 10);
            n.note = note;
            out.notes.push_back (n);
        }
        taken[(size_t) note] = true;
    };
    // named parts first
    for (const auto& p : parts)
    {
        if (p.notes.empty()) continue;
        int note = drumNoteForName (p.name);
        if (note == -2) { if (bassOut != nullptr) bassOut->insert (bassOut->end(), p.notes.begin(), p.notes.end()); continue; }
        if (note == 63) note = (percs++ % 2 == 0) ? 63 : 64;
        if (note < 0) { unknown.push_back (&p); continue; }
        if (taken[(size_t) note] && distinctNotes (p.notes) <= 2)
        {   // a second snare / hat part: the next free pad of the same kind
            static const int alt[][2] = { { 38, 40 }, { 39, 37 }, { 42, 44 }, { 46, 44 }, { 36, 35 }, { 63, 64 }, { 64, 70 } };
            for (const auto& a : alt) if (a[0] == note && ! taken[(size_t) a[1]]) { note = a[1]; break; }
        }
        place (p, note);
    }
    // the rest: by how they play (the downbeats = kick, 2 and 4 = snare / clap, the busiest = hats, offbeats = open hat)
    for (const auto* p : unknown)
    {
        int down = 0, back = 0, off8 = 0, hits = 0;
        float last = 0;
        for (const auto& n : p->notes)
        {
            const int pos = ((int) std::floor (n.start)) % 16;
            ++hits;
            if (pos == 0 || pos == 8) ++down;
            if (pos == 4 || pos == 12) ++back;
            if (pos % 4 == 2) ++off8;
            last = std::max (last, n.start);
        }
        const float bars = std::max (1.0f, std::ceil ((last + 0.01f) / 16.0f));
        const float perBar = (float) hits / bars;
        int note = 63;
        auto want = [&] (int n) { return ! taken[(size_t) n]; };
        if (distinctNotes (p->notes) > 2) note = 0;   // a whole kit: place() sorts it
        else if (perBar >= 6.0f && want (42)) note = 42;
        else if (back * 2 >= hits && want (38)) note = 38;
        else if (back * 2 >= hits && want (39)) note = 39;
        else if (down * 2 >= hits && want (36)) note = 36;
        else if (off8 * 2 >= hits && want (46)) note = 46;
        else note = want (63) ? 63 : (want (64) ? 64 : 70);
        place (*p, note);
    }
    finishClip (out);
    return out;
}
} // namespace vesper
