// Playing styles (tempo-synced rhythms, feel, timing) and upper extensions.
// Pure C++ (no JUCE) so it can be unit tested; no heap on the play path.
#pragma once

#include "Theory.h"

namespace vesper
{
enum Rhythm
{
    RPulse = 0, RDriving, RStabs, RSkank, RHouse, RComping, RBossa, RLatin, RFunk, RShuffle, RGospel, RBallad,
    RStride, RBoogie, RBroken, RAlberti, RArpUp, RArpDown, RArpUpDown, RArpRandom, RArp2Oct,
    RWaterfall, RRising, RTremolo, RTrill, numRhythms
};

enum Feel { FSoft = 0, FHard, FAccentTop, FStaccato, FLegato, FGhost, FOctaves, FSwell, FFade, numFeels };
enum Timing { TStrummed = 0, TRolled, TSwing, TLaidBack, TPushed, numTimings };

struct StyleInfo
{
    const char* id;      // parameter id
    const char* name;    // button text
    const char* blurb;   // tooltip
};

const StyleInfo& rhythmInfo (int r);
const StyleInfo& feelInfo (int f);
const StyleInfo& timingInfo (int t);
int feelPartner (int f);      // the feel that can't be on at the same time (-1 = none)
int timingPartner (int t);

// note values
constexpr int numRates = 6;
const char* rateName (int r);    // "1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32"
double rateBeats (int r);        // length of one step in beats
bool rateIsStraight (int r);     // swing applies
int rhythmDefaultRate (int r);
float rhythmDefaultGate (int r); // fraction of a step; <= 0 rings until release
bool rhythmOneShot (int r);      // waterfall / rising run through once
bool rhythmPlaysBass (int r);    // the pattern places the bass itself
bool rhythmNeedsBass (int r);    // the pattern is built around a bass line
bool rhythmBarAligned (int r);   // a bar-long pattern that should line up with FL's bars

struct Hit
{
    Notes notes;         // notes to strike on this step
    Notes hold;          // notes to strike that ring until release (trill)
    int accent = 0;      // velocity offset
    float gate = 0.5f;   // fraction of a step; <= 0 rings until release
    bool rest = true;
};

struct PatternInput
{
    Notes upper;         // chord tones, sorted (includes upper-extension notes when merged)
    int bass = -1;       // bass note, -1 = none
    int poolMask = 0xFFF;  // pitch classes in the key (for trills)
    bool addOctave = true; // waterfall / rising / 2-octave arp also use the octave above the chord
};

// What to play on step k. For grid-synced playing, k is the absolute grid position, so bar-long
// patterns line up with FL's bars. `memory` carries state between steps (random arp).
Hit rhythmStep (int rhythm, int k, const PatternInput&, Rng& rng, int& memory);
int rhythmLength (int rhythm, const PatternInput&);   // steps per cycle (one-shots: total steps)

// Upper extensions
enum ExtType { ExtTensions = 0, ExtUpperTriad, ExtOctaves, ExtSus, ExtFourths, ExtBells, numExtTypes };
enum ExtMode { ExtHold = 0, ExtPulse, ExtArp, ExtWaterfall, ExtWaterfallLoop, ExtRising, numExtModes };
const char* extTypeName (int t);
const char* extTypeBlurb (int t);
const char* extModeName (int m);
const char* extModeBlurb (int m);

// Notes to add above the voicing. Uses tensions that fit the key when the chord is in the key.
Notes upperExtension (const Chord&, const Notes& voicing, int type, int keyRoot, int scale);
} // namespace vesper
