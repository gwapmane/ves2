// YOUR MIDI on a band track: drop MIDI files (or a folder) on a track and it plays them instead of
// its style, a different file every few bars. Drums play as written; melodic files are moved into
// your key and bent onto the chord you're holding (basslines follow each chord's root).
#pragma once

#include "Theory.h"

#include <string>
#include <vector>

namespace vesper
{
struct ClipNote
{
    float start = 0, len = 1;   // 16ths from the clip start
    int note = 60, vel = 100;
};

struct MidiClip
{
    std::string name;
    int bars = 1;
    std::vector<ClipNote> notes;   // sorted by start
    int keyRoot = 0;               // the file's key (detected)
    bool minor = false;
};

struct ClipSet
{
    std::vector<MidiClip> clips;
    int cycleBars = 16;            // a new file every 4, 8 or 16 bars
};

// key of a set of notes (name first: "Am", "F# minor", "Cmaj7 loop"...; then the notes themselves)
bool keyFromName (const std::string& name, int& root, bool& minor);
void detectKey (const std::vector<ClipNote>&, int& root, bool& minor);

// finish a clip read from a file: sort, start at bar 1, work out its length and key
void finishClip (MidiClip&);

// which file of the set plays in this bar (the seed is the track's DICE)
int clipIndexAt (const ClipSet&, uint32_t seed, int64_t bar);

// Drum files from any layout (MPC pads, FPC, Battery, sample packs): works out which note is the kick
// (on the downbeats), the snare (beats 2 and 4, or 3), the hats (the busiest) ... and moves them to the
// standard drum notes VESPER DRUMS plays. Files already on standard notes are left alone.
void mapDrumRoles (MidiClip&);

// GM drum note -> kit piece (core/Grooves.h DrumPiece)
int drumPieceOf (int note);

// DRUM PARTS: the way drums come out of FL's channel rack - one MIDI file (or one track of an export) per sound, often
// every one of them on C5. Each part goes to its sound's standard note (the one VESPER DRUMS' pad plays), by its name
// ("Kick", "snare 2", "HH", "open hat", "perc"...), or by how it plays when the name doesn't say.
struct DrumPart { std::string name; std::vector<ClipNote> notes; };
int drumNoteForName (const std::string& name);              // -1 = the name doesn't say, -2 = not a drum (808, bass)
bool looksLikeDrumParts (const std::vector<DrumPart>&);     // two or more parts, nearly all of one or two sounds each
// the drum parts as one clip (each on its pad); `bassOut` gets the 808 / bass parts (for a bass track)
MidiClip mergeDrumParts (const std::vector<DrumPart>&, const std::string& name, std::vector<ClipNote>* bassOut = nullptr);
// the drum notes VESPER plays, for the map ("KICK", 36)
struct DrumNoteInfo { const char* name; int note; };
const std::vector<DrumNoteInfo>& drumNoteMap();
} // namespace vesper
