// YOUR MIDI on a band track: drop MIDI files (or a folder) on a track and it plays them instead of
// its style, a different file every few bars. Drums play as written; melodic files are moved into
// your key and bent onto the chord you're holding (basslines follow each chord's root).
#pragma once

#include "Theory.h"

#include <string>
#include <vector>

namespace vesper
{
struct ClipNote
{
    float start = 0, len = 1;   // 16ths from the clip start
    int note = 60, vel = 100;
};

struct MidiClip
{
    std::string name;
    int bars = 1;
    std::vector<ClipNote> notes;   // sorted by start
    int keyRoot = 0;               // the file's key (detected)
    bool minor = false;
};

struct ClipSet
{
    std::vector<MidiClip> clips;
    int cycleBars = 16;            // a new file every 4, 8 or 16 bars
};

// key of a set of notes (name first: "Am", "F# minor", "Cmaj7 loop"...; then the notes themselves)
bool keyFromName (const std::string& name, int& root, bool& minor);
void detectKey (const std::vector<ClipNote>&, int& root, bool& minor);

// finish a clip read from a file: sort, start at bar 1, work out its length and key
void finishClip (MidiClip&);

// which file of the set plays in this bar (the seed is the track's DICE)
int clipIndexAt (const ClipSet&, uint32_t seed, int64_t bar);

// Drum files from any layout (MPC pads, FPC, Battery, sample packs): works out which note is the kick
// (on the downbeats), the snare (beats 2 and 4, or 3), the hats (the busiest) ... and moves them to the
// standard drum notes VESPER DRUMS plays. Files already on standard notes are left alone.
void mapDrumRoles (MidiClip&);

// GM drum note -> kit piece (core/Grooves.h DrumPiece)
int drumPieceOf (int note);
} // namespace vesper
