// VESPER's SONG engine: whole-song shapes for every genre (intro, verses, hooks, pre-hooks, bridges, breakdowns,
// builds, drops, solos, outros), who plays in every bar, and the moments that make a beat feel arranged - fills,
// stops, beat drop-outs, builds, crashes, half-time bars. Built from how each genre is usually laid out (not copied
// from any record); every SONG number is a different take, so there are thousands per genre.
// Plain C++ (no JUCE), so the self-test can check it.
#pragma once

#include "Band.h"
#include "Theory.h"

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace vesper
{
enum SongSectionType { SecIntro = 0, SecVerse, SecPre, SecHook, SecBridge, SecBreak, SecBuild, SecDrop, SecSolo, SecOutro, numSongSectionTypes };
enum SongMoment { MomNone = 0, MomFill, MomStop, MomDrop, MomBuild, MomCrash, MomHalf, numSongMoments };

const char* songSectionName (int type);   // "HOOK"
const char* songMomentName (int m);       // "FILL"
const char* songMomentShort (int m);      // "F"
bool songMomentAtEnd (int m);             // FILL / STOP / BUILD happen at the end of their bar (the rest from beat 1)

struct SongSection
{
    int type = SecVerse;
    std::string label;            // what the screen calls it ("HOOK", "HEAD", "DROP"...)
    int bars = 8;
    float energyFrom = 0.5f, energyTo = 0.5f;
    int looper = 0;               // which recorded loop (A-D) it plays, when you've recorded them
    int grooveBlock = 0;          // 0 = your groove, 1..99 = a related groove, 100+ = a beat switch
    std::vector<uint16_t> mask;   // per bar: bit t = band track t plays
    std::vector<uint8_t> moment;  // per bar: a SongMoment
    float energyAt (int bar) const;
};

struct SongPlan
{
    int genre = 0, number = 1;
    std::vector<SongSection> sections;
    int totalBars() const;
    std::string describe() const;   // "INTRO 4 | HOOK 8 | VERSE 16 ..."
};

constexpr int maxSongNumber = 9999;
int songFamily (int genre);   // 0 rap, 1 song, 2 dance, 3 lo-fi, 4 reggaeton, 5 cinematic, 6 jazz, 7 blues

// a whole song for this genre (number picks one of thousands); who plays follows the tracks in `band`
SongPlan makeSongPlan (int genre, int number, const BandConfig& band);
// who plays in every bar of a section, from its energy (after the tracks change)
void songFillMasks (SongSection& s, int genre, const BandConfig& band, uint32_t seed);
// a new take on one section: same kind of section, new length, moments and entrances
void songRerollSection (SongPlan& plan, int index, const BandConfig& band, uint32_t seed);

// one new section of any type, the way this genre does it (bars <= 0: the genre's usual length)
SongSection songMakeSection (int genre, int type, int bars, const BandConfig& band, uint32_t seed);
// after sections are added, removed, moved or retyped: every section's moments look at what comes next again
void songReplaceMoments (SongPlan& plan, int fromIndex, uint32_t seed);

// SHAPES: whole-song arrangements to start from (each genre's own, plus the ones you save)
struct SongShapePart { int type = SecVerse; int bars = 8; std::string label; };
struct SongShape { std::string name; std::vector<SongShapePart> parts; };
std::vector<SongShape> songShapes (int genre);
SongPlan makeSongFromShape (int genre, int number, const BandConfig& band, const SongShape& shape);
std::string songShapeText (const SongPlan& plan);                    // "INTRO 4, VERSE 16, HOOK 8, ..."
bool songShapeFromText (const std::string& text, SongShape& shape);  // the same text back (false = nothing usable)
int songSectionTypeFromName (const std::string& word);              // "hook" / "chorus" -> SecHook, -1 = none
} // namespace vesper
