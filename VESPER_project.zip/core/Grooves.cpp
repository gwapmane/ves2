// VESPER grooves: the groove bank (core/GrooveBank.inc, built by tools/grooves/build_bank.py). Every genre's grooves
// are finished 4-bar phrases - bars 1-3 the groove, bar 4 its turnaround - from three places:
//   - real drummers (the Groove MIDI Dataset, Google Magenta, CC BY 4.0): every hit's velocity and push / drag kept
//   - the cleanest of the loops you sent
//   - each genre's own programming rules (trap rolls, drill skips, dembow, one drop, clave...)
// Near-copies were thrown out when the bank was built, so every groove in a genre's list plays differently, and each
// one is named for what it is. CHANGE moves between a groove's closest neighbours; VARY (core/Band.cpp) plays them a
// little differently every time round.
#include "Grooves.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cmath>

namespace vesper
{
const char* drumPieceName (int piece)
{
    static const char* n[numDrumPieces] = { "KICK", "SNARE", "CLAP", "HATS", "OPEN HAT", "PERC", "CYMBALS", "TOMS" };
    return n[std::clamp (piece, 0, numDrumPieces - 1)];
}

namespace
{
struct BankHit { uint16_t pos; int8_t feel; uint8_t note, vel; };
struct BankGroove { uint8_t genre, bars, flags; uint32_t first; uint16_t count, busy; };
#include "GrooveBank.inc"

constexpr int numBank = (int) (sizeof (bankGrooves) / sizeof (bankGrooves[0]));
static_assert (sizeof (bankNames) / sizeof (bankNames[0]) == (size_t) numBank, "a name for every groove");
static_assert (sizeof (bankNear) / sizeof (bankNear[0]) == (size_t) numBank, "neighbours for every groove");

int pieceOf (int note)
{
    switch (note)
    {
        case 35: case 36: return PieceKick;
        case 37: case 38: return PieceSnare;
        case 39: case 40: return PieceClap;
        case 42: case 44: return PieceHats;
        case 46: return PieceOpenHat;
        case 49: case 51: case 53: case 55: case 57: return PieceCymbal;
        case 41: case 43: case 45: case 47: case 48: case 50: return PieceTom;
        default: return PiecePerc;
    }
}

struct GenreBank
{
    std::vector<Groove> list;
    std::vector<std::array<int, 6>> near;   // each groove's closest neighbours (indices in this genre)
};

const std::vector<GenreBank>& banks()
{
    static const std::vector<GenreBank> all = []
    {
        std::vector<GenreBank> v ((size_t) numGenres);
        std::array<int, numGenres> base {};
        base.fill (-1);
        for (int i = 0; i < numBank; ++i)
        {
            const auto& b = bankGrooves[i];
            if (b.genre >= numGenres) continue;
            if (base[b.genre] < 0) base[b.genre] = i;
            Groove g;
            g.name = bankNames[i];
            g.bars = std::max (1, (int) b.bars);
            g.busy = b.busy;
            g.family = 0;                        // carries its own turnaround (no made-up fills, no extra crash)
            g.live = (b.flags & 1) != 0;
            g.swung = (b.flags & 2) != 0;
            g.hits.reserve (b.count);
            for (uint32_t k = b.first; k < b.first + b.count; ++k)
            {
                const auto& bh = bankHits[k];
                GrooveHit h;
                h.step = bh.pos / 12;
                h.off = (float) (bh.pos % 12) / 12.0f;
                h.feel = (float) bh.feel / 100.0f;
                h.note = bh.note;
                h.vel = std::clamp ((int) bh.vel, 1, 127);
                h.piece = pieceOf (bh.note);
                h.len = h.piece == PieceOpenHat || h.piece == PieceCymbal ? 1.5f : 0.5f;
                g.hits.push_back (h);
            }
            auto& G = v[b.genre];
            std::array<int, 6> nn {};
            for (int k = 0; k < 6; ++k) nn[(size_t) k] = std::max (0, (int) bankNear[i][k] - base[b.genre]);
            G.near.push_back (nn);
            G.list.push_back (std::move (g));
        }
        return v;
    }();
    return all;
}

const GenreBank& bankOf (int genre) { return banks()[(size_t) std::clamp (genre, 0, numGenres - 1)]; }

uint32_t hashMix (uint32_t a, uint32_t b)
{
    uint32_t h = a * 0x9e3779b1u ^ (b + 0x7f4a7c15u + (a << 6) + (a >> 2));
    h ^= h >> 15; h *= 0x2c1b3c6du; h ^= h >> 12; h *= 0x297a2d39u; h ^= h >> 15;
    return h;
}
} // namespace

bool genreHasLoops (int genre) { return ! bankOf (genre).list.empty(); }

int numGrooves (int genre) { return (int) bankOf (genre).list.size(); }

const Groove& groove (int genre, int index)
{
    const auto& list = bankOf (genre).list;
    static const Groove empty;
    if (list.empty()) return empty;
    return list[(size_t) std::clamp (index, 0, (int) list.size() - 1)];
}

std::string grooveLabel (int genre, int index)
{
    const int n = std::clamp (index, 0, std::max (0, numGrooves (genre) - 1)) + 1;
    std::string num = std::to_string (n);
    while (num.size() < 3) num = "0" + num;
    return num + " " + groove (genre, index).name;
}

int grooveNear (int genre, int index, int k)
{
    const auto& B = bankOf (genre);
    if (B.list.empty()) return 0;
    index = std::clamp (index, 0, (int) B.list.size() - 1);
    return std::clamp (B.near[(size_t) index][(size_t) (((k % 6) + 6) % 6)], 0, (int) B.list.size() - 1);
}

int grooveRelated (int genre, int index, int64_t block)
{
    const int n = numGrooves (genre);
    index = std::clamp (index, 0, std::max (0, n - 1));
    if (block == 0 || n < 2) return index;
    const uint32_t h = hashMix (hashMix ((uint32_t) (genre * 31 + 5), (uint32_t) index), (uint32_t) (block & 0xffffffff));
    // one of its closest neighbours - mostly the very closest few, so it moves without changing character
    const int k = (int) ((h >> 3) % 6u) / ((h & 1u) ? 2 : 1);
    int pick = grooveNear (genre, index, k);
    if (pick == index) pick = grooveNear (genre, index, k + 1);
    return pick;
}
} // namespace vesper
