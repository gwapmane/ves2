#pragma once
// BEATBOX: a recording of you beatboxing -> a drum beat. It finds every hit, learns which of YOUR sounds are the kicks,
// snares and hats (by how low or bright each one is, compared with the rest of the take), and puts them on the 16th grid
// at the song's tempo. The first kick is beat 1. No JUCE in here (the plugin reads the audio file and hands it over).
#include "Clips.h"
#include <string>
#include <vector>

namespace vesper
{
enum BeatboxKind { BbKick = 0, BbSnare, BbHat, BbOpenHat, numBeatboxKinds };
const char* beatboxKindName (int kind);   // "KICK"...
int beatboxKindNote (int kind);           // GM: 36, 38, 42, 46

struct BeatboxHit
{
    double time = 0;          // seconds into the recording
    float strength = 0;       // 0-1 (the loudest hit = 1)
    float centroid = 0;       // Hz: how bright it is
    float low = 0, high = 0;  // the share of its energy under 180 Hz / over 3.5 kHz
    float decay = 0;          // seconds until it's 20 dB down
    int kind = BbSnare;
    int slot = -1;            // 16th in the beat
};

struct BeatboxResult
{
    std::vector<ClipNote> notes;      // GM drums on the 16th grid (ClipNote.start in 16ths)
    std::vector<BeatboxHit> hits;     // what it heard, in time order
    int bars = 0;                     // 1, 2, 4 or 8
    double bpm = 0;                   // the tempo it put the beat on
    double heardBpm = 0;              // the tempo you beatboxed at, as far as it can tell
    bool songTempo = false;           // true: you were with the song, so it's on the song's tempo
    int count[numBeatboxKinds] {};
    std::string summary;              // "8 kicks, 8 snares, 14 hats - 2 bars at 90 BPM"
    bool ok() const { return ! notes.empty(); }
};

// mono: the recording (any level, any sample rate); songBpm: the song's tempo (0 = unknown). Up to 64 seconds are used.
BeatboxResult beatboxToDrums (const std::vector<float>& mono, double sampleRate, double songBpm);
}
