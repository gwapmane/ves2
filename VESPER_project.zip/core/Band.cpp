#include "Band.h"

#include <initializer_list>

#include <algorithm>
#include <cmath>

namespace vesper
{
static inline int pcOf (int x) { return ((x % 12) + 12) % 12; }
static constexpr double pi = 3.14159265358979323846;

//==============================================================================
// Names
struct StyleRow { const char* name; const char* blurb; };

static const StyleRow melodyStyles[] = {
    { "POP HOOK",       "Hand-written pop hooks: catchy, repeating, easy to sing" },
    { "R&B / SOUL",     "Hand-written R&B / neo-soul phrases: runs, 9ths, laid back" },
    { "JAZZ BEBOP",     "Hand-written bebop lines: arpeggios, enclosures, swung 8ths" },
    { "GOSPEL BLUES",   "Hand-written gospel licks: blue notes, runs, call-and-response" },
    { "LO-FI",          "Hand-written lo-fi motifs: few notes, lots of space, lazy" },
    { "ROCK RIFF",      "Hand-written riffs: pentatonic, punchy, repeating" },
    { "CLASSICAL",      "Hand-written classical lines: arpeggios, scales, resolutions" },
    { "AMBIENT",        "Long floating notes" },
    { "LATIN",          "Hand-written Latin lines: tresillo rhythms, syncopation" },
    { "TRAP / HIP-HOP", "Hand-written trap melodies: dark, repetitive, triplet flows" },
    { "COUNTRY",        "Hand-written country licks: slides, major pentatonic" },
    { "AFROBEATS",      "Hand-written Afrobeats hooks: bouncy, call-and-response" },
    { "CINEMATIC",      "Hand-written film themes: arching, long notes, big leaps" },
    { "EDM LEAD",       "Hand-written EDM hooks: short, plucky, repeating" },
};
static const StyleRow counterStyles[] = {
    { "HARMONY 3RDS",   "Follows the melody a 3rd below, in key (needs MELODY on)" },
    { "HARMONY 6THS",   "Follows the melody a 6th below, in key (needs MELODY on)" },
    { "ANSWER",         "Hand-written answer licks that fill the gaps, call-and-response" },
    { "GUIDE TONES",    "Holds the 3rd and 7th of each chord, moving smoothly" },
    { "DESCANT",        "A high singing line of long notes above everything" },
    { "OCTAVE DOUBLE",  "Doubles the melody an octave away (needs MELODY on)" },
};
static const StyleRow bassStyles[] = {
    { "ROOTS",          "Root notes on 1 and 3, simple and solid" },
    { "PUMPING 8THS",   "Steady eighth-note roots, pop and rock" },
    { "WALKING",        "Jazz walking quarter notes with approach notes" },
    { "MOTOWN",         "Busy, melodic soul bass with chromatic pickups" },
    { "FUNK",           "Syncopated 16ths, octave pops and ghost notes" },
    { "REGGAE",         "One-drop: weight around beat 3, space everywhere" },
    { "LATIN TUMBAO",   "Anticipated Afro-Cuban bass on the and-of-2 and beat 4" },
    { "808",            "Long sub notes with rolling 808 hits" },
    { "GOSPEL",         "Octave jumps and church walk-ups into each chord" },
    { "DISCO",          "Octave-jumping eighths" },
    { "NEO-SOUL",       "Lazy and sparse, slides and passing notes" },
    { "ROCK",           "Driving roots and fifths" },
    { "AFROBEATS",      "Syncopated, melodic and bouncy" },
    { "REGGAETON",      "Dembow bass locked to the kick" },
    { "DRILL 808",      "Sliding 808s (overlapping notes glide on a mono 808 patch)" },
    { "COUNTRY",        "Root-fifth boom-chick with walk-ups" },
    { "BOOGIE",         "Blues / rock-and-roll walking eighths: 1-3-5-6-b7" },
    { "HOUSE",          "Off-beat bass between the kicks" },
};
static const StyleRow stringStyles[] = {
    { "PAD",            "Lush sustained chords, smoothly voice-led" },
    { "LEGATO VOICES",  "Sustained voices with a moving top line" },
    { "SWELLS",         "Each bar swells in (expression, CC11)" },
    { "SPICCATO 8THS",  "Short bouncing eighth-note chords" },
    { "OSTINATO 16THS", "A driving cinematic sixteenth-note figure" },
    { "PIZZICATO",      "Plucked notes on the beats" },
    { "TREMOLO",        "Fast repeated shimmering chords" },
    { "HIGH DESCANT",   "Violins floating up high: long, singing notes with swells" },
    { "CELLO LINE",     "A singing cello counter-melody, like a real player" },
    { "VIOLIN LYRICAL", "Romantic violin phrases: long notes, swells, sighing steps" },
    { "VIOLIN SOUL",    "70s soul / neo-soul string lines: stabs, slides, answers" },
    { "VIOLIN RUNS",    "Violin flourishes: fast runs that land on the beat" },
};
static const StyleRow hornStyles[] = {
    { "STABS",          "Punchy syncopated section hits" },
    { "SWELLS",         "Long chords that swell up (expression, CC11)" },
    { "SHOUT LINE",     "Hand-written horn riffs in octaves: soul, funk, big band" },
    { "PADS",           "Soft sustained horn chords" },
    { "PUNCHES",        "Short hits on 2 and 4" },
};
static const StyleRow drumStyles[] = {
    { "BOOM BAP",       "Dusty 90s hip-hop (turn up SWING for the classic bounce)" },
    { "TRAP",           "Rolling hats, half-time clap" },
    { "HOUSE",          "Four on the floor, off-beat hats" },
    { "ROCK",           "Straight eighths, big backbeat" },
    { "FUNK",           "Syncopated kick, ghost-note snare, 16th hats" },
    { "JAZZ RIDE",      "Ride cymbal pattern, hi-hat on 2 and 4 (SWING around 65% for jazz)" },
    { "BOSSA NOVA",     "Brazilian kick with a rim-click clave" },
    { "REGGAE",         "One drop: kick and rim together on beat 3" },
    { "GOSPEL SHUFFLE", "Church groove with fills (SWING around 65% for the shuffle)" },
    { "NEO-SOUL",       "Laid-back, lazy snare, ghost notes" },
    { "LO-FI",          "Soft and dusty" },
    { "DISCO",          "Four on the floor with open hats" },
    { "POP",            "Clean modern pop beat" },
    { "AFROBEATS",      "Bouncy kick, rim clave, shaker and congas" },
    { "REGGAETON",      "Dembow: kick on every beat, snare on the and-of-1 and 2" },
    { "DRILL",          "Sliding hats, late snares, bouncy kick" },
    { "COUNTRY TRAIN",  "Train beat: busy snare with accents on 2 and 4" },
    { "BLUES SHUFFLE",  "Shuffle on hats and ride (SWING around 65% for the triplet feel)" },
    { "CINEMATIC",      "Big toms and hits for epic scores" },
    { "GROOVE",         "Plays the GROOVE picked at the top of the BAND tab (50 for every genre)" },
    { "GROOVE HALF",    "The GROOVE at half time: twice as slow, twice as heavy" },
    { "GROOVE DOUBLE",  "The GROOVE at double time" },
};
static const StyleRow pieceStyles[] = {
    { "GROOVE",         "This piece of the kit, exactly as the GROOVE plays it" },
    { "SIMPLE",         "Just the main hits: no ghost notes, no rolls" },
    { "BUSY",           "The GROOVE plus extra ghost notes and pickups" },
    { "HALF TIME",      "This piece at half time" },
    { "DOUBLE TIME",    "This piece at double time" },
};
static const StyleRow padStyles[] = {
    { "HELD",           "Long chords that ring until the next chord" },
    { "SWELL",          "Each bar swells in (expression, CC11)" },
    { "BREATHING",      "Soft chords that strike again every half bar" },
    { "HIGH SHIMMER",   "Held chords up high, airy and bright" },
    { "LOW WARM",       "Held chords down low and warm" },
};
static const StyleRow keysStyles[] = {
    { "BLOCK CHORDS",   "Chords on beats 1 and 3, simple and solid" },
    { "QUARTERS",       "A chord on every beat (pop, rock, gospel)" },
    { "OFFBEAT SKANK",  "Short chords on the and of each beat (reggae, ska)" },
    { "CHARLESTON",     "Jazz comping: beat 1 and the and of 2" },
    { "GOSPEL COMP",    "Syncopated church stabs with pushes" },
    { "HOUSE STABS",    "Short off-beat stabs between the kicks" },
    { "NEO-SOUL",       "Lazy, syncopated chords that sit back" },
    { "BALLAD",         "Half notes with soft pickups" },
    { "AFRO / HIGHLIFE","Bouncy syncopated chords" },
};
static const StyleRow arpStyles[] = {
    { "UP 16THS",       "Chord notes climbing in 16ths" },
    { "DOWN 16THS",     "Chord notes falling in 16ths" },
    { "UP-DOWN 16THS",  "Up and back down in 16ths" },
    { "UP 8THS",        "Chord notes climbing in 8ths" },
    { "RANDOM 16THS",   "Chord notes in a random order (the same every bar, DICE for a new one)" },
    { "OCTAVE PULSE",   "Root and octave bouncing in 8ths" },
    { "TRIPLET UP",     "Rolling 8th-note triplets" },
};
static const StyleRow guitarStyles[] = {
    { "STRUM 8THS",     "Down-up strums on every 8th" },
    { "ISLAND STRUM",   "Down, down-up, up-down-up" },
    { "FUNK CHOP",      "Tight 16th chops with muted scratches" },
    { "FINGERPICK",     "Picked patterns like a folk / R&B guitarist" },
    { "POWER CHUGS",    "Palm-muted power chords in 8ths (rock)" },
    { "WHOLE STRUM",    "One big strum that rings out" },
    { "SKANK",          "Short upstrokes on the off-beats (reggae)" },
};

static const StyleRow* rows (int type, int& count)
{
    switch (type)
    {
        case BMelody:  count = (int) (sizeof (melodyStyles) / sizeof (StyleRow));  return melodyStyles;
        case BCounter: count = (int) (sizeof (counterStyles) / sizeof (StyleRow)); return counterStyles;
        case BBass:    count = (int) (sizeof (bassStyles) / sizeof (StyleRow));    return bassStyles;
        case BStrings: count = (int) (sizeof (stringStyles) / sizeof (StyleRow));  return stringStyles;
        case BHorns:   count = (int) (sizeof (hornStyles) / sizeof (StyleRow));    return hornStyles;
        case BPad:     count = (int) (sizeof (padStyles) / sizeof (StyleRow));     return padStyles;
        case BKeys:    count = (int) (sizeof (keysStyles) / sizeof (StyleRow));    return keysStyles;
        case BArp:     count = (int) (sizeof (arpStyles) / sizeof (StyleRow));     return arpStyles;
        case BGuitar:  count = (int) (sizeof (guitarStyles) / sizeof (StyleRow));  return guitarStyles;
        case BDrums:   count = (int) (sizeof (drumStyles) / sizeof (StyleRow));    return drumStyles;
        default:       count = (int) (sizeof (pieceStyles) / sizeof (StyleRow));   return pieceStyles;
    }
}

const char* bandTypeName (int type)
{
    static const char* n[numBandTypes] = { "MELODY", "COUNTER", "BASS", "STRINGS", "HORNS", "DRUMS", "PAD", "KEYS", "ARP", "GUITAR",
                                           "KICK", "SNARE", "CLAP", "HATS", "OPEN HAT", "PERC", "CYMBALS", "TOMS" };
    return n[std::clamp (type, 0, numBandTypes - 1)];
}

const char* bandTypeShort (int type)
{
    static const char* n[numBandTypes] = { "Melody", "Counter", "Bass", "Strings", "Horns", "Drums", "Pad", "Keys", "Arp", "Guitar",
                                           "Kick", "Snare", "Clap", "Hats", "Open hat", "Perc", "Cymbals", "Toms" };
    return n[std::clamp (type, 0, numBandTypes - 1)];
}

const char* bandPartId (int part)
{
    static const char* n[numBandParts] = { "bMel", "bCtr", "bBass", "bStr", "bHrn", "bDrm" };
    return n[std::clamp (part, 0, numBandParts - 1)];
}

int bandDefaultType (int track)
{
    // the first six are the original band; tracks you add start as keys, pad, arp, guitar...
    static const int t[maxBandTracks] = { BMelody, BCounter, BBass, BStrings, BHorns, BDrums,
                                          BKeys, BPad, BArp, BGuitar, BStrings, BHorns, BMelody, BCounter, BPad };
    return t[std::clamp (track, 0, maxBandTracks - 1)];
}

int bandDefaultChannel (int track)
{
    // chords on 1; every track its own channel, drums on 10 (the General MIDI drum channel)
    static const int ch[maxBandTracks] = { 3, 4, 2, 5, 6, 10, 7, 8, 9, 11, 12, 13, 14, 15, 16 };
    return ch[std::clamp (track, 0, maxBandTracks - 1)];
}

int bandNumStyles (int type) { int c = 0; rows (type, c); return c; }

int bandMaxStyles()
{
    int m = 0;
    for (int t = 0; t < numBandTypes; ++t) m = std::max (m, bandNumStyles (t));
    return m;
}

const char* bandStyleName (int type, int style)
{
    int c = 0;
    const auto* r = rows (type, c);
    return r[std::clamp (style, 0, c - 1)].name;
}

const char* bandStyleBlurb (int type, int style)
{
    int c = 0;
    const auto* r = rows (type, c);
    return r[std::clamp (style, 0, c - 1)].blurb;
}

BandGenrePreset bandGenrePreset (int genre)
{
    enum { M = 1 << BMelody, C = 1 << BCounter, B = 1 << BBass, S = 1 << BStrings, H = 1 << BHorns, D = 1 << BDrums };
    struct Row { int st[6]; int lineup; float melD, melC, bassD, bassC, drmD, drmC; };
    //                    MEL CTR BASS STR HRN DRM
    static const Row rows[numGenres] = {
        { {  1, 3,  3, 10, 0,  9 }, M | B | D | C, .55f, .55f, .55f, .55f, .55f, .55f },  // R&B / soul
        { {  2, 0,  2, 0, 3,  5 }, M | B | D,     .60f, .65f, .50f, .55f, .50f, .60f },   // jazz
        { {  3, 2,  8, 2, 2,  8 }, M | B | D | S, .55f, .60f, .60f, .60f, .55f, .60f },   // gospel
        { {  5, 5, 11, 3, 4,  3 }, M | B | D,     .55f, .45f, .60f, .45f, .55f, .45f },   // rock / indie
        { {  0, 1,  1, 3, 4, 12 }, M | B | D | S, .55f, .40f, .55f, .35f, .55f, .40f },   // pop
        { {  1, 3,  0, 0, 0,  0 }, M | B | D,     .45f, .50f, .55f, .55f, .55f, .55f },   // hip-hop
        { {  9, 5,  7, 4, 1,  1 }, M | B | D,     .55f, .50f, .55f, .60f, .65f, .60f },   // trap
        { {  9, 4, 14, 9, 1, 15 }, M | B | D | S, .50f, .55f, .55f, .60f, .60f, .60f },   // drill
        { {  1, 3, 10, 10, 3,  9 }, M | B | D | C, .50f, .60f, .55f, .60f, .55f, .60f },  // neo-soul
        { {  4, 4, 10, 0, 3, 10 }, M | B | D,     .40f, .45f, .45f, .45f, .50f, .45f },   // lo-fi
        { {  1, 2,  4, 3, 0,  4 }, M | B | D | H, .55f, .55f, .65f, .65f, .65f, .65f },   // funk / disco
        { { 13, 4, 17, 0, 0,  2 }, M | B | D,     .60f, .45f, .55f, .45f, .60f, .45f },   // house / edm
        { { 11, 3, 12, 0, 0, 13 }, M | B | D,     .55f, .45f, .55f, .50f, .60f, .50f },   // afrobeats
        { {  8, 1,  6, 5, 0,  6 }, M | B | D,     .55f, .55f, .55f, .55f, .55f, .55f },   // latin
        { {  8, 1, 13, 0, 0, 14 }, M | B | D,     .55f, .45f, .60f, .45f, .55f, .45f },   // reggaeton
        { {  0, 1,  5, 0, 4,  7 }, M | B | D,     .50f, .45f, .55f, .50f, .55f, .50f },   // reggae
        { { 10, 1, 15, 9, 3, 16 }, M | B | D,     .55f, .45f, .55f, .50f, .55f, .45f },   // country
        { {  3, 2, 16, 0, 0, 17 }, M | B | D,     .55f, .55f, .60f, .45f, .55f, .50f },   // blues
        { { 12, 4,  0, 4, 1, 18 }, M | B | D | S, .45f, .50f, .30f, .40f, .55f, .55f },   // cinematic
    };
    // the newer types:       soul jazz gosp rock pop hiph trap drll neo lofi funk hous afro latn rgtn rgae ctry blue cine
    static const int padSt[numGenres]    = { 0,  0,   2,   4,   0,  3,   3,   4,   0,  4,   0,   1,   0,   0,   0,   0,   0,   4,   1 };
    static const int keysSt[numGenres]   = { 6,  3,   4,   1,   1,  0,   0,   7,   6,  7,   4,   5,   8,   4,   2,   2,   1,   1,   7 };
    static const int arpSt[numGenres]    = { 2,  3,   2,   3,   0,  3,   0,   1,   2,  3,   0,   0,   5,   4,   0,   3,   3,   3,   6 };
    static const int guitarSt[numGenres] = { 3,  5,   0,   4,   0,  3,   3,   5,   3,  3,   2,   2,   3,   3,   1,   6,   0,   0,   5 };

    const int gi = std::clamp (genre, 0, numGenres - 1);
    const Row& r = rows[gi];
    BandGenrePreset p {};
    for (int i = 0; i < numBandTypes; ++i)
    {
        int st = 0;
        if (i == BDrums) st = drumGrooveStyle;   // the drums play the GROOVE picked at the top of the BAND tab
        else if (i < numBandParts) st = r.st[i];
        else if (i == BPad) st = padSt[gi];
        else if (i == BKeys) st = keysSt[gi];
        else if (i == BArp) st = arpSt[gi];
        else if (i == BGuitar) st = guitarSt[gi];
        p.style[i] = std::clamp (st, 0, bandNumStyles (i) - 1);
        p.density[i] = 0.5f;
        p.complexity[i] = 0.5f;
    }
    p.lineup = r.lineup;
    p.density[BMelody] = r.melD;  p.complexity[BMelody] = r.melC;
    p.density[BBass] = r.bassD;   p.complexity[BBass] = r.bassC;
    p.density[BDrums] = r.drmD;   p.complexity[BDrums] = r.drmC;
    return p;
}


//==============================================================================
// BAND LAYOUTS
namespace
{
#define LP(type, style, d, c, oct, lvl) LayoutPart { type, style, d, c, oct, lvl }
#define DR LP (BDrums, -1, 0.55f, 0.55f, 0, 0.8f)
#define LAYOUT(name, blurb, ...) BandLayout { name, blurb, { __VA_ARGS__ }, (int) std::initializer_list<LayoutPart> { __VA_ARGS__ }.size() }
struct GenreLayouts { int genre; BandLayout l[5]; int n; };
const GenreLayouts& layoutsOf (int genre)
{
    static const GenreLayouts all[] = {
        { Soul, { LAYOUT ("SLOW JAM", "Neo-soul bass and keys, a soul violin, a warm pad and an R&B melody",
                          DR, LP (BBass, 10, .5f, .5f, 0, .8f), LP (BKeys, 6, .5f, .5f, 0, .75f), LP (BStrings, 10, .4f, .5f, 0, .6f),
                          LP (BMelody, 1, .45f, .5f, 0, .7f), LP (BPad, 4, .5f, .5f, 0, .5f)),
                  LAYOUT ("90s R&B", "Motown bass, ballad keys, a melody with a harmony in 3rds over a pad",
                          DR, LP (BBass, 3, .55f, .5f, 0, .8f), LP (BKeys, 7, .5f, .5f, 0, .75f), LP (BMelody, 1, .5f, .5f, 0, .7f),
                          LP (BCounter, 0, .45f, .5f, 0, .55f), LP (BPad, 0, .5f, .5f, 0, .45f)),
                  LAYOUT ("STRIPPED", "Just drums, bass, keys and a quiet melody",
                          LP (BDrums, -1, .4f, .45f, 0, .75f), LP (BBass, 0, .45f, .45f, 0, .8f), LP (BKeys, 6, .45f, .5f, 0, .75f),
                          LP (BMelody, 1, .35f, .45f, 0, .65f)),
                  LAYOUT ("STRINGS & SOUL", "Legato strings, a lyrical violin up top and horn swells",
                          DR, LP (BBass, 10, .5f, .5f, 0, .8f), LP (BStrings, 1, .5f, .5f, 0, .6f), LP (BStrings, 9, .45f, .5f, 1, .55f),
                          LP (BMelody, 1, .4f, .5f, 0, .7f), LP (BHorns, 1, .4f, .5f, 0, .5f)) }, 4 },
        { Jazz, { LAYOUT ("TRIO", "Walking bass, comping piano, the ride", DR, LP (BBass, 2, .6f, .6f, 0, .8f), LP (BKeys, 3, .5f, .55f, 0, .75f)),
                  LAYOUT ("QUARTET", "The trio plus a lead and guide tones",
                          DR, LP (BBass, 2, .6f, .6f, 0, .8f), LP (BKeys, 3, .5f, .55f, 0, .7f), LP (BMelody, 2, .55f, .6f, 0, .7f),
                          LP (BCounter, 3, .4f, .5f, 0, .5f)),
                  LAYOUT ("BIG BAND", "Shout lines and horn stabs over walking bass",
                          DR, LP (BBass, 2, .6f, .6f, 0, .8f), LP (BKeys, 1, .5f, .5f, 0, .65f), LP (BHorns, 2, .6f, .6f, 0, .7f),
                          LP (BHorns, 0, .5f, .5f, 0, .6f), LP (BMelody, 2, .5f, .6f, 0, .65f)),
                  LAYOUT ("BALLAD", "Soft drums, ballad piano, strings and a sparse lead",
                          LP (BDrums, -1, .35f, .4f, 0, .7f), LP (BBass, 0, .4f, .45f, 0, .75f), LP (BKeys, 7, .45f, .5f, 0, .75f),
                          LP (BStrings, 1, .45f, .5f, 0, .55f), LP (BMelody, 2, .35f, .5f, 0, .65f)) }, 4 },
        { Gospel, { LAYOUT ("SUNDAY MORNING", "Gospel bass and piano comping with an organ pad",
                            DR, LP (BBass, 8, .55f, .6f, 0, .8f), LP (BKeys, 4, .55f, .6f, 0, .75f), LP (BPad, 0, .5f, .5f, 0, .55f),
                            LP (BMelody, 3, .45f, .55f, 0, .7f)),
                    LAYOUT ("CHOIR", "Voices in legato and 3rds over the gospel rhythm section",
                            DR, LP (BBass, 8, .55f, .6f, 0, .8f), LP (BKeys, 4, .5f, .55f, 0, .7f), LP (BStrings, 1, .5f, .5f, 0, .6f),
                            LP (BCounter, 0, .45f, .5f, 0, .55f), LP (BMelody, 3, .45f, .55f, 0, .7f)),
                    LAYOUT ("PRAISE BREAK", "Everything up: busy bass, drums and keys, horn punches",
                            LP (BDrums, -1, .7f, .7f, 0, .85f), LP (BBass, 8, .7f, .7f, 0, .85f), LP (BKeys, 4, .7f, .7f, 0, .75f),
                            LP (BHorns, 4, .6f, .6f, 0, .65f), LP (BPad, 0, .5f, .5f, 0, .5f)) }, 3 },
        { Rock, { LAYOUT ("POWER TRIO", "Rock bass, power chugs and a riff", DR, LP (BBass, 11, .55f, .5f, 0, .8f), LP (BGuitar, 4, .6f, .5f, 0, .75f),
                          LP (BMelody, 5, .45f, .5f, 0, .65f)),
                  LAYOUT ("INDIE", "Pumping bass, strummed and fingerpicked guitars, quarter-note piano",
                          DR, LP (BBass, 1, .55f, .45f, 0, .8f), LP (BGuitar, 0, .55f, .5f, 0, .7f), LP (BGuitar, 3, .45f, .5f, 1, .55f),
                          LP (BKeys, 1, .45f, .45f, 0, .5f)),
                  LAYOUT ("ARENA", "Chugs, big strums, strings and the riff",
                          DR, LP (BBass, 11, .55f, .5f, 0, .8f), LP (BGuitar, 4, .6f, .5f, 0, .7f), LP (BGuitar, 5, .45f, .45f, 0, .6f),
                          LP (BStrings, 1, .45f, .5f, 0, .5f), LP (BMelody, 5, .45f, .5f, 0, .65f)) }, 3 },
        { Pop, { LAYOUT ("RADIO POP", "Pumping bass, piano, an 8th-note arp, the hook and a pad",
                         DR, LP (BBass, 1, .55f, .4f, 0, .8f), LP (BKeys, 1, .5f, .45f, 0, .7f), LP (BArp, 3, .5f, .5f, 1, .5f),
                         LP (BMelody, 0, .55f, .45f, 0, .7f), LP (BPad, 0, .5f, .5f, 0, .45f)),
                 LAYOUT ("PIANO BALLAD", "Ballad piano and strings, soft drums",
                         LP (BDrums, -1, .4f, .4f, 0, .7f), LP (BBass, 0, .45f, .4f, 0, .75f), LP (BKeys, 7, .5f, .5f, 0, .75f),
                         LP (BStrings, 1, .45f, .5f, 0, .55f), LP (BMelody, 0, .4f, .45f, 0, .65f)),
                 LAYOUT ("SYNTH POP", "16th arps, a swelling pad and a synth lead",
                         DR, LP (BBass, 1, .55f, .4f, 0, .8f), LP (BArp, 0, .55f, .5f, 0, .6f), LP (BPad, 1, .5f, .5f, 0, .5f),
                         LP (BMelody, 13, .5f, .5f, 0, .7f)),
                 LAYOUT ("ACOUSTIC", "Strummed and fingerpicked guitars, simple bass",
                         LP (BDrums, -1, .45f, .4f, 0, .7f), LP (BBass, 0, .45f, .4f, 0, .75f), LP (BGuitar, 0, .55f, .5f, 0, .7f),
                         LP (BGuitar, 3, .45f, .5f, 0, .5f), LP (BMelody, 0, .45f, .45f, 0, .65f)) }, 4 },
        { HipHop, { LAYOUT ("BOOM BAP", "Roots bass, chopped keys, horn stabs, a sparse line",
                            DR, LP (BBass, 0, .55f, .5f, 0, .8f), LP (BKeys, 0, .45f, .5f, 0, .7f), LP (BHorns, 0, .4f, .5f, 0, .5f),
                            LP (BMelody, 9, .35f, .5f, 0, .6f)),
                    LAYOUT ("SOUL SAMPLE", "Neo-soul bass and keys with a soul violin and horn swells",
                            DR, LP (BBass, 10, .5f, .5f, 0, .8f), LP (BKeys, 6, .5f, .5f, 0, .7f), LP (BStrings, 10, .4f, .5f, 0, .55f),
                            LP (BHorns, 1, .4f, .5f, 0, .5f)),
                    LAYOUT ("WEST COAST", "Funk bass, a synth lead up high, a pad and block keys",
                            DR, LP (BBass, 4, .6f, .55f, 0, .8f), LP (BMelody, 13, .45f, .5f, 1, .6f), LP (BPad, 0, .5f, .5f, 0, .45f),
                            LP (BKeys, 0, .45f, .45f, 0, .6f)),
                    LAYOUT ("JAZZY", "Walking bass, comping keys, soft horn pads, a jazz line",
                            DR, LP (BBass, 2, .45f, .5f, 0, .75f), LP (BKeys, 3, .45f, .5f, 0, .7f), LP (BHorns, 3, .4f, .5f, 0, .45f),
                            LP (BMelody, 2, .35f, .5f, 0, .6f)) }, 4 },
        { Trap, { LAYOUT ("ALL ARPS", "808 under three arps: 16ths up high, triplets in the middle, an octave pulse below",
                          DR, LP (BBass, 7, .55f, .6f, 0, .85f), LP (BArp, 0, .55f, .5f, 1, .55f), LP (BArp, 6, .5f, .5f, 0, .5f),
                          LP (BArp, 5, .45f, .5f, -1, .45f)),
                  LAYOUT ("ARPS + PADS", "808, an 8th-note arp, a warm pad and a shimmer, a quiet melody",
                          DR, LP (BBass, 7, .55f, .6f, 0, .85f), LP (BArp, 3, .5f, .5f, 1, .55f), LP (BPad, 4, .5f, .5f, 0, .5f),
                          LP (BPad, 3, .45f, .5f, 1, .4f), LP (BMelody, 9, .4f, .5f, 0, .6f)),
                  LAYOUT ("PIANO & STRINGS", "808, piano, pizzicato and legato strings, a melody",
                          DR, LP (BBass, 7, .55f, .6f, 0, .85f), LP (BKeys, 7, .5f, .5f, 0, .6f), LP (BStrings, 5, .5f, .5f, 0, .5f),
                          LP (BStrings, 1, .45f, .5f, 0, .45f), LP (BMelody, 9, .45f, .5f, 0, .65f)),
                  LAYOUT ("DARK BELLS", "808, a bell melody up high doubled in octaves, a low pad",
                          DR, LP (BBass, 7, .55f, .6f, 0, .85f), LP (BMelody, 9, .55f, .55f, 1, .65f), LP (BCounter, 5, .45f, .5f, 0, .45f),
                          LP (BPad, 4, .5f, .5f, -1, .5f)),
                  LAYOUT ("GUITAR TRAP", "808 and a fingerpicked guitar over a soft pad",
                          DR, LP (BBass, 7, .55f, .6f, 0, .85f), LP (BGuitar, 3, .55f, .5f, 0, .6f), LP (BPad, 0, .45f, .5f, 0, .4f),
                          LP (BMelody, 9, .4f, .5f, 0, .6f)) }, 5 },
        { Drill, { LAYOUT ("UK DRILL", "Sliding drill 808, a melody and legato strings",
                           DR, LP (BBass, 14, .55f, .6f, 0, .85f), LP (BMelody, 9, .5f, .55f, 0, .65f), LP (BStrings, 1, .45f, .5f, 0, .5f)),
                   LAYOUT ("DARK PIANO", "Drill 808, block piano, a melody and a low pad",
                           DR, LP (BBass, 14, .55f, .6f, 0, .85f), LP (BKeys, 0, .45f, .5f, 0, .6f), LP (BMelody, 9, .45f, .55f, 0, .6f),
                           LP (BPad, 4, .5f, .5f, 0, .45f)),
                   LAYOUT ("CHOIR & STRINGS", "Tremolo and high strings, a held choir pad, a sparse melody",
                           DR, LP (BBass, 14, .55f, .6f, 0, .85f), LP (BStrings, 6, .45f, .5f, 0, .45f), LP (BStrings, 7, .45f, .5f, 1, .45f),
                           LP (BPad, 0, .5f, .5f, 0, .5f), LP (BMelody, 9, .4f, .5f, 0, .6f)) }, 3 },
        { NeoSoul, { LAYOUT ("RHODES & BASS", "Neo-soul bass and keys, an R&B melody",
                             DR, LP (BBass, 10, .5f, .55f, 0, .8f), LP (BKeys, 6, .5f, .55f, 0, .75f), LP (BMelody, 1, .4f, .5f, 0, .65f)),
                     LAYOUT ("FULL BAND", "Keys, fingerpicked guitar, a soul violin, guide tones and a melody",
                             DR, LP (BBass, 10, .5f, .55f, 0, .8f), LP (BKeys, 6, .5f, .55f, 0, .7f), LP (BGuitar, 3, .45f, .5f, 0, .5f),
                             LP (BStrings, 10, .4f, .5f, 0, .5f), LP (BCounter, 3, .4f, .5f, 0, .45f), LP (BMelody, 1, .4f, .5f, 0, .65f)),
                     LAYOUT ("LATE NIGHT", "Soft drums, roots bass, keys, a warm pad and horn pads",
                             LP (BDrums, -1, .4f, .5f, 0, .7f), LP (BBass, 0, .4f, .45f, 0, .75f), LP (BKeys, 6, .45f, .5f, 0, .7f),
                             LP (BPad, 4, .5f, .5f, 0, .5f), LP (BHorns, 3, .4f, .5f, 0, .45f)) }, 3 },
        { LoFi, { LAYOUT ("STUDY BEATS", "Mellow bass, ballad keys, a lo-fi line and a warm pad",
                          DR, LP (BBass, 10, .45f, .45f, 0, .75f), LP (BKeys, 7, .45f, .5f, 0, .7f), LP (BMelody, 4, .35f, .45f, 0, .6f),
                          LP (BPad, 4, .45f, .5f, 0, .45f)),
                  LAYOUT ("JAZZY LO-FI", "Walking bass, comping keys, fingerpicked guitar",
                          DR, LP (BBass, 2, .4f, .45f, 0, .75f), LP (BKeys, 3, .45f, .5f, 0, .7f), LP (BGuitar, 3, .45f, .5f, 0, .5f),
                          LP (BMelody, 4, .3f, .45f, 0, .55f)),
                  LAYOUT ("RAINY", "Barely-there drums, ballad keys, a breathing pad and string swells",
                          LP (BDrums, -1, .35f, .4f, 0, .7f), LP (BBass, 0, .35f, .4f, 0, .7f), LP (BKeys, 7, .45f, .5f, 0, .7f),
                          LP (BPad, 2, .5f, .5f, 0, .5f), LP (BStrings, 2, .4f, .5f, 0, .4f)) }, 3 },
        { Funk, { LAYOUT ("FUNK BAND", "Funk bass and guitar chop, clav-style keys, horn stabs",
                          DR, LP (BBass, 4, .65f, .6f, 0, .85f), LP (BGuitar, 2, .6f, .55f, 0, .65f), LP (BKeys, 0, .55f, .5f, 0, .55f),
                          LP (BHorns, 0, .55f, .55f, 0, .6f)),
                  LAYOUT ("DISCO", "Disco bass, guitar chop, string ostinato, horn punches, house stabs",
                          DR, LP (BBass, 9, .6f, .55f, 0, .85f), LP (BGuitar, 2, .55f, .5f, 0, .6f), LP (BStrings, 4, .5f, .5f, 0, .5f),
                          LP (BHorns, 4, .5f, .5f, 0, .55f), LP (BKeys, 5, .5f, .5f, 0, .5f)),
                  LAYOUT ("JAZZ FUNK", "Funk bass, neo-soul keys, shout lines and a jazz lead",
                          DR, LP (BBass, 4, .6f, .6f, 0, .85f), LP (BKeys, 6, .5f, .55f, 0, .65f), LP (BHorns, 2, .5f, .55f, 0, .55f),
                          LP (BMelody, 2, .45f, .55f, 0, .6f)) }, 3 },
        { House, { LAYOUT ("PIANO HOUSE", "House bass, piano stabs, a pad and a lead",
                           DR, LP (BBass, 17, .55f, .45f, 0, .85f), LP (BKeys, 5, .6f, .5f, 0, .7f), LP (BPad, 0, .45f, .5f, 0, .45f),
                           LP (BMelody, 13, .4f, .45f, 0, .6f)),
                   LAYOUT ("DEEP HOUSE", "House bass, deep keys, a warm pad and an 8th-note arp up top",
                           DR, LP (BBass, 17, .5f, .45f, 0, .8f), LP (BKeys, 6, .45f, .5f, 0, .65f), LP (BPad, 4, .5f, .5f, 0, .5f),
                           LP (BArp, 3, .45f, .5f, 1, .4f)),
                   LAYOUT ("EDM BUILD", "Pumping bass, 16th arps, a swelling pad and a lead",
                           DR, LP (BBass, 1, .55f, .45f, 0, .85f), LP (BArp, 0, .55f, .5f, 1, .55f), LP (BPad, 1, .5f, .5f, 0, .5f),
                           LP (BMelody, 13, .55f, .5f, 0, .65f)) }, 3 },
        { Afro, { LAYOUT ("AFROBEATS", "Afro bass, fingerpicked guitar, highlife keys and a melody",
                          DR, LP (BBass, 12, .55f, .5f, 0, .8f), LP (BGuitar, 3, .55f, .5f, 0, .6f), LP (BKeys, 8, .5f, .5f, 0, .6f),
                          LP (BMelody, 11, .45f, .5f, 0, .65f)),
                  LAYOUT ("AMAPIANO", "Deep bass, neo-soul keys, a warm pad, a sparse melody",
                          DR, LP (BBass, 12, .55f, .5f, 0, .85f), LP (BKeys, 6, .5f, .5f, 0, .65f), LP (BPad, 4, .5f, .5f, 0, .5f),
                          LP (BMelody, 11, .35f, .5f, 0, .55f)),
                  LAYOUT ("HIGHLIFE", "Two guitars, horn stabs and a melody",
                          DR, LP (BBass, 12, .55f, .5f, 0, .8f), LP (BGuitar, 3, .55f, .5f, 0, .6f), LP (BGuitar, 1, .45f, .5f, 0, .5f),
                          LP (BHorns, 0, .45f, .5f, 0, .5f), LP (BMelody, 11, .45f, .5f, 0, .6f)) }, 3 },
        { Latin, { LAYOUT ("SALSA", "Tumbao bass, a montuno-style arp, shout horns and a melody",
                           DR, LP (BBass, 6, .6f, .55f, 0, .8f), LP (BArp, 3, .55f, .5f, 0, .55f), LP (BHorns, 2, .55f, .55f, 0, .6f),
                           LP (BMelody, 8, .45f, .5f, 0, .65f)),
                   LAYOUT ("BOSSA", "Soft tumbao, fingerpicked guitar, ballad keys",
                           DR, LP (BBass, 6, .45f, .45f, 0, .75f), LP (BGuitar, 3, .5f, .5f, 0, .6f), LP (BKeys, 7, .45f, .5f, 0, .5f),
                           LP (BMelody, 8, .35f, .45f, 0, .6f)),
                   LAYOUT ("BOLERO", "Roots bass, guitar, legato strings and a melody",
                           LP (BDrums, -1, .4f, .45f, 0, .7f), LP (BBass, 0, .45f, .45f, 0, .75f), LP (BGuitar, 3, .5f, .5f, 0, .6f),
                           LP (BStrings, 1, .45f, .5f, 0, .5f), LP (BMelody, 8, .45f, .5f, 0, .65f)) }, 3 },
        { Reggaeton, { LAYOUT ("PERREO", "Dembow bass, block keys, a pad, a melody",
                               DR, LP (BBass, 13, .55f, .5f, 0, .85f), LP (BKeys, 0, .5f, .45f, 0, .6f), LP (BPad, 0, .45f, .5f, 0, .45f),
                               LP (BMelody, 8, .45f, .5f, 0, .65f)),
                       LAYOUT ("ROMANTIC", "Fingerpicked guitar and a warm pad over the dembow",
                               DR, LP (BBass, 13, .5f, .5f, 0, .8f), LP (BGuitar, 3, .5f, .5f, 0, .6f), LP (BPad, 4, .5f, .5f, 0, .45f),
                               LP (BMelody, 8, .4f, .5f, 0, .6f)),
                       LAYOUT ("DARK", "Dembow bass, an octave pulse, a low pad, a dark melody",
                               DR, LP (BBass, 13, .55f, .5f, 0, .85f), LP (BArp, 5, .5f, .5f, 0, .5f), LP (BPad, 4, .5f, .5f, -1, .5f),
                               LP (BMelody, 9, .4f, .5f, 0, .6f)) }, 3 },
        { Reggae, { LAYOUT ("ROOTS", "Reggae bass, guitar skank, keys bubble, a melody",
                            DR, LP (BBass, 5, .55f, .5f, 0, .85f), LP (BGuitar, 6, .55f, .5f, 0, .6f), LP (BKeys, 2, .5f, .5f, 0, .55f),
                            LP (BMelody, 0, .4f, .45f, 0, .6f)),
                    LAYOUT ("DUB", "Heavy bass, sparse skank, a pad and horn swells - lots of space",
                            LP (BDrums, -1, .45f, .5f, 0, .75f), LP (BBass, 5, .5f, .5f, 0, .9f), LP (BKeys, 2, .4f, .45f, 0, .5f),
                            LP (BPad, 0, .4f, .5f, 0, .4f), LP (BHorns, 1, .4f, .5f, 0, .45f)),
                    LAYOUT ("LOVERS ROCK", "Skank guitar, ballad keys, strings and an R&B melody",
                            DR, LP (BBass, 5, .55f, .5f, 0, .8f), LP (BGuitar, 6, .5f, .5f, 0, .55f), LP (BKeys, 7, .45f, .5f, 0, .55f),
                            LP (BStrings, 1, .4f, .5f, 0, .45f), LP (BMelody, 1, .4f, .5f, 0, .6f)) }, 3 },
        { Country, { LAYOUT ("NASHVILLE", "Country bass, strummed and fingerpicked guitars, a melody",
                             DR, LP (BBass, 15, .55f, .45f, 0, .8f), LP (BGuitar, 0, .55f, .5f, 0, .65f), LP (BGuitar, 3, .45f, .5f, 1, .5f),
                             LP (BMelody, 10, .45f, .45f, 0, .65f)),
                     LAYOUT ("COUNTRY BALLAD", "Fingerpicked guitar, ballad piano, strings",
                             LP (BDrums, -1, .4f, .4f, 0, .7f), LP (BBass, 0, .45f, .4f, 0, .75f), LP (BGuitar, 3, .5f, .5f, 0, .6f),
                             LP (BKeys, 7, .45f, .5f, 0, .5f), LP (BStrings, 1, .4f, .5f, 0, .45f), LP (BMelody, 10, .4f, .45f, 0, .6f)),
                     LAYOUT ("HONKY TONK", "Boogie bass, quarter-note piano, strummed guitar",
                             DR, LP (BBass, 16, .55f, .5f, 0, .8f), LP (BKeys, 1, .55f, .5f, 0, .6f), LP (BGuitar, 0, .55f, .5f, 0, .6f),
                             LP (BMelody, 10, .45f, .5f, 0, .6f)) }, 3 },
        { Blues, { LAYOUT ("SHUFFLE", "Boogie bass, strummed guitar, quarter-note piano, a blues lead",
                           DR, LP (BBass, 16, .55f, .5f, 0, .8f), LP (BGuitar, 0, .5f, .5f, 0, .6f), LP (BKeys, 1, .45f, .5f, 0, .55f),
                           LP (BMelody, 3, .45f, .55f, 0, .65f)),
                   LAYOUT ("SLOW BLUES", "Walking bass, ballad keys, fingerpicked guitar",
                           LP (BDrums, -1, .4f, .45f, 0, .7f), LP (BBass, 2, .45f, .5f, 0, .75f), LP (BKeys, 7, .45f, .5f, 0, .6f),
                           LP (BGuitar, 3, .45f, .5f, 0, .55f), LP (BMelody, 3, .4f, .55f, 0, .65f)),
                   LAYOUT ("CHICAGO", "Boogie bass, comping piano, horn stabs, a blues lead",
                           DR, LP (BBass, 16, .55f, .5f, 0, .8f), LP (BKeys, 3, .5f, .5f, 0, .6f), LP (BHorns, 0, .45f, .5f, 0, .5f),
                           LP (BMelody, 3, .45f, .55f, 0, .65f)) }, 3 },
        { Cinematic, { LAYOUT ("EPIC", "String ostinato and legato, horn swells, a theme",
                               DR, LP (BBass, 0, .35f, .4f, 0, .7f), LP (BStrings, 4, .55f, .5f, 0, .6f), LP (BStrings, 1, .5f, .5f, 0, .55f),
                               LP (BHorns, 1, .45f, .5f, 0, .55f), LP (BMelody, 12, .45f, .5f, 0, .65f)),
                       LAYOUT ("TENDER", "Barely any drums: piano, strings, a high descant, a theme",
                               LP (BDrums, -1, .25f, .35f, 0, .6f), LP (BKeys, 7, .45f, .5f, 0, .7f), LP (BStrings, 1, .45f, .5f, 0, .55f),
                               LP (BStrings, 7, .4f, .5f, 1, .45f), LP (BMelody, 12, .35f, .45f, 0, .6f)),
                       LAYOUT ("DARK SCORE", "Low bass, tremolo strings, a cello line, a low pad and horn pads",
                               DR, LP (BBass, 0, .3f, .4f, -1, .7f), LP (BStrings, 6, .45f, .5f, 0, .45f), LP (BStrings, 8, .45f, .5f, 0, .55f),
                               LP (BPad, 4, .5f, .5f, 0, .5f), LP (BHorns, 3, .4f, .5f, 0, .45f)) }, 3 },
    };
    for (const auto& g : all) if (g.genre == genre) return g;
    return all[0];
}
#undef LAYOUT
#undef DR
#undef LP
} // namespace

// every instrument has its own channel(s), so ONE FL template with a sound on every channel fits every layout:
// bass 2, melody 3, counter 4, strings 5 (a second one 12), horns 6 (15), keys 7, pad 8 (14), arp 9 (14, 15), drums 10,
// guitar 11 (13). Chords sit on 16 with the cable on.
int bandHomeChannels (int type, int* out)
{
    static const int homes[numBandTypes][3] = {
        { 3, 0, 0 }, { 4, 0, 0 }, { 2, 0, 0 }, { 5, 12, 0 }, { 6, 15, 0 }, { 10, 0, 0 },
        { 8, 14, 0 }, { 7, 0, 0 }, { 9, 14, 15 }, { 11, 13, 0 } };
    if (type < 0 || type >= numBandTypes || bandTypeIsDrums (type)) { out[0] = 10; return 1; }
    int n = 0;
    for (int h : homes[type]) if (h > 0) out[n++] = h;
    return n;
}

int numBandLayouts (int genre) { return layoutsOf (genre).n; }
const BandLayout& bandLayout (int genre, int index)
{
    const auto& g = layoutsOf (genre);
    return g.l[std::clamp (index, 0, g.n - 1)];
}

bool Band::isDrumNote (int n)
{
    switch (n)
    {
        case Kick: case Rim: case Snare: case Clap: case ClosedHat: case LowTom: case PedalHat: case OpenHat:
        case MidTom: case Crash: case HighTom: case Ride: case Tambourine: case Cowbell: case Conga:
        case LowConga: case Shaker: case Claves:
        case 35: case 40: case 41: case 43: case 53: case 55: case 57: case 60: case 61: case 65: case 73:
            return true;   // 808, snap / rimshot, low toms, ride bell, splash / crash 2, bongos, timbale, guiro
        default: return false;
    }
}

//==============================================================================
// helpers
static uint32_t mix (uint32_t a, uint32_t b)
{
    a ^= b + 0x9e3779b9u + (a << 6) + (a >> 2);
    a ^= a >> 16; a *= 0x7feb352du;
    a ^= a >> 15; a *= 0x846ca68bu;
    a ^= a >> 16;
    return a;
}

static Rng seeded (uint32_t s) { Rng r; r.s = s | 1u; for (int i = 0; i < 3; ++i) r.next(); return r; }

enum Spec : int8_t
{
    SpNone = 0, SpRoot, SpFifth, SpOct, SpCT, SpStep, SpApproach, SpRepeat, SpLeap, SpExt, SpGrace,
    SpVoicing, SpCycle, SpDrum, SpCC, SpWalk, SpShout, SpRel,
    SpArp,      // arpeggio: a = pattern (ARP style), b = position in the bar
    SpStrum,    // guitar strum: a = 0 down / 1 up, b = 1 muted scratch
    SpPick,     // one guitar string: a = string (0 = bass)
    SpPower     // power chord: root, 5th, octave
};

static int chordTonePc (const Chord& c, int k)
{
    const Notes iv = chordIntervals (c);
    if (iv.empty()) return c.root;
    return pcOf (c.root + iv[((k % iv.size()) + iv.size()) % iv.size()]);
}

static int bassPc (const Chord& c) { return c.bass >= 0 ? c.bass : c.root; }

static int nearestWithPc (int target, int pc)
{
    int n = target - pcOf (target - pc);         // at or below target
    if (target - n > 6) n += 12;
    return n;
}

static int intoRange (int n, int lo, int hi)
{
    while (n < lo) n += 12;
    while (n > hi) n -= 12;
    return n;
}

static int stepInMask (int from, int steps, int mask)
{
    if (mask == 0) return from + steps;
    int n = from;
    const int dir = steps >= 0 ? 1 : -1;
    int moved = 0, guard = 0;
    while (moved < std::abs (steps) && guard++ < 48)
    {
        n += dir;
        if ((mask >> pcOf (n)) & 1) ++moved;
    }
    return n;
}

static int pentMask (int keyRoot, bool major)
{
    static const int maj[] = { 0, 2, 4, 7, 9 }, mnr[] = { 0, 3, 5, 7, 10 };
    int m = 0;
    for (int i = 0; i < 5; ++i) m |= 1 << pcOf (keyRoot + (major ? maj[i] : mnr[i]));
    return m;
}

static int bluesMask (int keyRoot, bool major)
{
    static const int maj[] = { 0, 2, 3, 4, 7, 9 }, mnr[] = { 0, 3, 5, 6, 7, 10 };
    int m = 0;
    for (int i = 0; i < 6; ++i) m |= 1 << pcOf (keyRoot + (major ? maj[i] : mnr[i]));
    return m;
}

// The notes a melodic part may use over this chord: the style's scale, kept friendly with the chord.
static int melodicMask (const Harmony& h, int scaleKind)
{
    const bool major = scaleIsMajorType (h.scale);
    const int key = poolMask (h.keyRoot, h.scale);
    const int chord = pcMask (h.chord);
    int m = key;
    if (scaleKind == 1) m = pentMask (h.keyRoot, major);
    else if (scaleKind == 2) m = bluesMask (h.keyRoot, major);
    else if (scaleKind == 3)
    {
        m = chord;
        const int nine = pcOf (h.chord.root + 2), six = pcOf (h.chord.root + 9);
        if ((key >> nine) & 1) m |= 1 << nine;
        if ((key >> six) & 1) m |= 1 << six;
    }
    // when the chord borrows notes from outside the key, follow the chord
    if (! fitsScale (h.chord, h.keyRoot, h.scale))
    {
        m |= chord;
        for (int pc = 0; pc < 12; ++pc)
            if (((m >> pc) & 1) && ! ((chord >> pc) & 1) && ((chord >> pcOf (pc - 1)) & 1))
                m &= ~(1 << pc);   // a half step above a chord tone clashes
    }
    return m == 0 ? chord : m;
}

// Voice-led chord for strings / horns
static Notes voiceLead (const Notes& prev, const Chord& c, int voices, int center, int lo, int hi)
{
    const int m = tonesMask (c);
    auto has = [m] (int i) { return (m >> i) & 1; };
    int pcs[6];
    int n = 0;
    auto addRel = [&] (int rel) { const int pc = pcOf (c.root + rel); for (int i = 0; i < n; ++i) if (pcs[i] == pc) return; if (n < 6) pcs[n++] = pc; };
    for (int rel : { 4, 3, 5, 2 }) if (has (rel)) { addRel (rel); break; }      // 3rd (or sus)
    for (int rel : { 10, 11, 9 }) if (has (rel)) { addRel (rel); break; }      // 7th / 6th
    for (int rel : { 7, 6, 8 }) if (has (rel)) { addRel (rel); break; }        // 5th
    addRel (0);
    for (int rel : { 2, 9, 5 }) if (has (rel)) { addRel (rel); break; }       // colour
    if (n == 0) addRel (0);
    n = std::min (n, voices);

    Notes out;
    for (int i = 0; i < n; ++i)
    {
        int ref = center + (i - n / 2) * 4;
        if (prev.size() == n) ref = prev[i];
        out.add (intoRange (nearestWithPc (ref, pcs[i]), lo, hi));
    }
    out.unique();
    return out;
}

//==============================================================================
void Band::reset()
{
    for (auto& s : st) s = PartState();
    phraseNow.fill (-1);
    melodyNote = -1;
    melodyHit = false;
}

struct MelStyle
{
    float p[4];       // onset chance: downbeat quarter, offbeat 8th, 16th "e", 16th "a"
    int grid;         // 1 = 16ths, 2 = 8ths, 4 = quarters
    int lenMode;      // 0 legato, 1 detached, 2 long, 3 short
    int scaleKind;    // 0 key, 1 pentatonic, 2 blues, 3 chord + colour
    float swing, leap, repeat, grace, run, trip, rest;
};

static const MelStyle melTable[] = {
    { { .80f, .55f, .12f, .10f }, 1, 0, 1, .00f, .12f, .30f, .05f, .0f, .00f, .5f },   // pop hook
    { { .60f, .45f, .30f, .28f }, 1, 0, 1, .10f, .20f, .10f, .25f, .5f, .00f, .5f },   // r&b
    { { .90f, .85f, .00f, .00f }, 2, 0, 0, .33f, .10f, .05f, .00f, .0f, .00f, .3f },   // bebop
    { { .65f, .45f, .25f, .20f }, 1, 0, 2, .15f, .18f, .15f, .40f, .3f, .00f, .6f },   // gospel blues
    { { .40f, .22f, .06f, .05f }, 1, 2, 3, .20f, .15f, .10f, .10f, .0f, .00f, .6f },   // lo-fi
    { { .75f, .60f, .20f, .10f }, 1, 1, 2, .00f, .15f, .35f, .10f, .0f, .00f, .3f },   // rock riff
    { { .85f, .75f, .50f, .45f }, 1, 0, 0, .00f, .06f, .05f, .00f, .3f, .00f, .3f },   // classical
    { { .30f, .06f, .00f, .00f }, 4, 2, 3, .00f, .25f, .05f, .00f, .0f, .00f, .5f },   // ambient
    { { .55f, .40f, .25f, .30f }, 1, 1, 0, .00f, .30f, .10f, .05f, .0f, .00f, .4f },   // latin
    { { .60f, .40f, .30f, .30f }, 1, 3, 2, .00f, .10f, .50f, .05f, .0f, .35f, .4f },   // trap
    { { .75f, .55f, .15f, .10f }, 1, 0, 1, .10f, .12f, .15f, .35f, .2f, .00f, .5f },   // country
    { { .55f, .50f, .30f, .35f }, 1, 1, 1, .06f, .10f, .45f, .05f, .0f, .00f, .4f },   // afrobeats
    { { .60f, .25f, .05f, .00f }, 2, 2, 0, .00f, .30f, .05f, .00f, .2f, .00f, .4f },   // cinematic
    { { .70f, .70f, .20f, .35f }, 1, 3, 3, .00f, .25f, .30f, .00f, .0f, .00f, .3f },   // edm lead
};
static constexpr int numMel = (int) (sizeof (melTable) / sizeof (MelStyle));

// Every pattern is written straight. Swing comes only from the SWING knob (BandConfig::swing), so the
// whole band always swings together, by exactly as much as you want.

// A guitar-style chord: root low, then 5th, octave, 3rd and 5th (or the 7th) like an open chord
static Notes guitarVoicing (const Chord& c, int oct)
{
    const int m = tonesMask (c);
    auto has = [m] (int i) { return (m >> i) & 1; };
    int third = 4, fifth = 7, seventh = -1;
    for (int rel : { 4, 3, 5, 2 }) if (has (rel)) { third = rel; break; }
    for (int rel : { 7, 6, 8 }) if (has (rel)) { fifth = rel; break; }
    for (int rel : { 10, 11, 9 }) if (has (rel)) { seventh = rel; break; }
    const int bass = c.bass >= 0 ? c.bass : c.root;
    const int r = intoRange (nearestWithPc (45, bass), 40, 51) + 12 * oct;
    const int top = intoRange (nearestWithPc (45, c.root), 40, 51) + 12 * oct;
    Notes v;
    v.add (r);
    v.add (top + fifth);
    v.add (seventh >= 0 ? top + seventh : top + 12);
    v.add (top + 12 + third);
    v.add (top + 12 + fifth);
    v.unique();
    return v;
}

//==============================================================================
// Plans
void Band::buildPlan (int track, const BandPartConfig& cfg, const BandConfig& bc, int64_t bar)
{
    auto& S = st[(size_t) track];
    const int part = cfg.type;
    S.count = 0;
    const int phrase = std::max (1, bc.phraseBars);
    const int pos = (int) (((bar % phrase) + phrase) % phrase);
    static const int letters8[8] = { 0, 0, 1, 0, 0, 0, 2, 0 }, vars8[8] = { 0, 1, 0, 2, 0, 1, 0, 3 };
    static const int letters4[4] = { 0, 0, 1, 0 }, vars4[4] = { 0, 1, 0, 2 };
    int letter = 0, var = 0;
    if (phrase == 2) { letter = pos; var = 0; }
    else if (phrase == 4) { letter = letters4[pos]; var = vars4[pos]; }
    else if (phrase >= 8) { letter = letters8[pos % 8]; var = vars8[pos % 8]; }
    const bool lastBar = pos == phrase - 1;
    const float dens = cfg.density, cx = cfg.complexity;

    const uint32_t base = mix (mix (cfg.seed, (uint32_t) (part * 977 + cfg.style * 131 + track * 7)), (uint32_t) (letter * 7919 + 1));
    Rng r = seeded (base);

    auto add = [&S] (int step, int8_t spec, float len, int accent = 0, int a = 0, int b = 0, float off = 0.0f)
    {
        if (S.count >= (int) S.plan.size()) return;
        PlanEv e;
        e.step = (int8_t) step;
        e.spec = spec;
        e.len = len;
        e.accent = (int8_t) std::clamp (accent, -100, 100);
        e.a = (int8_t) a;
        e.b = (int8_t) b;
        e.off = off;
        S.plan[(size_t) S.count++] = e;
    };
    auto chance = [&r] (float p) { return r.unit() < p; };

    // ---- melodic line used by melody, answer, shout and descant
    auto melodicLine = [&] (const MelStyle& T, float densityScale, const bool* blocked)
    {
        const float dm = (0.35f + 1.3f * dens) * densityScale;
        bool on[16] = {};
        for (int s = 0; s < 16; ++s)
        {
            if ((T.grid == 2 && (s % 2)) || (T.grid == 4 && (s % 4))) continue;
            if (blocked != nullptr && blocked[s]) continue;
            const int type = (s % 4 == 0) ? 0 : (s % 4 == 2) ? 1 : (s % 4 == 1) ? 2 : 3;
            float p = T.p[type] * dm;
            if (type >= 2) p *= 0.5f + cx;
            if (cfg.style == 8 && part == BMelody && (s == 0 || s == 3 || s == 6 || s == 10 || s == 12)) p += 0.35f;
            if (s == 0) p += 0.15f;
            on[s] = chance (std::clamp (p, 0.0f, 0.97f));
        }
        if (lastBar)
        {
            if (chance (T.rest)) for (int s = 10; s < 16; ++s) on[s] = false;
            else if (chance (T.run * (0.5f + cx))) for (int s = 12; s < 16; ++s) on[s] = blocked == nullptr || ! blocked[s];
        }
        int onsets[16], n = 0;
        for (int s = 0; s < 16; ++s) if (on[s]) onsets[n++] = s;
        if (n == 0)
            for (int s = 0; s < 16 && n == 0; s += 2)
                if (blocked == nullptr || ! blocked[s]) onsets[n++] = s;

        for (int i = 0; i < n; ++i)
        {
            const int s = onsets[i];
            const int next = i + 1 < n ? onsets[i + 1] : 16;
            const float dist = (float) (next - s);
            float len = dist * 0.95f;
            if (T.lenMode == 1) len = dist * 0.6f;
            else if (T.lenMode == 2) len = std::min (dist, 8.0f);
            else if (T.lenMode == 3) len = std::min (dist, 1.0f) * 0.45f;
            const int accent = s % 4 == 0 ? 8 : (s % 2 == 0 ? 0 : -6);

            int8_t spec = SpStep;
            int a = 1 + (chance (0.3f) ? 1 : 0), b = chance (0.25f) ? 1 : 0;   // b = 1: turn around
            if (s % 4 == 0)
            {
                const float u = r.unit();
                spec = SpCT;
                a = u < 0.2f ? 0 : u < 0.55f ? 1 : u < 0.8f ? 2 : 3;
                b = 0;
                if (T.scaleKind == 3 && chance (0.4f)) { spec = SpExt; a = r.below (2); }
                if (chance (T.grace * (0.5f + cx))) spec = SpGrace;
            }
            else
            {
                const float u = r.unit();
                if (u < T.repeat) spec = SpRepeat;
                else if (u < T.repeat + T.leap * (0.5f + cx)) { spec = SpLeap; a = r.below (3); }
            }
            if (T.grid == 2 && s % 4 == 2 && next % 4 == 0 && next < 16 && chance (0.6f))
            {
                spec = SpApproach;
                a = r.below (3);
                b = chance (0.5f) ? -1 : 1;
            }

            if (T.trip > 0.0f && dist >= 2.0f && chance (T.trip * (0.4f + cx)))
            {
                for (int t = 0; t < 3; ++t)
                    add (s, t == 0 ? spec : (int8_t) SpRepeat, 0.55f, accent - t * 4, a, b, (float) t * 0.667f);
                continue;
            }
            add (s, spec, len, accent, a, b);
        }
    };

    // ---- the band's GROOVE (core/Grooves): the full kit, or one piece of it
    //      transform: 0 as written, 1 simple, 2 busy, 3 half time, 4 double time
    auto playGroove = [&] (int pieceFilter, int transform)
    {
        // CHANGE: every N bars the drums move to a related groove (the same for every drum track, so a split kit agrees)
        int gIdx = bc.groove;
        if (bc.grooveChange > 0 && bc.userGroove == nullptr)
        {
            const int64_t n = bc.grooveChange;
            const int64_t block = bar >= 0 ? bar / n : (bar - n + 1) / n;
            gIdx = grooveRelated (bc.genre, bc.groove, block);
        }
        grooveNow = bc.userGroove != nullptr ? -2 : gIdx;
        const Groove& gr = bc.userGroove != nullptr ? *bc.userGroove : groove (bc.genre, gIdx);
        const int gb = std::max (1, gr.bars);
        // VARY: every time round the phrase plays a little differently - the drummer's other bars swapped in, another
        // groove's turnaround, a ghost note, a hat roll, a kick moved. Decided per bar (same for every drum track).
        const Groove* vg = &gr;          // whose bar plays here
        int vBar = (int) (((bar % gb) + gb) % gb);
        bool vGhost[16] = {}, vKick[16] = {};
        int vRoll = -1;
        const float vary = std::clamp (bc.vary, 0.0f, 1.0f);
        if (vary > 0.0f && transform == 0 && gb >= 4)
        {
            Rng vr = seeded (mix ((uint32_t) (bc.genre * 977 + gIdx * 13 + 3), (uint32_t) (bar & 0xffffff)));
            auto vChance = [&vr] (float p) { return vr.unit() < p; };
            const int pass = (int) (bar >= 0 ? bar / gb : (bar - gb + 1) / gb);
            if (pass > 0)   // the first time round is the groove exactly as it is
            {
                if (vBar < gb - 1 && vChance (0.45f * vary))
                    vBar = (vBar + 1 + vr.below (gb - 2)) % (gb - 1);              // another groove bar of the phrase
                else if (vBar == gb - 1 && bc.userGroove == nullptr && vChance (0.55f * vary))
                {
                    const Groove& other = groove (bc.genre, grooveNear (bc.genre, gIdx, vr.below (3)));
                    if (other.bars >= gb) vg = &other;                           // a close neighbour's turnaround
                }
                if (vChance (0.35f * vary))
                {
                    bool hasHats = false, hasGhosts = false;
                    for (const auto& h : gr.hits) { hasHats |= h.piece == PieceHats; hasGhosts |= h.piece == PieceSnare && h.vel < 60; }
                    const bool programmed = bc.genre == Trap || bc.genre == Drill || bc.genre == Reggaeton || bc.genre == House
                                            || bc.genre == Afro || bc.genre == Soul;
                    if (programmed && hasHats) vRoll = 2 + 4 * vr.below (4) + (vChance (0.5f) ? 0 : 1);
                    else if (! programmed || hasGhosts) vGhost[1 + 2 * vr.below (8)] = true;
                }
                static const int kickSpots[6] = { 3, 7, 10, 11, 14, 15 };
                if (vChance (0.25f * vary)) vKick[kickSpots[vr.below (6)]] = true;
            }
        }
        const float total = (float) (gb * 16);
        const float feelAmt = std::clamp (bc.feel, 0.0f, 1.0f);
        // fills and crashes are decided per bar, the same for every drum track, so a split kit agrees
        Rng fr = seeded (mix ((uint32_t) (bc.genre * 131 + gIdx * 7 + 1), (uint32_t) (bar & 0xffffff)));
        // grooves from loops carry their own turnarounds; only one-bar grooves get a made-up fill
        const bool fill = lastBar && cx > 0.25f && (gr.family < 0 || gb == 1);
        const int fillKind = fr.below (3);
        bool tomsTrack = false, cymTrack = false;
        for (int t = 0; t < std::clamp (bc.numTracks, 0, maxBandTracks); ++t)
        {
            const auto& c = bc.part[(size_t) t];
            if (! c.on || c.mode != ModeJam) continue;
            if (c.type == BTom) tomsTrack = true;
            if (c.type == BCymbal) cymTrack = true;
        }
        auto wants = [&] (int piece)
        {
            if (pieceFilter < 0) return true;
            if (piece == pieceFilter) return true;
            if (piece == PieceTom && pieceFilter == PieceSnare && ! tomsTrack) return true;    // no TOMS track: the snare plays the tom fills
            if (piece == PieceCymbal && pieceFilter == PieceHats && ! cymTrack) return true;   // no CYMBALS track: the hats play the crash
            return false;
        };
        // where each hit really lands: its grid spot plus the drummer's push / drag (FEEL), wrapped around the groove
        auto landsAt = [&] (const GrooveHit& h)
        {
            float e = (float) h.step + h.off + h.feel * feelAmt;
            e = std::fmod (e, total);
            if (e < 0.0f) e += total;
            return e;
        };
        bool hatAt[16] = {};
        for (int s = 0; s < 16; ++s)
        {
            // which groove 16ths play at this step of the bar, and how far into the step each one starts
            struct Src { int step; float base, scale; };
            Src srcs[2];
            int nSrc = 0;
            float stretch = 1.0f;
            if (transform == 3)        // half time: this bar plays half of a groove bar, stretched
            {
                if (s % 2) continue;
                srcs[nSrc++] = { (int) (((bar / 2) % gb) * 16 + (((bar % 2) + 2) % 2) * 8 + s / 2), 0.0f, 2.0f };
                stretch = 2.0f;
            }
            else if (transform == 4)   // double time: a groove bar squeezed into half a bar, twice
            {
                const int a = (int) ((bar % gb) * 16 + (s * 2) % 16);
                srcs[nSrc++] = { a, 0.0f, 0.5f };
                srcs[nSrc++] = { a + 1, 0.5f, 0.5f };
                stretch = 0.5f;
            }
            else srcs[nSrc++] = { vBar * 16 + s, 0.0f, 1.0f };
            for (int k = 0; k < nSrc; ++k)
            {
                const int src = srcs[k].step;
                for (const auto& h : (transform == 0 ? vg : &gr)->hits)
                {
                    if (! wants (h.piece)) continue;
                    const float e = landsAt (h);
                    if ((int) std::floor (e) != src) continue;
                    if (h.piece == PieceHats) hatAt[s] = true;
                    const bool ghost = h.vel < 60;
                    const bool roll = h.off > 0.001f;
                    if (transform == 1 && (ghost || roll || (h.step % 2) == 1)) continue;
                    if (roll && cx < 0.35f) continue;                                  // COMPLEX low: no rolls
                    if (dens < 0.3f && (ghost || (h.piece == PieceHats && (h.step % 2) == 1))) continue;   // BUSY low: sparser
                    if (fill && s >= 12 && (h.piece == PieceKick || h.piece == PieceSnare || h.piece == PieceClap)) continue;
                    float off = srcs[k].base + (e - (float) src) * srcs[k].scale;
                    off = std::clamp (off, 0.0f, 1.9f);
                    add (s, SpDrum, std::max (0.15f, h.len * stretch), 0, h.note, h.vel, off);
                }
            }
            if (vGhost[s] && wants (PieceSnare) && dens >= 0.3f) add (s, SpDrum, 0.3f, 0, gm::Snare, 36);
            if (vKick[s] && wants (PieceKick)) add (s, SpDrum, 0.4f, 0, gm::Kick, 92);
            if (vRoll == s && wants (PieceHats) && cx >= 0.35f)
            {
                const bool trip = (s % 2) == 0;
                for (int i = 0; i < (trip ? 3 : 2); ++i) add (s, SpDrum, 0.15f, 0, gm::ClosedHat, 64 + i * 14, trip ? (float) i * 0.333f : (float) i * 0.5f);
            }
            if (transform == 2)   // BUSY: ghost notes and pickups the groove leaves out
            {
                if (wants (PieceHats) && ! hatAt[s] && (s % 2) == 1 && chance (0.45f)) add (s, SpDrum, 0.3f, 0, gm::ClosedHat, 42);
                if (wants (PieceSnare) && (s % 4) == 3 && chance (0.3f)) add (s, SpDrum, 0.3f, 0, gm::Snare, 34);
                if (wants (PieceKick) && (s == 15 || s == 7) && chance (0.25f)) add (s, SpDrum, 0.4f, 0, gm::Kick, 70);
            }
        }
        if (fill)
        {
            for (int s = 12; s < 16; ++s)
            {
                int note = gm::Snare, piece = PieceSnare;
                if (fillKind == 1) { note = s == 12 ? gm::HighTom : (s == 13 ? gm::MidTom : gm::LowTom); piece = PieceTom; }
                if (fillKind == 2 && (s % 2) == 1) { note = s == 13 ? gm::HighTom : gm::LowTom; piece = PieceTom; }
                if (wants (piece)) add (s, SpDrum, 0.5f, 0, note, 70 + (s - 12) * 12);
            }
            if (wants (PieceKick)) add (14, SpDrum, 0.5f, 0, gm::Kick, 100);
        }
        // a crash at the top of every phrase - only on the hand-written grooves (loop grooves keep the loop's own cymbals)
        if (pos == 0 && dens > 0.35f && wants (PieceCymbal) && gr.family < 0) add (0, SpDrum, 1.0f, 0, gm::Crash, 96);
    };

    switch (part)
    {
        case BMelody:
            melodicLine (melTable[std::clamp (cfg.style, 0, numMel - 1)], 1.0f, nullptr);
            break;

        case BCounter:
        {
            if (cfg.style == 2)   // answer: only where the melody leaves space
            {
                bool blocked[16] = {};
                if (melodyTrack >= 0 && st[(size_t) melodyTrack].planBar == bar)
                {
                    const auto& M = st[(size_t) melodyTrack];
                    for (int i = 0; i < M.count; ++i)
                    {
                        const auto& e = M.plan[(size_t) i];
                        for (int s = std::max (0, e.step - 1); s <= std::min (15, e.step + 1); ++s) blocked[s] = true;
                    }
                }
                melodicLine (melTable[0], 0.6f, blocked);
            }
            else if (cfg.style == 4)   // descant: long notes
            {
                const bool two = dens > 0.4f;
                add (0, chance (0.4f) ? (int8_t) SpExt : (int8_t) SpCT, two ? 7.8f : 15.8f, 0, r.below (3), 0);
                if (two) add (8, SpStep, 7.8f, -4, 1, chance (0.5f) ? 1 : 0);
            }
            break;   // harmonies and guide tones are worked out live in step()
        }

        case BBass:
        {
            const int sty = cfg.style;
            switch (sty)
            {
                case 0:   // roots
                    if (dens > 0.35f)
                    {
                        add (0, SpRoot, 7.6f, 8);
                        add (8, chance (0.3f + 0.4f * cx) ? (int8_t) SpFifth : (int8_t) SpRoot, lastBar && cx > 0.4f ? 5.6f : 7.6f, 0);
                    }
                    else add (0, SpRoot, lastBar && cx > 0.4f ? 13.6f : 15.6f, 8);
                    if (lastBar && cx > 0.4f) add (14, SpApproach, 1.8f, -4, 0, -1);
                    break;
                case 1:   // pumping 8ths
                case 11:  // rock
                    for (int s = 0; s < 16; s += 2)
                    {
                        int8_t spec = SpRoot;
                        if ((s == 12 || s == 14) && chance (0.25f + 0.4f * cx)) spec = sty == 11 ? SpFifth : (chance (0.5f) ? SpFifth : SpOct);
                        if (lastBar && s == 14 && cx > 0.3f) spec = SpApproach;
                        add (s, spec, sty == 11 ? 1.7f : 1.6f, s % 4 == 0 ? 8 : -2, 0, spec == SpApproach ? -1 : 0);
                    }
                    break;
                case 2:   // walking
                    add (0, SpRoot, 3.7f, 8);
                    add (4, chance (0.5f) ? (int8_t) SpStep : (int8_t) SpCT, 3.7f, 0, chance (0.5f) ? 1 : 2, chance (0.5f) ? 1 : 0);
                    add (8, SpCT, 3.7f, 2, chance (0.6f) ? 2 : 1);
                    add (12, SpApproach, 3.7f, 0, 0, chance (0.5f) ? -1 : 1);
                    if (cx > 0.5f && chance (cx - 0.3f)) add (10, SpStep, 1.6f, -10, 1, 0);
                    break;
                case 3:   // motown
                {
                    static const int posM[] = { 0, 3, 6, 8, 10, 11, 14, 15 };
                    static const int8_t specM[] = { SpRoot, SpOct, SpFifth, SpRoot, SpCT, SpStep, SpApproach, SpApproach };
                    for (int i = 0; i < 8; ++i)
                    {
                        const float p = i == 0 ? 1.0f : (i == 3 ? 0.8f : 0.3f + 0.5f * dens * (0.6f + cx));
                        if (chance (p)) add (posM[i], specM[i], 1.4f, i == 0 ? 10 : -2, i == 4 ? 1 : 0, specM[i] == SpApproach ? (i == 7 ? 1 : -1) : 0);
                    }
                    break;
                }
                case 4:   // funk
                {
                    add (0, SpRoot, 1.5f, 14);
                    static const int posF[] = { 3, 5, 6, 7, 10, 11, 13, 14 };
                    for (int p : posF)
                    {
                        if (! chance (dens * 0.65f)) continue;
                        const float u = r.unit();
                        if (u < 0.35f) add (p, SpOct, 0.8f, 4);
                        else if (u < 0.7f) add (p, SpRoot, 0.8f, 0);
                        else if (u < 0.85f) add (p, SpCT, 0.8f, -2, 3);
                        else if (cx > 0.3f) add (p, SpRoot, 0.35f, -50);   // ghost
                    }
                    break;
                }
                case 5:   // reggae one drop
                {
                    static const int posR[] = { 2, 6, 8, 12, 14 };
                    static const int8_t specR[] = { SpRoot, SpCT, SpFifth, SpRoot, SpStep };
                    static const float lenR[] = { 2.0f, 1.8f, 3.0f, 1.8f, 1.5f };
                    for (int i = 0; i < 5; ++i)
                        if (i == 2 || chance (0.35f + 0.5f * dens)) add (posR[i], specR[i], lenR[i], i == 2 ? 8 : 0, i == 1 ? 1 : 1, 0);
                    break;
                }
                case 6:   // tumbao
                    add (6, SpFifth, 5.8f, 6);
                    add (12, SpRoot, 3.8f, 4);
                    if (cx > 0.4f && chance (cx)) add (14, SpOct, 0.8f, -6);
                    break;
                case 7:   // 808
                {
                    add (0, SpRoot, 6.8f, 12);
                    static const int posE[] = { 7, 10, 14 };
                    for (int p : posE)
                        if (chance (dens * 0.55f))
                        {
                            const float u = r.unit();
                            add (p, u < 0.6f ? (int8_t) SpRoot : (u < 0.85f ? (int8_t) SpOct : (int8_t) SpFifth), p == 14 ? 1.8f : 2.8f, 0);
                        }
                    if (lastBar && cx > 0.35f)
                        for (int t = 0; t < 6; ++t) add (12 + (t * 2) / 3, SpRoot, 0.5f, -10 + t * 3, 0, 0, (float) ((t * 2) % 3) * 0.333f);
                    break;
                }
                case 8:   // gospel
                    add (0, SpRoot, 3.5f, 10);
                    if (chance (0.5f + 0.4f * dens)) add (4, SpOct, 1.5f, 0);
                    if (chance (0.4f + 0.4f * dens)) add (6, SpRoot, 1.5f, -2);
                    add (8, SpFifth, 2.0f, 4);
                    if (chance (0.3f + 0.5f * cx)) add (10, SpCT, 1.5f, 0, 1);
                    for (int w = 0; w < 3; ++w) add (13 + w, SpWalk, 0.9f, -4 + w * 4, 0, 3 - w);
                    break;
                case 9:   // disco
                    for (int s = 0; s < 16; s += 2)
                        add (s, (s / 2) % 2 == 0 ? (int8_t) SpRoot : (chance (0.15f * cx) ? (int8_t) SpFifth : (int8_t) SpOct), 1.5f, s % 4 == 0 ? 8 : 0);
                    break;
                case 10:  // neo-soul
                    add (0, SpGrace, 5.0f, 6, 0, 0, 0.2f);
                    if (chance (0.3f + 0.5f * dens)) add (6, SpStep, 1.8f, -6, 1, 0);
                    add (8, SpCT, 3.0f, 0, chance (0.5f) ? 2 : 1);
                    if (chance (0.3f + 0.5f * cx)) add (14, SpApproach, 1.6f, -4, 0, chance (0.5f) ? -1 : 1);
                    break;
                case 12:  // afrobeats
                {
                    static const int posA[] = { 0, 3, 6, 8, 10, 11, 14 };
                    static const int8_t specA[] = { SpRoot, SpOct, SpFifth, SpRoot, SpCT, SpRoot, SpApproach };
                    for (int i = 0; i < 7; ++i)
                        if (i == 0 || i == 3 || chance (0.3f + 0.5f * dens))
                            add (posA[i], specA[i], 1.6f, i == 0 ? 8 : -2, i == 4 ? 1 : 0, specA[i] == SpApproach ? -1 : 0);
                    break;
                }
                case 13:  // reggaeton
                    add (0, SpRoot, 2.8f, 10);
                    add (3, SpRoot, 2.6f, 0);
                    add (8, SpRoot, 2.8f, 6);
                    add (11, SpRoot, 2.6f, 0);
                    if (chance (0.3f + 0.5f * dens)) add (6, SpOct, 1.6f, -4);
                    if (chance (0.3f + 0.5f * cx)) add (14, SpFifth, 1.6f, -4);
                    break;
                case 14:  // drill 808: notes overlap so a glide 808 slides between them
                    add (0, SpRoot, 7.0f, 12);
                    if (chance (0.4f + 0.5f * dens)) add (6, chance (0.5f) ? (int8_t) SpOct : (int8_t) SpFifth, 4.5f, 2);
                    add (10, SpRoot, 3.0f, 4);
                    if (chance (0.3f + 0.6f * cx)) add (12, chance (0.5f) ? (int8_t) SpCT : (int8_t) SpOct, 4.0f, 0, 1);
                    break;
                case 15:  // country
                    add (0, SpRoot, 3.5f, 8);
                    add (8, SpFifth, 3.5f, 2);
                    if (dens > 0.6f) { add (4, SpFifth, 1.8f, -6); add (12, SpRoot, 1.8f, -6); }
                    if (lastBar || chance (0.3f * cx)) { add (12, SpCT, 1.8f, 0, 1); add (14, SpApproach, 1.8f, 0, 0, -1); }
                    break;
                case 16:  // boogie
                {
                    static const int rel[8] = { 0, 4, 7, 9, 10, 9, 7, 4 };
                    for (int i = 0; i < 8; ++i) add (i * 2, SpRel, 1.7f, i % 2 == 0 ? 6 : -2, rel[i]);
                    break;
                }
                case 17:  // house
                    for (int s = 2; s < 16; s += 4) add (s, SpRoot, 1.5f, s == 2 ? 4 : 0);
                    if (chance (0.3f + 0.5f * dens)) add (7, SpOct, 0.8f, -6);
                    if (chance (0.3f + 0.5f * cx)) add (15, SpFifth, 0.8f, -6);
                    break;
                default:
                    add (0, SpRoot, 15.6f, 8);
                    break;
            }
            break;
        }

        case BStrings:
        {
            const int sty = cfg.style;
            if (sty == 1)   // legato voices
            {
                add (0, SpVoicing, 8.2f, -6, 4, 0);
                if (dens > 0.35f) add (8, SpVoicing, 8.2f, -10, 4, chance (0.5f) ? 1 : -1);
            }
            else if (sty == 2)   // swells
            {
                add (0, SpVoicing, 15.9f, -12, 4, 0);
                static const int ccs[] = { 25, 45, 65, 85, 100, 110, 118 };
                for (int i = 0; i < 7; ++i) add (i * 2, SpCC, 0.0f, 0, ccs[i]);
            }
            else if (sty == 3)   // spiccato
            {
                for (int s = 0; s < 16; s += (dens < 0.4f ? 4 : 2)) add (s, SpVoicing, 0.7f, s % 4 == 0 ? 6 : -6, 3, 0);
            }
            else if (sty == 4)   // ostinato
            {
                const int pattern = r.below (4);
                for (int s = 0; s < 16; ++s)
                    if (dens > 0.25f || s % 2 == 0) add (s, SpCycle, 0.9f, s % 4 == 0 ? 8 : -4, pattern);
            }
            else if (sty == 5)   // pizzicato
            {
                for (int s = 0; s < 16; s += 2)
                    if (s % 4 == 0 || chance (dens * 0.5f)) add (s, SpCT, 0.5f, s % 4 == 0 ? 4 : -8, r.below (4), r.below (3) - 1);
            }
            else if (sty == 6)   // tremolo
            {
                for (int s = 0; s < 16; ++s) add (s, SpVoicing, 0.9f, -14 + (int) (r.unit() * 10.0f), 3, 0);
            }
            else if (sty == 7)   // high descant
            {
                const bool two = dens > 0.4f;
                add (0, chance (0.5f) ? (int8_t) SpExt : (int8_t) SpCT, two ? 7.8f : 15.8f, -4, r.below (3), 0);
                if (two) add (8, SpStep, 7.8f, -8, 1, chance (0.5f) ? 1 : 0);
            }
            else if (sty == 8)   // cello line
            {
                add (0, SpCT, 3.8f, 0, 0);
                for (int s = 4; s < 16; s += 4)
                    if (chance (0.4f + 0.5f * dens)) add (s, chance (0.5f) ? (int8_t) SpStep : (int8_t) SpCT, 3.8f, -6, chance (0.5f) ? 1 : 2, chance (0.4f) ? 1 : 0);
            }
            break;   // PAD is played on each chord change in step()
        }

        case BHorns:
        {
            const int sty = cfg.style;
            if (sty == 0)   // stabs
            {
                static const int posH[] = { 0, 3, 6, 7, 10, 11, 14 };
                int hits = 0;
                for (int p : posH)
                    if (chance (p == 0 ? 0.6f : 0.25f + 0.4f * dens) && hits < 2 + (int) (3 * dens)) { add (p, SpVoicing, 0.6f, 10, 3, 0); ++hits; }
                if (hits == 0) add (0, SpVoicing, 0.6f, 10, 3, 0);
            }
            else if (sty == 1)   // swells
            {
                add (0, SpVoicing, 7.6f, -10, 3, 0);
                static const int ccs[] = { 20, 60, 100, 122 };
                for (int i = 0; i < 4; ++i) add (i * 2, SpCC, 0.0f, 0, ccs[i]);
                if (dens > 0.5f) { add (8, SpVoicing, 7.6f, -10, 3, 0); for (int i = 0; i < 4; ++i) add (8 + i * 2, SpCC, 0.0f, 0, ccs[i]); }
            }
            else if (sty == 2)   // shout line
            {
                melodicLine (melTable[5], 0.9f, nullptr);
                for (int i = 0; i < S.count; ++i) S.plan[(size_t) i].b = S.plan[(size_t) i].spec == SpStep ? S.plan[(size_t) i].b : 0;
                for (int i = 0; i < S.count; ++i) S.plan[(size_t) i].accent = (int8_t) (S.plan[(size_t) i].accent + 6);
            }
            else if (sty == 4)   // punches
            {
                add (4, SpVoicing, 0.45f, 6, 3, 0);
                add (12, SpVoicing, 0.45f, 6, 3, 0);
                if (cx > 0.4f && chance (cx)) add (14, SpVoicing, 0.4f, 0, 3, 0);
            }
            break;   // PADS play on each chord change in step()
        }

        case BKick: case BSnare: case BClap: case BHats: case BOpenHat: case BPerc: case BCymbal: case BTom:
        {
            static const int tf[5] = { 0, 1, 2, 3, 4 };
            playGroove (bandTypePiece (part), tf[std::clamp (cfg.style, 0, 4)]);
            break;
        }

        case BDrums:
        {
            if (cfg.style >= drumGrooveStyle)
            {
                const int k = cfg.style - drumGrooveStyle;
                playGroove (-1, k == 1 ? 3 : (k == 2 ? 4 : 0));
                break;
            }
            struct Line { int note; const char* v[3]; bool ghosty; bool hats; };
            static const Line boomBap[] = {
                { Kick, { "x.....x...x.....", "x......x..x.....", "x.....x.x..x...." }, false, false },
                { Snare, { "....X.......X...", nullptr, nullptr }, false, false },
                { Snare, { "...........g...g", "......g........g", nullptr }, true, false },
                { ClosedHat, { "x...x...x...x...", "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx" }, false, true },
                { OpenHat, { "..............o.", nullptr, nullptr }, true, false } };
            static const Line trap[] = {
                { Kick, { "x......x..x.....", "x.....x....x..x.", "x..x......x.x..." }, false, false },
                { Clap, { "........X.......", nullptr, nullptr }, false, false },
                { ClosedHat, { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "xxxxxxrxxxxxxxrr" }, false, true },
                { OpenHat, { "......o.........", nullptr, nullptr }, true, false } };
            static const Line house[] = {
                { Kick, { "x...x...x...x...", nullptr, nullptr }, false, false },
                { Clap, { "....X.......X...", nullptr, nullptr }, false, false },
                { ClosedHat, { "..x...x...x...x.", "x.x.x.x.x.x.x.x.", "xxoxxxoxxxoxxxox" }, false, true },
                { Shaker, { "xxxxxxxxxxxxxxxx", nullptr, nullptr }, true, false } };
            static const Line rock[] = {
                { Kick, { "x.......x.x.....", "x......xx.......", "x.x.....x......." }, false, false },
                { Snare, { "....X.......X...", nullptr, nullptr }, false, false },
                { ClosedHat, { "x...x...x...x...", "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx" }, false, true } };
            static const Line funk[] = {
                { Kick, { "x..x..x...x.x...", "x.x...x..x..x...", "x...x.x...x..x.." }, false, false },
                { Snare, { "....X.......X...", nullptr, nullptr }, false, false },
                { Snare, { ".......g.g.....g", "..g....g...g...g", nullptr }, true, false },
                { ClosedHat, { "x.x.x.x.x.x.x.x.", "xXxxxXxxxXxxxXxx", "xXxoxXxxxXxoxXxx" }, false, true } };
            static const Line jazz[] = {
                { Ride, { "x...x.x.x...x.x.", "x...x.x.x.x.x.x.", nullptr }, false, false },
                { PedalHat, { "....x.......x...", nullptr, nullptr }, false, false },
                { Kick, { "g...g...g...g...", nullptr, nullptr }, true, false },
                { Snare, { "......g.....g...", "...g......g.....", "..g.......g..g.." }, true, false } };
            static const Line bossa[] = {
                { Kick, { "x..x....x..x....", "x..xx..xx..xx..x", nullptr }, false, false },
                { Rim, { "x..x..x...x..x..", "x..x...x..x..x..", nullptr }, false, false },
                { ClosedHat, { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", nullptr }, false, true } };
            static const Line reggae[] = {
                { Kick, { "........X.......", nullptr, nullptr }, false, false },
                { Rim, { "........X.......", nullptr, nullptr }, false, false },
                { ClosedHat, { "..x...x...x...x.", "x.x.x.x.x.x.x.x.", "x.xxx.xxx.xxx.xx" }, false, true } };
            static const Line gospel[] = {
                { Kick, { "x.....x.x.......", "x.....x...x.x...", nullptr }, false, false },
                { Snare, { "....X.......X...", nullptr, nullptr }, false, false },
                { Snare, { "..g.....g.....g.", "..g...g...g...g.", nullptr }, true, false },
                { ClosedHat, { "x.x.x.x.x.x.x.x.", "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx" }, false, true } };
            static const Line neo[] = {
                { Kick, { "x......x..x.x...", "x....x....x.....", "x.......x..x...." }, false, false },
                { Snare, { "....X.......X...", nullptr, nullptr }, false, false },
                { Snare, { "......g......g..", "..g.....g.......", nullptr }, true, false },
                { ClosedHat, { "x.x.x.x.x.x.x.x.", "xgxgxgxgxgxgxgxg", "xgxxxgxxxgxxxgxx" }, false, true } };
            static const Line lofi[] = {
                { Kick, { "x.....x...x.....", "x......x.x......", nullptr }, false, false },
                { Snare, { "....x.......x...", nullptr, nullptr }, false, false },
                { ClosedHat, { "x...x...x...x...", "x.x.x.x.x.x.x.x.", "xgxgxgxgxgxgxgxg" }, false, true },
                { Shaker, { "..g...g...g...g.", nullptr, nullptr }, true, false } };
            static const Line disco[] = {
                { Kick, { "x...x...x...x...", nullptr, nullptr }, false, false },
                { Snare, { "....X.......X...", nullptr, nullptr }, false, false },
                { OpenHat, { "..o...o...o...o.", nullptr, nullptr }, false, false },
                { ClosedHat, { "x.x.x.x.x.x.x.x.", "xx.xxx.xxx.xxx.x", "xxxxxxxxxxxxxxxx" }, false, true } };

            static const Line pop[] = {
                { Kick, { "x.......x.x.....", "x......xx.......", "x..x....x.x....." }, false, false },
                { Clap, { "....X.......X...", nullptr, nullptr }, false, false },
                { Snare, { "....x.......x...", nullptr, nullptr }, false, false },
                { ClosedHat, { "x...x...x...x...", "x.x.x.x.x.x.x.x.", "x.xxx.xxx.xxx.xx" }, false, true },
                { Tambourine, { "....x.......x...", nullptr, nullptr }, true, false } };
            static const Line afro[] = {
                { Kick, { "x.....x...x.....", "x..x..x...x.....", "x.....x.x...x..." }, false, false },
                { Rim, { "...x..x....x..x.", "x..x..x...x.x...", nullptr }, false, false },
                { Clap, { "........X.......", "....X.......X...", nullptr }, false, false },
                { Shaker, { "xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx", "x.x.x.x.x.x.x.x." }, false, true },
                { Conga, { "..x...x...xx..x.", "..x..x....x..x..", nullptr }, true, false },
                { LowConga, { ".......x.......x", nullptr, nullptr }, true, false } };
            static const Line dembow[] = {
                { Kick, { "x...x...x...x...", nullptr, nullptr }, false, false },
                { Snare, { "...x..x....x..x.", nullptr, nullptr }, false, false },
                { ClosedHat, { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx" }, false, true },
                { Rim, { "..x.......x.....", nullptr, nullptr }, true, false } };
            static const Line drill[] = {
                { Kick, { "x......x..x.....", "x.....x..x...x..", "x..x......x..x.." }, false, false },
                { Snare, { "........X.....x.", "........X..x....", nullptr }, false, false },
                { ClosedHat, { "x..x..x.x..x..x.", "x..x..x.x.rx..x.", "x.rx..x.x..xr.x." }, false, true },
                { Rim, { "...g.......g....", nullptr, nullptr }, true, false } };
            static const Line country[] = {
                { Kick, { "x.......x.......", "x...x...x...x...", nullptr }, false, false },
                { Snare, { "gggXgggggggXgggg", "g.gXg.g.g.gXg.g.", nullptr }, false, false },
                { ClosedHat, { "..x...x...x...x.", "x.x.x.x.x.x.x.x.", nullptr }, false, true } };
            static const Line shuffle[] = {
                { Kick, { "x.......x.......", "x.....x.x.......", nullptr }, false, false },
                { Snare, { "....X.......X...", nullptr, nullptr }, false, false },
                { Snare, { "......g.......g.", nullptr, nullptr }, true, false },
                { ClosedHat, { "x.x.x.x.x.x.x.x.", "x.x.x.x.x.x.x.x.", nullptr }, false, true },
                { Ride, { "x...x...x...x...", nullptr, nullptr }, true, false } };
            static const Line cine[] = {
                { Kick, { "x.........x.....", "x.......x.......", "x.....x...x....." }, false, false },
                { LowTom, { "x..x..x.x..x..x.", "x..x..x...x.....", nullptr }, false, false },
                { MidTom, { "......x.......x.", "..x.......x.....", nullptr }, true, false },
                { Snare, { "........X.......", "....X.......X...", nullptr }, false, false },
                { Shaker, { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", nullptr }, false, true } };

            const Line* L = boomBap;
            int nl = 5;
            switch (cfg.style)
            {
                case 1: L = trap; nl = 4; break;
                case 2: L = house; nl = 4; break;
                case 3: L = rock; nl = 3; break;
                case 4: L = funk; nl = 4; break;
                case 5: L = jazz; nl = 4; break;
                case 6: L = bossa; nl = 3; break;
                case 7: L = reggae; nl = 3; break;
                case 8: L = gospel; nl = 4; break;
                case 9: L = neo; nl = 4; break;
                case 10: L = lofi; nl = 4; break;
                case 11: L = disco; nl = 4; break;
                case 12: L = pop; nl = 5; break;
                case 13: L = afro; nl = 6; break;
                case 14: L = dembow; nl = 4; break;
                case 15: L = drill; nl = 4; break;
                case 16: L = country; nl = 3; break;
                case 17: L = shuffle; nl = 5; break;
                case 18: L = cine; nl = 5; break;
                default: break;
            }
            const bool fill = lastBar && cx > 0.25f;
            for (int li = 0; li < nl; ++li)
            {
                const Line& line = L[li];
                if (line.ghosty && cx < 0.35f) continue;
                int nv = 0;
                while (nv < 3 && line.v[nv] != nullptr) ++nv;
                int vi = r.below (nv);
                if (line.hats) vi = std::min (nv - 1, dens < 0.3f ? 0 : (dens < 0.65f ? 1 : 2));
                if (line.note == Shaker && dens < 0.55f && cfg.style == 2) continue;
                const char* pat = line.v[vi];
                for (int s = 0; s < 16; ++s)
                {
                    if (fill && s >= 12 && (line.note == Snare || line.note == Kick || line.note == Clap)) continue;
                    const char c = pat[s];
                    if (c == '.') continue;
                    int note = line.note, vel = 92;
                    if (c == 'X') vel = 116;
                    else if (c == 'g') vel = 38;
                    else if (c == 'o') { note = OpenHat; vel = 88; }
                    if (cfg.style == 9 && line.note == Snare && c != 'g') { add (s, SpDrum, 0.5f, 0, note, vel, 0.12f); continue; }
                    if (c == 'r')
                    {
                        for (int t = 0; t < 3; ++t) add (s, SpDrum, 0.3f, 0, note, 62 + t * 10, (float) t * 0.333f);
                        continue;
                    }
                    add (s, SpDrum, 0.5f, 0, note, vel);
                }
            }
            if (fill)
            {
                const int kind = r.below (3);
                for (int s = 12; s < 16; ++s)
                {
                    int note = Snare;
                    if (kind == 1) note = s == 12 ? HighTom : (s == 13 ? MidTom : (s == 14 ? LowTom : LowTom));
                    if (kind == 2) note = (s % 2 == 0) ? Snare : (s == 13 ? HighTom : LowTom);
                    add (s, SpDrum, 0.5f, 0, note, 70 + (s - 12) * 12);
                }
                if (cfg.style != 5) add (14, SpDrum, 0.5f, 0, Kick, 100);
            }
            if (pos == 0 && dens > 0.35f && cfg.style != 5 && cfg.style != 10 && cfg.style != 7) add (0, SpDrum, 1.0f, 0, Crash, 96);
            break;
        }

        case BPad:
        {
            const int sty = cfg.style;
            if (sty == 1)   // swell
            {
                add (0, SpVoicing, 15.9f, -12, 4, 0);
                static const int ccs[] = { 25, 45, 65, 85, 100, 110, 118 };
                for (int i = 0; i < 7; ++i) add (i * 2, SpCC, 0.0f, 0, ccs[i]);
            }
            else if (sty == 2)   // breathing
            {
                add (0, SpVoicing, 7.7f, -14, 4, 0);
                add (8, SpVoicing, 7.7f, -20, 4, 0);
            }
            break;   // HELD / HIGH / LOW play on each chord change in step()
        }

        case BKeys:
        {
            auto hit = [&] (int s, float len, int accent, float off = 0.0f) { add (s, SpVoicing, len, accent, 4, 0, off); };
            switch (cfg.style)
            {
                case 0:   // block chords
                    hit (0, 7.6f, 6);
                    hit (8, 7.6f, 0);
                    if (dens > 0.6f && chance (0.5f)) hit (14, 1.6f, -8);
                    break;
                case 1:   // quarters
                    for (int s = 0; s < 16; s += 4) hit (s, 3.4f, s % 8 == 0 ? 6 : -2);
                    if (dens > 0.65f) for (int s = 2; s < 16; s += 4) if (chance (0.3f)) hit (s, 1.5f, -12);
                    break;
                case 2:   // offbeat skank
                    for (int s = 2; s < 16; s += 4) hit (s, 0.9f, 4);
                    if (dens > 0.6f) for (int s = 3; s < 16; s += 4) if (chance (0.3f + 0.3f * cx)) hit (s, 0.6f, -12);
                    break;
                case 3:   // charleston
                    hit (0, 1.6f, 6);
                    hit (6, 1.6f, 2);
                    if (dens > 0.5f && chance (0.5f)) hit (10, 1.4f, -4);
                    if (cx > 0.5f && chance (cx - 0.2f)) hit (14, 1.6f, 0);
                    break;
                case 4:   // gospel comp
                    hit (0, 2.6f, 8);
                    if (chance (0.4f + 0.5f * dens)) hit (3, 1.6f, -2);
                    hit (6, 1.6f, 2);
                    if (chance (0.4f + 0.4f * dens)) hit (10, 1.5f, 0);
                    hit (12, 1.8f, 4);
                    if (cx > 0.4f && chance (cx)) hit (14, 1.6f, -2);
                    break;
                case 5:   // house stabs
                    for (int s = 2; s < 16; s += 4) hit (s, 0.7f, 6);
                    if (dens > 0.55f) { if (chance (0.5f)) hit (7, 0.5f, -6); if (chance (0.5f)) hit (15, 0.5f, -6); }
                    break;
                case 6:   // neo-soul
                    hit (0, 5.5f, 2, 0.15f);
                    if (chance (0.3f + 0.5f * dens)) hit (6, 1.8f, -6, 0.1f);
                    hit (10, 3.6f, 0, 0.15f);
                    if (chance (0.2f + 0.5f * cx)) hit (15, 0.8f, -10, 0.1f);
                    break;
                case 7:   // ballad
                    hit (0, 7.6f, 4);
                    hit (8, 5.6f, -2);
                    if (cx > 0.4f && chance (0.6f)) add (14, SpCT, 1.8f, -10, 2, 0);
                    break;
                default:  // afro / highlife
                {
                    static const int posA[] = { 0, 3, 6, 10, 12, 14 };
                    for (int i = 0; i < 6; ++i)
                        if (i == 0 || i == 2 || chance (0.3f + 0.5f * dens)) hit (posA[i], 1.2f, i == 0 ? 6 : -2);
                    break;
                }
            }
            break;
        }

        case BArp:
        {
            const int sty = cfg.style;
            if (sty == 6)   // triplet up: twelve 8th-note triplets a bar
            {
                for (int k = 0; k < 12; ++k)
                {
                    const float t = (float) k * 4.0f / 3.0f;
                    const int s = (int) t;
                    if (dens < 0.3f && k % 3 == 2) continue;
                    add (s, SpArp, 1.2f, k % 3 == 0 ? 6 : -4, 0, k, t - (float) s);
                }
            }
            else
            {
                const int every = (sty == 3 || sty == 5) ? 2 : 1;
                int k = 0;
                for (int s = 0; s < 16; s += every)
                {
                    if (every == 1 && dens < 0.3f && (s % 2) == 1) continue;   // sparse: 8ths
                    add (s, SpArp, (float) every * 0.85f, s % 4 == 0 ? 6 : -4, sty, k++);
                }
            }
            break;
        }

        case BGuitar:
        {
            // a = 0 down-strum, 1 up-strum; b = 1 a muted scratch
            auto strum = [&] (int s, float len, int accent, int up, int muted = 0) { add (s, SpStrum, len, accent, up, muted); };
            switch (cfg.style)
            {
                case 0:   // strum 8ths
                    for (int s = 0; s < 16; s += 2)
                    {
                        if (dens < 0.35f && s % 4 == 2) continue;
                        strum (s, s % 4 == 0 ? 1.8f : 1.5f, s % 4 == 0 ? 4 : -8, s % 4 == 0 ? 0 : 1);
                    }
                    break;
                case 1:   // island strum: D . D U . U D U
                {
                    static const int posI[] = { 0, 4, 6, 10, 12, 14 };
                    static const int upI[] = { 0, 0, 1, 1, 0, 1 };
                    for (int i = 0; i < 6; ++i) strum (posI[i], 1.8f, upI[i] ? -8 : 2, upI[i]);
                    break;
                }
                case 2:   // funk chop
                    for (int s = 0; s < 16; ++s)
                    {
                        const bool accent = s == 4 || s == 10 || s == 13 || (s == 0 && cx > 0.5f);
                        if (accent) strum (s, 0.6f, 6, s % 2);
                        else if (chance (0.3f + 0.5f * dens)) strum (s, 0.25f, -30, s % 2, 1);
                    }
                    break;
                case 3:   // fingerpick: bass on the beats, treble on the off-beats
                {
                    static const int strings[8] = { 0, 3, 1, 4, 0, 3, 1, 2 };
                    for (int i = 0; i < 8; ++i)
                    {
                        if (dens < 0.35f && (i % 2) == 1 && i != 3) continue;
                        add (i * 2, SpPick, 3.5f, i % 2 == 0 ? 2 : -6, strings[i]);
                    }
                    if (cx > 0.5f && chance (cx - 0.2f)) add (15, SpPick, 0.9f, -10, 4);
                    break;
                }
                case 4:   // power chugs
                    for (int s = 0; s < 16; s += 2) add (s, SpPower, 1.2f, s % 4 == 0 ? 6 : -4);
                    if (dens > 0.6f) for (int s = 3; s < 16; s += 4) if (chance (0.3f)) add (s, SpPower, 0.6f, -10);
                    break;
                case 5:   // whole strum
                    strum (0, dens > 0.5f ? 7.6f : 15.6f, 4, 0);
                    if (dens > 0.5f) strum (8, 7.6f, -4, 0);
                    break;
                default:  // skank
                    for (int s = 2; s < 16; s += 4) strum (s, 0.7f, 2, 1);
                    if (cx > 0.5f) for (int s = 3; s < 16; s += 8) if (chance (0.4f)) strum (s, 0.4f, -12, 1, 1);
                    break;
            }
            break;
        }
        default: break;
    }

    // A' and A'' bars: a few small changes so the phrase develops
    if (var > 0 && ! bandTypeIsDrums (part))
    {
        Rng m = seeded (mix (base, (uint32_t) (var * 104729 + 17)));
        const float p = 0.15f + 0.35f * cx;
        for (int i = 0; i < S.count; ++i)
        {
            auto& e = S.plan[(size_t) i];
            if (e.spec == SpCC || e.spec == SpVoicing) continue;
            if (m.unit() < p)
            {
                if (e.spec == SpStep) e.b = (int8_t) (e.b ? 0 : 1);
                else if (e.spec == SpCT) e.a = (int8_t) ((e.a + 1 + m.below (3)) % 4);
                else if (e.spec == SpRepeat) e.spec = SpStep;
                else if (e.spec == SpRoot && e.step != 0) e.spec = SpOct;
            }
        }
    }
}

//==============================================================================
int Band::resolve (int track, const PlanEv& e, const BandPartConfig& cfg, const Harmony& h, int64_t bar, BandEvent* out, int maxOut)
{
    auto& S = st[(size_t) track];
    const int part = cfg.type;
    int n = 0;
    auto emit = [&] (int note, int vel, float off, float len)
    {
        if (n >= maxOut || note < 0 || note > 127) return;
        BandEvent& ev = out[n++];
        ev = BandEvent();
        ev.part = track;
        ev.channel = cfg.channel;
        ev.note = note;
        ev.velocity = std::clamp (vel, 1, 127);
        ev.offset = off;
        ev.length = len;
    };

    Rng r = seeded (mix (cfg.seed ^ 0x5bd1e995u, (uint32_t) (bar * 64 + e.step * 4 + track)));
    const float level = 0.45f + 0.75f * cfg.level;
    auto vel = [&] (int accent) { return (int) ((92 + accent) * level + (r.unit() * 2.0f - 1.0f) * 5.0f); };
    const int oct = 12 * cfg.octave;

    if (e.spec == SpDrum)
    {
        emit (e.a, (int) (e.b * level + (r.unit() * 2.0f - 1.0f) * 4.0f), e.off, e.len);
        return n;
    }
    if (e.spec == SpCC)
    {
        if (n < maxOut)
        {
            BandEvent& ev = out[n++];
            ev = BandEvent();
            ev.part = track;
            ev.channel = cfg.channel;
            ev.isCC = true;
            ev.note = 11;
            ev.velocity = std::clamp ((int) e.a, 0, 127);
            ev.offset = e.off;
        }
        return n;
    }

    // part ranges
    int center = 74, lo = 62, hi = 88;
    int scaleKind = 0;
    if (part == BMelody) { center = 74; lo = 63; hi = 88; scaleKind = melTable[std::clamp (cfg.style, 0, numMel - 1)].scaleKind; }
    else if (part == BCounter) { center = cfg.style == 4 ? 84 : 66; lo = center - 9; hi = center + 9; }
    else if (part == BBass) { center = 40; lo = 28; hi = 55; }
    else if (part == BStrings) { center = cfg.style == 7 ? 82 : (cfg.style == 8 ? 50 : 64); lo = center - 9; hi = center + 12; }
    else if (part == BHorns) { center = 67; lo = 58; hi = 80; scaleKind = 2; }
    else if (part == BPad) { center = cfg.style == 3 ? 79 : (cfg.style == 4 ? 55 : 67); lo = center - 9; hi = center + 12; }
    else if (part == BKeys) { center = 64; lo = 54; hi = 79; }
    else if (part == BArp) { center = 72; lo = 60; hi = 90; }
    center += oct; lo += oct; hi += oct;

    const int mask = melodicMask (h, scaleKind);
    int last = S.last >= 0 ? S.last : center;
    if (last < lo - 6 || last > hi + 6) last = center;
    const Chord& c = h.chord;

    auto bassRoot = [&] () { return intoRange (nearestWithPc (center - 3, bassPc (c)), lo, hi); };
    auto chordTone = [&] (int k, int ref) { return intoRange (nearestWithPc (ref, chordTonePc (c, k)), lo, hi); };

    switch (e.spec)
    {
        case SpRoot:  { const int note = bassRoot(); emit (note, vel (e.accent), e.off, e.len); S.last = note; break; }
        case SpOct:   { int note = bassRoot() + 12; if (note > hi + 5) note -= 12; emit (note, vel (e.accent), e.off, e.len); S.last = note; break; }
        case SpFifth:
        {
            const int m = tonesMask (c);
            const int fifth = (m >> 7) & 1 ? 7 : ((m >> 6) & 1 ? 6 : ((m >> 8) & 1 ? 8 : 7));
            int note = bassRoot() + fifth;
            if (note > hi) note -= 12;
            emit (note, vel (e.accent), e.off, e.len);
            S.last = note;
            break;
        }
        case SpRel:
        {
            int rel = e.a;
            const int m = tonesMask (c);
            if (rel == 4 && ! ((m >> 4) & 1) && ((m >> 3) & 1)) rel = 3;      // minor chord: minor 3rd
            if (rel == 7 && ! ((m >> 7) & 1) && ((m >> 6) & 1)) rel = 6;      // diminished 5th
            if (rel == 10 && ((m >> 11) & 1)) rel = 11;                       // maj7 chord: major 7th
            int note = bassRoot() + rel;
            if (note > hi) note -= 12;
            emit (note, vel (e.accent), e.off, e.len);
            S.last = note;
            break;
        }
        case SpWalk:
        {
            const int note = bassRoot() - e.b;
            emit (note, vel (e.accent), e.off, e.len);
            S.last = note;
            break;
        }
        case SpCT:
        {
            int note = chordTone (e.a, last);
            if (e.b != 0) note = intoRange (note + 12 * e.b, lo - 12, hi + 12);
            emit (note, vel (e.accent), e.off, e.len);
            S.last = note;
            break;
        }
        case SpExt:
        {
            static const int rels[3] = { 2, 9, 5 };
            int rel = rels[std::clamp ((int) e.a, 0, 2)];
            if (rel == 5 && ((tonesMask (c) >> 4) & 1)) rel = 2;   // no 11 over a major 3rd
            int pc = pcOf (c.root + rel);
            if (! ((mask >> pc) & 1) && ! ((pcMask (c) >> pc) & 1)) pc = chordTonePc (c, 1);
            const int note = intoRange (nearestWithPc (last, pc), lo, hi);
            emit (note, vel (e.accent), e.off, e.len);
            S.last = note;
            break;
        }
        case SpStep:
        {
            if (e.b) S.dir = -S.dir;
            if (last >= hi - 2) S.dir = -1;
            if (last <= lo + 2) S.dir = 1;
            int note = stepInMask (last, S.dir * std::max (1, (int) e.a), mask);
            note = intoRange (note, lo, hi);
            emit (note, vel (e.accent), e.off, e.len);
            if (part == BHorns && cfg.style == 2) emit (note - 12, vel (e.accent - 6), e.off, e.len);
            S.last = note;
            break;
        }
        case SpRepeat:
        {
            const int note = S.last >= 0 ? S.last : chordTone (0, center);
            emit (note, vel (e.accent), e.off, e.len);
            if (part == BHorns && cfg.style == 2) emit (note - 12, vel (e.accent - 6), e.off, e.len);
            S.last = note;
            break;
        }
        case SpLeap:
        {
            const int note = intoRange (nearestWithPc (last + S.dir * 7, chordTonePc (c, e.a)), lo, hi);
            S.dir = note >= last ? -1 : 1;   // leaps turn around afterwards
            emit (note, vel (e.accent + 4), e.off, e.len);
            if (part == BHorns && cfg.style == 2) emit (note - 12, vel (e.accent - 2), e.off, e.len);
            S.last = note;
            break;
        }
        case SpApproach:
        {
            const int target = part == BBass ? bassRoot() : chordTone (e.a, last);
            const int dir = e.b == 0 ? -1 : e.b;
            const bool chromatic = r.unit() < 0.25f + 0.6f * cfg.complexity;
            const int note = chromatic ? target + dir : stepInMask (target, dir, poolMask (h.keyRoot, h.scale) | pcMask (c));
            emit (note, vel (e.accent - 4), e.off, e.len);
            S.last = note;
            break;
        }
        case SpGrace:
        {
            const int target = part == BBass ? bassRoot() : chordTone (e.a, last);
            const bool chromatic = r.unit() < 0.35f + 0.5f * cfg.complexity;
            emit (chromatic ? target - 1 : stepInMask (target, -1, mask), vel (e.accent - 18), e.off, 0.25f);
            emit (target, vel (e.accent), e.off + 0.25f, std::max (0.3f, e.len - 0.25f));
            S.last = target;
            break;
        }
        case SpVoicing:
        {
            Notes v = voiceLead (S.voice, c, std::max (3, (int) e.a), center, lo, hi);
            if (e.b != 0 && v.size() >= 2)
            {
                // move the top voice to the next chord tone up or down
                const int top = v.highest();
                int alt = top;
                for (int k = 0; k < 6; ++k)
                {
                    const int cand = intoRange (nearestWithPc (top + e.b * 3, chordTonePc (c, k)), lo, hi);
                    if (cand != top && ! v.contains (cand)) { alt = cand; break; }
                }
                v.removeAt (v.size() - 1);
                v.add (alt);
                v.unique();
            }
            S.voice = v;
            for (int i = 0; i < v.size(); ++i) emit (v[i], vel (e.accent - (i == v.size() - 1 ? 0 : 6)), e.off, e.len);
            break;
        }
        case SpCycle:
        {
            if (S.voice.size() < 3) S.voice = voiceLead (S.voice, c, 4, center, lo, hi);
            static const int pats[4][4] = { { 0, 1, 2, 1 }, { 0, 2, 1, 2 }, { 0, 1, 2, 3 }, { 2, 1, 0, 1 } };
            const int idx = pats[std::clamp ((int) e.a, 0, 3)][S.cycle++ % 4] % S.voice.size();
            emit (S.voice[idx], vel (e.accent), e.off, e.len);
            break;
        }
        case SpArp:
        {
            Notes v = voiceLead (S.voice, c, 4, center, lo, hi);
            S.voice = v;
            if (v.empty()) break;
            Notes pool = v;
            if (v.lowest() + 12 <= hi + 6 && ! pool.contains (v.lowest() + 12)) pool.add (v.lowest() + 12);
            pool.sort();
            const int np = pool.size();
            const int k = e.b;
            int idx = 0;
            switch (e.a)
            {
                case 1:  idx = np - 1 - k % np; break;                                         // down
                case 2:  { const int period = std::max (1, 2 * np - 2); const int p = k % period; idx = p < np ? p : period - p; break; }
                case 4:  idx = (int) (mix (cfg.seed, (uint32_t) (k * 31 + (int) (bar % 2) * 7)) % (uint32_t) np); break;
                case 5:  { const int root = intoRange (nearestWithPc (center - 5, c.root), lo - 5, hi - 12); emit (k % 2 == 0 ? root : root + 12, vel (e.accent), e.off, e.len); S.last = root; return n; }
                default: idx = k % np; break;                                                   // up
            }
            idx = std::clamp (idx, 0, np - 1);
            emit (pool[idx], vel (e.accent), e.off, e.len);
            S.last = pool[idx];
            break;
        }
        case SpStrum:
        case SpPick:
        case SpPower:
        {
            const Notes g = guitarVoicing (c, cfg.octave);
            S.voice = g;
            if (g.empty()) break;
            if (e.spec == SpPick)
            {
                const int si = std::clamp ((int) e.a, 0, g.size() - 1);
                emit (g[si], vel (e.accent), e.off, e.len);
                break;
            }
            if (e.spec == SpPower)
            {
                const int root = g[0];
                const int m = tonesMask (c);
                const int fifth = (m >> 7) & 1 ? 7 : ((m >> 6) & 1 ? 6 : ((m >> 8) & 1 ? 8 : 7));
                for (int note : { root, root + fifth, root + 12 }) emit (note, vel (e.accent), e.off, e.len);
                break;
            }
            // strum: down = low string to high, up = the top strings, high to low; a few ms apart
            const bool up = e.a == 1, muted = e.b == 1;
            const int first = up ? g.size() - 1 : 0;
            const int count = up ? std::max (2, g.size() - 2) : g.size();
            const float gap = muted ? 0.025f : 0.05f;
            for (int i = 0; i < count; ++i)
            {
                const int idx = up ? first - i : i;
                if (idx < 0 || idx >= g.size()) break;
                const float o = e.off + gap * (float) i;
                emit (g[idx], vel (e.accent - (up ? 6 : 0) - (muted ? 0 : i * 2)), o, std::max (0.15f, e.len - (o - e.off)));
            }
            break;
        }
        default: break;
    }
    return n;
}

//==============================================================================
// Hand-written phrases (core/Phrases.cpp), placed over the chord of the moment.
int Band::pickPhrase (int set, const BandPartConfig& cfg, const BandConfig& bc, uint32_t salt, int avoid, int avoidBase) const
{
    const auto& ids = phrasesInSet (set);
    if (ids.empty()) return -1;
    const auto& lib = phraseLibrary();
    // phrases no longer than the PHRASE setting (if the set has any), closest to BUSY / COMPLEX first;
    // never a line you skipped, liked lines first, and after a DICE roll a different idea from the last one
    constexpr int maxCand = 512;
    int cand[maxCand];
    float score[maxCand];
    int count = 0;
    bool anyFits = false, anyOtherBase = false, anyLiked = false;
    int notSkipped = 0;
    for (int id : ids)
    {
        const auto& ph = lib[(size_t) id];
        if (ph.bars <= std::max (1, bc.phraseBars)) anyFits = true;
        if (phraseRating (id) >= 0) ++notSkipped;
        if (phraseRating (id) > 0) anyLiked = true;
        if (ph.base != avoidBase) anyOtherBase = true;
    }
    for (int id : ids)
    {
        const auto& ph = lib[(size_t) id];
        if (anyFits && ph.bars > std::max (1, bc.phraseBars)) continue;
        if (id == avoid && ids.size() > 1) continue;
        if (notSkipped > 0 && phraseRating (id) < 0) continue;
        if (anyOtherBase && avoidBase >= 0 && ph.base == avoidBase) continue;
        if (count >= maxCand) break;
        cand[count] = id;
        score[count] = std::abs (ph.density - cfg.density) * 1.2f + std::abs (ph.complexity - cfg.complexity)
                     + (float) (mix (cfg.seed, (uint32_t) id * 31u + salt) % 1000u) * 0.0004f
                     - (phraseRating (id) > 0 ? 0.35f : 0.0f);
        ++count;
    }
    (void) anyLiked;
    if (count == 0) return ids[0];
    // keep the better-fitting 60%, then let the seed choose
    for (int a = 0; a < count; ++a)
        for (int b = a + 1; b < count; ++b)
            if (score[b] < score[a]) { std::swap (score[a], score[b]); std::swap (cand[a], cand[b]); }
    const int keep = std::max (1, (count * 3 + 4) / 5);
    return cand[mix (mix (cfg.seed, salt), (uint32_t) set * 7919u) % (uint32_t) keep];
}

int Band::phraseStep (int track, int set, const BandPartConfig& cfg, const BandConfig& bc, const Harmony& h, int64_t absStep,
                      BandEvent* out, int maxOut)
{
    auto& S = st[(size_t) track];
    const int part = cfg.type;
    const auto& lib = phraseLibrary();
    int n = 0;

    // ranges: where each kind of player lives
    int lo = 60, hi = 88, center = 72;
    if (part == BCounter) { if (set == PsDescant) { lo = 72; hi = 96; center = 84; } else { lo = 57; hi = 81; center = 69; } }
    else if (part == BStrings)
    {
        if (set == PsCello) { lo = 36; hi = 64; center = 50; }
        else if (set == PsDescant) { lo = 72; hi = 96; center = 84; }
        else { lo = 55; hi = 96; center = 72; }
    }
    else if (part == BHorns) { lo = 55; hi = 82; center = 67; }
    lo += 12 * cfg.octave; hi += 12 * cfg.octave; center += 12 * cfg.octave;

    // the track's DICE was rolled: a new line from the next bar, and a different idea from the one before
    if (cfg.seed != S.seedSeen)
    {
        if (S.seedSeen != 0)
        {
            if (S.letterA >= 0) S.lastBase = lib[(size_t) S.letterA].base;
            S.letterA = -1;
            S.phrase = -1;
            S.nextPhrase = absStep;
            S.slot = 0;
        }
        S.seedSeen = cfg.seed;
    }
    // you skipped the line that's playing: it stops and another one starts on the next bar
    if (const uint32_t ep = phraseRatingsEpoch(); ep != S.ratingSeen)
    {
        S.ratingSeen = ep;
        if ((S.phrase >= 0 && phraseRating (S.phrase) < 0) || (S.letterA >= 0 && phraseRating (S.letterA) < 0))
        {
            if (S.letterA >= 0) S.lastBase = lib[(size_t) S.letterA].base;
            S.letterA = -1;
            S.phrase = -1;
            S.nextPhrase = absStep;
        }
    }

    // start a new phrase on a bar line once the gap has passed
    if (S.phrase < 0 && absStep >= S.nextPhrase && absStep % 16 == 0)
    {
        // A A B A for melodies and riffs, A B A C for string lines (a melody that develops)
        const bool develop = set == PsViolinLyrical || set == PsCello || set == PsDescant || set == PsCinematic || set == PsAmbient;
        const int pos = S.slot % 4, group = S.slot / 4;
        if (S.letterA < 0) S.letterA = pickPhrase (set, cfg, bc, 1u, -1, S.lastBase);
        int id;
        if (develop) id = (pos == 0 || pos == 2) ? S.letterA : pickPhrase (set, cfg, bc, 1000u + (uint32_t) (group * 2 + pos), S.letterA);
        else id = pos == 2 ? pickPhrase (set, cfg, bc, 2000u + (uint32_t) group, S.letterA) : S.letterA;
        S.phrase = id;
        phraseNow[(size_t) track] = id;
        S.phraseStart = absStep;
        S.noteIdx = 0;
        S.lastIdx = -1;
    }

    const float level = 0.45f + 0.75f * cfg.level;
    auto emitCC = [&] (float value01, float offset)
    {
        if (cfg.dyn <= 0) return;
        const int v = std::clamp ((int) std::lround (16.0f + value01 * 111.0f), 0, 127);
        if (S.ccLast >= 0 && std::abs ((float) v - S.ccLast) < 2.0f) return;
        S.ccLast = (float) v;
        for (int which = 0; which < 2; ++which)
        {
            const int cc = which == 0 ? 1 : 11;
            if (cc == 1 && ! (cfg.dyn == 1 || cfg.dyn == 3)) continue;
            if (cc == 11 && ! (cfg.dyn == 2 || cfg.dyn == 3)) continue;
            if (n >= maxOut) return;
            BandEvent& ev = out[n++];
            ev = BandEvent();
            ev.part = track;
            ev.channel = cfg.channel;
            ev.isCC = true;
            ev.note = cc;
            ev.velocity = v;
            ev.offset = offset;
        }
    };

    if (S.phrase < 0)
    {
        if (S.ccLast > 0) emitCC (std::max (0.3f, (S.ccLast - 16.0f) / 111.0f - 0.03f), 0.0f);   // relax between phrases
        return n;
    }

    const Phrase& P = lib[(size_t) S.phrase];
    const float rel = (float) (absStep - S.phraseStart);
    const float total = (float) (P.bars * 16);

    // feel: some styles sit behind the beat, some swing
    float laid = 0.0f;
    if (set == PsRnb || set == PsViolinSoul) laid = 0.1f;
    else if (set == PsLofi) laid = 0.2f;
    else if (set == PsGospel) laid = 0.06f;
    const float sw = bc.swing;

    const int keyMask = poolMask (h.keyRoot, h.scale);
    const int stepMask = keyMask | pcMask (h.chord);
    const int root = h.chord.root;

    auto place = [&] (int pc, int ref, int oct)
    {
        // ' and , ask for up / down, but never at the cost of a leap bigger than a 6th
        // (the chord may have changed under the phrase; a player would take the near note)
        const int near = nearestWithPc (ref, pc);
        if (oct > 0) { const int up = ref + 1 + pcOf (pc - (ref + 1)); return up - ref <= 9 ? up : near; }
        if (oct < 0) { const int dn = ref - 1 - pcOf ((ref - 1) - pc); return ref - dn <= 9 ? dn : near; }
        return near;
    };

    while (S.noteIdx < (int) P.notes.size() && P.notes[(size_t) S.noteIdx].start < rel + 1.0f && n < maxOut - 3)
    {
        const int idx = S.noteIdx++;
        const PhraseNote& pn = P.notes[(size_t) idx];
        if (pn.kind == PkRest) continue;

        // pitch, against the chord playing right now. A new phrase starts back near home.
        int ref = (S.last >= lo - 7 && S.last <= hi + 7) ? S.last : center;
        if (S.lastIdx < 0) ref = (ref + 2 * center) / 3;
        int note = ref;
        switch (pn.kind)
        {
            case PkDegree: note = place (pcOf (root + degreeInterval (pn.value, h.chord, keyMask)), ref, pn.octave); break;
            case PkInterval: note = place (pcOf (root + pn.value), ref, pn.octave); break;
            case PkBlue:
            {
                // blue notes bend with the chord: over a minor chord the "b3" lick starts a step lower
                // (so b3 -> 3 becomes 9 -> b3), and over a major-7 chord the b7 becomes the 6th
                const int tm = tonesMask (h.chord);
                int rel = pn.value == 3 ? 3 : (pn.value == 5 ? 6 : 10);
                if (pn.value == 3 && ((tm >> 3) & 1) && ! ((tm >> 4) & 1)) rel = 2;
                if (pn.value == 7 && ((tm >> 11) & 1)) rel = 9;
                note = place (pcOf (root + rel), ref, pn.octave);
                break;
            }
            case PkStep: note = stepInMask (ref, pn.value, stepMask); break;
            case PkChromatic: note = ref + pn.value; break;
            case PkRepeat: default: note = ref; break;
        }
        while (note < lo) note += 12;
        while (note > hi) note -= 12;
        S.last = note;

        // length and articulation: legato notes overlap the next one (legato patches need that)
        int next = idx + 1;
        while (next < (int) P.notes.size() && P.notes[(size_t) next].kind == PkRest) ++next;
        const bool contiguous = next < (int) P.notes.size() && P.notes[(size_t) next].start <= pn.start + pn.dur + 0.01f;
        float len;
        if ((pn.art & ArtLegato) && contiguous) len = pn.dur + 0.18f;
        else if (pn.art & ArtShort) len = std::min (pn.dur, 1.0f) * 0.45f;
        else if ((pn.art & ArtSwell) || pn.dur >= 8.0f) len = pn.dur * 0.97f;
        else len = pn.dur * (contiguous ? 0.92f : 0.86f);

        // dynamics: each phrase rises and falls, accents and the first note shaped like a player would
        const float pos = pn.start / total;
        float vel = (60.0f + 10.0f * std::sin ((float) pi * std::min (1.0f, pos * 1.15f))) * level;
        if (pn.art & ArtAccent) vel += 14.0f;
        if (pn.art & ArtShort) vel -= 4.0f;
        if (pn.art & ArtSwell) vel -= 6.0f;
        if (S.lastIdx < 0) vel -= 4.0f;
        if (pn.dur < 1.1f) vel -= 5.0f;                       // quick notes are lighter
        const uint32_t hsh = mix (cfg.seed ^ (uint32_t) (absStep * 131), (uint32_t) idx);
        vel += (float) (hsh % 9u) - 4.0f;
        const int velocity = std::clamp ((int) std::lround (vel), 1, 127);

        // timing
        float off = pn.start - rel;
        const float inBeat = std::fmod (pn.start, 4.0f);
        if (sw > 0.0f)
        {
            if (std::abs (inBeat - 2.0f) < 0.01f) off += sw * 2.0f;
            else if (std::abs (std::fmod (pn.start, 2.0f) - 1.0f) < 0.01f) off += sw;
        }
        off += laid + ((float) ((hsh >> 8) % 7u) - 3.0f) * 0.012f;
        off = std::max (0.0f, off);

        if ((pn.art & ArtGrace) && n < maxOut)
        {
            BandEvent& g = out[n++];
            g = BandEvent();
            g.part = track; g.channel = cfg.channel; g.note = std::clamp (note - 1, 0, 127);
            g.velocity = std::max (1, velocity - 18); g.offset = off; g.length = 0.3f;
            off += 0.25f;
            len = std::max (0.3f, len - 0.25f);
        }
        if (n < maxOut)
        {
            BandEvent& ev = out[n++];
            ev = BandEvent();
            ev.part = track;
            ev.channel = cfg.channel;
            ev.note = std::clamp (note, 0, 127);
            ev.velocity = velocity;
            ev.offset = off;
            ev.length = len;
        }
        S.lastIdx = idx;
        S.lastVel = velocity;
    }

    // dynamics (CC1 / CC11): follow the note, swell the long ones
    if (cfg.dyn > 0 && S.lastIdx >= 0)
    {
        const PhraseNote& cur = P.notes[(size_t) S.lastIdx];
        const float base = std::clamp ((float) S.lastVel / 110.0f, 0.2f, 1.0f);
        for (int half = 0; half < 2; ++half)
        {
            const float t = (rel + 0.5f * (float) half - cur.start) / std::max (0.5f, cur.dur);
            float shape;
            if (t >= 1.0f) shape = 0.72f;
            else if (cur.art & ArtSwell) shape = t < 0.55f ? 0.55f + 0.45f * std::sin (t / 0.55f * (float) pi * 0.5f) : 1.0f - 0.25f * (t - 0.55f) / 0.45f;
            else shape = 0.92f - 0.12f * std::max (0.0f, t);
            emitCC (base * shape, 0.5f * (float) half);
            if (! (cur.art & ArtSwell) && half == 0) break;
        }
    }

    // phrase over: leave room before the next one (more room when BUSY is low), on a 2-bar line
    if (rel + 1.0f >= total)
    {
        const int64_t end = S.phraseStart + (int64_t) total;
        int64_t next = ((end + 31) / 32) * 32;
        if (cfg.density < 0.3f) next += 32;
        else if (cfg.density < 0.6f && (S.slot % 2) == 1) next += 32;
        S.nextPhrase = next;
        S.phrase = -1;
        ++S.slot;
    }
    return n;
}

//==============================================================================
Notes bandHoldNotes (const BandPartConfig& cfg, const Notes& playedIn, const Chord& chord)
{
    Notes played = playedIn;
    played.unique();
    Notes out;
    if (played.empty() || bandTypeIsDrums (cfg.type)) return out;
    const int oct = 12 * cfg.octave;
    switch (cfg.type)
    {
        case BBass:
        {
            // the bottom note (the chord's bass note when you play a chord), down where a bass lives
            int note = played.lowest();
            if (played.size() >= 3 && chord.valid()) note = nearestWithPc (played.lowest(), bassPc (chord));
            out.add (intoRange (note, 28, 52) + oct);
            break;
        }
        case BMelody:
            out.add (played.highest() + oct);
            break;
        case BCounter:
            out.add ((played.size() >= 2 ? played[played.size() - 2] : played.highest()) + oct);
            break;
        default:
            for (int i = 0; i < played.size(); ++i) out.add (played[i] + oct);
            break;
    }
    Notes clean;
    for (int i = 0; i < out.size(); ++i)
    {
        int note = out[i];
        while (note > 127) note -= 12;
        while (note < 0) note += 12;
        clean.add (note);
    }
    clean.unique();
    return clean;
}

//==============================================================================
int Band::clipStep (int track, const ClipSet& cs, const BandPartConfig& cfg, const BandConfig& bc, const Harmony& h, int64_t absStep,
                    BandEvent* out, int maxOut)
{
    const int64_t bar = absStep >= 0 ? absStep / 16 : (absStep - 15) / 16;
    const int ci = clipIndexAt (cs, cfg.seed, bar);
    clipNow[(size_t) track] = ci;
    const MidiClip& c = cs.clips[(size_t) std::clamp (ci, 0, (int) cs.clips.size() - 1)];
    const int64_t cycle = std::max (1, cs.cycleBars);
    const int64_t cycleStart = (bar >= 0 ? bar / cycle : (bar - cycle + 1) / cycle) * cycle;
    const int64_t clipLen = (int64_t) c.bars * 16;
    const int64_t rel = absStep - cycleStart * 16;
    const int pos = (int) (((rel % clipLen) + clipLen) % clipLen);
    const int loop = (int) (rel / clipLen);   // which time round the file this is, inside the cycle
    const int part = cfg.type;
    const bool drums = bandTypeIsDrums (part);
    const int piece = bandTypePiece (part);
    const float level = 0.45f + 0.75f * cfg.level;

    // melodic files: move the file into your key (a minor file over a major key goes to the relative minor)
    const bool targetMinor = ! scaleIsMajorType (h.scale);
    int shift = h.keyRoot - c.keyRoot;
    if (c.minor && ! targetMinor) shift = h.keyRoot + 9 - c.keyRoot;
    if (! c.minor && targetMinor) shift = h.keyRoot + 3 - c.keyRoot;
    shift = ((shift % 12) + 12) % 12;
    if (shift > 6) shift -= 12;
    const int keyMask = poolMask (h.keyRoot, h.scale);
    const int chordMask = pcMask (h.chord);
    const int tonic = pcOf (c.keyRoot + shift);
    int toChord = pcOf (bassPc (h.chord) - tonic);   // basslines follow each chord's root
    if (toChord > 6) toChord -= 12;

    auto snap = [] (int note, int mask)
    {
        if (mask == 0) return note;
        for (int d = 0; d <= 6; ++d)
        {
            if ((mask >> pcOf (note - d)) & 1) return note - d;
            if ((mask >> pcOf (note + d)) & 1) return note + d;
        }
        return note;
    };

    // REWORK (drums): this bar of the file, played like a drummer of the genre would - worked out once per bar
    const ClipNote* src = c.notes.data();
    size_t srcCount = c.notes.size();
    int srcPos = pos;
    if (drums && cfg.rework > 0.005f)
    {
        auto& S = st[(size_t) track];
        const int clipBar = pos / 16;
        const int64_t key = (int64_t) (mix (mix (cfg.seed, (uint32_t) (cycleStart * 31 + loop * 7 + clipBar)),
                                            (uint32_t) (ci * 131 + (int) (cfg.rework * 100.0f) * 7 + cfg.reworkLock * 3 + bc.genre))) & 0x7fffffffffffLL;
        if (key != S.rwKey)
        {
            S.rwKey = key;
            ClipNote barIn[160];
            int nb = 0;
            for (const auto& cn : c.notes)
                if (cn.start >= (float) (clipBar * 16) && cn.start < (float) (clipBar * 16 + 16) && nb < 160)
                {
                    barIn[nb] = cn;
                    barIn[nb].start -= (float) (clipBar * 16);
                    ++nb;
                }
            const bool phraseEnd = clipBar == c.bars - 1 || ((bar + 1) % 4 == 0);
            S.rwN = reworkDrumBar (barIn, nb, bc.genre, cfg.rework, cfg.reworkLock, (uint32_t) key, phraseEnd, S.rw.data(), (int) S.rw.size());
        }
        src = S.rw.data();
        srcCount = (size_t) S.rwN;
        srcPos = pos % 16;
    }

    int n = 0;
    for (size_t k = 0; k < srcCount && n < maxOut; ++k)
    {
        const ClipNote& cn = src[k];
        if ((int) std::floor (cn.start) != srcPos) continue;
        const uint32_t hsh = mix (mix (cfg.seed, (uint32_t) (cycleStart * 31 + loop)), (uint32_t) k);
        const bool strong = pos % 4 == 0 || cn.len >= 2.0f;
        // BUSY below the middle thins the file out (never the downbeat)
        if (cfg.density < 0.5f && pos % 16 != 0 && (float) (hsh % 1000u) / 1000.0f < (0.5f - cfg.density) * 1.6f) continue;
        int note = cn.note;
        if (drums)
        {
            if (piece >= 0 && drumPieceOf (note) != piece) continue;
        }
        else
        {
            note += cfg.transpose;
            if (part == BBass)
            {
                note = snap (note + shift + toChord, keyMask | chordMask);
                while (note > 60) note -= 12;
                while (note < 28) note += 12;
            }
            else
            {
                note += shift;
                const bool chordTone = (chordMask >> pcOf (note)) & 1;
                const bool rubs = ((chordMask >> pcOf (note - 1)) & 1) || ((chordMask >> pcOf (note + 1)) & 1);
                if (strong && ! chordTone && rubs) note = snap (note, chordMask);          // long / on-the-beat notes sit on the chord
                else note = snap (note, keyMask | chordMask);
                // COMPLEX: the file changes a little each time round
                if (loop > 0 && ! strong && cfg.complexity > 0.5f && (float) ((hsh >> 10) % 1000u) / 1000.0f < (cfg.complexity - 0.5f) * 0.6f)
                    note = snap (note + ((hsh >> 20) & 1 ? 2 : -2), keyMask | chordMask);
            }
            note += 12 * cfg.octave;
            while (note > 120) note -= 12;
            while (note < 12) note += 12;
        }
        BandEvent& ev = out[n++];
        ev = BandEvent();
        ev.part = track;
        ev.channel = cfg.channel;
        ev.note = std::clamp (note, 0, 127);
        ev.velocity = std::clamp ((int) std::lround ((float) cn.vel * level), 1, 127);
        ev.offset = cn.start - std::floor (cn.start);
        ev.length = drums ? std::min (cn.len, 1.0f) : cn.len;
        if (bc.swing > 0.0f)
        {
            if (pos % 4 == 2) ev.offset += bc.swing * 2.0f;
            else if (pos % 2 == 1) ev.offset += bc.swing;
        }
    }
    return n;
}

//==============================================================================
int Band::step (const BandConfig& bc, const Harmony& h, int64_t absStep, BandEvent* out, int maxOut)
{
    if (! h.valid()) return 0;
    const int64_t bar = absStep >= 0 ? absStep / 16 : (absStep - 15) / 16;
    const int s = (int) (absStep - bar * 16);
    const int numTracks = std::clamp (bc.numTracks, 0, maxBandTracks);
    int n = 0;
    melodyHit = false;

    // the melody the counter-melody follows: the first melody track that's playing its style
    melodyTrack = -1;
    for (int t = 0; t < numTracks; ++t)
    {
        const auto& c = bc.part[(size_t) t];
        if (c.on && c.mode == ModeJam && c.type == BMelody) { melodyTrack = t; break; }
    }

    // drums and bass first, then the melody (the counter-melody listens to it), then everything else
    static const int order[numBandTypes] = { BDrums, BKick, BSnare, BClap, BHats, BOpenHat, BPerc, BCymbal, BTom,
                                             BBass, BMelody, BCounter, BStrings, BHorns, BPad, BKeys, BArp, BGuitar };
    for (int oi = 0; oi < numBandTypes && n < maxOut; ++oi)
    for (int track = 0; track < numTracks && n < maxOut; ++track)
    {
        const auto& cfg = bc.part[(size_t) track];
        if (cfg.type != order[oi]) continue;
        const int part = cfg.type;
        auto& S = st[(size_t) track];
        if (! cfg.on || cfg.mode != ModeJam) { S.harmonyId = -1; continue; }

        // YOUR MIDI
        if (const ClipSet* cs = bc.clips[(size_t) track]; cs != nullptr && ! cs->clips.empty())
        {
            const int first = n;
            n += clipStep (track, *cs, cfg, bc, h, absStep, out + n, maxOut - n);
            S.harmonyId = h.id;
            if (track == melodyTrack)
                for (int i = first; i < n; ++i)
                    if (! out[i].isCC && out[i].offset < 0.9f) { melodyHit = true; melodyNote = out[i].note; melodyLen = out[i].length; melodyOff = out[i].offset; }
            continue;
        }

        // hand-written phrases
        const int pset = phraseSetFor (part, cfg.style);
        if (pset >= 0)
        {
            const int first = n;
            n += phraseStep (track, pset, cfg, bc, h, absStep, out + n, maxOut - n);
            S.harmonyId = h.id;
            if (track == melodyTrack)
                for (int i = first; i < n; ++i)
                    if (! out[i].isCC && out[i].offset < 0.9f && out[i].length > 0.3f)
                    { melodyHit = true; melodyNote = out[i].note; melodyLen = out[i].length; melodyOff = out[i].offset; }
            continue;
        }

        const int key = (int) mix (mix (cfg.seed, (uint32_t) (cfg.style + 64 * part)), (uint32_t) (bc.phraseBars * 100 + (int) (cfg.density * 50) * 7 + (int) (cfg.complexity * 50)));
        if (S.planBar != bar || S.planKey != key)
        {
            buildPlan (track, cfg, bc, bar);
            S.planBar = bar;
            S.planKey = key;
        }

        const bool changed = h.id != S.harmonyId;
        S.harmonyId = h.id;
        const int first = n;

        // parts that answer chord changes directly
        if (changed)
        {
            PlanEv pe;
            pe.step = (int8_t) s;
            const bool heldPad = (part == BStrings && cfg.style == 0) || (part == BHorns && cfg.style == 3)
                              || (part == BPad && (cfg.style == 0 || cfg.style == 3 || cfg.style == 4));
            const bool catchUp = part == BBass || (part == BStrings && (cfg.style == 1 || cfg.style == 2))
                              || (part == BHorns && cfg.style == 1) || (part == BPad && (cfg.style == 1 || cfg.style == 2))
                              || (part == BKeys && (cfg.style == 0 || cfg.style == 1 || cfg.style == 6 || cfg.style == 7))
                              || (part == BGuitar && cfg.style == 5);
            if (heldPad)
            {
                pe.spec = SpVoicing;
                pe.a = 4;
                pe.len = -1.0f;
                pe.accent = (int8_t) (part == BHorns ? -24 : -12);
                n += resolve (track, pe, cfg, h, bar, out + n, maxOut - n);
            }
            else if (catchUp)
            {
                // a new chord between this part's planned notes: catch it now instead of waiting
                bool planned = false;
                int next = 16;
                for (int i = 0; i < S.count; ++i)
                {
                    const int ps = S.plan[(size_t) i].step;
                    if (ps == s && S.plan[(size_t) i].spec != SpCC) planned = true;
                    if (ps > s) next = std::min (next, ps);
                }
                if (! planned)
                {
                    pe.spec = part == BBass ? (int8_t) SpRoot : (part == BGuitar ? (int8_t) SpStrum : (int8_t) SpVoicing);
                    pe.a = (int8_t) (pe.spec == SpVoicing ? 4 : 0);
                    pe.len = (float) std::max (1, next - s) - 0.15f;
                    pe.accent = (int8_t) (part == BBass ? 2 : -10);
                    n += resolve (track, pe, cfg, h, bar, out + n, maxOut - n);
                }
            }
            else if (part == BCounter && cfg.style == 3)
            {
                // guide tone: the 3rd or 7th closest to the last one
                const int m = tonesMask (h.chord);
                int rels[2] = { -1, -1 };
                for (int rel : { 4, 3, 5, 2 }) if ((m >> rel) & 1) { rels[0] = rel; break; }
                for (int rel : { 10, 11, 9 }) if ((m >> rel) & 1) { rels[1] = rel; break; }
                const int ref = S.last >= 0 ? S.last : 64 + 12 * cfg.octave;
                int best = -1;
                for (int rel : rels)
                {
                    if (rel < 0) continue;
                    const int cand = intoRange (nearestWithPc (ref, pcOf (h.chord.root + rel)), 55 + 12 * cfg.octave, 76 + 12 * cfg.octave);
                    if (best < 0 || std::abs (cand - ref) < std::abs (best - ref)) best = cand;
                }
                if (best >= 0 && n < maxOut)
                {
                    BandEvent& ev = out[n++];
                    ev = BandEvent();
                    ev.part = track;
                    ev.channel = cfg.channel;
                    ev.note = best;
                    ev.velocity = std::clamp ((int) ((80) * (0.45f + 0.75f * cfg.level)), 1, 127);
                    ev.length = -1.0f;
                    S.last = best;
                }
            }
        }

        // harmonies that follow the melody note for note
        if (part == BCounter && (cfg.style == 0 || cfg.style == 1 || cfg.style == 5))
        {
            if (melodyHit && melodyNote >= 0 && n < maxOut)
            {
                int note = melodyNote;
                const int mask = poolMask (h.keyRoot, h.scale) | pcMask (h.chord);
                if (cfg.style == 0) note = stepInMask (melodyNote, -2, mask);
                else if (cfg.style == 1) note = stepInMask (melodyNote, -5, mask);
                else note = melodyNote + (cfg.octave > 0 ? 12 : -12);
                if (cfg.style != 5 && cfg.octave != 0) note += 12 * cfg.octave;
                BandEvent& ev = out[n++];
                ev = BandEvent();
                ev.part = track;
                ev.channel = cfg.channel;
                ev.note = std::clamp (note, 0, 127);
                ev.velocity = std::clamp ((int) (84 * (0.45f + 0.75f * cfg.level)), 1, 127);
                ev.offset = melodyOff;
                ev.length = melodyLen;
                S.last = note;
            }
            continue;
        }

        for (int i = 0; i < S.count && n < maxOut; ++i)
            if (S.plan[(size_t) i].step == s)
                n += resolve (track, S.plan[(size_t) i], cfg, h, bar, out + n, maxOut - n);

        // swing (the SWING knob): off-beat 8ths and 16ths land later
        const float sw = bc.swing;
        if (sw > 0.0f)
            for (int i = first; i < n; ++i)
            {
                if (out[i].isCC) continue;
                if (s % 4 == 2) out[i].offset += sw * 2.0f;
                else if (s % 2 == 1) out[i].offset += sw;
            }

        if (track == melodyTrack)
            for (int i = first; i < n; ++i)
                if (! out[i].isCC && out[i].offset < 0.9f) { melodyHit = true; melodyNote = out[i].note; melodyLen = out[i].length; melodyOff = out[i].offset; }
    }
    return n;
}
} // namespace vesper
