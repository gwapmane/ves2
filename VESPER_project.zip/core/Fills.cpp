#include "Fills.h"
#include "Theory.h"
#include "Song.h"

#include <algorithm>
#include <cmath>

namespace vesper
{
namespace
{
struct R
{
    uint32_t s;
    explicit R (uint32_t seed) : s (seed * 2654435761u + 0x7f4a7c15u) { if (s == 0) s = 1; next(); next(); next(); }
    uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float uni() { return (float) (next() & 0xffffff) / 16777216.0f; }
    bool chance (float p) { return uni() < p; }
    int pick (int n) { return n <= 1 ? 0 : (int) (next() % (uint32_t) n); }
};

// GM drum notes (the same ones the band's grooves use)
enum Note { NKick = 36, NRim = 37, NSnare = 38, NClap = 39, NHat = 42, NPedal = 44, NOpen = 46, NLowTom = 45, NMidTom = 47,
            NHighTom = 50, NCrash = 49, NRide = 51, NBell = 53, NTamb = 54, NCowbell = 56, NConga = 63, NLowConga = 64 };

// the voices a rhythm cell uses; the PATH decides what "main" actually is at each moment of the fill
enum Voice { VMain = 0, VKick, VHat, VOpen, VGhost };

struct CellHit { float at; int8_t voice; int8_t acc; };
struct Cell { int n; CellHit h[12]; };

// one beat each (positions in 16ths, 0 .. 4)
enum CellId
{
    CQuarter = 0, C8ths, C16ths, C16a, C16b, C16c, CPickup, CTrip8, CTrip16, C32Roll, CHalfRoll, CDotted, CSync, CRest,
    C64Burst, CFlam, CLinear, CLinear2, CSextet, CTripKick, CDrag, CStab, numCells
};

const Cell& cell (int id)
{
    static const Cell cells[numCells] = {
        { 1, { { 0.0f, VMain, 2 } } },                                                                    // quarter
        { 2, { { 0.0f, VMain, 2 }, { 2.0f, VMain, 0 } } },                                                 // 8ths
        { 4, { { 0.0f, VMain, 2 }, { 1.0f, VMain, -1 }, { 2.0f, VMain, 1 }, { 3.0f, VMain, -1 } } },      // 16ths
        { 3, { { 0.0f, VMain, 2 }, { 1.0f, VMain, 0 }, { 2.0f, VMain, 1 } } },                            // three, then air
        { 3, { { 0.0f, VMain, 2 }, { 2.0f, VMain, 0 }, { 3.0f, VMain, 0 } } },                            // gallop
        { 3, { { 0.0f, VMain, 2 }, { 1.0f, VMain, 0 }, { 3.0f, VMain, 1 } } },                            // reverse gallop
        { 3, { { 1.0f, VMain, 0 }, { 2.0f, VMain, 1 }, { 3.0f, VMain, 1 } } },                            // pickup
        { 3, { { 0.0f, VMain, 2 }, { 4.0f / 3.0f, VMain, 0 }, { 8.0f / 3.0f, VMain, 0 } } },              // 8th triplets
        { 6, { { 0.0f, VMain, 2 }, { 2.0f / 3.0f, VMain, -1 }, { 4.0f / 3.0f, VMain, 0 },
               { 2.0f, VMain, 1 }, { 8.0f / 3.0f, VMain, -1 }, { 10.0f / 3.0f, VMain, 0 } } },             // 16th triplets
        { 8, { { 0.0f, VMain, 1 }, { 0.5f, VMain, -2 }, { 1.0f, VMain, 0 }, { 1.5f, VMain, -2 },
               { 2.0f, VMain, 1 }, { 2.5f, VMain, -2 }, { 3.0f, VMain, 0 }, { 3.5f, VMain, -1 } } },       // 32nd roll
        { 6, { { 0.0f, VMain, 2 }, { 0.5f, VMain, -2 }, { 1.0f, VMain, 0 }, { 1.5f, VMain, -2 },
               { 2.0f, VMain, 1 }, { 3.0f, VMain, 1 } } },                                                 // half roll
        { 2, { { 0.0f, VMain, 2 }, { 3.0f, VMain, 1 } } },                                                 // dotted
        { 2, { { 1.0f, VMain, 1 }, { 3.0f, VMain, 2 } } },                                                 // syncopated
        { 0, {} },                                                                                         // rest
        { 10, { { 0.0f, VMain, 1 }, { 0.25f, VMain, -3 }, { 0.5f, VMain, -2 }, { 0.75f, VMain, -2 },
                { 1.0f, VMain, 0 }, { 1.25f, VMain, -2 }, { 1.5f, VMain, -1 }, { 1.75f, VMain, -1 },
                { 2.0f, VMain, 1 }, { 3.0f, VMain, 1 } } },                                                // 64th burst
        { 3, { { -0.14f, VGhost, -3 }, { 0.0f, VMain, 2 }, { 2.0f, VMain, 1 } } },                        // flam
        { 4, { { 0.0f, VKick, 1 }, { 1.0f, VMain, 1 }, { 2.0f, VKick, 0 }, { 3.0f, VMain, 2 } } },        // linear
        { 4, { { 0.0f, VMain, 2 }, { 1.0f, VKick, 0 }, { 2.0f, VMain, 0 }, { 3.0f, VMain, 1 } } },        // linear 2
        { 6, { { 0.0f, VMain, 2 }, { 2.0f / 3.0f, VMain, -1 }, { 4.0f / 3.0f, VKick, 0 },
               { 2.0f, VMain, 1 }, { 8.0f / 3.0f, VMain, -1 }, { 10.0f / 3.0f, VKick, 0 } } },             // sextuplet chop
        { 3, { { 0.0f, VMain, 2 }, { 4.0f / 3.0f, VMain, 0 }, { 8.0f / 3.0f, VKick, 1 } } },              // triplet + kick
        { 4, { { 0.0f, VMain, 2 }, { 1.5f, VGhost, -3 }, { 1.75f, VGhost, -3 }, { 2.0f, VMain, 1 } } },   // drag
        { 2, { { 0.0f, VMain, 3 }, { 0.0f, VKick, 2 } } },                                                 // stab (unison)
    };
    return cells[std::clamp (id, 0, numCells - 1)];
}

// where the "main" voice travels during the fill
enum Path { PSnare = 0, PDown, PDownPairs, PAlternate, PUp, PToms, PSnareThenToms, PHatRoll, PClap, PRim, PPerc, PTimbale, PLowToms, PClapSnare, numPaths };

int pathNote (int path, float frac, int index, R& r)
{
    static const int down[4] = { NSnare, NHighTom, NMidTom, NLowTom };
    const int q = std::clamp ((int) (frac * 4.0f), 0, 3);
    switch (path)
    {
        case PSnare: return NSnare;
        case PDown: return down[q];
        case PDownPairs: return down[(index / 2) % 4];
        case PAlternate: return (index % 2 == 0) ? NSnare : down[std::max (1, q)];
        case PUp: return down[3 - q] == NSnare ? NHighTom : down[3 - q];
        case PToms: { static const int t[3] = { NHighTom, NMidTom, NLowTom }; return t[std::clamp ((int) (frac * 3.0f), 0, 2)]; }
        case PSnareThenToms: return frac < 0.5f ? NSnare : (frac < 0.75f ? NMidTom : NLowTom);
        case PHatRoll: return NHat;
        case PClap: return NClap;
        case PRim: return (index % 3 == 2) ? NSnare : NRim;
        case PPerc: { static const int p[4] = { NConga, NHighTom, NLowConga, NMidTom }; return p[(index + (int) (frac * 2.0f)) % 4]; }
        case PTimbale: return (index % 2 == 0) ? NHighTom : NMidTom;
        case PLowToms: return (index % 3 == 0) ? NMidTom : NLowTom;
        case PClapSnare: return (index % 2 == 0) ? NSnare : NClap;
        default: (void) r; return NSnare;
    }
}

enum Dyn { DBuild = 0, DSteady, DFall, DAccent, numDyns };
enum Ending { EndCrash = 0, EndChoke, EndOpenHat, EndUnison, EndNone, numEndings };

// a genre's way of filling
struct Vocab
{
    const int* cells; int numCells;
    const int* paths; int numPaths;
    float density = 0.5f;      // 0 sparse .. 1 busy (how often a beat gets one of the busy cells)
    float softness = 0.0f;     // 0 .. 1: quieter overall (lo-fi, neo-soul)
    float lazy = 0.0f;         // hits land this many 16ths late (behind the beat)
    bool kickUnder = false;    // kick under the fill's downbeats (rock, cinematic, gospel)
    bool hatStyle = false;     // the groove keeps going under the fill (hat rolls)
};

#define ARR(...) __VA_ARGS__
#define VOCAB(name, cellsList, pathsList) \
    static const int name##C[] = { cellsList }; static const int name##P[] = { pathsList };

VOCAB (rap,    ARR (C16ths, C32Roll, CTrip16, C64Burst, C8ths, CTrip8, CHalfRoll, CRest, CPickup), ARR (PHatRoll, PHatRoll, PHatRoll, PSnare, PClap, PClapSnare))
VOCAB (drill,  ARR (CTrip8, CTrip16, C32Roll, C64Burst, CSync, CPickup, CRest),                     ARR (PHatRoll, PHatRoll, PSnare, PRim))
VOCAB (pop,    ARR (C16ths, C16a, C16b, C16c, CPickup, C8ths, CFlam, CDotted, CSync, CLinear),       ARR (PDown, PDownPairs, PAlternate, PSnare, PSnareThenToms, PToms))
VOCAB (rock,   ARR (C16ths, C16ths, C8ths, CTrip8, C16b, C16c, CFlam, CStab, CHalfRoll),              ARR (PDown, PDownPairs, PToms, PSnareThenToms, PAlternate, PUp))
VOCAB (soul,   ARR (C16ths, CPickup, CSync, CDotted, CFlam, C16a, CTrip8, CLinear2, CDrag),           ARR (PSnare, PDown, PAlternate, PSnareThenToms, PRim))
VOCAB (gospel, ARR (C32Roll, CSextet, CTrip16, C16ths, CHalfRoll, CLinear, CTripKick, C64Burst),      ARR (PDown, PAlternate, PDownPairs, PSnare, PToms, PSnareThenToms))
VOCAB (neo,    ARR (CPickup, CSync, CDotted, CDrag, CQuarter, C16c, CTrip8, CRest),                   ARR (PRim, PSnare, PToms, PAlternate))
VOCAB (funk,   ARR (CLinear, CLinear2, C16ths, CSync, CDrag, C16c, CPickup, CStab),                   ARR (PSnare, PSnare, PAlternate, PDown, PRim))
VOCAB (house,  ARR (C16ths, C8ths, C32Roll, CQuarter, CHalfRoll),                                     ARR (PSnare, PClap, PClapSnare))
VOCAB (lofi,   ARR (CDotted, CSync, CPickup, CQuarter, CRest, CDrag, C8ths),                          ARR (PRim, PSnare, PToms))
VOCAB (latin,  ARR (C16ths, CTrip8, CLinear, C16b, C8ths, CStab, C16a),                               ARR (PTimbale, PPerc, PTimbale, PDown))
VOCAB (reggaeton, ARR (C16ths, CLinear, CTrip8, C8ths, C16b, CStab, CHalfRoll),                       ARR (PTimbale, PSnare, PClap, PToms))
VOCAB (afro,   ARR (C16ths, CTrip8, CSync, C16b, CLinear2, CPickup),                                  ARR (PPerc, PToms, PRim, PTimbale))
VOCAB (reggae, ARR (CTrip8, CDotted, CSync, CQuarter, CDrag, C8ths),                                  ARR (PRim, PToms, PLowToms, PSnare))
VOCAB (country,ARR (C16ths, C8ths, C16a, CFlam, CTrip8, CPickup),                                     ARR (PSnare, PDown, PSnareThenToms))
VOCAB (jazz,   ARR (CTrip8, CTrip16, CSync, CDotted, CDrag, CQuarter, CTripKick),                     ARR (PSnare, PToms, PAlternate, PRim))
VOCAB (blues,  ARR (CTrip8, CTrip16, C8ths, CTripKick, CFlam, CDotted),                               ARR (PDown, PSnare, PAlternate))
VOCAB (cine,   ARR (CTrip8, CTrip16, C16ths, C32Roll, CStab, CQuarter, CHalfRoll),                    ARR (PLowToms, PToms, PDown, PLowToms))

#define USE(name) name##C, (int) (sizeof (name##C) / sizeof (int)), name##P, (int) (sizeof (name##P) / sizeof (int))

Vocab vocabFor (int genre)
{
    switch (genre)
    {
        case HipHop: case Trap: { Vocab v { USE (rap) }; v.density = 0.7f; v.hatStyle = true; return v; }
        case Drill:     { Vocab v { USE (drill) }; v.density = 0.6f; v.hatStyle = true; return v; }
        case Rock:      { Vocab v { USE (rock) }; v.density = 0.7f; v.kickUnder = true; return v; }
        case Pop:       { Vocab v { USE (pop) }; v.density = 0.55f; return v; }
        case Gospel:    { Vocab v { USE (gospel) }; v.density = 0.9f; v.kickUnder = true; return v; }
        case NeoSoul:   { Vocab v { USE (neo) }; v.density = 0.35f; v.softness = 0.35f; v.lazy = 0.12f; return v; }
        case Funk:      { Vocab v { USE (funk) }; v.density = 0.65f; return v; }
        case House:     { Vocab v { USE (house) }; v.density = 0.6f; return v; }
        case LoFi:      { Vocab v { USE (lofi) }; v.density = 0.25f; v.softness = 0.5f; v.lazy = 0.15f; return v; }
        case Latin:     { Vocab v { USE (latin) }; v.density = 0.65f; return v; }
        case Reggaeton: { Vocab v { USE (reggaeton) }; v.density = 0.6f; return v; }
        case Afro:      { Vocab v { USE (afro) }; v.density = 0.55f; return v; }
        case Reggae:    { Vocab v { USE (reggae) }; v.density = 0.3f; v.softness = 0.15f; return v; }
        case Country:   { Vocab v { USE (country) }; v.density = 0.55f; return v; }
        case Jazz:      { Vocab v { USE (jazz) }; v.density = 0.5f; v.softness = 0.2f; return v; }
        case Blues:     { Vocab v { USE (blues) }; v.density = 0.5f; return v; }
        case Cinematic: { Vocab v { USE (cine) }; v.density = 0.7f; v.kickUnder = true; return v; }
        case Soul: default: { Vocab v { USE (soul) }; v.density = 0.5f; v.softness = 0.1f; return v; }
    }
}

int cellBusyness (int id) { return cell (id).n; }
} // namespace

//==============================================================================
const char* fillSizeName (int size)
{
    static const char* n[numFillSizes] = { "SMALL", "MEDIUM", "BIG", "OUT" };
    return size >= 0 && size < numFillSizes ? n[size] : "";
}

int fillSizeFor (int next, int cur, bool changing)
{
    if (cur == SecBuild && changing) return FillBig;
    if (! changing) return FillSmall;
    switch (next)
    {
        case SecHook: case SecDrop: case SecSolo: return FillBig;
        case SecBreak: case SecBridge: case SecIntro: return FillOut;
        case SecOutro: return FillMedium;
        case SecBuild: case SecVerse: case SecPre: default: return FillMedium;
    }
}

int fillBeatsFor (int size, uint32_t seed)
{
    R r (seed ^ 0xbeefu);
    switch (size)
    {
        case FillSmall: return 1;
        case FillMedium: return r.chance (0.7f) ? 2 : 1;
        case FillBig: return r.chance (0.45f) ? 4 : 2;
        case FillOut: default: return 1;
    }
}

int makeFill (int genre, int size, int beats, uint32_t seed, FillHit* out, int maxHits, FillInfo& info)
{
    info = FillInfo();
    beats = std::clamp (beats, 1, 4);
    size = std::clamp (size, 0, numFillSizes - 1);
    R r (seed * 977u + (uint32_t) genre * 131u + (uint32_t) size * 7u + (uint32_t) beats);
    const Vocab v = vocabFor (genre);

    // the shape of this one
    int path = v.paths[r.pick (v.numPaths)];
    int dyn = size == FillOut ? (r.chance (0.7f) ? DFall : DSteady) : (size == FillBig ? (r.chance (0.7f) ? DBuild : DAccent) : r.pick (numDyns));
    int ending = EndNone;
    if (size == FillBig) ending = r.chance (0.6f) ? EndCrash : (r.chance (0.5f) ? EndUnison : EndChoke);
    else if (size == FillMedium) ending = r.chance (0.5f) ? EndCrash : (r.chance (0.4f) ? EndOpenHat : EndNone);
    else if (size == FillOut) ending = r.chance (0.5f) ? EndChoke : EndNone;
    else ending = r.chance (0.25f) ? EndOpenHat : EndNone;
    const bool kickUnder = v.kickUnder ? r.chance (0.7f) : r.chance (0.15f);
    const bool ramp = size == FillBig || r.chance (0.5f);   // busier as it goes
    info.grooveKeeps = v.hatStyle && path == PHatRoll;
    info.crashAfter = ending == EndCrash || ending == EndUnison || ending == EndChoke;

    // one cell per beat; a sparse genre or a small fill leans on the lighter cells
    int chosen[4];
    for (int b = 0; b < beats; ++b)
    {
        int id = v.cells[r.pick (v.numCells)];
        // busier fills take a second look for a busier cell, sparse ones for a lighter one
        const float want = std::clamp (v.density + (size == FillBig ? 0.2f : size == FillOut ? -0.3f : 0.0f), 0.05f, 0.95f);
        const int alt = v.cells[r.pick (v.numCells)];
        if ((r.uni() < want) == (cellBusyness (alt) > cellBusyness (id))) id = alt;
        if (id == CRest && (b == beats - 1 || beats == 1) && ending != EndChoke) id = CQuarter;   // a fill never ends in silence by accident
        chosen[b] = id;
    }
    if (ramp && beats > 1) std::stable_sort (chosen, chosen + beats, [] (int a, int b) { return cellBusyness (a) < cellBusyness (b); });
    if (size == FillOut && beats == 1 && chosen[0] != CRest && r.chance (0.4f)) chosen[0] = r.chance (0.5f) ? CPickup : CSync;

    const float total = (float) beats * 4.0f;
    int n = 0, index = 0;
    auto add = [&] (float at, int note, int vel)
    {
        if (n >= maxHits) return;
        out[n].step = std::max (-0.25f, at);
        out[n].note = note;
        out[n].vel = std::clamp (vel, 1, 127);
        ++n;
    };
    const float softMul = 1.0f - 0.35f * v.softness;
    for (int b = 0; b < beats; ++b)
    {
        const Cell& c = cell (chosen[b]);
        for (int i = 0; i < c.n; ++i)
        {
            const auto& h = c.h[i];
            const float at = (float) b * 4.0f + h.at + (h.at > 0.0f ? v.lazy : 0.0f);
            const float frac = std::clamp (at / total, 0.0f, 0.999f);
            float vel = 92.0f;
            switch (dyn)
            {
                case DBuild:  vel = 56.0f + 60.0f * frac; break;
                case DSteady: vel = 98.0f; break;
                case DFall:   vel = 112.0f - 52.0f * frac; break;
                case DAccent: vel = 76.0f; break;
                default: break;
            }
            vel += (float) h.acc * (dyn == DAccent ? 9.0f : 5.0f);
            vel += (r.uni() * 2.0f - 1.0f) * 5.0f;
            vel *= softMul;
            int note = NSnare;
            switch (h.voice)
            {
                case VKick:  note = NKick; vel += 6.0f; break;
                case VHat:   note = NHat; break;
                case VOpen:  note = NOpen; break;
                case VGhost: note = path == PHatRoll ? NHat : (path == PRim ? NRim : NSnare); vel *= 0.45f; break;
                default:     note = pathNote (path, frac, index++, r); break;
            }
            if (note == NHat && path == PHatRoll) vel = std::max (36.0f, vel - 8.0f);
            add (at, note, (int) std::lround (vel));
        }
        // kick under the downbeats of the fill (and of each busy cell)
        if (kickUnder && c.n > 0 && chosen[b] != CLinear && chosen[b] != CLinear2 && chosen[b] != CSextet && chosen[b] != CTripKick)
            add ((float) b * 4.0f, NKick, (int) std::lround ((dyn == DFall ? 100.0f : 92.0f) * softMul));
    }

    // the ending
    const float last = total - 2.0f;   // the last 8th
    switch (ending)
    {
        case EndChoke:   // everything stops for the last 8th: a breath before the one
        {
            int w = 0;
            for (int i = 0; i < n; ++i) if (out[i].step < last - 0.01f) out[w++] = out[i];
            n = w;
            add (last - 0.0f, NKick, 104);
            add (last - 0.0f, NCrash, 96);
            break;
        }
        case EndOpenHat:
            add (total - 2.0f, NOpen, (int) std::lround (88.0f * softMul));
            break;
        case EndUnison:   // a kick + snare + crash stab on the last 16th, then the one
            add (total - 1.0f, NKick, 112);
            add (total - 1.0f, path == PClap ? NClap : NSnare, 112);
            break;
        default: break;
    }
    if (path == PHatRoll && size != FillSmall && r.chance (0.5f)) add (total - 1.0f, NOpen, 84);   // a hat roll opens up at the end

    std::stable_sort (out, out + n, [] (const FillHit& a, const FillHit& b) { return a.step < b.step; });
    return n;
}

uint32_t fillSignature (const FillHit* hits, int n)
{
    uint32_t h = 2166136261u;
    for (int i = 0; i < n; ++i)
    {
        const auto q = (uint32_t) std::lround (hits[i].step * 12.0f);   // 1/48ths: 32nds and triplets both land on it
        h = (h ^ (q * 131u + (uint32_t) hits[i].note)) * 16777619u;
        h = (h ^ (uint32_t) (hits[i].vel / 16)) * 16777619u;
    }
    return h ^ (uint32_t) n;
}
} // namespace vesper
