#include "Rework.h"
#include "Fills.h"
#include "Theory.h"

#include <algorithm>
#include <cmath>

namespace vesper
{
namespace
{
struct R
{
    uint32_t s;
    explicit R (uint32_t seed) : s (seed * 2654435761u + 0x51ed27u) { if (s == 0) s = 1; next(); next(); }
    uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float uni() { return (float) (next() & 0xffffff) / 16777216.0f; }
    bool chance (float p) { return uni() < p; }
    int pick (int n) { return n <= 1 ? 0 : (int) (next() % (uint32_t) n); }
};

enum Style { StTrap, StDrill, StHipHop, StHouse, StSoul, StFunk, StRock, StAfro, StLatin, StReggaeton, StReggae, StJazz, StBlues,
             StGospel, StLofi, StCinema };

Style styleOf (int genre)
{
    switch (genre)
    {
        case Trap: return StTrap;            case Drill: return StDrill;        case HipHop: return StHipHop;
        case House: return StHouse;          case Funk: return StFunk;          case Rock: case Pop: case Country: return StRock;
        case Afro: return StAfro;            case Latin: return StLatin;        case Reggaeton: return StReggaeton;
        case Reggae: return StReggae;        case Jazz: return StJazz;          case Blues: return StBlues;
        case Gospel: return StGospel;        case LoFi: return StLofi;          case Cinematic: return StCinema;
        case Soul: case NeoSoul: default: return StSoul;
    }
}

bool locked (uint16_t mask, int piece) { return ((mask >> piece) & 1u) != 0; }

struct Bar
{
    ClipNote* out;
    int n = 0, max = 0;
    void add (float start, float len, int note, int vel)
    {
        if (n >= max || start < 0.0f || start >= 16.0f) return;
        out[n].start = start;
        out[n].len = std::max (0.05f, len);
        out[n].note = note;
        out[n].vel = std::clamp (vel, 1, 127);
        ++n;
    }
    bool has (int piece, float at, float tol = 0.2f) const
    {
        for (int i = 0; i < n; ++i) if (drumPieceOf (out[i].note) == piece && std::abs (out[i].start - at) < tol) return true;
        return false;
    }
};

// where each style puts its extra kicks (16ths in the bar)
void kickSpots (Style st, int* spots, int& count)
{
    static const int trap[] = { 3, 10, 11, 14, 15, 7 }, drill[] = { 3, 6, 11, 14 }, hiphop[] = { 3, 7, 10, 11, 14 },
                     soul[] = { 7, 10, 14, 15 }, funk[] = { 3, 6, 10, 14 }, rock[] = { 7, 10, 11, 14 }, afro[] = { 3, 6, 11, 14 },
                     latin[] = { 3, 6, 11 }, jazz[] = { 6, 10, 14 }, blues[] = { 10, 14 }, lofi[] = { 7, 10, 14 };
    const int* s = nullptr;
    int c = 0;
    switch (st)
    {
        case StTrap: s = trap; c = 6; break;      case StDrill: s = drill; c = 4; break;   case StHipHop: s = hiphop; c = 5; break;
        case StSoul: case StGospel: s = soul; c = 4; break;
        case StFunk: s = funk; c = 4; break;      case StRock: s = rock; c = 4; break;     case StAfro: s = afro; c = 4; break;
        case StLatin: s = latin; c = 3; break;    case StJazz: s = jazz; c = 3; break;     case StBlues: s = blues; c = 2; break;
        case StLofi: s = lofi; c = 3; break;
        default: break;   // house four-on-the-floor, dembow, one drop, cinematic: the kick stays as it is
    }
    count = c;
    for (int i = 0; i < c; ++i) spots[i] = s[i];
}

bool ghostStyle (Style st)
{
    return st == StHipHop || st == StSoul || st == StFunk || st == StRock || st == StGospel || st == StLofi || st == StJazz || st == StBlues;
}

// a new hat bar in the style, about as busy as the one you wrote
void hatPattern (Style st, int writtenHats, float amount, R& r, Bar& b, int velBase)
{
    auto hat = [&] (float at, int vel, int note = 42) { b.add (at, 0.5f, note, vel); };
    const bool busy = writtenHats >= 10;
    switch (st)
    {
        case StTrap:
        {
            for (int s = 0; s < 16; s += 2) hat ((float) s, velBase + (s % 4 == 0 ? 10 : 0));
            // rolls: 16th triplets or 32nds on one or two beats
            const int rolls = 1 + (r.chance (amount * 0.6f) ? 1 : 0);
            for (int k = 0; k < rolls; ++k)
            {
                const int beat = r.pick (4);
                const bool trip = r.chance (0.5f);
                const float start = (float) (beat * 4 + 2);
                for (int i = 0; i < (trip ? 3 : 4); ++i) hat (start + (trip ? (float) i * 2.0f / 3.0f : (float) i * 0.5f), velBase - 12 + i * 6);
            }
            break;
        }
        case StDrill:
        {
            static const float skip[] = { 0.0f, 1.333f, 2.667f, 4.0f, 6.0f, 7.333f, 8.0f, 9.333f, 10.667f, 12.0f, 14.0f, 15.333f };
            for (float s : skip) if (r.chance (0.85f)) hat (s, velBase + (std::fmod (s, 4.0f) < 0.01f ? 8 : -6));
            break;
        }
        case StHouse:
            for (int s = 0; s < 16; ++s) if (busy || s % 2 == 0) hat ((float) s, velBase - 20 + (s % 4 == 2 ? 12 : 0));
            for (int s = 2; s < 16; s += 4) hat ((float) s, velBase + 4, 46);   // the offbeat open hat
            break;
        case StJazz:   // the ride: ding, ding-ga ding, ding-ga, with the hat foot on 2 and 4
        {
            static const float ride[] = { 0.0f, 4.0f, 6.667f, 8.0f, 12.0f, 14.667f };
            for (float s : ride) b.add (s, 1.0f, 51, velBase - (std::fmod (s, 4.0f) > 0.01f ? 18 : 0));
            b.add (4.0f, 0.5f, 44, velBase - 20);
            b.add (12.0f, 0.5f, 44, velBase - 20);
            break;
        }
        case StAfro:   // shaker-style 16ths with the 3-3-2 lift
            for (int s = 0; s < 16; ++s)
            {
                const bool accent = s == 0 || s == 3 || s == 6 || s == 8 || s == 11 || s == 14;
                hat ((float) s, velBase - (accent ? 0 : 22));
            }
            break;
        case StReggae:
            for (int s = 0; s < 16; s += 2) hat ((float) s, velBase - (s % 4 == 2 ? 0 : 18));
            break;
        case StCinema:
            break;
        case StLatin: case StReggaeton:
            for (int s = 0; s < 16; ++s) if (busy || s % 2 == 0) hat ((float) s, velBase - (s % 4 == 2 ? 0 : 16));
            break;
        case StHipHop: case StLofi:   // swung 8ths (16ths when you wrote them busy), pushed a little behind
            for (int s = 0; s < 16; s += busy ? 1 : 2)
            {
                const float swing = (s % 4 == 2) ? 0.18f : (s % 2 == 1 ? 0.1f : 0.0f);
                if (s % 2 == 1 && r.chance (0.35f)) continue;   // breathing room
                hat ((float) s + swing, velBase - (s % 4 == 0 ? 0 : (s % 2 == 0 ? 10 : 24)));
            }
            break;
        case StFunk:
            for (int s = 0; s < 16; ++s) hat ((float) s, velBase - (s % 4 == 1 || s % 4 == 3 ? 6 : 16) + (s % 4 == 0 ? 8 : 0));
            break;
        case StRock:
            for (int s = 0; s < 16; s += busy ? 1 : 2) hat ((float) s, velBase - (s % 4 == 0 ? 0 : 14));
            break;
        case StSoul: case StGospel: case StBlues: default:
            for (int s = 0; s < 16; s += busy ? 1 : 2)
            {
                if (r.chance (0.12f * amount) && s % 4 != 0) continue;   // a lift
                hat ((float) s, velBase - (s % 4 == 0 ? 0 : (s % 2 == 0 ? 12 : 26)));
            }
            break;
    }
}
} // namespace

int reworkDrumBar (const ClipNote* in, int numIn, int genre, float amount, uint16_t lockMask, uint32_t seed, bool phraseEnd,
                   ClipNote* out, int maxOut)
{
    amount = std::clamp (amount, 0.0f, 1.0f);
    Bar b;
    b.out = out;
    b.max = maxOut;
    if (amount < 0.005f)
    {
        for (int i = 0; i < numIn; ++i) b.add (in[i].start, in[i].len, in[i].note, in[i].vel);
        return b.n;
    }
    R r (seed);
    const Style st = styleOf (genre);

    // what you wrote, piece by piece
    int writtenHats = 0, hatVelSum = 0, kicks = 0;
    for (int i = 0; i < numIn; ++i)
    {
        const int pc = drumPieceOf (in[i].note);
        if (pc == PieceHats) { ++writtenHats; hatVelSum += in[i].vel; }
        if (pc == PieceKick) ++kicks;
    }
    const int hatVel = writtenHats > 0 ? hatVelSum / writtenHats : 84;
    auto isBackbeat = [] (float at) { const float q = std::fmod (at, 16.0f); return std::abs (q - 4.0f) < 0.3f || std::abs (q - 12.0f) < 0.3f || std::abs (q - 8.0f) < 0.3f; };
    auto onBeat = [] (float at) { return std::abs (at - std::round (at / 4.0f) * 4.0f) < 0.3f; };

    // ---- the bones and the locked pieces, as written
    const bool rewriteHats = ! locked (lockMask, PieceHats) && writtenHats > 0 && amount >= 0.45f && st != StCinema;
    for (int i = 0; i < numIn; ++i)
    {
        const auto& c = in[i];
        const int pc = drumPieceOf (c.note);
        if (locked (lockMask, pc)) { b.add (c.start, c.len, c.note, c.vel); continue; }
        switch (pc)
        {
            case PieceKick:
            {
                // the one, and every kick on a beat, stays; the others may lean a 16th (never in house / dembow / one drop)
                const bool core = c.start < 0.3f || onBeat (c.start) || c.vel >= 100;
                const bool movable = st != StHouse && st != StReggaeton && st != StReggae && st != StCinema;
                if (! core && movable && r.chance (amount * 0.15f)) break;   // dropped
                float at = c.start;
                if (! core && movable && r.chance (amount * 0.35f))
                {
                    const float to = at + (r.chance (0.5f) ? 1.0f : -1.0f);
                    if (to > 0.5f && to < 16.0f && ! isBackbeat (to)) at = to;
                }
                b.add (at, c.len, c.note, c.vel);
                break;
            }
            case PieceSnare: case PieceClap:
            {
                // the backbeat never moves; a snare off the backbeat may lean a 16th
                float at = c.start;
                if (! isBackbeat (c.start) && c.vel >= 60 && r.chance (amount * 0.25f))
                {
                    const float to = at + (r.chance (0.5f) ? 1.0f : -1.0f);
                    if (to > 0.0f && to < 16.0f) at = to;
                }
                b.add (at, c.len, c.note, c.vel);
                break;
            }
            case PieceHats:
                if (rewriteHats) break;   // a new hat bar below
                {   // lighter rework: the same hats, a new touch (accents, a dropped or added 16th)
                    if (! onBeat (c.start) && r.chance (amount * 0.2f)) break;
                    const int accent = onBeat (c.start) ? 8 : (std::fmod (c.start, 2.0f) < 0.1f ? 0 : -14);
                    b.add (c.start, c.len, c.note, (int) std::lround ((float) c.vel * (1.0f - amount * 0.3f) + (float) (accent + 80) * amount * 0.3f));
                }
                break;
            default:
                b.add (c.start, c.len, c.note, c.vel);
                break;
        }
    }

    // ---- new details
    // hats: a new pattern in the style (about as busy as yours), or a roll / extra 16th on the light setting
    if (rewriteHats)
        hatPattern (st, writtenHats, amount, r, b, std::clamp (hatVel, 60, 104));
    else if (! locked (lockMask, PieceHats) && writtenHats > 0 && (st == StTrap || st == StDrill) && r.chance (amount * 0.8f))
    {
        const int beat = r.pick (4);
        for (int i = 0; i < 3; ++i) b.add ((float) (beat * 4 + 2) + (float) i * 2.0f / 3.0f, 0.4f, 42, hatVel - 10 + i * 5);
    }
    // an open hat on the "and" of 4 at the end of a phrase
    if (! locked (lockMask, PieceOpenHat) && writtenHats > 0 && st != StJazz && st != StCinema && (phraseEnd ? r.chance (amount * 0.6f) : r.chance (amount * 0.15f)))
        if (! b.has (PieceOpenHat, 14.0f)) b.add (14.0f, 1.0f, 46, std::clamp (hatVel + 6, 1, 127));
    // ghost notes around the backbeat
    if (! locked (lockMask, PieceSnare) && ghostStyle (st))
    {
        static const int spots[] = { 3, 7, 10, 11, 15, 6, 13, 9 };
        const int count = (int) std::lround (amount * (st == StGospel || st == StFunk ? 4.0f : 2.5f) * r.uni() + amount);
        for (int k = 0; k < count; ++k)
        {
            const float at = (float) spots[r.pick (8)];
            if (! b.has (PieceSnare, at, 0.6f)) b.add (at, 0.4f, 38, 24 + r.pick (18));
        }
    }
    else if (! locked (lockMask, PieceSnare) && (st == StTrap || st == StDrill) && r.chance (amount * 0.3f))
        b.add (st == StDrill ? 7.0f : 15.0f, 0.4f, 37, 52);   // a rim pickup
    // kicks where the style puts them
    if (! locked (lockMask, PieceKick) && kicks > 0)
    {
        int spots[8], count = 0;
        kickSpots (st, spots, count);
        const int adds = count > 0 ? (r.chance (amount * 0.6f) ? 1 : 0) + (r.chance (amount * 0.25f) ? 1 : 0) : 0;
        for (int k = 0; k < adds; ++k)
        {
            const float at = (float) spots[r.pick (count)];
            if (! b.has (PieceKick, at, 0.6f) && ! isBackbeat (at)) b.add (at, 0.5f, 36, st == StJazz ? 56 : 88 + r.pick (16));
        }
        if (st == StTrap && r.chance (amount * 0.3f))   // an 808 double
            if (! b.has (PieceKick, 10.5f, 0.3f)) b.add (10.5f, 0.4f, 36, 84);
    }
    // a fill at the end of the phrase
    if (phraseEnd && r.chance (amount * 0.75f))
    {
        FillHit fh[maxFillHits];
        FillInfo info;
        const int beats = amount > 0.8f && r.chance (0.5f) ? 2 : 1;
        const int fn = makeFill (genre, amount > 0.7f ? FillMedium : FillSmall, beats, r.next(), fh, maxFillHits, info);
        const float from = 16.0f - 4.0f * (float) beats;
        // the fill has the kit for its beats: unlocked snare / toms / hats there step aside
        if (! info.grooveKeeps)
        {
            int w = 0;
            for (int i = 0; i < b.n; ++i)
            {
                const int pc = drumPieceOf (b.out[i].note);
                const bool clears = (pc == PieceSnare || pc == PieceTom || pc == PieceHats || pc == PieceClap) && ! locked (lockMask, pc);
                if (! (clears && b.out[i].start >= from - 0.05f)) b.out[w++] = b.out[i];
            }
            b.n = w;
        }
        for (int i = 0; i < fn; ++i)
        {
            const int pc = drumPieceOf (fh[i].note);
            if (locked (lockMask, pc) || pc == PieceCymbal) continue;
            b.add (from + fh[i].step, 0.4f, fh[i].note, fh[i].vel);
        }
    }
    // a touch of human in the velocities
    for (int i = 0; i < b.n; ++i)
        if (! locked (lockMask, drumPieceOf (b.out[i].note)))
            b.out[i].vel = std::clamp (b.out[i].vel + (int) std::lround ((r.uni() * 2.0f - 1.0f) * 7.0f * amount), 1, 127);

    std::stable_sort (b.out, b.out + b.n, [] (const ClipNote& x, const ClipNote& y) { return x.start < y.start; });
    return b.n;
}
} // namespace vesper
