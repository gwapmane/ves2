// REWORK: your own drum MIDI, played like a drummer of the genre would play it. The bones stay (the kick on the one
// and the backbeat snare never move); the rest gets that genre's details - hat patterns (trap rolls, drill skips,
// house offbeats, a ride pattern in jazz...), ghost notes, a kick pushed or added where that style puts them, a fill
// at the end of the phrase. AMOUNT 0 = exactly as written, 1 = same bones, new details. Locked pieces are never touched.
// Plain C++ (no JUCE), so the self-test can check it.
#pragma once

#include "Clips.h"
#include "Grooves.h"

#include <cstdint>

namespace vesper
{
// One bar of your drums (notes with start 0 .. 16, in 16ths) -> the reworked bar (sorted by start). lockMask has a bit per
// DrumPiece (Grooves.h): those pieces play exactly as written. phraseEnd = the last bar of a phrase (a fill can go there).
// Returns how many notes it wrote.
int reworkDrumBar (const ClipNote* in, int numIn, int genre, float amount, uint16_t lockMask, uint32_t seed, bool phraseEnd,
                   ClipNote* out, int maxOut);
} // namespace vesper
