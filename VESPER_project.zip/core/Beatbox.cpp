#include "Beatbox.h"
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdio>
#include <numeric>

namespace vesper
{
namespace
{
constexpr double pi = 3.14159265358979323846;

void fft (std::vector<std::complex<float>>& a)
{
    const size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; ++i)
    {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap (a[i], a[j]);
    }
    static thread_local std::vector<std::complex<float>> tw;   // the twiddles for this size, worked out once
    if (tw.size() != n / 2)
    {
        tw.resize (n / 2);
        for (size_t j = 0; j < n / 2; ++j) tw[j] = { (float) std::cos (-2.0 * pi * (double) j / (double) n), (float) std::sin (-2.0 * pi * (double) j / (double) n) };
    }
    for (size_t len = 2; len <= n; len <<= 1)
    {
        const size_t stride = n / len;
        for (size_t i = 0; i < n; i += len)
            for (size_t j = 0; j < len / 2; ++j)
            {
                const auto u = a[i + j], v = a[i + j + len / 2] * tw[j * stride];
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
            }
    }
}

std::vector<float> hann (int n)
{
    std::vector<float> w ((size_t) n);
    for (int i = 0; i < n; ++i) w[(size_t) i] = (float) (0.5 - 0.5 * std::cos (2.0 * pi * i / (n - 1)));
    return w;
}

// RMS of x[from, from + len)
float rms (const std::vector<float>& x, int from, int len)
{
    double s = 0;
    int n = 0;
    for (int i = std::max (0, from); i < std::min ((int) x.size(), from + len); ++i, ++n) s += (double) x[(size_t) i] * x[(size_t) i];
    return n > 0 ? (float) std::sqrt (s / n) : 0.0f;
}

// 1. where the hits are: spectral flux (how much new energy arrives, across the spectrum), peak-picked
std::vector<int> findOnsets (const std::vector<float>& x, double sr)
{
    const int N = sr > 70000 ? 2048 : 1024, H = N / 4;
    const int numFrames = (int) x.size() < N ? 0 : ((int) x.size() - N) / H + 1;
    std::vector<int> out;
    if (numFrames < 3) return out;
    const auto w = hann (N);
    const int kLo = std::max (1, (int) (30.0 * N / sr)), kHi = std::min (N / 2, (int) (16000.0 * N / sr));
    std::vector<float> prev ((size_t) (N / 2 + 1), 0.0f), flux ((size_t) numFrames, 0.0f), energy ((size_t) numFrames, 0.0f),
                       bright ((size_t) numFrames, 0.0f);   // the energy over 2 kHz
    const int k2k = (int) (2000.0 * N / sr);
    std::vector<std::complex<float>> buf ((size_t) N);
    for (int f = 0; f < numFrames; ++f)
    {
        double e = 0;
        for (int i = 0; i < N; ++i)
        {
            const float s = x[(size_t) (f * H + i)];
            e += (double) s * s;
            buf[(size_t) i] = { s * w[(size_t) i], 0.0f };
        }
        energy[(size_t) f] = (float) (e / N);
        fft (buf);
        float fl = 0, br = 0;
        for (int k = kLo; k <= kHi; ++k)
        {
            const float mag = std::abs (buf[(size_t) k]);
            const float lm = std::log1p (10.0f * mag);
            if (f > 0) fl += std::max (0.0f, lm - prev[(size_t) k]);
            prev[(size_t) k] = lm;
            if (k >= k2k) br += mag * mag;
        }
        flux[(size_t) f] = fl;
        bright[(size_t) f] = br;
    }
    const float maxFlux = *std::max_element (flux.begin(), flux.end());
    const float maxE = *std::max_element (energy.begin(), energy.end());
    if (maxFlux <= 0 || maxE <= 0) return out;
    const int minGap = std::max (1, (int) (0.055 * sr / H));
    int lastFrame = -1000000;
    float lastVal = 0;
    for (int f = 1; f < numFrames - 1; ++f)
    {
        const float v = flux[(size_t) f] / maxFlux;
        if (v < 0.07f) continue;
        bool peak = true;
        for (int d = -3; d <= 3 && peak; ++d)
            if (d != 0 && f + d >= 0 && f + d < numFrames && flux[(size_t) (f + d)] > flux[(size_t) f]) peak = false;
        if (! peak) continue;
        double mean = 0;
        int n = 0;
        for (int d = -12; d <= 12; ++d) if (f + d >= 0 && f + d < numFrames) { mean += flux[(size_t) (f + d)] / maxFlux; ++n; }
        mean /= std::max (1, n);
        if (v < 1.25 * mean + 0.04) continue;
        const float eNext = std::max (energy[(size_t) f], energy[(size_t) std::min (numFrames - 1, f + 1)]);
        if (10.0f * std::log10 (eNext / maxE + 1e-12f) < -42.0f) continue;   // too quiet: a breath, the room
        {   // a new hit makes it louder (or brighter) than just before it; a hit dying away (a kick's tail) doesn't
            const int fb = std::max (0, f - 4);
            float eNow = 0, bNow = 0;
            for (int d = 0; d <= 2 && f + d < numFrames; ++d) { eNow = std::max (eNow, energy[(size_t) (f + d)]); bNow = std::max (bNow, bright[(size_t) (f + d)]); }
            if (eNow < 1.6f * energy[(size_t) fb] && bNow < 3.0f * bright[(size_t) fb] + 1e-9f) continue;
        }
        if (f - lastFrame < minGap)
        {   // two peaks on one hit: keep the bigger
            if (v > lastVal) { out.back() = f * H + N / 2; lastFrame = f; lastVal = v; }
            continue;
        }
        out.push_back (f * H + N / 2);
        lastFrame = f;
        lastVal = v;
    }
    // 2. the exact start: the first millisecond, going back from the loudest one, that's 20% of it
    const int blk = std::max (16, (int) (sr * 0.001));
    for (auto& s : out)
    {
        const int from = std::max (0, s - N / 2 - N / 4), to = std::min ((int) x.size() - blk, s + N / 2);
        int best = from;
        float bestR = 0;
        for (int i = from; i <= to; i += blk) { const float r = rms (x, i, blk); if (r > bestR) { bestR = r; best = i; } }
        int start = best;
        while (start - blk >= from && rms (x, start - blk, blk) > 0.2f * bestR) start -= blk;
        s = start;
    }
    std::sort (out.begin(), out.end());
    out.erase (std::unique (out.begin(), out.end(), [blk] (int a, int b) { return std::abs (a - b) < 2 * blk; }), out.end());
    return out;
}

// 3. what each hit sounds like
BeatboxHit describe (const std::vector<float>& x, double sr, int start, int next)
{
    BeatboxHit h;
    h.time = start / sr;
    const int maxLen = (int) (0.05 * sr), minLen = (int) (0.015 * sr);
    const int len = std::max (minLen, std::min (maxLen, next - start - (int) (0.005 * sr)));
    int N = 1;
    while (N < len) N <<= 1;
    N = std::max (N, 1024);
    std::vector<std::complex<float>> buf ((size_t) N);
    const auto w = hann (len);
    for (int i = 0; i < len; ++i)
    {
        const int j = start + i;
        buf[(size_t) i] = { j < (int) x.size() ? x[(size_t) j] * w[(size_t) i] : 0.0f, 0.0f };
    }
    fft (buf);
    double total = 0, lo = 0, hi = 0, cen = 0;
    for (int k = 1; k < N / 2; ++k)
    {
        const double f = k * sr / N;
        if (f < 20.0 || f > 16000.0) continue;
        const double p = std::norm (buf[(size_t) k]);
        total += p;
        cen += f * p;
        if (f < 180.0) lo += p;
        if (f > 3500.0) hi += p;
    }
    if (total > 0) { h.centroid = (float) (cen / total); h.low = (float) (lo / total); h.high = (float) (hi / total); }
    // loudness and decay, in 5 ms steps
    const int blk = std::max (32, (int) (0.005 * sr));
    float peak = 0;
    int peakAt = start;
    for (int i = start; i < start + (int) (0.04 * sr); i += blk) { const float r = rms (x, i, blk); if (r > peak) { peak = r; peakAt = i; } }
    h.strength = peak;
    const int stop = std::min ({ (int) x.size(), next, start + (int) (0.5 * sr) });
    int end = peakAt;
    while (end + blk < stop && rms (x, end, blk) > 0.1f * peak) end += blk;
    h.decay = (float) ((end - start) / sr);
    return h;
}

// 4. which of your sounds is which: group them by brightness (log centroid), then name the groups
int absoluteKind (float centroid, float low)
{
    if (low > 0.3f || centroid < 1000.0f) return BbKick;
    if (centroid > 4000.0f && low < 0.15f) return BbHat;
    return BbSnare;
}

void classify (std::vector<BeatboxHit>& hits)
{
    const int n = (int) hits.size();
    if (n == 0) return;
    std::vector<double> lc ((size_t) n);
    for (int i = 0; i < n; ++i) lc[(size_t) i] = std::log2 (std::max (50.0f, hits[(size_t) i].centroid));
    std::vector<int> group ((size_t) n, 0);
    std::vector<double> centers;
    if (n >= 4)
    {
        // start the three groups at the darkest sound, the brightest, and the one furthest from both (so two snares
        // among a lot of kicks still get their own group)
        const double lo = *std::min_element (lc.begin(), lc.end()), hi = *std::max_element (lc.begin(), lc.end());
        double mid = 0.5 * (lo + hi), far = -1;
        for (double v : lc) { const double d = std::min (v - lo, hi - v); if (d > far) { far = d; mid = v; } }
        centers = { lo, mid, hi };
        for (int it = 0; it < 30; ++it)
        {
            for (int i = 0; i < n; ++i)
            {
                int b = 0;
                for (int c = 1; c < (int) centers.size(); ++c)
                    if (std::abs (lc[(size_t) i] - centers[(size_t) c]) < std::abs (lc[(size_t) i] - centers[(size_t) b])) b = c;
                group[(size_t) i] = b;
            }
            for (int c = 0; c < (int) centers.size(); ++c)
            {
                double s = 0;
                int m = 0;
                for (int i = 0; i < n; ++i) if (group[(size_t) i] == c) { s += lc[(size_t) i]; ++m; }
                if (m > 0) centers[(size_t) c] = s / m;
            }
        }
        // empty groups out, then groups closer than about half an octave are one sound
        std::vector<std::pair<double, std::vector<int>>> gs;
        for (int c = 0; c < (int) centers.size(); ++c)
        {
            std::vector<int> mem;
            for (int i = 0; i < n; ++i) if (group[(size_t) i] == c) mem.push_back (i);
            if (! mem.empty()) gs.push_back ({ centers[(size_t) c], mem });
        }
        std::sort (gs.begin(), gs.end(), [] (const auto& a, const auto& b) { return a.first < b.first; });
        for (size_t g = 1; g < gs.size();)
        {
            if (gs[g].first - gs[g - 1].first < 0.55)
            {
                auto& a = gs[g - 1];
                const double na = (double) a.second.size(), nb = (double) gs[g].second.size();
                a.first = (a.first * na + gs[g].first * nb) / (na + nb);
                a.second.insert (a.second.end(), gs[g].second.begin(), gs[g].second.end());
                gs.erase (gs.begin() + (long) g);
            }
            else ++g;
        }
        // name them: in order (low = kick, middle = snare, bright = hat), unless a group plainly says otherwise
        std::vector<int> label (gs.size());
        for (size_t g = 0; g < gs.size(); ++g)
        {
            double low = 0;
            for (int i : gs[g].second) low += hits[(size_t) i].low;
            low /= (double) gs[g].second.size();
            const int abs = absoluteKind ((float) std::exp2 (gs[g].first), (float) low);
            int ord = abs;
            if (gs.size() == 3) ord = (int) g;
            else if (gs.size() == 2) ord = g == 0 ? (abs == BbHat ? BbSnare : abs) : std::max (abs, label[0] + 1);
            label[g] = std::abs (ord - abs) >= 2 ? abs : ord;
        }
        for (size_t g = 0; g < gs.size(); ++g)
            for (int i : gs[g].second) hits[(size_t) i].kind = gs.size() == 1 ? absoluteKind (hits[(size_t) i].centroid, hits[(size_t) i].low) : label[g];
    }
    else
        for (auto& h : hits) h.kind = absoluteKind (h.centroid, h.low);
    for (size_t i = 0; i < hits.size(); ++i)
    {
        auto& h = hits[i];
        if (h.low > 0.5f) h.kind = BbKick;   // a big low thump is a kick, whatever else is around
        const double gap = i + 1 < hits.size() ? hits[i + 1].time - h.time : 1.0;
        if (h.kind == BbHat && h.decay > 0.11f && gap > 0.15) h.kind = BbOpenHat;
    }
}

// 5. the tempo you beatboxed at: the onsets' autocorrelation, liking a beat and a bar, around 100 BPM
double estimateBpm (const std::vector<BeatboxHit>& hits)
{
    if (hits.size() < 3) return 0;
    const double rate = 200.0;   // 5 ms bins
    const int len = (int) (hits.back().time * rate) + 400;
    std::vector<double> o ((size_t) len, 0.0);
    for (const auto& h : hits)
    {
        const int c = (int) std::lround (h.time * rate);
        for (int d = -4; d <= 4; ++d)
            if (c + d >= 0 && c + d < len) o[(size_t) (c + d)] += std::sqrt (h.strength) * std::exp (-0.5 * d * d / 4.0);
    }
    const int maxLag = std::min (len - 1, (int) (4.2 * rate));
    std::vector<double> r ((size_t) maxLag + 1, 0.0);
    for (int lag = 1; lag <= maxLag; ++lag)
    {
        double s = 0;
        for (int i = 0; i + lag < len; ++i) s += o[(size_t) i] * o[(size_t) (i + lag)];
        r[(size_t) lag] = s;
    }
    auto at = [&] (double lag)
    {
        if (lag < 1 || lag >= maxLag) return 0.0;
        const int i = (int) lag;
        const double f = lag - i;
        return r[(size_t) i] * (1 - f) + r[(size_t) (i + 1)] * f;
    };
    double best = 0, bestScore = -1;
    for (double bpm = 60; bpm <= 200; bpm += 0.25)
    {
        const double beat = 60.0 / bpm * rate;
        const double score = (at (beat) + 0.6 * at (2 * beat) + 0.4 * at (4 * beat) + 0.3 * at (beat / 2))
                             * std::exp (-0.5 * std::pow (std::log2 (bpm / 100.0) / 0.9, 2.0));
        if (score > bestScore) { bestScore = score; best = bpm; }
    }
    return best;
}

// 6. onto the grid: a slow phase-lock follows you if you drift; returns the mean miss (in 16ths)
double quantize (std::vector<BeatboxHit>& hits, int anchor, double bpm, bool followTempo)
{
    double step = 60.0 / bpm / 4.0, t0 = hits[(size_t) anchor].time, miss = 0;
    long lastK = 0;
    for (size_t i = (size_t) anchor; i < hits.size(); ++i)
    {
        const double t = hits[i].time;
        long k = std::lround ((t - t0) / step);
        if (k < lastK) k = lastK;
        const double err = t - (t0 + (double) k * step);
        miss += std::abs (err) / step;
        t0 += 0.3 * err;
        if (followTempo && k > 0) step += 0.08 * err / (double) k;
        hits[i].slot = (int) k;
        lastK = k;
    }
    const double step0 = 60.0 / bpm / 4.0;
    for (int i = 0; i < anchor; ++i)
        hits[(size_t) i].slot = (int) std::lround ((hits[(size_t) i].time - hits[(size_t) anchor].time) / step0);   // a pickup: negative
    return miss / (double) std::max<size_t> (1, hits.size() - (size_t) anchor);
}
}

const char* beatboxKindName (int kind)
{
    static const char* n[] = { "KICK", "SNARE", "HAT", "OPEN HAT" };
    return n[std::clamp (kind, 0, numBeatboxKinds - 1)];
}

int beatboxKindNote (int kind)
{
    static const int n[] = { 36, 38, 42, 46 };
    return n[std::clamp (kind, 0, numBeatboxKinds - 1)];
}

BeatboxResult beatboxToDrums (const std::vector<float>& monoIn, double sr, double songBpm)
{
    BeatboxResult res;
    if (sr < 8000 || monoIn.size() < (size_t) (sr * 0.2)) { res.summary = "the recording is too short"; return res; }
    // the level doesn't matter: the loudest moment is 1, and any DC offset is gone
    std::vector<float> x (monoIn.begin(), monoIn.begin() + (long) std::min (monoIn.size(), (size_t) (sr * 64.0)));
    const double dc = std::accumulate (x.begin(), x.end(), 0.0) / (double) x.size();
    float peak = 0;
    for (auto& s : x) { s = (float) (s - dc); peak = std::max (peak, std::abs (s)); }
    if (peak < 1e-5f) { res.summary = "the recording is silent"; return res; }
    for (auto& s : x) s /= peak;

    const auto onsets = findOnsets (x, sr);
    std::vector<BeatboxHit> hits;
    for (size_t i = 0; i < onsets.size(); ++i)
        hits.push_back (describe (x, sr, onsets[i], i + 1 < onsets.size() ? onsets[i + 1] : (int) x.size()));
    float maxS = 0;
    for (const auto& h : hits) maxS = std::max (maxS, h.strength);
    hits.erase (std::remove_if (hits.begin(), hits.end(), [maxS] (const BeatboxHit& h) { return h.strength < 0.08f * maxS; }), hits.end());
    if (hits.size() < 2) { res.summary = "it couldn't hear enough hits"; return res; }
    for (auto& h : hits) h.strength /= maxS;
    classify (hits);

    // the tempo: the song's, when you were with it (or with half / double it), otherwise yours
    int anchor = 0;
    for (size_t i = 0; i < hits.size(); ++i) if (hits[i].kind == BbKick) { anchor = (int) i; break; }
    res.heardBpm = estimateBpm (hits);
    double bpm = 0;
    if (songBpm >= 40 && songBpm <= 300)
    {
        double bestMiss = 1e9, bestBpm = 0;
        for (double m : { 1.0, 0.5, 2.0 })
        {
            auto copy = hits;
            const double miss = quantize (copy, anchor, songBpm * m, false) + (m == 1.0 ? 0.0 : 0.03);
            if (miss < bestMiss) { bestMiss = miss; bestBpm = songBpm * m; }
        }
        if (bestMiss < 0.2 || (res.heardBpm > 0 && std::abs (res.heardBpm / bestBpm - 1.0) < 0.12)) { bpm = songBpm; res.songTempo = true; }
        if (res.songTempo && bestBpm != songBpm)
            bpm = bestBpm;   // you were at half (or double) the song: the grid follows you, the beat plays at the song's tempo
    }
    if (bpm <= 0) bpm = res.heardBpm > 0 ? res.heardBpm : (songBpm > 0 ? songBpm : 90.0);
    quantize (hits, anchor, bpm, ! res.songTempo);
    const double scale = res.songTempo ? songBpm / bpm : 1.0;   // half-time take -> 16ths of the song: double the slots
    if (scale != 1.0) for (auto& h : hits) h.slot = (int) std::lround (h.slot * scale);
    res.bpm = res.songTempo ? songBpm : bpm;

    // how long: whole bars (1, 2, 4 or 8). A lone hit on the next bar's one is you ending the take, not a new bar
    int maxSlot = 0;
    for (const auto& h : hits) maxSlot = std::max (maxSlot, h.slot);
    int bars = maxSlot / 16 + 1;
    if (bars > 1)
    {
        int inLast = 0;
        bool onlyOne = true;
        for (const auto& h : hits)
            if (h.slot >= (bars - 1) * 16) { ++inLast; if (h.slot > (bars - 1) * 16 + 1) onlyOne = false; }
        if (onlyOne && inLast <= 2)
        {
            hits.erase (std::remove_if (hits.begin(), hits.end(), [bars] (const BeatboxHit& h) { return h.slot >= (bars - 1) * 16; }), hits.end());
            --bars;
        }
    }
    int loopBars = 1;
    while (loopBars < bars && loopBars < 8) loopBars *= 2;
    const int loopSlots = loopBars * 16;
    for (auto& h : hits) if (h.slot < 0) h.slot = ((h.slot % loopSlots) + loopSlots) % loopSlots;   // the pickup goes round
    hits.erase (std::remove_if (hits.begin(), hits.end(), [loopSlots] (const BeatboxHit& h) { return h.slot >= loopSlots; }), hits.end());

    // beat 1: if the kicks and snares sit better turned round (you started on a pickup), turn the loop round
    int bestRot = 0;
    double bestScore = -1e9;
    for (int rot = 0; rot < 16; ++rot)
    {
        double s = rot == 0 ? 0.5 : 0.0;
        for (const auto& h : hits)
        {
            const int sl = ((h.slot - rot) % 16 + 16) % 16;
            if (h.kind == BbKick) s += sl == 0 ? 3.0 : (sl == 8 ? 1.0 : 0.0);
            if (h.kind == BbSnare) s += (sl == 4 || sl == 12) ? 3.0 : 0.0;
            if (h.kind == BbHat) s += sl % 2 == 0 ? 0.3 : 0.0;
        }
        if (s > bestScore + 1e-9) { bestScore = s; bestRot = rot; }
    }
    if (bestRot != 0) for (auto& h : hits) h.slot = ((h.slot - bestRot) % loopSlots + loopSlots) % loopSlots;

    // the notes: one per sound per 16th (the stronger one), louder hits louder, each sound against its own loudest
    float maxKind[numBeatboxKinds] {};
    for (const auto& h : hits) maxKind[h.kind] = std::max (maxKind[h.kind], h.strength);
    std::sort (hits.begin(), hits.end(), [] (const BeatboxHit& a, const BeatboxHit& b) { return a.time < b.time; });
    std::vector<int> taken ((size_t) (loopSlots * numBeatboxKinds), -1);
    for (size_t i = 0; i < hits.size(); ++i)
    {
        auto& t = taken[(size_t) (hits[i].slot * numBeatboxKinds + hits[i].kind)];
        if (t < 0 || hits[(size_t) t].strength < hits[i].strength) t = (int) i;
    }
    for (int s = 0; s < loopSlots; ++s)
        for (int k = 0; k < numBeatboxKinds; ++k)
        {
            const int i = taken[(size_t) (s * numBeatboxKinds + k)];
            if (i < 0) continue;
            const auto& h = hits[(size_t) i];
            ClipNote cn;
            cn.start = (float) s;
            cn.len = k == BbOpenHat ? 2.0f : 1.0f;
            cn.note = beatboxKindNote (k);
            const float rel = maxKind[k] > 0 ? h.strength / maxKind[k] : 1.0f;
            cn.vel = std::clamp ((int) std::lround (64.0 + 63.0 * std::pow (rel, 0.8)), 40, 127);
            res.notes.push_back (cn);
            ++res.count[k];
        }
    res.hits = hits;
    res.bars = loopBars;
    char buf[200];
    std::snprintf (buf, sizeof (buf), "%d kick%s, %d snare%s, %d hat%s%s - %d bar%s at %.0f BPM%s",
                   res.count[BbKick], res.count[BbKick] == 1 ? "" : "s", res.count[BbSnare], res.count[BbSnare] == 1 ? "" : "s",
                   res.count[BbHat] + res.count[BbOpenHat], res.count[BbHat] + res.count[BbOpenHat] == 1 ? "" : "s",
                   res.count[BbOpenHat] > 0 ? " (some open)" : "", loopBars, loopBars == 1 ? "" : "s", res.bpm,
                   res.songTempo ? " (the song's tempo)" : "");
    res.summary = buf;
    return res;
}
}
