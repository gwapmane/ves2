// VESPER's drum FILLS: thousands of them, built the way drummers build fills - one-beat rhythm cells (16ths, 32nd
// rolls, triplets, flams, linear kick-snare...), a path around the kit (down the toms, snare and toms taking turns,
// a hat roll, timbale-style toms...), a dynamic shape (building, steady, falling away) and an ending (a crash on the
// one, a choke, an open hat). Each genre has its own vocabulary, and the size of the fill follows what comes next:
// a big one into a hook or a drop, a short one into a verse, a falling-away one into a break.
// Every seed is a different fill. Plain C++ (no JUCE), so the self-test can check it.
#pragma once

#include <cstdint>

namespace vesper
{
struct FillHit
{
    float step = 0.0f;   // when, in 16ths from the start of the fill (32nds, triplets and flams land in between)
    int note = 38;       // GM drum note
    int vel = 100;
};

enum FillSize { FillSmall = 0, FillMedium, FillBig, FillOut, numFillSizes };
const char* fillSizeName (int size);   // "SMALL"

// the kind of fill that leads from one section type (Song.h) into another; `changing` = false: a fill inside a section
int fillSizeFor (int nextSectionType, int curSectionType, bool changing);
// how many beats a fill of that size lasts (1, 2 or 4); the seed picks between the choices
int fillBeatsFor (int size, uint32_t seed);

struct FillInfo
{
    bool crashAfter = false;   // land on the next one with a crash
    bool grooveKeeps = false;  // the groove keeps playing under it (a hat roll); otherwise the fill replaces the beat
};

constexpr int maxFillHits = 96;
// a fill `beats` long (1..4) for this genre (Theory.h) and size. Returns how many hits it wrote (sorted by time).
int makeFill (int genre, int size, int beats, uint32_t seed, FillHit* out, int maxHits, FillInfo& info);
// a fingerprint of a fill (so the same fill never comes twice in a row, and so the tests can count them)
uint32_t fillSignature (const FillHit* hits, int n);
} // namespace vesper
