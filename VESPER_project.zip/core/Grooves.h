// VESPER grooves: every genre's list of finished 4-bar drum phrases (bars 1-3 the groove, bar 4 its turnaround) from
// the groove bank (core/GrooveBank.inc): real drummers, the cleanest of your loops, and each genre's own programming
// rules - every one different from the rest, each named for what it is. Each groove is a full kit (kick, snare, clap,
// hats, open hat, cymbals, toms, percussion) with each hit's velocity and push / drag (FEEL). The band's drum tracks
// (the full kit, or KICK / SNARE / HATS ... on their own tracks) all play the same groove, so they always lock together.
#pragma once

#include "Theory.h"

#include <cstdint>
#include <string>
#include <vector>

namespace vesper
{
enum DrumPiece { PieceKick = 0, PieceSnare, PieceClap, PieceHats, PieceOpenHat, PiecePerc, PieceCymbal, PieceTom, numDrumPieces };
const char* drumPieceName (int piece);    // "KICK"

struct GrooveHit
{
    int step = 0;          // 0 .. bars * 16 - 1
    float off = 0.0f;      // in 16ths after the step: where a roll / triplet sits on the grid
    float feel = 0.0f;     // in 16ths: how far ahead (-) or behind (+) the drummer played it (the FEEL knob scales it)
    float len = 0.5f;
    int note = 36;
    int vel = 92;
    int piece = PieceKick;
};

struct Groove
{
    std::string name;      // "KNOCK 2"
    int bars = 1;
    std::vector<GrooveHit> hits;
    int busy = 0;          // how much is going on (the list runs from simple to busy)
    int family = 0;        // 0 = from the bank: it carries its own turnaround (-1 = hand-made: the band adds fills / crashes)
    bool live = false;     // played by a real drummer
    bool swung = false;    // on a triplet grid (shuffle, swing)
};

static constexpr int maxGroovesPerGenre = 300;
int numGrooves (int genre);                       // how many grooves the genre has (each one different)
bool genreHasLoops (int genre);                   // the genre has grooves (all do)
const Groove& groove (int genre, int index);
std::string grooveLabel (int genre, int index);   // "007 CEDAR - LIVE 16THS GHOSTS"
int grooveRelated (int genre, int index, int64_t block);   // CHANGE: another groove close to this one (block 0 = itself)
int grooveNear (int genre, int index, int k);     // its k-th closest groove (0 = the closest)

// standard (General MIDI) drum notes VESPER plays
namespace gm
{
    enum : int { Kick = 36, Rim = 37, Snare = 38, Clap = 39, ClosedHat = 42, LowTom = 45, PedalHat = 44, OpenHat = 46,
                 MidTom = 47, Crash = 49, HighTom = 50, Ride = 51, Tambourine = 54, Cowbell = 56, HiBongo = 60, LoBongo = 61,
                 HiConga = 63, LoConga = 64, Shaker = 70, Claves = 75 };
}
} // namespace vesper
