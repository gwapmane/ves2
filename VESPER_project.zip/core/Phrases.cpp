#include "Phrases.h"

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>

namespace vesper
{
namespace
{
struct Entry { int set; const char* text; };

// Every line here was written by hand, phrase by phrase, the way a player would play it over
// the chord of the moment. Strong beats land on chord tones; passing notes move by step.
const Entry library[] = {
    //---------------------------------------------------------------- MELODY: POP HOOK
    { PsPop, "3e_ 3e_ +1e_ 3q_ -1e_ 1q | re 3e_ +1e_ +1e_ 5h | 3e_ 3e_ +1e_ 3q_ -1e_ 1q | re 1e_ -1e_ 1e_ 1h" },
    { PsPop, "5e_ 5e_ 3q_ 5e_ 6e_ 5q | 3e_ 1e_ 3e_ 2e_ 1h" },
    { PsPop, "re 1e_ 3e_ 5e_ 6q_ 5q | re 3e_ 5e_ 3e_ 2q_ 1q" },
    { PsPop, "1q_ 1e_ 3e_ 3q_ 2q | 1H rq" },
    { PsPop, "5Q_ 3e_ 3q_ 1q | 2Q_ 1e_ 3h" },
    { PsPop, "re 5e_ 5e_ 5e_ 6q_ 5q | 3h~ rh" },
    { PsPop, "3s_ 5s_ 3e_ 1q re 1e_ 3q | 5s_ 6s_ 5e_ 3q re 2e_ 1q" },
    { PsPop, "rq 5e_ 6e_ 5q_ 3q | 2e_ 3e_ 5e_ 3e_ 1h | rq 5e_ 6e_ 5q_ 3q | 2e_ 3e_ 2e_ 7,e_ 1h" },

    //---------------------------------------------------------------- MELODY: R&B / SOUL / NEO-SOUL
    { PsRnb, "rq re 5e_ 6e_ 5e_ 3q | re 2e_ 3e_ 2e_ 1h~" },
    { PsRnb, "9q_ 7e_ 5e_ 3q_ 5q | 3s_ 2s_ 1e_ 6,e_ 1h~ re" },
    { PsRnb, "5'Q~ 6s_ 5s_ 3s_ 2s_ 1s_ 2s_ 1s_ 6,s_ 5,e | 1h~ rh" },
    { PsRnb, "re 3e_ 5e_ 3e 9q~ 7e_ 5e | 3h~ rh" },
    { PsRnb, "1e_ 3e_ 5e_ 7e_ 9q~ rq | 7e_ 5e_ 3e_ 2e_ 1h" },
    { PsRnb, "rh 3e_ 2e_ 1e_ 6,e | 1Q~ 2e_ 3e_ 1e_ 6,q" },
    { PsRnb, "b3s_ c+1s_ 5e_ 6e_ 5e_ 3q_ 1q | rq 5e_ 3e_ 2Q~ re" },
    { PsRnb, "5h^~ 3q_ 2q | 1e_ 2e_ 3e_ 5e_ 3h" },
    { PsRnb, "rq 9e_ 1'e_ 9e_ 7e_ 5q | 6e_ 5e_ 3e_ 5e_ 3e_ 2e_ 1q" },

    //---------------------------------------------------------------- MELODY: JAZZ BEBOP
    { PsJazz, "1e_ 3e_ 5e_ 7e_ 9e_ 7e_ 5e_ c-1e | 3e_ -1e_ -1e_ c-1e_ 1q rq" },
    { PsJazz, "rq 5e_ c+1e_ 6e_ 5e_ c-1e_ -1e | 3h~ rh" },
    { PsJazz, "re 2e_ c-3e_ c+1e_ 3e_ 5e_ 7e_ 9e | 7q_ 5q 3h" },
    { PsJazz, "3e_ c+1e_ 5e_ 7e_ 9q_ 7e_ 5e | 3e_ 2e_ 1e_ 7,e_ 6,q rq" },
    { PsJazz, "rh 7e_ 5e_ 3e_ 1e | c-1e_ 1e_ 3e_ 5e_ 9h" },
    { PsJazz, "1t_ 3t_ 5t_ 7t_ 5t_ 3t_ 1h | rw" },

    //---------------------------------------------------------------- MELODY: GOSPEL BLUES
    { PsGospel, "5e_ 5e_ 6e_ 5e_ 3q_ 1q | b3s_ c+1s_ 1e_ 6,e_ 1Q~ rq" },
    { PsGospel, "1'q~ b7e_ 5e_ 6e_ 5e_ 3q | 1h~ rh" },
    { PsGospel, "rq 1's_ 6s_ 5s_ 3s_ b3s_ 2s_ 1s_ 6,s_ 1q | 3H~ rq" },
    { PsGospel, "3e_ 5e_ 6e_ 5e_ 3e_ 1e_ 3q | 5e_ 3e_ 2e_ 1e_ 6,q_ 1q" },
    { PsGospel, "5Q~ 3e_ 5q_ 6q | 1'H~ rq" },
    { PsGospel, "rh 5e_ 6e_ 1'q | b3'e_ 2e_ 1e_ 6e_ 5h" },
    { PsGospel, "1e_ 1e_ 3e_ 5e_ 6q_ 5q | 3h~ 1h" },

    //---------------------------------------------------------------- MELODY: LO-FI
    { PsLofi, "rh 5q_ 3q | 9h~ rh" },
    { PsLofi, "re 3e_ 2e_ 1e 5,h | rw" },
    { PsLofi, "9Q~ 7e_ 5h | rw" },
    { PsLofi, "rq 3e_ 5e 9q 7q | 5h~ rh" },
    { PsLofi, "5e_ 3e 1q rh | 2e_ 3e 5q rh" },
    { PsLofi, "rw | rq 7e_ 9e_ 5h~" },
    { PsLofi, "3h~ 2q_ 1q | 6,w~" },

    //---------------------------------------------------------------- MELODY: ROCK RIFF
    { PsRock, "@0e! @0e! @3e_ @0e_ @5e_ @3e_ @0q | @0e! @0e! @3e_ @0e_ @7e_ @5e_ @3q" },
    { PsRock, "@7e_ @5e_ @3e_ @0e_ @3e_ @5e_ @0q | @10,e_ @0e_ @3e_ @0e_ @0h" },
    { PsRock, "@0s @0s @3e @5e @0s @0s @7e @5e @3e @0e | @0h~ @3e_ @5e_ @7q" },
    { PsRock, "5q_ 3q_ 1h | 5q_ 6q_ 5h" },
    { PsRock, "@0e_ @3e_ @5e_ @7e_ @10e_ @7e_ @5q | @3e_ @0e_ @3e_ @5e_ @0h" },

    //---------------------------------------------------------------- MELODY: CLASSICAL
    { PsClassical, "1e_ 3e_ 5e_ 1'e_ 3'e_ 1'e_ 5e_ 3e | 2h_ 1h" },
    { PsClassical, "5q_ +1e_ +1e_ +1e_ +1e_ -1e_ -1e | 3h~ -1q_ -1q" },
    { PsClassical, "3'Q_ 2e_ 1q_ 7,q | 1h~ rh" },
    { PsClassical, "1s_ 3s_ 5s_ 3s_ 1s_ 3s_ 5s_ 3s_ 1s_ 3s_ 5s_ 3s_ 1'q | 5h~ 3h" },
    { PsClassical, "5h_ 6q_ 5q | 4h_ 3h" },
    { PsClassical, "rq 5e_ 6e_ 7e_ 1'e_ 2'e_ 3'e | 1'H~ rq" },

    //---------------------------------------------------------------- MELODY: AMBIENT
    { PsAmbient, "5w~ | 3w~" },
    { PsAmbient, "9w~ | rw" },
    { PsAmbient, "1H~ 5q_ | 3w~" },
    { PsAmbient, "rh 3'h~ | 2w~" },
    { PsAmbient, "7w~ | 5w~" },

    //---------------------------------------------------------------- MELODY: LATIN
    { PsLatin, "3E_ 5E_ 3e_ 1E_ 3E_ 5e | 6E_ 5E_ 3e_ 2h" },
    { PsLatin, "re 5e_ re 5e_ 6e_ 5e_ 3q | re 2e_ re 2e_ 3e_ 2e_ 1q" },
    { PsLatin, "1'q_ 7e_ 6e_ 5q_ 3q | 2E_ 3E_ 1e_ 1h" },
    { PsLatin, "rq 3e_ 5e_ 1'q_ 7e_ 5e | 6E_ 5E_ 3e_ 1h" },
    { PsLatin, "5s_ 6s_ 5e_ 3e_ 1e_ c-1e_ 1e_ 3q | 5h~ rh" },

    //---------------------------------------------------------------- MELODY: TRAP / HIP-HOP
    { PsTrap, "1t_ 1t_ 3t_ 1q_ 7,q re 1e | 5,h~ rh" },
    { PsTrap, "1e_ 3e_ 4e_ 3e_ 1q rq | 1e_ 3e_ 5e_ 4e_ 3h" },
    { PsTrap, "5Q_ 4e_ 3h | 1Q_ 3e_ 1h" },
    { PsTrap, "rq 1e 1e 3q 1q | 7,Q 1e 1h" },
    { PsTrap, "1u_ 3u_ 4u_ 5h~ 4e_ 3e_ 1e | rw" },
    { PsTrap, "3e_ 3e_ 3e_ 1e_ 3q_ 4q | 3e_ 1e_ 7,e_ 1e_ 1h" },
    { PsTrap, "5q_ 3q_ 1q_ 5,q | 6,h_ 5,h" },

    //---------------------------------------------------------------- MELODY: COUNTRY
    { PsCountry, "re 1e_ 2e_ 3e^ 5q_ 3q | 2e_ 1e_ 6,e_ 1e_ 1h" },
    { PsCountry, "5q^ 6e_ 5e_ 3q_ 1q | 2Q_ 3e_ 1h" },
    { PsCountry, "3e_ 5e_ 6e_ 1'e_ 6q_ 5q | 3h~ rh" },
    { PsCountry, "1'e^_ 6e_ 5e_ 3e_ 2q_ 1q | 6,Q_ 1e_ 1h" },
    { PsCountry, "5h^ 3e_ 2e_ 1q | 3w~" },

    //---------------------------------------------------------------- MELODY: AFROBEATS
    { PsAfro, "re 3e_ re 3e_ 5e_ 3e_ 1q | re 3e_ re 3e_ 6e_ 5e_ 3q" },
    { PsAfro, "5E_ 5E_ 3e_ 1q_ 3q | 2E_ 2E_ 1e_ 6,h" },
    { PsAfro, "1e_ 3e_ 5e_ 6e_ 5q_ 3q | re 1e_ re 1e_ 3h" },
    { PsAfro, "rq 6e_ 5e_ 3e_ 2e_ 1q | rq 6e_ 5e_ 3h" },
    { PsAfro, "3s_ 5s_ 3e_ re 1e_ 3s_ 5s_ 3e_ re 6,e | 1h~ rh" },

    //---------------------------------------------------------------- MELODY: CINEMATIC
    { PsCinematic, "1h~ 5h~ | 6Q_ 5e_ 3h | 2h~ 3q_ 5q | 1w~" },
    { PsCinematic, "5,h_ 1h~ | 3H~ 2q_ | 1h_ 5,h | 1w~" },
    { PsCinematic, "1Q_ 2e_ 3h~ | 5Q_ 6e_ 5h | 3Q_ 2e_ 1h | 2w~" },
    { PsCinematic, "rh 5,q_ 1q | 3H~ 2q_ | 1H~ 7,q | 1w~" },
    { PsCinematic, "3w~ | 5h~ 1'h~ | 7h~ 6h_ | 5w~" },
    { PsCinematic, "1q_ 5q_ 1'h~ | 7Q_ 6e_ 5h | 3q_ +1q_ +1h~ | 1w~" },

    //---------------------------------------------------------------- MELODY: EDM LEAD
    { PsEdm, "1e! 1'e! 5e! 3e! re 5e! re 3e! | 1e! 1'e! 5e! 3e! re 2e! 1q!" },
    { PsEdm, "re 3e_ 5e_ 3e_ re 3e_ 6e_ 5e | re 3e_ 5e_ 3e_ re 2e_ 1q" },
    { PsEdm, "5e! 5e! 6e! 5e! 3q> 1q! | 2e! 2e! 3e! 2e! 1h>" },
    { PsEdm, "1s_ 3s_ 5s_ 1's_ 5s_ 3s_ 1e re 1s_ 3s_ 5s_ 1's_ 5e | 6s_ 5s_ 3s_ 1s_ 2q 1h" },
    { PsEdm, "3q! 3e! 5e! re 3e! 2e! 1e! | 1'h> rh" },

    //---------------------------------------------------------------- VIOLIN: LYRICAL (singing lines, swells)
    { PsViolinLyrical, "5h~ +1q_ +1q | 3'h~ -1q_ -1q | 1Q_ +1e_ +1q_ +1q | 3w~" },
    { PsViolinLyrical, "re 1e_ +1e_ +1e 5h~ | -1q_ 3h~ -1q_ | -1q_ 1Q~ +1e_ +1q | 3w~" },
    { PsViolinLyrical, "3w~ | -1h_ -1h | 5'H~ +1q_ | 3w~" },
    { PsViolinLyrical, "1q_ 3q_ 5h~ | 6Q_ -1e_ -2h | -1q_ -1q_ -1q_ -1q | 3H~ rq" },
    { PsViolinLyrical, "rq 3q_ 1'h~ | -1q_ -1q_ -1q_ -1q | 3h~ 5,h~ | 1w~" },
    { PsViolinLyrical, "3Q~ +1e_ +1h~ | 5w~" },
    { PsViolinLyrical, "5h~ -1q_ -1q | 1w~" },
    { PsViolinLyrical, "1Q_ +1e_ +1q_ +1q | 5'w~" },
    { PsViolinLyrical, "6h~ 5h_ | 3w~" },
    { PsViolinLyrical, "3h~ 5h_ | 6Q~ -1e_ -1h | -1e_ -1e_ -1e_ -1e_ -1e_ +1e_ +1e_ +1e | 1w~" },
    { PsViolinLyrical, "5'H~ =q_ | -1w~ | 3H~ -1q_ | 1w~" },
    { PsViolinLyrical, "1h_ +1h | 3h_ +1h | 5h_ +1h | 1'w~" },

    //---------------------------------------------------------------- VIOLIN: SOUL (Philly / Motown / neo-soul strings)
    { PsViolinSoul, "rq re 5e_ +1e_ +1e 3'q | 1'h~ rh" },
    { PsViolinSoul, "re 3e! re 3e! re 5e_ 3e_ 1e | 2h~ rh" },
    { PsViolinSoul, "1e_ 3e_ 5e_ 7e_ 9h~ | rw" },
    { PsViolinSoul, "rh re 5s_ 6s_ 7e_ 1'e | 9H~ rq" },
    { PsViolinSoul, "3'q~ -1e_ -1e_ 1h | re 5,e_ +1e_ +1e_ 3h | 1Q~ -1e_ 5,h | rw" },
    { PsViolinSoul, "rh 5e! 5e! re 3e | 1'h~ rh" },
    { PsViolinSoul, "1h~ rq 3e_ 5e | 9h~ 7q_ 5q | 6h~ 5q_ 3q | 1w~" },
    { PsViolinSoul, "rq 5'Q^~ 3e_ 1q | 3h~ rh" },
    { PsViolinSoul, "rh 1e_ 3e_ 5e_ 1'e | 3'Q~ 2e_ 1h" },
    { PsViolinSoul, "5e_ 6e_ 5e_ 3e_ 2e_ 3e_ 1q | rw" },

    //---------------------------------------------------------------- VIOLIN: RUNS (flourishes into the downbeat)
    { PsViolinRuns, "rh 1s_ +1s_ +1s_ +1s_ +1s_ +1s_ +1s_ +1s | 3'w~" },
    { PsViolinRuns, "5'h~ -1s_ -1s_ -1s_ -1s_ -1s_ -1s_ -1s_ -1s | 1h~ rh" },
    { PsViolinRuns, "rq 1t_ +1t_ +1t_ +1t_ +1t_ +1t_ 5'q | 3'Q~ -1e_ -1h | 1w~ | rw" },
    { PsViolinRuns, "3h~ rq +1s_ +1s_ +1s_ +1s | 6q_ 5q_ 3h~ | 1w~ | rw" },
    { PsViolinRuns, "rq 1'e_ -2s_ -1s_ -2e_ b3s_ c-1s_ 1e_ 5,e | 1h~ rh" },
    { PsViolinRuns, "rh rq 5s_ +1s_ +1s_ +1s | 9'h~ 7q_ 5q | 3w~ | rw" },
    { PsViolinRuns, "1s_ +1s_ +1s_ +1s_ +1s_ +1s_ +1s_ +1s_ +1s_ +1s_ +1s_ +1s_ 5'q~ | 3'w~" },

    //---------------------------------------------------------------- CELLO LINES
    { PsCello, "1h~ +1q_ +1q | 3h~ -1q_ -1q | 1H~ 5,q | 1w~" },
    { PsCello, "5h_ +1q_ +1q | 1'h~ -1h | -1h_ -1h | 1w~" },
    { PsCello, "3Q_ -1e_ -1h | 1Q_ +1e_ +1h | 3h_ 5h | 1w~" },
    { PsCello, "1w~ | 5h_ -1h | 3w~ | 1w~" },
    { PsCello, "rh 5,q_ 1q | 3h~ +1q_ -1q | 1h_ -1h | 1w~" },
    { PsCello, "1Q~ 3e_ 5h | 6h_ 5q_ 3q | 1w~ | rw" },

    //---------------------------------------------------------------- HIGH DESCANT (long floating notes)
    { PsDescant, "5'w~ | 9w~ | 3'w~ | 1w~" },
    { PsDescant, "3'H~ +1q_ | 5w~ | 3H~ -1q | 1w~" },
    { PsDescant, "9'w~ | 7h_ 5h~ | 6w~ | 5w~" },
    { PsDescant, "1'h~ 3h~ | 5w~ | 3h~ 1h_ | 9,w~" },
    { PsDescant, "rw | 5'H~ +1q_ | 3'w~ | rw" },

    //---------------------------------------------------------------- ANSWER LICKS (counter-melody in the gaps)
    { PsAnswer, "rw | re 5e_ +1e_ +1e 3h~" },
    { PsAnswer, "rh re 3e_ 5e_ 3e | 1'h~ rh" },
    { PsAnswer, "rw | rq 1t_ 3t_ 5t_ 7q_ 9q~" },
    { PsAnswer, "rw | 9e_ 7e_ 5e_ 3e_ 1h~" },
    { PsAnswer, "rh 5Q_ 3e | rw" },
    { PsAnswer, "rw | rq 3'e! 3e! re 1e_ 3q" },
    { PsAnswer, "rh rq 5s_ +1s_ +1s_ +1s | 3'h~ rh" },
    { PsAnswer, "rw | b3s_ c+1s_ 5e_ 1'e_ 5e_ 3h~" },

    //---------------------------------------------------------------- HORN SHOUT LINES
    { PsHorns, "1e! 1e! re 3e> re 5e! 7e_ 1'e> | rw" },
    { PsHorns, "re 5e! re 5e! 6e_ 5e_ 3q> | rw" },
    { PsHorns, "rq 3e_ 5e_ 1'q> rq | rq 9e_ 1'e_ 5q> rq" },
    { PsHorns, "1s! b3s_ 3e> re 5e! re 7e_ 1'e! re | rw" },
    { PsHorns, "5q> 5e! 3e! re 1e_ 3e_ 5e | 1'h> rh" },
    { PsHorns, "re 1e_ 3e_ 5e_ 7q> 5q! | rw" },
};

float durCode (char c)
{
    switch (c)
    {
        case 'x': return 0.5f;
        case 'u': return 2.0f / 3.0f;
        case 's': return 1.0f;
        case 't': return 4.0f / 3.0f;
        case 'S': return 1.5f;
        case 'e': return 2.0f;
        case 'T': return 8.0f / 3.0f;
        case 'E': return 3.0f;
        case 'q': return 4.0f;
        case 'Q': return 6.0f;
        case 'h': return 8.0f;
        case 'H': return 12.0f;
        case 'w': return 16.0f;
        default: return 0.0f;
    }
}

// ---- VARIATIONS of every hand-written line, so each style has dozens of different ideas, not a handful.
// They keep the line's shape and only change how it's phrased: off the beat, pushed, answered, with space, ornamented,
// swung, slower or busier.
enum Variant { VarWritten = 0, VarPickup, VarPushed, VarAnswer, VarSpace, VarOrnament, VarSwing, VarHalfTime, VarDoubleTime,
               VarPickupSwing, VarAnswerOrnament, VarSpacePickup, numVariants };

bool sane (const Phrase& p)
{
    if (p.notes.empty() || p.bars < 1 || p.bars > 8) return false;
    const float total = 16.0f * (float) p.bars;
    int sounding = 0;
    float last = -1.0f;
    for (const auto& n : p.notes)
    {
        if (n.start < 0.0f || n.start >= total || n.dur <= 0.0f || n.start + 1e-4f < last) return false;
        last = n.start;
        if (n.kind != PkRest) ++sounding;
    }
    return sounding >= 2;
}

void clip (Phrase& p)
{
    const float total = 16.0f * (float) p.bars;
    std::vector<PhraseNote> keep;
    for (auto n : p.notes)
    {
        if (n.start >= total) continue;
        n.dur = std::min (n.dur, total - n.start);
        if (n.dur > 0.01f) keep.push_back (n);
    }
    p.notes = keep;
}

bool vary (const Phrase& in, int v, Phrase& p)
{
    p = in;
    p.variant = v;
    const float total = 16.0f * (float) p.bars;
    auto& ns = p.notes;
    switch (v)
    {
        case VarPickup:   // the whole line an 8th later: it starts off the beat
            for (auto& n : ns) n.start += 2.0f;
            clip (p);
            break;
        case VarPushed:   // every note after the first lands a 16th early (pushed, like a singer leaning in)
            for (size_t i = 1; i < ns.size(); ++i)
                if (ns[i].start - 1.0f > ns[i - 1].start + 0.25f)
                {
                    ns[i].start -= 1.0f;
                    ns[i].dur += 1.0f;
                    ns[i - 1].dur = std::min (ns[i - 1].dur, ns[i].start - ns[i - 1].start);
                }
            break;
        case VarAnswer:   // a one-bar line gets an answer: the same rhythm again, starting a chord tone higher, ending home
        {
            if (p.bars != 1) return false;
            std::vector<PhraseNote> two = ns;
            // only move the first note if what follows it doesn't count from it (a chromatic or scale step would land elsewhere)
            bool first = true;
            for (size_t i = 0; i < ns.size(); ++i)
                if (ns[i].kind == PkDegree)
                {
                    if (i + 1 < ns.size() && (ns[i + 1].kind == PkChromatic || ns[i + 1].kind == PkStep || ns[i + 1].kind == PkRepeat)) first = false;
                    break;
                }
            for (auto n : ns)
            {
                n.start += 16.0f;
                if (first && n.kind == PkDegree)
                {
                    n.value = (int8_t) (n.value == 1 ? 3 : n.value == 3 ? 5 : n.value == 5 ? 1 : 1);
                    if (n.value == 1) n.octave = 1;
                    first = false;
                }
                two.push_back (n);
            }
            for (int i = (int) two.size() - 1; i >= 0; --i)   // the answer ends on the root
                if (two[(size_t) i].kind != PkRest) { two[(size_t) i].kind = PkDegree; two[(size_t) i].value = 1; two[(size_t) i].octave = 0; break; }
            ns = two;
            p.bars = 2;
            break;
        }
        case VarSpace:    // the last part of the line is left out: room for an answer (or for the singer)
        {
            const float cut = total - std::max (4.0f, total * 0.3f);
            std::vector<PhraseNote> keep;
            for (const auto& n : ns) if (n.start < cut) keep.push_back (n);
            if (keep.size() < 3) return false;
            if (keep.back().start + keep.back().dur > cut) keep.back().dur = std::max (1.0f, cut - keep.back().start);
            ns = keep;
            p.density *= 0.75f;
            break;
        }
        case VarOrnament: // grace notes into the strong notes, and a turn on the long ones
        {
            std::vector<PhraseNote> out;
            for (size_t i = 0; i < ns.size(); ++i)
            {
                const auto& n = ns[i];
                PhraseNote a = n;
                // a grace note (a half step below) into the accents - not in the classical-style lines, where it doesn't belong
                const bool graceFits = in.set != PsClassical && in.set != PsDescant && in.set != PsCello && in.set != PsViolinLyrical
                                       && in.set != PsCinematic && in.set != PsAmbient;
                if (graceFits && n.kind != PkRest && ((n.art & ArtAccent) || (i == 0 && n.dur >= 2.0f))) a.art = (uint8_t) (a.art | ArtGrace);
                // a turn only where the next note doesn't count from this one (a chromatic step would move)
                const bool nextRelative = i + 1 < ns.size() && (ns[i + 1].kind == PkChromatic || ns[i + 1].kind == PkStep || ns[i + 1].kind == PkRepeat);
                if (n.kind != PkRest && n.dur >= 8.0f && ! nextRelative)
                {
                    a.dur = n.dur - 2.0f;
                    out.push_back (a);
                    PhraseNote up;
                    up.start = n.start + a.dur;
                    up.dur = 1.0f;
                    up.kind = PkStep;
                    up.value = 1;
                    out.push_back (up);
                    PhraseNote back = up;
                    back.start += 1.0f;
                    back.value = -1;
                    out.push_back (back);
                    continue;
                }
                out.push_back (a);
            }
            ns = out;
            p.complexity = std::min (1.0f, p.complexity + 0.15f);
            break;
        }
        case VarSwing:    // straight 8th pairs become long-short
        {
            bool changed = false;
            for (size_t i = 0; i + 1 < ns.size(); ++i)
                if (std::fmod (ns[i].start, 4.0f) < 0.01f && std::abs (ns[i].dur - 2.0f) < 0.01f && std::abs (ns[i + 1].start - ns[i].start - 2.0f) < 0.01f)
                {
                    ns[i].dur = 3.0f;
                    ns[i + 1].start += 1.0f;
                    ns[i + 1].dur = std::max (0.5f, ns[i + 1].dur - 1.0f);
                    changed = true;
                }
            if (! changed) return false;
            p.complexity = std::min (1.0f, p.complexity + 0.05f);
            break;
        }
        case VarHalfTime: // twice as slow: lyrical, for verses
            if (p.bars > 2) return false;
            for (auto& n : ns) { n.start *= 2.0f; n.dur *= 2.0f; }
            p.bars *= 2;
            p.density *= 0.6f;
            break;
        case VarDoubleTime: // twice as fast: busier, for hooks and solos
        {
            if (p.bars < 2) return false;
            for (const auto& n : ns) if (n.dur < 1.0f) return false;
            for (auto& n : ns) { n.start *= 0.5f; n.dur *= 0.5f; }
            p.bars /= 2;
            p.density = std::min (1.0f, p.density * 1.4f + 0.05f);
            p.complexity = std::min (1.0f, p.complexity + 0.1f);
            break;
        }
        case VarPickupSwing: { Phrase a; if (! vary (in, VarPickup, a) || ! vary (a, VarSwing, p)) return false; break; }
        case VarAnswerOrnament: { Phrase a; if (! vary (in, VarAnswer, a) || ! vary (a, VarOrnament, p)) return false; break; }
        case VarSpacePickup: { Phrase a; if (! vary (in, VarSpace, a) || ! vary (a, VarPickup, p)) return false; break; }
        default: return false;
    }
    p.variant = v;
    std::stable_sort (ns.begin(), ns.end(), [] (const PhraseNote& a, const PhraseNote& b) { return a.start < b.start; });
    return sane (p);
}

std::vector<Phrase> build()
{
    std::vector<Phrase> out;
    for (const auto& e : library)
    {
        Phrase p;
        std::string err;
        if (parsePhrase (e.text, p, &err))
        {
            p.set = e.set;
            p.text = e.text;
            const int base = (int) out.size();
            p.base = base;
            out.push_back (p);
            for (int v = 1; v < numVariants; ++v)
            {
                Phrase q;
                if (vary (out[(size_t) base], v, q)) { q.base = base; q.set = e.set; q.text = e.text; out.push_back (std::move (q)); }
            }
        }
        else std::fprintf (stderr, "PHRASE ERROR: %s\n", err.c_str());
    }
    return out;
}

std::atomic<int8_t>* ratings()
{
    static std::atomic<int8_t> r[8192];
    return r;
}
std::atomic<uint32_t>& ratingsEpoch() { static std::atomic<uint32_t> e { 0 }; return e; }
} // namespace

const char* phraseVariantName (int v)
{
    static const char* names[numVariants] = { "AS WRITTEN", "PICKUP", "PUSHED", "ANSWERED", "WITH SPACE", "ORNAMENTED", "SWUNG",
                                              "HALF TIME", "DOUBLE TIME", "PICKUP + SWUNG", "ANSWERED + ORNAMENTED", "SPACE + PICKUP" };
    return v >= 0 && v < numVariants ? names[v] : "";
}

void setPhraseRating (int id, int rating)
{
    const auto& lib = phraseLibrary();
    if (id < 0 || id >= (int) lib.size()) return;
    const int base = lib[(size_t) id].base;
    if (base < 0 || base >= 8192) return;
    ratings()[base].store ((int8_t) std::clamp (rating, -1, 1));
    ratingsEpoch().fetch_add (1);
}

int phraseRating (int id)
{
    const auto& lib = phraseLibrary();
    if (id < 0 || id >= (int) lib.size()) return 0;
    const int base = lib[(size_t) id].base;
    return (base >= 0 && base < 8192) ? (int) ratings()[base].load (std::memory_order_relaxed) : 0;
}

uint32_t phraseRatingsEpoch() { return ratingsEpoch().load (std::memory_order_relaxed); }

void clearPhraseRatings()
{
    for (int i = 0; i < 8192; ++i) ratings()[i].store (0);
    ratingsEpoch().fetch_add (1);
}

namespace
{
} // namespace

bool parsePhrase (const char* text, Phrase& out, std::string* error)
{
    out = Phrase();
    out.text = text;
    float t = 0.0f;
    const char* c = text;
    auto fail = [&] (const std::string& why) { if (error) *error = why + " in: " + text; return false; };
    while (*c)
    {
        while (*c == ' ') ++c;
        if (! *c) break;
        if (*c == '|')
        {
            const float r = std::fmod (t, 16.0f);
            if (std::abs (r) > 0.01f && std::abs (r - 16.0f) > 0.01f) return fail ("bar line at " + std::to_string (t) + " steps");
            ++c;
            continue;
        }
        PhraseNote n;
        // pitch
        if (*c == 'r') { n.kind = PkRest; ++c; }
        else if (*c == '=') { n.kind = PkRepeat; ++c; }
        else if (*c == 'b' && std::isdigit ((unsigned char) c[1])) { n.kind = PkBlue; n.value = (int8_t) (c[1] - '0'); c += 2; }
        else if (*c == '@' || *c == 'c' || *c == '+' || *c == '-')
        {
            if (*c == '@') { n.kind = PkInterval; ++c; }
            else if (*c == 'c') { n.kind = PkChromatic; ++c; }
            else n.kind = PkStep;
            int sign = 1;
            if (*c == '+') ++c;
            else if (*c == '-') { sign = -1; ++c; }
            if (! std::isdigit ((unsigned char) *c)) return fail ("number expected");
            int v = 0;
            while (std::isdigit ((unsigned char) *c)) v = v * 10 + (*c++ - '0');
            n.value = (int8_t) (sign * v);
        }
        else if (std::isdigit ((unsigned char) *c))
        {
            int v = 0;
            while (std::isdigit ((unsigned char) *c)) v = v * 10 + (*c++ - '0');
            if (v < 1 || v > 13) return fail ("degree " + std::to_string (v));
            n.kind = PkDegree;
            n.value = (int8_t) v;
        }
        else return fail (std::string ("unexpected '") + *c + "'");
        // octave
        if (*c == '\'') { n.octave = 1; ++c; }
        else if (*c == ',') { n.octave = -1; ++c; }
        // length
        float d = durCode (*c);
        if (d <= 0.0f) return fail ("length expected");
        ++c;
        while (*c == '+' && durCode (c[1]) > 0.0f) { d += durCode (c[1]); c += 2; }
        // articulation
        while (*c == '_' || *c == '!' || *c == '>' || *c == '~' || *c == '^')
        {
            if (*c == '_') n.art |= ArtLegato;
            if (*c == '!') n.art |= ArtShort;
            if (*c == '>') n.art |= ArtAccent;
            if (*c == '~') n.art |= ArtSwell;
            if (*c == '^') n.art |= ArtGrace;
            ++c;
        }
        if (*c && *c != ' ' && *c != '|') return fail (std::string ("junk '") + *c + "'");
        n.start = t;
        n.dur = d;
        t += d;
        out.notes.push_back (n);
    }
    const float bars = t / 16.0f;
    if (t <= 0.0f || std::abs (bars - std::round (bars)) > 0.01f) return fail ("length " + std::to_string (t) + " isn't whole bars");
    out.bars = (int) std::round (bars);

    int notes = 0, busy = 0;
    for (const auto& n : out.notes)
    {
        if (n.kind == PkRest) continue;
        ++notes;
        if (n.dur < 2.0f) ++busy;
        if (n.kind == PkChromatic || n.kind == PkBlue || (n.art & ArtGrace)) busy += 2;
    }
    out.density = std::clamp ((float) notes / (float) out.bars / 8.0f, 0.0f, 1.0f);
    out.complexity = notes > 0 ? std::clamp ((float) busy / (float) notes, 0.0f, 1.0f) : 0.0f;
    return true;
}

const std::vector<Phrase>& phraseLibrary()
{
    static const std::vector<Phrase> lib = build();
    return lib;
}

const std::vector<int>& phrasesInSet (int set)
{
    static const std::vector<std::vector<int>> sets = []
    {
        std::vector<std::vector<int>> s ((size_t) numPhraseSets);
        const auto& lib = phraseLibrary();
        for (int i = 0; i < (int) lib.size(); ++i) s[(size_t) lib[(size_t) i].set].push_back (i);
        return s;
    }();
    static const std::vector<int> none;
    return (set >= 0 && set < numPhraseSets) ? sets[(size_t) set] : none;
}

const char* phraseSetName (int set)
{
    static const char* const names[numPhraseSets] = { "POP", "R&B", "JAZZ", "GOSPEL", "LO-FI", "ROCK", "CLASSICAL", "AMBIENT",
                                                      "LATIN", "TRAP", "COUNTRY", "AFROBEATS", "CINEMATIC", "EDM",
                                                      "VIOLIN LYRICAL", "VIOLIN SOUL", "VIOLIN RUNS", "CELLO", "DESCANT",
                                                      "ANSWER", "HORNS" };
    return (set >= 0 && set < numPhraseSets) ? names[set] : "";
}

int phraseSetFor (int part, int style)
{
    // band parts: 0 melody, 1 counter, 2 bass, 3 strings, 4 horns, 5 drums (see Band.h)
    switch (part)
    {
        case 0: return (style >= 0 && style <= 13) ? style : -1;
        case 1: return style == 2 ? PsAnswer : (style == 4 ? PsDescant : -1);
        case 3:
            if (style == 7) return PsDescant;
            if (style == 8) return PsCello;
            if (style == 9) return PsViolinLyrical;
            if (style == 10) return PsViolinSoul;
            if (style == 11) return PsViolinRuns;
            return -1;
        case 4: return style == 2 ? PsHorns : -1;
        default: return -1;
    }
}

int degreeInterval (int degree, const Chord& c, int keyMask)
{
    const int m = tonesMask (c);
    auto has = [m] (int r) { return (m >> r) & 1; };
    auto inKey = [&] (int r) { return (keyMask >> ((c.root + r) % 12)) & 1; };
    switch (degree)
    {
        case 1: return 0;
        case 3:
            if (has (4)) return 4;
            if (has (3)) return 3;
            if (has (5)) return 5;
            if (has (2)) return 2;
            return inKey (4) ? 4 : 3;
        case 5:
            if (has (7)) return 7;
            if (has (6)) return 6;
            if (has (8)) return 8;
            return 7;
        case 7:
            if (has (10)) return 10;
            if (has (11)) return 11;
            if (has (9)) return 9;
            if (inKey (10)) return 10;
            return inKey (11) ? 11 : 10;
        case 2: case 9:
            if (has (2)) return 2;
            if (has (1)) return 1;
            if (has (3) && ! inKey (2)) return 1;
            return 2;
        case 4: case 11:
            if (has (5)) return 5;
            if (has (6) && ! has (7)) return 6;
            return inKey (5) ? 5 : 6;
        case 6: case 13:
            if (has (9)) return 9;
            if (has (8)) return 8;
            return inKey (9) ? 9 : 8;
        default: return 0;
    }
}
} // namespace vesper
