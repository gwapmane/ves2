#include "Song.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <initializer_list>

namespace vesper
{
namespace
{
struct R
{
    uint32_t s;
    explicit R (uint32_t seed) : s (seed * 2654435761u + 0x9e3779b9u) { if (s == 0) s = 1; next(); next(); }
    uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float uni() { return (float) (next() & 0xffffff) / 16777216.0f; }
    bool chance (float p) { return uni() < p; }
    int pick (int n) { return n <= 1 ? 0 : (int) (next() % (uint32_t) n); }
    int of (std::initializer_list<int> l) { return *(l.begin() + pick ((int) l.size())); }
};

enum Family { FamRap = 0, FamSong, FamDance, FamLofi, FamReggaeton, FamCinema, FamJazz, FamBlues };

int looperFor (int type)
{
    switch (type)
    {
        case SecHook: case SecDrop: return 1;                     // B
        case SecBridge: case SecBreak: case SecBuild: return 2;   // C
        case SecPre: return 3;                                    // D
        default: return 0;                                        // A: intro, verses, solos, outro
    }
}

SongSection make (int type, int bars, float e0, float e1, const char* label = nullptr, int groove = 0)
{
    SongSection s;
    s.type = type;
    s.label = label != nullptr ? label : songSectionName (type);
    s.bars = std::max (1, bars);
    s.energyFrom = e0;
    s.energyTo = e1;
    s.looper = looperFor (type);
    s.grooveBlock = groove;
    s.mask.assign ((size_t) s.bars, 0xffff);
    s.moment.assign ((size_t) s.bars, (uint8_t) MomNone);
    return s;
}

float threshold (int type)
{
    switch (type)
    {
        case BPad: return 0.0f;     case BKeys: return 0.05f;   case BStrings: return 0.2f;  case BGuitar: return 0.35f;
        case BArp: return 0.45f;    case BBass: return 0.38f;   case BDrums: return 0.42f;   case BKick: return 0.42f;
        case BSnare: return 0.48f;  case BClap: return 0.55f;   case BHats: return 0.32f;    case BOpenHat: return 0.6f;
        case BPerc: return 0.5f;    case BCymbal: return 0.62f; case BTom: return 0.75f;     case BMelody: return 0.58f;
        case BCounter: return 0.72f; case BHorns: return 0.78f;
        default: return 0.5f;
    }
}

bool isLead (int t) { return t == BMelody || t == BCounter || t == BHorns; }
bool isBed (int t) { return t == BPad || t == BKeys || t == BStrings || t == BGuitar || t == BArp; }
bool isBeatDrum (int t) { return t == BDrums || t == BKick || t == BSnare || t == BClap || t == BTom || t == BCymbal; }

// the moments of one section, knowing what comes after it
void placeMoments (SongSection& s, int nextType, int family, int genre, R& r)
{
    std::fill (s.moment.begin(), s.moment.end(), (uint8_t) MomNone);
    const int last = s.bars - 1;
    auto set = [&] (int bar, int m) { if (bar >= 0 && bar < s.bars) s.moment[(size_t) bar] = (uint8_t) m; };
    const bool bigNext = nextType == SecHook || nextType == SecDrop;
    const bool stopGenre = genre == Funk || genre == Latin || genre == Gospel || genre == Reggaeton;

    // into the next section
    if (nextType >= 0 && s.type != SecBuild)
    {
        if (family == FamRap && bigNext) set (last, r.chance (0.55f) ? MomDrop : (r.chance (0.5f) ? MomStop : MomFill));
        else if (family == FamReggaeton && s.type == SecPre) set (last, r.chance (0.6f) ? MomStop : MomBuild);
        else if (family == FamLofi) { if (r.chance (0.35f)) set (last, MomDrop); }
        else if (family == FamCinema && nextType == SecDrop) set (last, MomStop);
        else if (stopGenre && r.chance (0.45f)) set (last, MomStop);
        else if (family == FamSong && s.type == SecPre && r.chance (0.3f)) set (last, MomBuild);
        else if (r.chance (family == FamDance ? 0.5f : (genre == Afro ? 0.35f : 0.65f))) set (last, MomFill);
    }
    if (s.type == SecBuild) set (last, MomBuild);
    if (s.type == SecOutro) set (last, r.chance (0.5f) ? MomStop : MomFill);

    // a big section lands with a crash
    if ((s.type == SecHook || s.type == SecDrop || s.type == SecSolo) && r.chance (family == FamLofi ? 0.2f : 0.75f)) set (0, MomCrash);

    // inside: the beat keeps moving every 4 / 8 bars
    for (int b = 3; b < last; b += 4)
    {
        if (s.moment[(size_t) b] != MomNone) continue;
        const bool eight = (b + 1) % 8 == 0;
        if (family == FamRap && s.type == SecVerse)
        {
            if (eight && r.chance (0.25f)) set (b, MomDrop);
            else if (r.chance (0.3f)) set (b, MomFill);   // a hat roll
        }
        else if (family == FamBlues && (b + 1) % 12 == 0) set (b, MomFill);
        else if (family == FamLofi) { if (eight && r.chance (0.15f)) set (b, MomHalf); }
        else if (family == FamReggaeton && s.type == SecPre && b < 4 && r.chance (0.5f)) set (b, MomDrop);
        else if ((genre == Reggae || genre == Afro) && eight && r.chance (0.2f)) set (b, MomDrop);
        else if (eight && r.chance (family == FamDance ? 0.45f : family == FamJazz ? 0.4f : 0.3f)) set (b, MomFill);
    }
    // blues stop-time: the band hits and stops for the first bars of a chorus
    if (family == FamBlues && s.type == SecVerse && r.chance (0.25f)) for (int b = 0; b < std::min (4, last); ++b) set (b, MomStop);
    // a half-time bar at the end of a hook (rap, rock, cinematic)
    if ((family == FamRap || genre == Rock || family == FamCinema) && (s.type == SecHook || s.type == SecDrop)
        && nextType != SecHook && s.moment[(size_t) last] == MomFill && r.chance (0.3f))
        set (last, MomHalf);
    // dance: a drop-out bar before the end of a long groove
    if (family == FamDance && (s.type == SecVerse || s.type == SecDrop) && s.bars >= 16 && r.chance (0.35f)) set (last - 1, MomDrop);
}
} // namespace

//==============================================================================
const char* songSectionName (int type)
{
    static const char* names[numSongSectionTypes] = { "INTRO", "VERSE", "PRE", "HOOK", "BRIDGE", "BREAK", "BUILD", "DROP", "SOLO", "OUTRO" };
    return type >= 0 && type < numSongSectionTypes ? names[type] : "";
}

const char* songMomentName (int m)
{
    static const char* names[numSongMoments] = { "", "FILL", "STOP", "DROP", "BUILD", "CRASH", "HALF" };
    return m >= 0 && m < numSongMoments ? names[m] : "";
}

const char* songMomentShort (int m)
{
    static const char* names[numSongMoments] = { "", "F", "S", "D", "B", "C", "H" };
    return m >= 0 && m < numSongMoments ? names[m] : "";
}

bool songMomentAtEnd (int m) { return m == MomFill || m == MomStop || m == MomBuild; }

float SongSection::energyAt (int bar) const
{
    if (bars <= 1) return energyFrom;
    const float t = std::clamp ((float) bar / (float) (bars - 1), 0.0f, 1.0f);
    return energyFrom + (energyTo - energyFrom) * t;
}

int SongPlan::totalBars() const
{
    int n = 0;
    for (const auto& s : sections) n += s.bars;
    return n;
}

std::string SongPlan::describe() const
{
    std::string out;
    for (size_t i = 0; i < sections.size(); ++i)
    {
        if (i > 0) out += " | ";
        out += sections[i].label + " " + std::to_string (sections[i].bars);
    }
    return out;
}

int songFamily (int genre)
{
    switch (genre)
    {
        case HipHop: case Trap: case Drill: return FamRap;
        case House: return FamDance;
        case LoFi: return FamLofi;
        case Reggaeton: return FamReggaeton;
        case Cinematic: return FamCinema;
        case Jazz: return FamJazz;
        case Blues: return FamBlues;
        default: return FamSong;
    }
}

//==============================================================================
void songFillMasks (SongSection& s, int genre, const BandConfig& band, uint32_t seed)
{
    const int family = songFamily (genre);
    R r (seed ^ 0x51a7u);
    const int nt = std::clamp (band.numTracks, 0, (int) maxBandTracks);
    // each track's own entry point (a little different every section, so layers don't all move together)
    float thr[maxBandTracks];
    bool lateVerse = r.chance (0.5f), lateHook = r.chance (0.5f);
    for (int t = 0; t < nt; ++t)
    {
        const int ty = band.part[(size_t) t].type;
        float v = threshold (ty) + (r.uni() - 0.5f) * 0.08f;
        if (s.type == SecIntro || s.type == SecOutro)
        {
            if (isLead (ty)) v += 0.3f;
            if (family == FamDance) { if (isBed (ty)) v += 0.15f; if (bandTypeIsDrums (ty)) v -= 0.15f; }
        }
        if (s.type == SecBreak)
        {
            const bool keepPerc = family == FamDance || genre == Afro || genre == Reggae || family == FamReggaeton;
            if (isBeatDrum (ty)) v = 2.0f;
            else if ((ty == BHats || ty == BPerc || ty == BOpenHat) && ! keepPerc) v = 2.0f;
            if (ty == BBass && (genre == Reggae || family == FamReggaeton)) v = 0.1f;   // dub / perreo: the bass carries it
            if (isLead (ty)) v = 2.0f;
        }
        if (s.type == SecSolo) { if (ty == BMelody) v = 0.0f; if (ty == BCounter) v = 2.0f; }
        if (s.type == SecDrop) v -= 0.1f;
        if (family == FamCinema && bandTypeIsDrums (ty)) v += 0.2f;
        if (family == FamLofi && (ty == BHorns || ty == BCounter)) v += 0.15f;
        thr[t] = v;
    }
    s.mask.assign ((size_t) s.bars, 0);
    for (int b = 0; b < s.bars; ++b)
    {
        const float e = s.energyAt (b);
        uint16_t m = 0;
        for (int t = 0; t < nt; ++t)
        {
            const int ty = band.part[(size_t) t].type;
            bool on = e >= thr[t];
            // a verse lets the melody in after the first phrase; a hook brings the extra voices in halfway
            if (s.type == SecVerse && ty == BMelody && lateVerse && s.bars >= 8 && b < 4) on = false;
            if (s.type == SecHook && (ty == BCounter || ty == BHorns) && lateHook && s.bars >= 8 && b < s.bars / 2) on = false;
            if (on) m = (uint16_t) (m | (1u << t));
        }
        s.mask[(size_t) b] = m;
    }
    // a flat section still breathes: one voice rests for a phrase, so even a 4-bar loop keeps moving
    if (std::abs (s.energyTo - s.energyFrom) < 0.05f && s.bars >= 8 && r.chance (0.75f))
    {
        int cand[maxBandTracks], n = 0;
        for (int t = 0; t < nt; ++t)
            if (! bandTypeIsDrums (band.part[(size_t) t].type) && band.part[(size_t) t].type != BBass && ((s.mask[0] >> t) & 1u)) cand[n++] = t;
        if (n > 0)
        {
            const int t = cand[r.pick (n)];
            const int start = 4 * (1 + r.pick (s.bars / 4 - 1));
            for (int b = start; b < std::min (s.bars, start + 4); ++b) s.mask[(size_t) b] = (uint16_t) (s.mask[(size_t) b] & ~(1u << t));
        }
    }
    if ((int) s.moment.size() != s.bars) s.moment.resize ((size_t) s.bars, (uint8_t) MomNone);
}

SongPlan makeSongPlan (int genre, int number, const BandConfig& band)
{
    SongPlan p;
    p.genre = std::clamp (genre, 0, numGenres - 1);
    p.number = std::clamp (number, 1, maxSongNumber);
    const int family = songFamily (p.genre);
    R r ((uint32_t) (p.genre * 100003 + p.number * 7919));
    auto& S = p.sections;
    auto add = [&] (int type, int bars, float e0, float e1, const char* label = nullptr, int groove = 0) { S.push_back (make (type, bars, e0, e1, label, groove)); };

    switch (family)
    {
        case FamRap:
        {
            const int intro = r.of ({ 4, 8 }), verse = r.of ({ 16, 16, 12, 8 }), hook = r.of ({ 8, 8, 16 });
            const int hookGroove = r.chance (0.5f) ? 1 : 0;
            const bool switchBeat = (p.genre == Trap || p.genre == Drill) && r.chance (0.35f);
            const int form = r.pick (4);
            add (SecIntro, intro, 0.3f, 0.45f);
            if (form == 0 || form == 2) add (SecHook, hook, 0.85f, 0.85f, nullptr, hookGroove);
            if (form == 3)
            {
                for (int i = 0; i < 3; ++i)
                {
                    add (SecVerse, 8, 0.6f, 0.62f, nullptr, (i == 2 && switchBeat) ? 100 + r.pick (50) : 0);
                    add (SecHook, hook, 0.85f, 0.88f, nullptr, hookGroove);
                }
            }
            else
            {
                add (SecVerse, verse, 0.58f, 0.62f);
                add (SecHook, hook, 0.85f, 0.88f, nullptr, hookGroove);
                if (form == 1)
                {
                    add (SecVerse, verse, 0.6f, 0.64f, nullptr, switchBeat ? 100 + r.pick (50) : 0);
                    add (SecHook, hook, 0.86f, 0.9f, nullptr, hookGroove);
                    add (SecBridge, 8, 0.5f, 0.55f);
                    add (SecHook, hook, 0.9f, 0.9f, nullptr, hookGroove);
                }
                else
                {
                    if (form == 2) add (SecBreak, 4, 0.3f, 0.35f);
                    add (SecVerse, verse, 0.6f, 0.64f, nullptr, switchBeat ? 100 + r.pick (50) : 0);
                    add (SecHook, hook, 0.88f, 0.92f, nullptr, hookGroove);
                    if (form == 2) add (SecHook, hook, 0.92f, 0.95f, "LAST HOOK", hookGroove);
                }
            }
            add (SecOutro, r.of ({ 4, 8 }), 0.5f, 0.25f);
            break;
        }
        case FamSong:
        {
            const int g = p.genre;
            const int intro = r.of ({ 4, 4, 8 }), verse = r.of ({ 8, 16, 16 }), hook = r.of ({ 8, 8, 16 });
            const bool pre = r.chance ((g == Pop || g == Soul || g == NeoSoul || g == Gospel || g == Country) ? 0.6f : 0.3f);
            const int preLen = r.of ({ 4, 8 });
            const int hookGroove = r.chance (0.4f) ? 1 : 0;
            add (SecIntro, intro, 0.3f, 0.45f);
            for (int round = 0; round < 2; ++round)
            {
                add (SecVerse, g == Funk ? 16 : verse, 0.5f, 0.6f, nullptr, round == 1 && r.chance (0.3f) ? 2 : 0);
                if (pre) add (SecPre, preLen, 0.6f, 0.75f);
                add (SecHook, g == Latin ? 16 : hook, 0.8f, 0.82f, nullptr, hookGroove);
            }
            if (r.chance (0.25f)) add (SecVerse, 8, 0.55f, 0.6f);
            // the middle: a solo, a breakdown or a bridge, the way that genre does it
            if (g == Rock || g == Country) add (SecSolo, 8, 0.75f, 0.8f);
            else if (g == Latin) add (SecSolo, 16, 0.8f, 0.85f, "MAMBO");
            else if (g == Funk) add (SecBreak, 8, 0.35f, 0.45f, "BREAKDOWN");
            else if (g == Reggae) add (SecBreak, 8, 0.3f, 0.35f, "DUB");
            else if (g == Afro) add (SecBreak, 8, 0.35f, 0.4f, "PERC BREAK");
            else add (SecBridge, 8, 0.5f, 0.6f);
            if ((g == Rock || g == Pop) && r.chance (0.4f)) add (SecBuild, 2, 0.6f, 0.9f);
            if (g == Gospel) add (SecHook, 16, 0.85f, 1.0f, "VAMP", hookGroove);
            else
            {
                add (SecHook, hook, 0.85f, 0.88f, nullptr, hookGroove);
                if (r.chance (0.5f)) add (SecHook, hook, 0.92f, 0.95f, "LAST HOOK", hookGroove);
            }
            add (SecOutro, r.of ({ 4, 8 }), 0.5f, 0.2f);
            break;
        }
        case FamDance:
        {
            add (SecIntro, r.of ({ 16, 32 }), 0.45f, 0.55f);
            add (SecVerse, 16, 0.6f, 0.7f, "GROOVE");
            add (SecBuild, 8, 0.5f, 0.95f);
            add (SecDrop, r.of ({ 16, 32 }), 1.0f, 1.0f);
            add (SecBreak, 16, 0.25f, 0.35f, "BREAKDOWN");
            add (SecBuild, 8, 0.4f, 1.0f);
            if (r.chance (0.4f)) { add (SecDrop, 16, 1.0f, 1.0f); add (SecDrop, 16, 1.0f, 1.0f, "DROP 2", 100 + r.pick (50)); }
            else add (SecDrop, 32, 1.0f, 1.0f);
            add (SecOutro, r.of ({ 16, 32 }), 0.6f, 0.35f);
            break;
        }
        case FamLofi:
        {
            const int a = r.of ({ 8, 8, 16 });
            add (SecIntro, 4, 0.2f, 0.25f);
            add (SecVerse, a, 0.5f, 0.55f, "A");
            add (SecHook, 8, 0.6f, 0.65f, "B");
            add (SecVerse, a, 0.5f, 0.55f, "A");
            add (SecBreak, 4, 0.25f, 0.3f);
            add (SecHook, 8, 0.62f, 0.65f, "B");
            if (r.chance (0.5f)) add (SecHook, 8, 0.6f, 0.62f, "B");
            add (SecVerse, a, 0.5f, 0.5f, "A");
            add (SecOutro, 4, 0.3f, 0.1f);
            break;
        }
        case FamReggaeton:
        {
            const int hook = r.of ({ 8, 16 });
            add (SecIntro, r.of ({ 4, 8 }), 0.35f, 0.45f);
            add (SecVerse, 16, 0.6f, 0.62f);
            add (SecPre, 8, 0.55f, 0.75f);
            add (SecHook, hook, 0.9f, 0.9f);
            add (SecVerse, r.of ({ 8, 16 }), 0.6f, 0.62f);
            add (SecPre, r.of ({ 4, 8 }), 0.55f, 0.75f);
            add (SecHook, hook, 0.9f, 0.92f);
            if (r.chance (0.6f)) add (SecBreak, 8, 0.45f, 0.5f, "PERREO");
            else add (SecBridge, 8, 0.5f, 0.55f);
            add (SecHook, hook, 0.92f, 0.95f, "LAST HOOK");
            add (SecOutro, 4, 0.5f, 0.3f);
            break;
        }
        case FamCinema:
        {
            add (SecIntro, 8, 0.15f, 0.25f);
            add (SecVerse, 8, 0.35f, 0.4f, "A");
            add (SecBuild, 8, 0.4f, 0.8f);
            add (SecHook, 8, 0.85f, 0.88f, "THEME");
            add (SecBreak, 8, 0.25f, 0.3f, "QUIET");
            add (SecBuild, 8, 0.5f, 1.0f);
            add (SecDrop, r.of ({ 8, 16 }), 1.0f, 1.0f, "CLIMAX");
            add (SecOutro, 8, 0.5f, 0.1f);
            break;
        }
        case FamJazz:
        {
            add (SecIntro, r.of ({ 4, 8 }), 0.4f, 0.45f);
            add (SecVerse, 32, 0.6f, 0.62f, "HEAD");
            const int solos = 1 + r.pick (2);
            for (int i = 0; i < solos; ++i) add (SecSolo, 32, 0.7f + 0.05f * i, 0.78f + 0.05f * i, "SOLOS");
            add (SecVerse, 32, 0.65f, 0.68f, "HEAD");
            add (SecOutro, r.of ({ 4, 8 }), 0.5f, 0.3f, "TAG");
            break;
        }
        case FamBlues:
        default:
        {
            add (SecIntro, 4, 0.45f, 0.5f);
            const int verses = 2 + r.pick (2);
            for (int i = 0; i < verses; ++i) add (SecVerse, 12, 0.6f, 0.62f);
            const int solos = 1 + r.pick (2);
            for (int i = 0; i < solos; ++i) add (SecSolo, 12, 0.72f, 0.78f);
            add (SecVerse, 12, 0.65f, 0.68f);
            add (SecOutro, 4, 0.5f, 0.3f, "ENDING");
            break;
        }
    }

    for (size_t i = 0; i < S.size(); ++i)
    {
        placeMoments (S[i], i + 1 < S.size() ? S[i + 1].type : -1, family, p.genre, r);
        songFillMasks (S[i], p.genre, band, (uint32_t) (p.number * 131 + (int) i * 17 + p.genre));
    }
    return p;
}

namespace
{
void defaultEnergy (int type, float& e0, float& e1)
{
    switch (type)
    {
        case SecIntro:  e0 = 0.3f;  e1 = 0.45f; break;
        case SecVerse:  e0 = 0.55f; e1 = 0.62f; break;
        case SecPre:    e0 = 0.6f;  e1 = 0.75f; break;
        case SecHook:   e0 = 0.85f; e1 = 0.88f; break;
        case SecBridge: e0 = 0.5f;  e1 = 0.6f;  break;
        case SecBreak:  e0 = 0.3f;  e1 = 0.35f; break;
        case SecBuild:  e0 = 0.5f;  e1 = 0.95f; break;
        case SecDrop:   e0 = 1.0f;  e1 = 1.0f;  break;
        case SecSolo:   e0 = 0.75f; e1 = 0.8f;  break;
        case SecOutro:  e0 = 0.5f;  e1 = 0.2f;  break;
        default:        e0 = 0.55f; e1 = 0.6f;  break;
    }
}

int defaultBars (int family, int type)
{
    if (family == FamBlues && (type == SecVerse || type == SecSolo)) return 12;
    if (family == FamJazz && (type == SecVerse || type == SecSolo)) return 32;
    if (family == FamDance) return type == SecBuild ? 8 : (type == SecBreak ? 16 : 16);
    switch (type)
    {
        case SecIntro: case SecOutro: case SecBreak: return 4;
        case SecPre: return 4;
        case SecBuild: return 4;
        case SecVerse: return family == FamRap ? 16 : 8;
        default: return 8;
    }
}
} // namespace

SongSection songMakeSection (int genre, int type, int bars, const BandConfig& band, uint32_t seed)
{
    genre = std::clamp (genre, 0, numGenres - 1);
    type = std::clamp (type, 0, numSongSectionTypes - 1);
    const int family = songFamily (genre);
    float e0, e1;
    defaultEnergy (type, e0, e1);
    SongSection s = make (type, bars > 0 ? bars : defaultBars (family, type), e0, e1);
    R r (seed * 7919u + (uint32_t) type * 31u + 3u);
    placeMoments (s, -1, family, genre, r);
    songFillMasks (s, genre, band, seed * 131u + (uint32_t) type);
    return s;
}

void songReplaceMoments (SongPlan& plan, int fromIndex, uint32_t seed)
{
    const int family = songFamily (plan.genre);
    R r (seed * 389u + 11u);
    for (int i = std::max (0, fromIndex); i < (int) plan.sections.size(); ++i)
    {
        auto& s = plan.sections[(size_t) i];
        if ((int) s.moment.size() != s.bars) s.moment.assign ((size_t) s.bars, (uint8_t) MomNone);
        placeMoments (s, i + 1 < (int) plan.sections.size() ? plan.sections[(size_t) (i + 1)].type : -1, family, plan.genre, r);
    }
}

std::vector<SongShape> songShapes (int genre)
{
    std::vector<SongShape> v;
    auto shape = [&] (const char* name, std::initializer_list<SongShapePart> parts) { v.push_back ({ name, std::vector<SongShapePart> (parts) }); };
    switch (songFamily (genre))
    {
        case FamRap:
            shape ("RAP: HOOK FIRST", { { SecIntro, 4, "" }, { SecHook, 8, "" }, { SecVerse, 16, "" }, { SecHook, 8, "" }, { SecVerse, 16, "" }, { SecHook, 8, "" }, { SecOutro, 4, "" } });
            shape ("RAP: VERSE FIRST", { { SecIntro, 8, "" }, { SecVerse, 16, "" }, { SecHook, 8, "" }, { SecVerse, 16, "" }, { SecHook, 8, "" }, { SecBridge, 8, "" }, { SecHook, 8, "" }, { SecOutro, 4, "" } });
            shape ("SHORT 8-BAR VERSES", { { SecIntro, 4, "" }, { SecVerse, 8, "" }, { SecHook, 8, "" }, { SecVerse, 8, "" }, { SecHook, 8, "" }, { SecVerse, 8, "" }, { SecHook, 8, "" }, { SecOutro, 4, "" } });
            shape ("TWO VERSES + BEAT SWITCH", { { SecIntro, 4, "" }, { SecHook, 8, "" }, { SecVerse, 16, "" }, { SecHook, 8, "" }, { SecBreak, 4, "SWITCH" }, { SecVerse, 16, "" }, { SecHook, 8, "" }, { SecOutro, 8, "" } });
            break;
        case FamDance:
            shape ("CLUB", { { SecIntro, 16, "" }, { SecVerse, 16, "GROOVE" }, { SecBuild, 8, "" }, { SecDrop, 16, "" }, { SecBreak, 16, "BREAKDOWN" }, { SecBuild, 8, "" }, { SecDrop, 32, "" }, { SecOutro, 16, "" } });
            shape ("RADIO EDIT", { { SecIntro, 8, "" }, { SecVerse, 16, "" }, { SecBuild, 4, "" }, { SecDrop, 16, "" }, { SecBreak, 8, "" }, { SecBuild, 4, "" }, { SecDrop, 16, "" }, { SecOutro, 8, "" } });
            break;
        case FamLofi:
            shape ("LO-FI LOOP", { { SecIntro, 4, "" }, { SecVerse, 8, "A" }, { SecHook, 8, "B" }, { SecVerse, 8, "A" }, { SecBreak, 4, "" }, { SecHook, 8, "B" }, { SecOutro, 4, "" } });
            shape ("TAPE A-A-B-A", { { SecIntro, 4, "" }, { SecVerse, 8, "A" }, { SecVerse, 8, "A" }, { SecHook, 8, "B" }, { SecVerse, 8, "A" }, { SecOutro, 4, "" } });
            break;
        case FamReggaeton:
            shape ("REGGAETON", { { SecIntro, 4, "" }, { SecVerse, 16, "" }, { SecPre, 8, "" }, { SecHook, 8, "" }, { SecVerse, 8, "" }, { SecPre, 4, "" }, { SecHook, 8, "" }, { SecBreak, 8, "PERREO" }, { SecHook, 8, "" }, { SecOutro, 4, "" } });
            break;
        case FamCinema:
            shape ("CUE", { { SecIntro, 8, "" }, { SecVerse, 8, "A" }, { SecBuild, 8, "" }, { SecHook, 8, "THEME" }, { SecBreak, 8, "QUIET" }, { SecBuild, 8, "" }, { SecDrop, 16, "CLIMAX" }, { SecOutro, 8, "" } });
            break;
        case FamJazz:
            shape ("HEAD - SOLOS - HEAD", { { SecIntro, 4, "" }, { SecVerse, 32, "HEAD" }, { SecSolo, 32, "SOLOS" }, { SecVerse, 32, "HEAD" }, { SecOutro, 4, "TAG" } });
            break;
        case FamBlues:
            shape ("12-BAR", { { SecIntro, 4, "" }, { SecVerse, 12, "" }, { SecVerse, 12, "" }, { SecSolo, 12, "" }, { SecVerse, 12, "" }, { SecOutro, 4, "ENDING" } });
            break;
        default: break;
    }
    // shapes every genre can use
    shape ("RADIO: VERSE - PRE - HOOK", { { SecIntro, 4, "" }, { SecVerse, 8, "" }, { SecPre, 4, "" }, { SecHook, 8, "" }, { SecVerse, 8, "" }, { SecPre, 4, "" }, { SecHook, 8, "" }, { SecBridge, 8, "" }, { SecHook, 8, "" }, { SecOutro, 4, "" } });
    shape ("VERSE - HOOK (NO PRE)", { { SecIntro, 4, "" }, { SecVerse, 16, "" }, { SecHook, 8, "" }, { SecVerse, 16, "" }, { SecHook, 8, "" }, { SecOutro, 4, "" } });
    shape ("WITH A SOLO", { { SecIntro, 4, "" }, { SecVerse, 8, "" }, { SecHook, 8, "" }, { SecVerse, 8, "" }, { SecHook, 8, "" }, { SecSolo, 8, "" }, { SecHook, 8, "" }, { SecOutro, 4, "" } });
    shape ("GOSPEL: VAMP OUT", { { SecIntro, 4, "" }, { SecVerse, 8, "" }, { SecHook, 8, "CHORUS" }, { SecVerse, 8, "" }, { SecHook, 8, "CHORUS" }, { SecBridge, 8, "" }, { SecHook, 16, "VAMP" }, { SecOutro, 4, "" } });
    shape ("SHORT IDEA (INTRO - A - B - OUTRO)", { { SecIntro, 4, "" }, { SecVerse, 8, "" }, { SecHook, 8, "" }, { SecOutro, 4, "" } });
    return v;
}

SongPlan makeSongFromShape (int genre, int number, const BandConfig& band, const SongShape& shape)
{
    SongPlan p;
    p.genre = std::clamp (genre, 0, numGenres - 1);
    p.number = std::clamp (number, 1, maxSongNumber);
    const int family = songFamily (p.genre);
    R r ((uint32_t) (p.genre * 100003 + p.number * 7919 + (int) shape.parts.size() * 31));
    int hooks = 0;
    for (const auto& part : shape.parts)
    {
        float e0, e1;
        defaultEnergy (part.type, e0, e1);
        if (part.type == SecHook) { e0 += 0.02f * (float) hooks; e1 += 0.03f * (float) hooks; ++hooks; }   // every hook a little bigger
        p.sections.push_back (make (part.type, std::clamp (part.bars, 1, 64), std::min (1.0f, e0), std::min (1.0f, e1),
                                    part.label.empty() ? nullptr : part.label.c_str()));
    }
    for (size_t i = 0; i < p.sections.size(); ++i)
    {
        placeMoments (p.sections[i], i + 1 < p.sections.size() ? p.sections[i + 1].type : -1, family, p.genre, r);
        songFillMasks (p.sections[i], p.genre, band, (uint32_t) (p.number * 131 + (int) i * 17 + p.genre));
    }
    return p;
}

std::string songShapeText (const SongPlan& plan)
{
    std::string out;
    for (size_t i = 0; i < plan.sections.size(); ++i)
    {
        const auto& s = plan.sections[i];
        if (i > 0) out += ", ";
        out += songSectionName (s.type);
        if (! s.label.empty() && s.label != songSectionName (s.type)) out += " \"" + s.label + "\"";
        out += " " + std::to_string (s.bars);
    }
    return out;
}

int songSectionTypeFromName (const std::string& wordIn)
{
    std::string w;
    for (char c : wordIn) if (c != ' ' && c != '-' && c != '_') w += (char) std::tolower ((unsigned char) c);
    if (w == "intro") return SecIntro;
    if (w == "verse" || w == "head" || w == "a") return SecVerse;
    if (w == "pre" || w == "prechorus" || w == "prehook" || w == "lift") return SecPre;
    if (w == "hook" || w == "chorus" || w == "refrain" || w == "b" || w == "theme" || w == "vamp") return SecHook;
    if (w == "bridge" || w == "middle8") return SecBridge;
    if (w == "break" || w == "breakdown" || w == "dub" || w == "quiet") return SecBreak;
    if (w == "build" || w == "buildup" || w == "riser") return SecBuild;
    if (w == "drop" || w == "climax") return SecDrop;
    if (w == "solo" || w == "solos" || w == "mambo") return SecSolo;
    if (w == "outro" || w == "ending" || w == "end" || w == "tag") return SecOutro;
    return -1;
}

bool songShapeFromText (const std::string& text, SongShape& shape)
{
    shape.parts.clear();
    std::string cur;
    auto flush = [&]
    {
        // "HOOK 8", "VERSE \"A\" 16", "chorus 8"
        std::string word, label, num;
        bool inQuote = false;
        for (char c : cur)
        {
            if (c == '"') { inQuote = ! inQuote; continue; }
            if (inQuote) { label += c; continue; }
            if (std::isdigit ((unsigned char) c)) num += c;
            else if (std::isalpha ((unsigned char) c) || c == '-') word += c;
        }
        cur.clear();
        const int type = songSectionTypeFromName (word);
        if (type < 0) return;
        SongShapePart p;
        p.type = type;
        p.bars = num.empty() ? 8 : std::clamp (std::atoi (num.c_str()), 1, 64);
        p.label = label;
        shape.parts.push_back (p);
    };
    for (char c : text)
    {
        if (c == ',' || c == '|' || c == '\n' || c == ';') flush();
        else cur += c;
    }
    flush();
    return ! shape.parts.empty();
}

void songRerollSection (SongPlan& plan, int index, const BandConfig& band, uint32_t seed)
{
    if (index < 0 || index >= (int) plan.sections.size()) return;
    auto& s = plan.sections[(size_t) index];
    R r (seed * 977u + (uint32_t) index * 31u + 7u);
    const int family = songFamily (plan.genre);
    // a new length that still fits the genre's phrasing
    if (family == FamBlues && (s.type == SecVerse || s.type == SecSolo)) s.bars = 12;
    else if (family == FamJazz && (s.type == SecVerse || s.type == SecSolo)) s.bars = 32;
    else if (s.type == SecBuild) s.bars = r.of ({ 2, 4, 8 });
    else if (s.type == SecIntro || s.type == SecOutro || s.type == SecBreak) s.bars = family == FamDance ? r.of ({ 16, 32 }) : r.of ({ 4, 8 });
    else s.bars = family == FamDance ? r.of ({ 16, 32 }) : r.of ({ 8, 8, 16 });
    s.moment.assign ((size_t) s.bars, (uint8_t) MomNone);
    placeMoments (s, index + 1 < (int) plan.sections.size() ? plan.sections[(size_t) (index + 1)].type : -1, family, plan.genre, r);
    songFillMasks (s, plan.genre, band, seed * 131u + (uint32_t) index);
}
} // namespace vesper
