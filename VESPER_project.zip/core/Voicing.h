// Voicings: every way VESPER can stack a chord. No heap use on the play path.
#pragma once

#include "Guitar.h"
#include "Theory.h"

namespace vesper
{
enum Style
{
    Close = 0, Open, Drop2, Drop3, Drop24, Shell, RootlessA, RootlessB, Quartal,
    Lush, Fat, Wide, Cluster, UpperStructure, GuitarStyle, PowerRock, numStyles
};

const char* styleName (int style);       // "Drop 2"
const char* styleBlurb (int style);      // plain-language description
int genreDefaultStyle (int genre);
int genreVaryStyles (int genre, int* out);    // fills up to numStyles, returns count

// VOICE SETS: what VARY mixes, genre by genre. A few voicing styles that sound right together; VARY picks among the
// smoothest ways to get from the last chord (the top note never jumps more than `topLeap`, plus SPICE). The last set
// of every genre is COLORFUL: everything the genre does.
struct VoiceSet
{
    const char* name;
    const char* blurb;
    int styles[8];
    int numStyles;
    int topLeap;      // semitones the top note may move at SPICE 0 (SPICE adds up to 5 more)
};
int numVoiceSets (int genre);
const VoiceSet& voiceSetFor (int genre, int index);   // index is clamped
bool styleHasRootBass (int style);

int numVariants (const Chord&, int style);
std::string variantName (const Chord&, int style, int variant, bool flats);

// Builds one voicing with the root near MIDI 48 (before fitting to the register).
Notes buildVoicing (const Chord&, int style, int variant, const Shape* shapes = nullptr, int numShapes = -1);
Notes fitToCenter (Notes v, int center);

struct VoicingPick
{
    Notes notes;
    int style = 0;
    int variant = 0;
};

// smooth: pick the inversion that moves the least from `previous`
// vary:   pick a different random voicing than `avoid` (when avoid is not empty)
// voiceSet: -2 = the genre's old VARY list (only on a repeated chord), -1 = just `style` (VARY re-voices it), else a
// VOICE SET of the genre (VARY mixes it on every chord). spice 0..1: how adventurous VARY gets.
VoicingPick chooseVoicing (const Chord& chord, int style, int variant, int center,
                           bool smooth, const Notes& previous,
                           bool vary, const Notes& avoid, int genre, Rng& rng,
                           int voiceSet = -2, float spice = 0.5f, int prevRoot = -1);   // prevRoot: the last chord's root

// Bass note for the chord (slash bass if any), placed below the voicing.
int bassNoteFor (const Chord&, const Notes& voicing, int lowest = 28);

// STACK: what each key plays instead of the whole chord
enum StackMode { StackChord = 0, StackSingle, StackOctaves, Stack3rds, Stack4ths, Stack5ths, Stack6ths, StackPower, numStackModes };
const char* stackName (int mode);          // "STACKED 3RDS"
const char* stackBlurb (int mode);
// Built on the chord's root, placed at (or just under) `ref` - the key you pressed - so the keyboard
// plays in its own octaves. 3rds / 4ths / 5ths / 6ths are counted in the key (keyMask), so they never
// clash. count = how many notes (2 to 4; SINGLE is always 1, POWER always 3).
Notes stackVoicing (const Chord&, int mode, int count, int ref, int keyMask);
} // namespace vesper
