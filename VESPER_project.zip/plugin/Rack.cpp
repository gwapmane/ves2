#include "Rack.h"

namespace
{
constexpr int maxScratchChannels = 64;

// the instrument's own window, floating over FL like any plugin window
struct HostWindow : public juce::DocumentWindow
{
    HostWindow (const juce::String& title, juce::AudioProcessorEditor* ed)
        : juce::DocumentWindow (title, juce::Colour (0xff1d1f22), juce::DocumentWindow::closeButton | juce::DocumentWindow::minimiseButton)
    {
        setUsingNativeTitleBar (true);
        setContentOwned (ed, true);
        setResizable (ed->isResizable(), false);
        setAlwaysOnTop (true);
        centreWithSize (getWidth(), getHeight());
        setVisible (true);
    }
    void closeButtonPressed() override { setVisible (false); }
};

juce::Array<juce::File> instrumentFolders()
{
    juce::Array<juce::File> roots;
#if JUCE_WINDOWS
    roots.add (juce::File::getSpecialLocation (juce::File::globalApplicationsDirectory).getChildFile ("Common Files/VST3"));
    roots.add (juce::File ("C:/Program Files/Common Files/VST3"));
    roots.add (juce::File::getSpecialLocation (juce::File::userHomeDirectory).getChildFile ("AppData/Local/Programs/Common/VST3"));
#elif JUCE_MAC
    roots.add (juce::File ("/Library/Audio/Plug-Ins/VST3"));
    roots.add (juce::File::getSpecialLocation (juce::File::userHomeDirectory).getChildFile ("Library/Audio/Plug-Ins/VST3"));
#else
    roots.add (juce::File::getSpecialLocation (juce::File::userHomeDirectory).getChildFile (".vst3"));
    roots.add (juce::File ("/usr/lib/vst3"));
    roots.add (juce::File ("/usr/local/lib/vst3"));
#endif
    return roots;
}
} // namespace

juce::String InstrumentRack::outputName (int slot)
{
    return slot == chordSlot ? juce::String ("CHORDS OUT") : "TRACK " + juce::String (slot) + " OUT";
}

InstrumentRack::InstrumentRack()
{
    formats.addFormat (new juce::VST3PluginFormat());
    for (auto& o : ownOutput) o.store (0);
}

InstrumentRack::~InstrumentRack()
{
    for (auto& s : slots)
    {
        s.window.reset();   // the instrument's editor goes before the instrument
        const juce::SpinLock::ScopedLockType sl (s.lock);
        s.inst.reset();
    }
}

juce::Array<juce::File> InstrumentRack::installedInstruments()
{
    juce::Array<juce::File> found;
    juce::StringArray seen;
    for (const auto& root : instrumentFolders())
    {
        if (! root.isDirectory()) continue;
        for (const auto& it : juce::RangedDirectoryIterator (root, true, "*.vst3", juce::File::findFilesAndDirectories))
        {
            const auto f = it.getFile();
            // a .vst3 bundle is a folder with another .vst3 inside it: only the outer one counts
            bool nested = false;
            for (auto d = f.getParentDirectory(); d != root && d.getFullPathName().length() > root.getFullPathName().length(); d = d.getParentDirectory())
                if (d.hasFileExtension ("vst3")) { nested = true; break; }
            if (nested) continue;
            const auto name = f.getFileNameWithoutExtension();
            if (name.equalsIgnoreCase ("VESPER") || name.containsIgnoreCase ("Troupe Chord Engine") || seen.contains (f.getFullPathName())) continue;   // not itself inside itself
            seen.add (f.getFullPathName());
            found.add (f);
        }
    }
    std::sort (found.begin(), found.end(), [] (const juce::File& a, const juce::File& b)
               { return a.getFileNameWithoutExtension().compareIgnoreCase (b.getFileNameWithoutExtension()) < 0; });
    return found;
}

bool InstrumentRack::load (int s, const juce::File& file, juce::String& error, const juce::MemoryBlock* state)
{
    if (s < 0 || s >= numSlots) return false;
    juce::OwnedArray<juce::PluginDescription> types;
    for (auto* fmt : formats.getFormats())
        if (fmt->fileMightContainThisPluginType (file.getFullPathName()))
            fmt->findAllTypesForFile (types, file.getFullPathName());
    if (types.isEmpty())
    {
        error = "TROUPE couldn't open " + file.getFileName() + " as an instrument.";
        return false;
    }
    const juce::PluginDescription* d = types[0];
    for (auto* t : types) if (t->isInstrument) { d = t; break; }
    auto inst = formats.createPluginInstance (*d, sr, block, error);
    if (inst == nullptr)
    {
        if (error.isEmpty()) error = "TROUPE couldn't open " + file.getFileName() + ".";
        return false;
    }
    inst->disableNonMainBuses();   // its main stereo out is all VESPER needs
    if (state != nullptr && state->getSize() > 0) inst->setStateInformation (state->getData(), (int) state->getSize());
    inst->setRateAndBufferSizeDetails (sr, block);
    inst->prepareToPlay (sr, block);

    auto& sl = slots[(size_t) s];
    sl.window.reset();
    std::unique_ptr<juce::AudioPluginInstance> old;
    {
        const juce::SpinLock::ScopedLockType lk (sl.lock);
        old = std::move (sl.inst);
        sl.inst = std::move (inst);
        sl.file = file;
        sl.name = d->name;
        sl.missing.clear();
    }
    has[(size_t) s].store (true);
    old.reset();
    changed.fetch_add (1);
    return true;
}

void InstrumentRack::unload (int s)
{
    if (s < 0 || s >= numSlots) return;
    auto& sl = slots[(size_t) s];
    sl.window.reset();
    std::unique_ptr<juce::AudioPluginInstance> old;
    {
        const juce::SpinLock::ScopedLockType lk (sl.lock);
        old = std::move (sl.inst);
        sl.file = juce::File();
        sl.name.clear();
        sl.missing.clear();
    }
    has[(size_t) s].store (false);
    old.reset();
    ownOutput[(size_t) s].store (0);
    changed.fetch_add (1);
}

void InstrumentRack::swap (int a, int b)
{
    if (a == b || a < 0 || b < 0 || a >= numSlots || b >= numSlots) return;
    auto& x = slots[(size_t) a];
    auto& y = slots[(size_t) b];
    x.window.reset();
    y.window.reset();
    {
        const juce::SpinLock::ScopedLockType l1 (x.lock);
        const juce::SpinLock::ScopedLockType l2 (y.lock);
        std::swap (x.inst, y.inst);
        std::swap (x.file, y.file);
        std::swap (x.name, y.name);
        std::swap (x.missing, y.missing);
    }
    const bool h = has[(size_t) a].load();
    has[(size_t) a].store (has[(size_t) b].load());
    has[(size_t) b].store (h);
    const int o = ownOutput[(size_t) a].load();
    ownOutput[(size_t) a].store (ownOutput[(size_t) b].load());
    ownOutput[(size_t) b].store (o);
    changed.fetch_add (1);
}

bool InstrumentRack::loaded (int s) const
{
    if (s < 0 || s >= numSlots) return false;
    const juce::SpinLock::ScopedLockType lk (slots[(size_t) s].lock);
    return slots[(size_t) s].inst != nullptr;
}

juce::String InstrumentRack::name (int s) const
{
    if (s < 0 || s >= numSlots) return {};
    const juce::SpinLock::ScopedLockType lk (slots[(size_t) s].lock);
    return slots[(size_t) s].name;
}

juce::String InstrumentRack::missing (int s) const
{
    if (s < 0 || s >= numSlots) return {};
    const juce::SpinLock::ScopedLockType lk (slots[(size_t) s].lock);
    return slots[(size_t) s].missing;
}

void InstrumentRack::showWindow (int s, const juce::String& title)
{
    if (s < 0 || s >= numSlots) return;
    auto& sl = slots[(size_t) s];
    if (sl.window != nullptr)
    {
        sl.window->setName (title);
        sl.window->setVisible (true);
        sl.window->toFront (true);
        return;
    }
    juce::AudioProcessorEditor* ed = nullptr;
    {
        const juce::SpinLock::ScopedLockType lk (sl.lock);
        if (sl.inst == nullptr) return;
    }
    // (creating the editor touches only the message-thread side of the instrument)
    ed = sl.inst->createEditorIfNeeded();
    if (ed == nullptr) ed = new juce::GenericAudioProcessorEditor (*sl.inst);
    sl.window = std::make_unique<HostWindow> (title, ed);
}

void InstrumentRack::hideWindow (int s)
{
    if (s >= 0 && s < numSlots && slots[(size_t) s].window != nullptr) slots[(size_t) s].window->setVisible (false);
}

bool InstrumentRack::windowShowing (int s) const
{
    return s >= 0 && s < numSlots && slots[(size_t) s].window != nullptr && slots[(size_t) s].window->isVisible();
}

std::unique_ptr<juce::XmlElement> InstrumentRack::toXml() const
{
    auto x = std::make_unique<juce::XmlElement> ("SOUNDS");
    for (int s = 0; s < numSlots; ++s)
    {
        const auto& sl = slots[(size_t) s];
        juce::MemoryBlock st;
        juce::String name, path, missing;
        {
            const juce::SpinLock::ScopedLockType lk (sl.lock);
            name = sl.name;
            path = sl.file.getFullPathName();
            missing = sl.missing;
        }
        if (name.isEmpty() && missing.isEmpty()) continue;
        if (sl.inst != nullptr) sl.inst->getStateInformation (st);
        auto* e = x->createNewChildElement ("SLOT");
        e->setAttribute ("index", s);
        e->setAttribute ("name", name.isNotEmpty() ? name : missing);
        e->setAttribute ("file", path);
        e->setAttribute ("out", ownOutput[(size_t) s].load());
        if (st.getSize() > 0) e->setAttribute ("state", st.toBase64Encoding());
    }
    return x;
}

void InstrumentRack::fromXml (const juce::XmlElement& x)
{
    for (int s = 0; s < numSlots; ++s) if (loaded (s)) unload (s);
    for (auto* e : x.getChildWithTagNameIterator ("SLOT"))
    {
        const int s = e->getIntAttribute ("index", -1);
        if (s < 0 || s >= numSlots) continue;
        juce::MemoryBlock st;
        st.fromBase64Encoding (e->getStringAttribute ("state"));
        juce::String err;
        const juce::File f (e->getStringAttribute ("file"));
        if (! (f.exists() && load (s, f, err, &st)))
        {
            const juce::SpinLock::ScopedLockType lk (slots[(size_t) s].lock);
            slots[(size_t) s].missing = e->getStringAttribute ("name", f.getFileNameWithoutExtension());
            slots[(size_t) s].file = f;
        }
        ownOutput[(size_t) s].store (e->getIntAttribute ("out", 0) != 0 ? 1 : 0);
    }
    changed.fetch_add (1);
}

void InstrumentRack::prepare (double sampleRate, int blockSize)
{
    sr = sampleRate > 0 ? sampleRate : 44100.0;
    block = juce::jmax (32, blockSize);
    scratch.setSize (maxScratchChannels, block, false, true, true);
    slotMidi.ensureSize (16384);
    keep.ensureSize (32768);
    for (auto& s : slots)
    {
        const juce::SpinLock::ScopedLockType lk (s.lock);
        if (s.inst == nullptr) continue;
        s.inst->releaseResources();
        s.inst->setRateAndBufferSizeDetails (sr, block);
        s.inst->prepareToPlay (sr, block);
    }
}

void InstrumentRack::release()
{
    for (auto& s : slots)
    {
        const juce::SpinLock::ScopedLockType lk (s.lock);
        if (s.inst != nullptr) s.inst->releaseResources();
    }
}

void InstrumentRack::process (juce::AudioProcessor& host, juce::AudioBuffer<float>& io, juce::MidiBuffer& midi,
                              const std::array<int, numSlots>& channelOf)
{
    const int n = io.getNumSamples();
    if (n <= 0) return;
    uint32_t taken = 0;
    for (int s = 0; s < numSlots; ++s)
    {
        const int ch = channelOf[(size_t) s];
        if (ch < 1 || ch > 16) continue;
        auto& sl = slots[(size_t) s];
        const juce::SpinLock::ScopedTryLockType lk (sl.lock);
        if (! lk.isLocked() || sl.inst == nullptr) continue;
        auto* p = sl.inst.get();
        taken |= 1u << (ch - 1);

        // its notes: on channel 1 (what nearly every instrument listens to), drums keep channel 10
        slotMidi.clear();
        for (const auto meta : midi)
        {
            auto m = meta.getMessage();
            if (m.getChannel() != ch) continue;
            if (ch != 10) m.setChannel (1);
            slotMidi.addEvent (m, meta.samplePosition);
        }
        const int chans = juce::jmax (2, p->getTotalNumInputChannels(), p->getTotalNumOutputChannels());
        if (chans > scratch.getNumChannels() || n > scratch.getNumSamples()) continue;
        juce::AudioBuffer<float> view (scratch.getArrayOfWritePointers(), chans, n);
        view.clear();
        p->setPlayHead (host.getPlayHead());
        p->processBlock (view, slotMidi);

        // MAIN, or its own output when FL has that output switched on
        int bus = 0;
        if (ownOutput[(size_t) s].load() != 0)
        {
            const int b = s + 1;
            if (b < host.getBusCount (false))
                if (auto* bb = host.getBus (false, b); bb != nullptr && bb->isEnabled()) bus = b;
        }
        auto dst = host.getBusBuffer (io, false, bus);
        const int pOut = juce::jmax (1, p->getTotalNumOutputChannels());
        for (int c = 0; c < dst.getNumChannels(); ++c) dst.addFrom (c, 0, view, juce::jmin (c, pOut - 1), 0, n);
    }
    if (taken == 0) return;
    // those notes stay inside VESPER: they don't go out as MIDI too
    keep.clear();
    for (const auto meta : midi)
    {
        const auto m = meta.getMessage();
        const int ch = m.getChannel();
        if (ch >= 1 && ch <= 16 && ((taken >> (ch - 1)) & 1u)) continue;
        keep.addEvent (m, meta.samplePosition);
    }
    midi.swapWith (keep);
}
