#pragma once

#include <juce_gui_basics/juce_gui_basics.h>

#include "Look.h"
#include "PluginProcessor.h"
#include "Perform.h"

juce::String toJ (const std::string& s);

// What the CURRENT CHORD panel is showing / editing.
struct Focus
{
    vesper::Chord chord;
    int style = -1, variant = -1;
    int origin = 0;     // 0 palette pad, 1 scale key, 2 library, 3 suggestion, 4 played on the keyboard
    int card = -1;      // palette index when origin == 0
    int key = -1;       // MIDI key that plays it, if any
};

// Implemented by the editor; lets the panels talk to each other.
class EditorContext
{
public:
    virtual ~EditorContext() = default;
    virtual VesperProcessor& proc() = 0;
    virtual const Theme& theme() const = 0;
    virtual void play (int source, const vesper::Chord&, int style, int variant) = 0;
    virtual void playNotes (int source, const vesper::Notes&, const vesper::Chord& label) = 0;
    virtual void release (int source) = 0;
    virtual const Focus& focus() const = 0;
    virtual void setFocus (const Focus&) = 0;
    virtual void selectCard (int index) = 0;
    virtual void sendToSelectedCard (const vesper::Chord&, int style, int variant) = 0;
    virtual void paletteEdited() = 0;
    virtual void dragChordOut (const vesper::Chord&, int style, int variant) = 0;
    virtual const PlayedInfo& lastPlayed() const = 0;
};

namespace src
{
    constexpr int pad = 1000, library = 2000, libraryTriad = 2001, scale = 3000, next = 4000, chordPanel = 4100, guitar = 4200;
}

//==============================================================================
class PaletteGrid : public juce::Component
{
public:
    explicit PaletteGrid (EditorContext& c) : ctx (c) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;

private:
    juce::Rectangle<float> cardRect (int i) const;
    int cardAt (juce::Point<int>) const;
    EditorContext& ctx;
    int pressed = -1, dragOver = -1;
    bool dragging = false, draggedOut = false;
};

//==============================================================================
class ScaleGrid : public juce::Component
{
public:
    explicit ScaleGrid (EditorContext& c) : ctx (c) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;

private:
    static constexpr int labelW = 104, headerH = 18;
    juce::Rectangle<float> cellRect (int row, int col) const;
    int noteAt (juce::Point<int>) const;
    int overflowRowAt (juce::Point<int>) const;
    EditorContext& ctx;
    int pressedNote = -1;
    bool draggedOut = false;
};

//==============================================================================
class LibraryView : public juce::Component
{
public:
    explicit LibraryView (EditorContext& c);
    ~LibraryView() override;
    void resized() override;
    void paint (juce::Graphics&) override;
    void syncFromFocus();
    void rebuild();

private:
    struct TypeList;
    struct VoicingList;
    struct TriadGrid;

    vesper::Chord current() const;
    void chooseRoot (int r);

    EditorContext& ctx;
    int root = 0, quality = 0, bass = -1, style = -1, variant = -1;
    juce::OwnedArray<juce::TextButton> rootButtons;
    juce::ComboBox bassBox;
    juce::TextButton toPad;
    std::unique_ptr<TypeList> typeList;
    std::unique_ptr<VoicingList> voicingList;
    std::unique_ptr<TriadGrid> triadGrid;
    juce::Viewport typeView, voicingView, triadView;
};

//==============================================================================
class ChordPanel : public juce::Component
{
public:
    explicit ChordPanel (EditorContext& c);
    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void refresh();

private:
    void edited();
    juce::Rectangle<int> nameArea() const;
    EditorContext& ctx;
    juce::TextButton prev { "<" }, next { ">" }, toPad { "TO PAD" };
    juce::ComboBox rootBox, typeBox, bassBox, styleBox, shapeBox;
    bool auditioning = false, refreshing = false;
};

//==============================================================================
class PreviewPanel : public juce::Component
{
public:
    explicit PreviewPanel (EditorContext& c);
    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void refresh();

private:
    juce::Rectangle<float> guitarArea() const;
    EditorContext& ctx;
    juce::TextButton prevShape { "<" }, nextShape { ">" };
    vesper::Chord chord;
    vesper::Shape shapes[vesper::maxShapes];
    int numShapes = 0, shapeIndex = 0;
};

//==============================================================================
class NextPanel : public juce::Component
{
public:
    explicit NextPanel (EditorContext& c) : ctx (c) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void refresh (const vesper::Chord& current);

private:
    juce::Rectangle<float> cardRect (int i) const;
    EditorContext& ctx;
    std::vector<vesper::Suggestion> items;
    std::vector<juce::String> where;
    std::vector<int> keys;
    int pressed = -1;
};

//==============================================================================
class KeyboardStrip : public juce::Component
{
public:
    explicit KeyboardStrip (EditorContext& c) : ctx (c) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;

private:
    juce::Rectangle<float> keyRect (int note) const;
    int noteAt (juce::Point<float>) const;
    float whiteW() const { return (float) getWidth() / 75.0f; }
    EditorContext& ctx;
    int pressedSource = -1;
};

//==============================================================================
class DragTile : public juce::Component
{
public:
    explicit DragTile (EditorContext& c) : ctx (c) {}
    void paint (juce::Graphics&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;

private:
    EditorContext& ctx;
    bool started = false;
};
