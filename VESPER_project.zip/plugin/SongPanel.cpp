#include "SongPanel.h"

#include <cmath>
#include <utility>

using namespace vesper;

namespace
{
const int padMoments[6] = { MomFill, MomStop, MomDrop, MomBuild, MomCrash, MomHalf };

juce::Colour momentColour (int m, const Theme& t)
{
    switch (m)
    {
        case MomFill:  return t.accent;
        case MomStop:  return juce::Colour (0xffe0574b);
        case MomDrop:  return juce::Colour (0xffd9963a);
        case MomBuild: return t.color;
        case MomCrash: return t.home;
        case MomHalf:  return t.move;
        default:       return t.dim;
    }
}

juce::Colour sectionColour (int type, const Theme& t)
{
    switch (type)
    {
        case SecHook: case SecDrop: return t.accent;
        case SecPre: case SecBuild: return t.color;
        case SecBreak: case SecBridge: return t.move;
        case SecSolo: return t.pull;
        case SecIntro: case SecOutro: return t.cardHi;
        default: return t.home;
    }
}
} // namespace

SongPanel::SongPanel (EditorContext& c) : ctx (c)
{
    auto& p = ctx.proc();
    playBtn.setTooltip ("Play the whole song: VESPER arranges the band around what you play (or your A-D loops, if you've "
                        "recorded them). Hit record in FL first and let it run");
    playBtn.onClick = [this] { auto& pr = ctx.proc(); pr.songOn.store (! pr.songOn.load()); };
    prevBtn.setTooltip ("The previous song shape");
    nextBtn.setTooltip ("The next song shape (there are 9999 for every genre)");
    prevBtn.onClick = [this] { auto& pr = ctx.proc(); pr.newSong (juce::jmax (1, pr.songNumber.load() - 1)); };
    nextBtn.onClick = [this] { auto& pr = ctx.proc(); pr.newSong (juce::jmin (maxSongNumber, pr.songNumber.load() + 1)); };
    diceBtn.setTooltip ("A random song shape for this genre");
    diceBtn.onClick = [this] { ctx.proc().newSong (1 + juce::Random::getSystemRandom().nextInt (maxSongNumber)); };
    loopBtn.setTooltip ("LOOP SECTION: stay in the section that's playing until you tap another one (DJ it). "
                        "Off: the song plays through, section after section");
    loopBtn.onClick = [this] { auto& pr = ctx.proc(); pr.songLoopSection.store (! pr.songLoopSection.load()); };
    followBtn.setTooltip ("FOLLOW ME: the song reacts to you. Dig in and the hook comes early; pull back and it breaks down; "
                          "change to a new progression and the next section starts with it (with a fill); stop playing "
                          "and the band plays the ending");
    followBtn.onClick = [this] { auto& pr = ctx.proc(); pr.followMe.store (! pr.followMe.load()); };
    for (auto* b : { &playBtn, &prevBtn, &nextBtn, &diceBtn, &loopBtn, &followBtn }) addAndMakeVisible (b);

    static const char* tips[6] = {
        "FILL: a drum fill into the next bar (a hat roll in hip-hop / trap / drill)",
        "STOP: the whole band stops on beat 4, then comes back in with a crash",
        "DROP: the beat drops out for a bar (everything else keeps going), then slams back in",
        "BUILD: a snare roll that speeds up and gets louder, into a crash",
        "CRASH: a crash cymbal on the one",
        "HALF: one bar of half time (kick on 1, snare on 3)" };
    for (int i = 0; i < 6; ++i)
    {
        padBtns[i].setButtonText (songMomentName (padMoments[i]));
        padBtns[i].setTooltip (juce::String (tips[i]) + ". Tap it: FILL / STOP / BUILD land at the end of this bar, the others on the next one. Works with the band even when no song is playing");
        padBtns[i].onClick = [this, i] { ctx.proc().momentTap.store (padMoments[i]); };
        addAndMakeVisible (padBtns[i]);
    }
    // ---- playing it live
    shapeBtn.setTooltip ("SHAPE: start from a whole arrangement - this genre's own shapes, or one you saved. Save the song you've "
                         "built (lengths, order) as your own shape to use again");
    shapeBtn.onClick = [this] { shapeMenu(); };
    switchBtn.setTooltip ("When a section you call starts: at the END OF THE PHRASE (every 4 bars - call it any time in the "
                          "phrase and it lands on the next one), on the NEXT BAR, or at the END OF THE SECTION");
    switchBtn.onClick = [this] { switchMenu(); };
    soloBtn.setTooltip ("SOLO: one player takes a solo (the lead, or who you pick: right-click). The other leads lay out and the bed "
                        "thins under it. It starts where a called section would (see the timing button), with a fill into it");
    soloBtn.onClick = [this] { if (std::exchange (menuClick, false)) return; ctx.proc().command (VesperProcessor::CmdSolo, ctx.proc().soloPick.load()); };
    jamBtn.setTooltip ("JAM: the whole band digs in for a few bars (right-click: how many) - busier parts and a fill every bar, "
                       "the biggest one at the end");
    jamBtn.onClick = [this] { if (std::exchange (menuClick, false)) return; ctx.proc().command (VesperProcessor::CmdJam); };
    transBtn.setTooltip ("TRANSITION: a change is coming. The next section gets queued (if you haven't called one) and the "
                         "drummer plays the biggest fill there is into it");
    transBtn.onClick = [this] { ctx.proc().command (VesperProcessor::CmdTransition); };
    catchBtn.setTooltip ("CATCH: VESPER is always listening. Played something great and weren't recording? CATCH turns the last 16 "
                         "bars of everything into a take (drag it from DRAG MIDI) and saves it in Documents/VESPER/Takes");
    catchBtn.onClick = [this] { ctx.proc().command (VesperProcessor::CmdCatch); };
    takeBtn.setTooltip ("TAKE: the sections you played and the calls you made, as they happened. Keep it as the song (then fix "
                        "any part of it right here and play it back exactly)");
    takeBtn.onClick = [this] { takeMenu(); };
    keysBtn.setTooltip ("KEYS: put sections, fills, stops, drop-outs, SOLO, JAM, TRANSITION and CATCH on keys of your "
                        "controller, so you can call the whole song with one hand");
    keysBtn.onClick = [this] { keysMenu(); };
    soloBtn.addMouseListener (this, false);
    jamBtn.addMouseListener (this, false);
    for (auto* b : { &shapeBtn, &switchBtn, &soloBtn, &jamBtn, &transBtn, &catchBtn, &takeBtn, &keysBtn }) addAndMakeVisible (b);
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    for (auto* k : { &moodKnob, &glideKnob })
    {
        k->setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        k->setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        k->onValueChange = [this] { repaint (536, 0, 140, 40); };
        addAndMakeVisible (k);
    }
    moodKnob.setTooltip ("MOOD: dark to bright. Brighter = chords voiced higher and played a touch harder, and CC74 (brightness / "
                         "filter on most synths) opens on every instrument; darker = the opposite. Double-click for the middle");
    glideKnob.setTooltip ("GLIDE: chords slide into each other. The built-in keys glide from the last chord's notes; your synths get "
                          "CC5 (glide time) and CC65 (glide on) - turn on legato / portamento in the synth to hear it");
    moodKnob.setDoubleClickReturnValue (true, 0.0);
    glideKnob.setDoubleClickReturnValue (true, 0.0);
    sliderAtt.push_back (std::make_unique<SA> (p.apvts, ids::mood, moodKnob));
    sliderAtt.push_back (std::make_unique<SA> (p.apvts, ids::glide, glideKnob));
    refreshRows();
    startTimerHz (20);
}

void SongPanel::flash (const juce::String& text)
{
    flashText = text;
    flashUntil = juce::Time::getMillisecondCounterHiRes() + 2500.0;
    repaint();
}

void SongPanel::shapeMenu()
{
    auto& p = ctx.proc();
    juce::PopupMenu m, del;
    const auto shapes = songShapes (p.bandGenreNow());
    m.addSectionHeader ("START FROM A SHAPE (" + juce::String (genreShort (p.bandGenreNow())) + ")");
    for (int i = 0; i < (int) shapes.size(); ++i) m.addItem (1 + i, shapes[(size_t) i].name);
    const auto saved = p.savedShapeNames();
    if (! saved.isEmpty())
    {
        m.addSectionHeader ("YOUR SHAPES");
        for (int i = 0; i < saved.size(); ++i) { m.addItem (500 + i, saved[i]); del.addItem (800 + i, saved[i]); }
    }
    m.addSeparator();
    m.addItem (400, "Save this song's shape as...");
    if (! saved.isEmpty()) m.addSubMenu ("Delete a saved shape", del);
    m.addItem (401, "Add a section at the end...");
    juce::Component::SafePointer<SongPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&shapeBtn), [safe, shapes, saved] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        auto& pr = safe->ctx.proc();
        if (r >= 1 && r <= (int) shapes.size()) { pr.songFromShape (shapes[(size_t) (r - 1)]); safe->flash (shapes[(size_t) (r - 1)].name); }
        else if (r >= 500 && r < 500 + saved.size())
        {
            SongShape sh;
            if (pr.loadSavedShape (saved[r - 500], sh)) { pr.songFromShape (sh); safe->flash (saved[r - 500]); }
        }
        else if (r >= 800 && r < 800 + saved.size()) pr.deleteShape (saved[r - 800]);
        else if (r == 401)
        {
            juce::PopupMenu add;
            for (int ty = 0; ty < numSongSectionTypes; ++ty) add.addItem (1 + ty, songSectionName (ty));
            add.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&safe->shapeBtn), [safe] (int ty)
            {
                if (safe == nullptr || ty <= 0) return;
                auto& p2 = safe->ctx.proc();
                p2.songInsertSection ((int) p2.songPlanCopy().sections.size() - 1, ty - 1, -1);
            });
        }
        else if (r == 400)
        {
            auto* w = new juce::AlertWindow ("Save this shape", "A name for it (the sections and their lengths are saved; any genre can use it):",
                                             juce::MessageBoxIconType::NoIcon);
            w->addTextEditor ("name", "");
            w->addButton ("SAVE", 1, juce::KeyPress (juce::KeyPress::returnKey));
            w->addButton ("Cancel", 0, juce::KeyPress (juce::KeyPress::escapeKey));
            w->enterModalState (true, juce::ModalCallbackFunction::create ([safe, w] (int res)
            {
                if (res == 1 && safe != nullptr) { safe->ctx.proc().saveShape (w->getTextEditorContents ("name")); safe->flash ("Shape saved"); }
            }), true);
        }
    });
}

void SongPanel::switchMenu()
{
    auto& p = ctx.proc();
    juce::PopupMenu m;
    m.addSectionHeader ("A SECTION YOU CALL STARTS...");
    m.addItem (2, "At the end of the phrase (every 4 bars)", true, p.switchAt.load() == 1);
    m.addItem (1, "On the next bar", true, p.switchAt.load() == 0);
    m.addItem (3, "At the end of the section", true, p.switchAt.load() == 2);
    m.addSeparator();
    m.addItem (10, "A fill into every section I call", true, p.fillIntoCalls.load());
    juce::Component::SafePointer<SongPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&switchBtn), [safe] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        auto& pr = safe->ctx.proc();
        if (r == 10) pr.fillIntoCalls.store (! pr.fillIntoCalls.load());
        else pr.switchAt.store (r == 1 ? 0 : (r == 2 ? 1 : 2));
        safe->repaint();
    });
}

void SongPanel::soloMenu()
{
    auto& p = ctx.proc();
    juce::PopupMenu m, len;
    m.addSectionHeader ("WHO SOLOS");
    m.addItem (1, "VESPER picks (the lead: melody, horns, guitar, keys...)", true, p.soloPick.load() < 0);
    for (int t = 0; t < p.numTracks.load(); ++t)
    {
        if (p.trackValue (t, TpOn) < 0.5f || bandTypeIsDrums (p.trackType (t))) continue;
        const auto nm = p.trackName (t).isNotEmpty() ? p.trackName (t) : juce::String (bandTypeName (p.trackType (t)));
        m.addItem (100 + t, "Track " + juce::String (t + 1) + ": " + nm, true, p.soloPick.load() == t);
    }
    for (int b : { 4, 8, 12, 16, 32 }) len.addItem (200 + b, juce::String (b) + " bars", true, p.soloBars.load() == b);
    m.addSubMenu ("How long", len);
    juce::Component::SafePointer<SongPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&soloBtn), [safe] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        auto& pr = safe->ctx.proc();
        if (r == 1) pr.soloPick.store (-1);
        else if (r >= 200) pr.soloBars.store (r - 200);
        else if (r >= 100) pr.soloPick.store (r - 100);
    });
}

void SongPanel::jamMenu()
{
    auto& p = ctx.proc();
    juce::PopupMenu m;
    m.addSectionHeader ("JAM FOR...");
    for (int b : { 2, 4, 8, 16 }) m.addItem (b, juce::String (b) + " bars", true, p.jamBars.load() == b);
    juce::Component::SafePointer<SongPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&jamBtn), [safe] (int r)
    {
        if (safe != nullptr && r > 0) safe->ctx.proc().jamBars.store (r);
    });
}

void SongPanel::takeMenu()
{
    auto& p = ctx.proc();
    juce::PopupMenu m;
    const auto text = p.performanceText();
    m.addSectionHeader (text.isEmpty() ? juce::String ("NO TAKE YET: press PLAY SONG and call the sections") : juce::String ("THE TAKE SO FAR"));
    if (text.isNotEmpty()) m.addItem (99, text.substring (0, 160) + (text.length() > 160 ? "..." : ""), false);
    m.addItem (1, "Keep it as the song (fix anything here, then play it back exactly)", text.isNotEmpty());
    m.addItem (2, "Start a new take", text.isNotEmpty());
    juce::Component::SafePointer<SongPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&takeBtn), [safe] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        auto& pr = safe->ctx.proc();
        if (r == 1) { pr.songOn.store (false); if (pr.keepPerformanceAsSong()) safe->flash ("The take is the song now"); }
        else if (r == 2) pr.clearPerformance();
    });
}

void SongPanel::keysMenu()
{
    auto& p = ctx.proc();
    juce::PopupMenu m;
    m.addSectionHeader ("PUT IT ON A KEY (pick one, then press the key)");
    for (int k = 0; k < VesperProcessor::numCommandKeys; ++k)
    {
        if (k == 10) m.addSeparator();
        const int key = p.commandKey[(size_t) k].load();
        m.addItem (1 + k, juce::String (VesperProcessor::commandKeyName (k))
                          + (key >= 0 ? "   [" + toJ (midiName (key, p.flats())) + "]" : juce::String()), true, key >= 0);
    }
    m.addSeparator();
    m.addItem (100, "Forget all these keys");
    juce::Component::SafePointer<SongPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&keysBtn), [safe] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        auto& pr = safe->ctx.proc();
        if (r == 100) { for (auto& k : pr.commandKey) k.store (-1); return; }
        pr.commandLearn.store (r - 1);
        safe->flash ("Press the key for " + juce::String (VesperProcessor::commandKeyName (r - 1)) + "...");
    });
}

SongPanel::~SongPanel() { stopTimer(); }

void SongPanel::resized()
{
    playBtn.setBounds (0, 14, 96, 24);
    prevBtn.setBounds (102, 14, 22, 24);
    nextBtn.setBounds (200, 14, 22, 24);
    diceBtn.setBounds (228, 14, 48, 24);
    shapeBtn.setBounds (282, 14, 56, 24);
    loopBtn.setBounds (344, 14, 100, 24);
    followBtn.setBounds (450, 14, 82, 24);
    moodKnob.setBounds (548, 12, 26, 26);
    glideKnob.setBounds (612, 12, 26, 26);
    switchBtn.setBounds (676, 14, 104, 24);
    const int y = getHeight() - 26;
    for (int i = 0; i < 6; ++i) padBtns[i].setBounds (labelW + i * 86, y, 80, 24);
    soloBtn.setBounds (640, y, 56, 24);
    jamBtn.setBounds (700, y, 50, 24);
    transBtn.setBounds (754, y, 96, 24);
    catchBtn.setBounds (856, y, 60, 24);
    takeBtn.setBounds (920, y, 54, 24);
    keysBtn.setBounds (978, y, 54, 24);
}

juce::Rectangle<int> SongPanel::gridArea() const
{
    return { labelW, rowTop, getWidth() - labelW, getHeight() - rowTop - 34 };
}

int SongPanel::viewSection() const
{
    const auto& p = ctx.proc();
    const int now = p.songSecNow.load();
    if (p.songOn.load() && now >= 0) return now;
    return juce::jlimit (0, juce::jmax (0, (int) plan.sections.size() - 1), viewSec);
}

juce::Rectangle<float> SongPanel::sectionRect (int s) const
{
    const int n = (int) plan.sections.size();
    if (s < 0 || s >= n) return {};
    const float w = (float) getWidth();
    const float minW = 46.0f, gap = 3.0f;
    const int total = juce::jmax (1, plan.totalBars());
    // proportional to length, but never too thin to read
    float extra = 0;
    for (const auto& sec : plan.sections) extra += juce::jmax (0.0f, minW - (w - gap * n) * (float) sec.bars / (float) total);
    const float scale = juce::jmax (0.1f, (w - gap * n - extra) / (w - gap * n));
    float x = 0;
    for (int i = 0; i < n; ++i)
    {
        const float raw = (w - gap * n) * (float) plan.sections[(size_t) i].bars / (float) total;
        const float sw = raw * scale < minW ? minW : raw * scale;
        if (i == s) return { x, 44.0f, sw, 30.0f };
        x += sw + gap;
    }
    return {};
}

int SongPanel::rowAt (int y) const
{
    const auto g = gridArea();
    const int n = (int) rows.size() + 1;
    const float h = (float) g.getHeight() / (float) n;
    const int r = (int) std::floor ((y - g.getY()) / h);
    return r >= 0 && r < n ? r - 1 : -2;   // -1 = the moments row
}

int SongPanel::barAt (int x) const
{
    const int s = viewSection();
    if (s < 0 || s >= (int) plan.sections.size()) return -1;
    const auto g = gridArea();
    const int bars = plan.sections[(size_t) s].bars;
    const float w = (float) g.getWidth() / (float) bars;
    const int b = (int) std::floor ((x - g.getX()) / w);
    return b >= 0 && b < bars ? b : -1;
}

void SongPanel::refreshRows()
{
    auto& p = ctx.proc();
    rows.clear();
    uint32_t sig = (uint32_t) p.numTracks.load();
    for (int t = 0; t < p.numTracks.load(); ++t)
        if (p.trackValue (t, TpOn) > 0.5f) { rows.push_back (t); sig = sig * 31u + (uint32_t) t + 1u + (uint32_t) p.trackType (t) * 97u; }
    rowSig = sig;
}

void SongPanel::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    drawCaption (g, { 0.0f, 0.0f, 96.0f, 12.0f }, "SONG", t);
    drawCaption (g, { 102.0f, 0.0f, 120.0f, 12.0f }, juce::String (genreName (plan.genre)), t);
    g.setFont (uiFont (12.5f, true));
    g.setColour (t.text);
    g.drawText ("SONG " + juce::String (plan.number).paddedLeft ('0', 4), juce::Rectangle<float> (124.0f, 14.0f, 76.0f, 24.0f), juce::Justification::centred);
    drawCaption (g, { 540.0f, 0.0f, 60.0f, 12.0f }, "MOOD", t);
    drawCaption (g, { 604.0f, 0.0f, 60.0f, 12.0f }, "GLIDE", t);
    {
        g.setFont (uiFont (9.5f, true));
        g.setColour (t.dim);
        const float mood = (float) moodKnob.getValue();
        g.drawText (std::abs (mood) < 0.05f ? juce::String ("MID") : (mood < 0 ? "DARK " : "BRIGHT ") + juce::String (juce::roundToInt (std::abs (mood) * 100.0f)),
                    juce::Rectangle<float> (574.0f, 18.0f, 40.0f, 14.0f), juce::Justification::centredLeft);
        const double gl = glideKnob.getValue();
        g.drawText (gl < 0.005 ? juce::String ("OFF") : juce::String (juce::roundToInt (gl * 1000.0)) + "ms",
                    juce::Rectangle<float> (638.0f, 18.0f, 40.0f, 14.0f), juce::Justification::centredLeft);
    }
    drawCaption (g, { 676.0f, 0.0f, 104.0f, 12.0f }, "CALLS LAND AT", t);
    g.setFont (uiFont (11.0f, true));
    g.setColour (p.songOn.load() ? t.text : t.dim);
    const bool flashing = juce::Time::getMillisecondCounterHiRes() < flashUntil && flashText.isNotEmpty();
    juce::String status = p.songStatus();
    if (const int solo = p.soloShown.load(); solo >= 0) status << "   SOLO: " << (p.trackName (solo).isNotEmpty() ? p.trackName (solo) : juce::String (bandTypeName (p.trackType (solo))));
    if (const int jam = p.jamShown.load(); jam > 0) status << "   JAM: " << jam << " bars";
    g.drawFittedText (status, juce::Rectangle<int> (786, 2, getWidth() - 786, 22), juce::Justification::centredLeft, 2, 0.8f);
    if (flashing)
    {
        g.setColour (t.accent);
        g.drawFittedText (flashText, juce::Rectangle<int> (786, 24, getWidth() - 786, 16), juce::Justification::centredLeft, 1, 0.8f);
    }

    // the sections, in order (tap one: it starts on the next bar line)
    const int now = p.songOn.load() ? p.songSecNow.load() : -1;
    const int queued = p.songJump.load();
    const int view = viewSection();
    const bool blink = (juce::Time::getMillisecondCounter() / 250) % 2 == 0;
    for (int s = 0; s < (int) plan.sections.size(); ++s)
    {
        const auto r = sectionRect (s);
        const auto& sec = plan.sections[(size_t) s];
        auto col = sectionColour (sec.type, t);
        g.setColour (s == now ? col : col.withAlpha (0.28f));
        g.fillRoundedRectangle (r, 5.0f);
        g.setColour (s == queued ? (blink ? t.text : t.accent) : (s == view ? t.text.withAlpha (0.7f) : t.panelEdge));
        g.drawRoundedRectangle (r.reduced (0.5f), 5.0f, s == queued ? 2.2f : (s == view ? 1.5f : 1.0f));
        g.setColour (s == now ? t.accentText : t.text);
        g.setFont (uiFont (r.getWidth() < 60 ? 9.0f : 10.5f, true));
        g.drawFittedText (juce::String (sec.label) + " " + juce::String (sec.bars), r.toNearestInt().reduced (3, 0), juce::Justification::centred, 1, 0.8f);
        if (s == now && sec.bars > 0)   // how far through it is
        {
            const float f = (float) (p.songBarNow.load() + 1) / (float) sec.bars;
            g.setColour (t.accentText.withAlpha (0.5f));
            g.fillRect (r.getX() + 3.0f, r.getBottom() - 4.0f, (r.getWidth() - 6.0f) * juce::jlimit (0.0f, 1.0f, f), 2.0f);
        }
    }

    // who plays in every bar of the section in view, and the moments
    const auto ga = gridArea();
    if (view >= 0 && view < (int) plan.sections.size())
    {
        const auto& sec = plan.sections[(size_t) view];
        const int n = (int) rows.size() + 1;
        const float rh = (float) ga.getHeight() / (float) n, cw = (float) ga.getWidth() / (float) sec.bars;
        const int playBar = (now == view) ? p.songBarNow.load() : -1;
        g.setFont (uiFont (juce::jmin (11.0f, rh * 0.62f), true));
        for (int r = -1; r < (int) rows.size(); ++r)
        {
            const float y = (float) ga.getY() + rh * (float) (r + 1);
            juce::String name;
            if (r < 0) name = "MOMENTS";
            else
            {
                const int tr = rows[(size_t) r];
                name = p.trackName (tr).isNotEmpty() ? p.trackName (tr) : juce::String (bandTypeName (p.trackType (tr)));
            }
            g.setColour (r < 0 ? t.dim : t.text);
            g.drawFittedText (name, juce::Rectangle<int> (0, (int) y, labelW - 8, (int) rh), juce::Justification::centredLeft, 1, 0.7f);
            for (int b = 0; b < sec.bars; ++b)
            {
                auto cell = juce::Rectangle<float> ((float) ga.getX() + cw * (float) b, y, cw, rh).reduced (juce::jmin (2.0f, cw * 0.12f), juce::jmin (2.0f, rh * 0.12f));
                if (r < 0)
                {
                    const int m = sec.moment[(size_t) b];
                    g.setColour (m != MomNone ? momentColour (m, t).withAlpha (0.9f) : t.cardDark.withAlpha (0.6f));
                    g.fillRoundedRectangle (cell, 3.0f);
                    if (m != MomNone)
                    {
                        g.setColour (t.accentText);
                        g.drawText (songMomentShort (m), cell, juce::Justification::centred);
                    }
                }
                else
                {
                    const bool on = (sec.mask[(size_t) b] >> rows[(size_t) r]) & 1u;
                    g.setColour (on ? sectionColour (sec.type, t).withAlpha (b == playBar ? 1.0f : 0.75f) : t.cardDark.withAlpha (0.55f));
                    g.fillRoundedRectangle (cell, 3.0f);
                }
                if (b == playBar)
                {
                    g.setColour (t.text.withAlpha (0.8f));
                    g.drawRoundedRectangle (cell, 3.0f, 1.2f);
                }
            }
        }
        if (rows.empty())
        {
            g.setColour (t.color);
            g.setFont (uiFont (11.0f, true));
            g.drawText ("Turn on some BAND tracks (or pick a GENRE on the BAND tab): the grid shows who plays in every bar", ga.toFloat(), juce::Justification::centred);
        }
    }
    drawCaption (g, { 0.0f, (float) getHeight() - 26.0f, (float) labelW - 6.0f, 24.0f }, "MOMENT PADS", t);
    drawCaption (g, { 1036.0f, (float) getHeight() - 26.0f, (float) getWidth() - 1036.0f, 24.0f }, "LIVE", t);
}

void SongPanel::mouseDown (const juce::MouseEvent& e)
{
    auto& p = ctx.proc();
    // right-click SOLO / JAM: who and how long
    if (e.originalComponent == &soloBtn) { if (e.mods.isPopupMenu()) { menuClick = true; soloMenu(); } return; }
    if (e.originalComponent == &jamBtn) { if (e.mods.isPopupMenu()) { menuClick = true; jamMenu(); } return; }
    const auto pos = e.getPosition();
    // a section: start it on the next bar line (right-click: more)
    for (int s = 0; s < (int) plan.sections.size(); ++s)
        if (sectionRect (s).contains (pos.toFloat()))
        {
            if (e.mods.isPopupMenu()) { sectionMenu (s); return; }
            viewSec = s;
            p.command (VesperProcessor::CmdGoTo, s);
            repaint();
            return;
        }
    // the grid: who plays in that bar, or the bar's moment
    if (gridArea().contains (pos))
    {
        const int s = viewSection(), b = barAt (pos.x), r = rowAt (pos.y);
        if (s < 0 || b < 0 || r < -1) return;
        if (r == -1)
        {
            const bool clear = e.mods.isPopupMenu();
            p.editSong ([&] (SongPlan& pl)
            {
                if (s >= (int) pl.sections.size()) return;
                auto& m = pl.sections[(size_t) s].moment[(size_t) b];
                m = clear ? (uint8_t) MomNone : (uint8_t) ((m + 1) % numSongMoments);
            });
        }
        else if (r < (int) rows.size())
        {
            const int tr = rows[(size_t) r];
            p.editSong ([&] (SongPlan& pl)
            {
                if (s >= (int) pl.sections.size()) return;
                auto& m = pl.sections[(size_t) s].mask[(size_t) b];
                m = (uint16_t) (m ^ (1u << tr));
            });
        }
    }
}

void SongPanel::sectionMenu (int s)
{
    juce::PopupMenu m, len;
    const auto& sec = plan.sections[(size_t) s];
    m.addSectionHeader (juce::String (sec.label) + " (" + juce::String (sec.bars) + " bars)");
    m.addItem (1, "Play it now (from the next bar)");
    m.addItem (2, "Loop it (stay here until you tap another section)");
    m.addItem (3, "A new take on this section (length, moments, who plays)");
    for (int b : { 2, 4, 8, 12, 16, 24, 32 }) len.addItem (100 + b, juce::String (b) + " bars", true, sec.bars == b);
    m.addSubMenu ("Length", len);
    m.addItem (4, "Clear its moments");
    m.addItem (5, "Everyone plays every bar");
    m.addSeparator();
    juce::PopupMenu retype, add;
    for (int ty = 0; ty < numSongSectionTypes; ++ty)
    {
        retype.addItem (300 + ty, songSectionName (ty), true, sec.type == ty);
        add.addItem (400 + ty, songSectionName (ty));
    }
    m.addSubMenu ("Change it to", retype);
    m.addSubMenu ("Add a section after it", add);
    m.addItem (6, "Copy it (the copy goes right after)");
    m.addItem (7, "Move it left", s > 0);
    m.addItem (8, "Move it right", s + 1 < (int) plan.sections.size());
    m.addItem (9, "Remove it", plan.sections.size() > 1);
    juce::Component::SafePointer<SongPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options(), [safe, s] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        auto& p = safe->ctx.proc();
        safe->viewSec = s;
        if (r >= 300 && r < 300 + numSongSectionTypes) { p.songRetypeSection (s, r - 300); return; }
        if (r >= 400 && r < 400 + numSongSectionTypes) { p.songInsertSection (s, r - 400, -1); safe->viewSec = s + 1; return; }
        if (r == 6) { p.songDuplicateSection (s); return; }
        if (r == 7) { p.songMoveSection (s, -1); safe->viewSec = s - 1; return; }
        if (r == 8) { p.songMoveSection (s, 1); safe->viewSec = s + 1; return; }
        if (r == 9) { p.songRemoveSection (s); safe->viewSec = juce::jmax (0, s - 1); return; }
        if (r == 1 || r == 2)
        {
            if (r == 2) p.songLoopSection.store (true);
            p.command (VesperProcessor::CmdGoTo, s);
        }
        else if (r == 3) p.rerollSongSection (s);
        else if (r == 4) p.editSong ([s] (SongPlan& pl) { if (s < (int) pl.sections.size()) std::fill (pl.sections[(size_t) s].moment.begin(), pl.sections[(size_t) s].moment.end(), (uint8_t) MomNone); });
        else if (r == 5) p.editSong ([s] (SongPlan& pl) { if (s < (int) pl.sections.size()) std::fill (pl.sections[(size_t) s].mask.begin(), pl.sections[(size_t) s].mask.end(), (uint16_t) 0xffff); });
        else if (r > 100)
        {
            const int bars = r - 100;
            p.editSong ([s, bars] (SongPlan& pl)
            {
                if (s >= (int) pl.sections.size()) return;
                auto& sec = pl.sections[(size_t) s];
                const uint16_t lastMask = sec.mask.empty() ? (uint16_t) 0xffff : sec.mask.back();
                sec.mask.resize ((size_t) bars, lastMask);
                sec.moment.resize ((size_t) bars, (uint8_t) MomNone);
                sec.bars = bars;
            });
        }
        safe->repaint();
    });
}

void SongPanel::timerCallback()
{
    auto& p = ctx.proc();
    bool dirty = false;
    if (p.songPlanChanged.load() != lastChanged)
    {
        lastChanged = p.songPlanChanged.load();
        plan = p.songPlanCopy();
        dirty = true;
    }
    {
        const uint32_t before = rowSig;
        refreshRows();
        if (rowSig != before) dirty = true;
    }
    const int sec = p.songSecNow.load(), bar = p.songBarNow.load(), jump = p.songJump.load(), mom = p.momentShown.load();
    const bool on = p.songOn.load();
    if (sec != lastSec || bar != lastBar || jump != lastJump || on != lastOn || mom != lastMoment || p.songNumber.load() != lastNumber)
    {
        lastSec = sec; lastBar = bar; lastJump = jump; lastOn = on; lastMoment = mom; lastNumber = p.songNumber.load();
        dirty = true;
    }
    if (jump >= 0) dirty = true;   // the queued section blinks
    playBtn.setToggleState (on, juce::dontSendNotification);
    playBtn.setButtonText (on ? "STOP SONG" : "PLAY SONG");
    loopBtn.setToggleState (p.songLoopSection.load(), juce::dontSendNotification);
    followBtn.setToggleState (p.followMe.load(), juce::dontSendNotification);
    for (int i = 0; i < 6; ++i) padBtns[i].setToggleState (on && mom == padMoments[i], juce::dontSendNotification);
    {
        static const char* sw[3] = { "NEXT BAR", "PHRASE END", "SECTION END" };
        switchBtn.setButtonText (sw[juce::jlimit (0, 2, p.switchAt.load())]);
        soloBtn.setToggleState (p.soloShown.load() >= 0, juce::dontSendNotification);
        jamBtn.setToggleState (p.jamShown.load() > 0, juce::dontSendNotification);
        keysBtn.setToggleState (p.commandLearn.load() >= 0, juce::dontSendNotification);
        if (p.commandCount.load() != lastCmdCount)   // a call you made (here, on a key, or by voice): show it
        {
            lastCmdCount = p.commandCount.load();
            const auto said = p.lastCommandText();
            if (said.isNotEmpty()) flash (said);
        }
        if (p.perfChanged.load() != lastPerf) { lastPerf = p.perfChanged.load(); takeBtn.setTooltip (p.performanceText().isEmpty() ? takeBtn.getTooltip() : p.performanceText()); }
        if (flashUntil > 0 && juce::Time::getMillisecondCounterHiRes() > flashUntil) { flashUntil = 0; dirty = true; }
    }
    const auto st = p.songStatus();
    if (st != lastStatus) { lastStatus = st; dirty = true; }
    if (dirty) repaint();
}
