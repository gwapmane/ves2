// The chord looper: play a progression once and VESPER keeps playing it, in time, as if you kept pressing the keys.
// Four sections (A-D), each with its own loop and groove. MAKE IT A SONG strings them into intro / verse / chorus /
// bridge / outro on its own.
#pragma once

#include <juce_audio_basics/juce_audio_basics.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <vector>

struct LoopEvent { double beat = 0; uint8_t note = 60, vel = 0, ch = 1; };   // vel 0 = key up

struct LoopSection
{
    std::vector<LoopEvent> evs;   // reserved up front: the audio thread never grows it past `cap`
    double len = 0;               // in beats, 0 = nothing recorded
    int groove = -1;              // the groove it was recorded with
};

class Looper
{
public:
    static constexpr int numSections = 4, cap = 4096;
    enum State { Off = 0, Armed, Recording, Playing };
    Looper() { for (auto& s : sec) s.evs.reserve (cap); }

    // ---- from the UI (picked up at the start of the next block)
    std::atomic<int> cmd { 0 };              // 1 record a new loop, 2 play, 3 stop
    std::atomic<int> bars { 4 };
    std::atomic<int> wantSection { -1 };     // switch at the next bar line
    // ---- for the UI
    std::atomic<int> state { Off }, section { 0 };
    std::atomic<uint32_t> filled { 0 };      // bit per section that has a loop
    std::atomic<double> position { 0 };      // beats into the loop
    std::atomic<double> length { 0 };

    std::array<LoopSection, numSections> sec;
    bool justSwitched = false;               // a section change happened this block (the drummer crashes)
    double switchBeat = 0;
    int cycles = 0;                          // how many times the loop has come round

    // a key you played (real keys only): recorded while recording, starts the recording when armed
    void record (const juce::MidiMessage& m, double beat, bool synced)
    {
        if (! (m.isNoteOn() || m.isNoteOff())) return;
        const int st = state.load();
        if (st == Armed && m.isNoteOn())
        {
            recStart = synced ? std::floor (beat / 4.0 + 1e-6) * 4.0 : beat;   // FL playing: from that bar's start
            state.store (Recording);
        }
        if (state.load() != Recording) return;
        if (beat - recStart >= juce::jlimit (1, 16, bars.load()) * 4.0) return;   // past the end: it's already playing
        auto& s = sec[(size_t) section.load()];
        if ((int) s.evs.size() >= cap) return;
        LoopEvent e;
        e.beat = std::max (0.0, beat - recStart);
        e.note = (uint8_t) m.getNoteNumber();
        e.vel = (uint8_t) (m.isNoteOn() ? juce::jmax (1, (int) m.getVelocity()) : 0);
        e.ch = (uint8_t) m.getChannel();
        s.evs.push_back (e);
        recHeld[(size_t) (e.ch - 1)][e.note] = e.vel > 0;
    }

    // a real key-up for a key you were still holding when the recording ended (the loop is playing it now)
    bool swallowOff (const juce::MidiMessage& m)
    {
        if (! swallowOn || ! m.isNoteOff()) return false;
        auto& f = endHeld[(size_t) juce::jlimit (0, 15, m.getChannel() - 1)][(size_t) m.getNoteNumber()];
        if (! f) return false;
        f = false;
        swallowOn = false;
        for (auto& c : endHeld) for (bool b : c) swallowOn = swallowOn || b;
        return true;
    }
    bool swallowing() const { return swallowOn; }

    bool playing() const { return state.load() == Playing; }
    bool busy() const { const int s = state.load(); return s == Recording || s == Playing; }

    // first thing in every block (before the keys are recorded): FL jumping, and what you clicked
    void begin (double b0, double spb, int numSamples, bool synced, juce::MidiBuffer& inject)
    {
        // FL jumped or stopped: pick the loop up again from here
        if (std::abs (b0 - expect) > 0.05 && state.load() == Playing)
        {
            releaseAll (inject, 0);
            playStart = synced ? std::floor (b0 / 4.0 + 1e-6) * 4.0 : b0;
        }
        expect = b0 + numSamples / spb;
        commands (b0, synced, inject);
    }

    // then: the end of a recording, section changes, and the keys to play back (into `inject`)
    void process (double b0, double spb, int numSamples, bool synced, int grooveNow, juce::MidiBuffer& inject)
    {
        const double b1 = b0 + numSamples / spb;
        justSwitched = false;
        auto posOf = [&] (double beat) { return juce::jlimit (0, juce::jmax (0, numSamples - 1), (int) std::floor ((beat - b0) * spb)); };
        commands (b0, synced, inject);   // anything that came in since begin() (MAKE IT A SONG starting)

        // the recording ends after its bars: every key still down lets go, then it plays straight on
        if (state.load() == Recording)
        {
            const double len = juce::jlimit (1, 16, bars.load()) * 4.0;
            if (b1 >= recStart + len)
            {
                auto& s = sec[(size_t) section.load()];
                for (int c = 0; c < 16; ++c)
                    for (int n = 0; n < 128; ++n)
                        if (recHeld[(size_t) c][(size_t) n] && (int) s.evs.size() < cap)
                            s.evs.push_back ({ len - 0.01, (uint8_t) n, 0, (uint8_t) (c + 1) });
                std::sort (s.evs.begin(), s.evs.end(), [] (const LoopEvent& a, const LoopEvent& b) { return a.beat < b.beat; });
                endHeld = recHeld;   // you're still holding these: letting go of them mustn't cut the loop
                swallowOn = true;
                s.len = len;
                s.groove = grooveNow;
                filled.fetch_or (1u << section.load());
                playStart = recStart + len;
                cycles = 0;
                state.store (Playing);
            }
        }

        if (state.load() != Playing) { position.store (0); return; }

        // a section change waits for the next bar line
        {
            const int w = wantSection.load();
            if (w >= 0 && w != section.load())
            {
                const double bar = playStart + std::ceil ((b0 - playStart) / 4.0 - 1e-9) * 4.0;
                if (bar < b1)
                {
                    wantSection.store (-1);
                    if (sec[(size_t) w].len > 0)
                    {
                        // the old loop plays up to the bar line, the new one starts on it
                        emit (inject, b0, bar, b0, spb, numSamples);
                        releaseAll (inject, posOf (bar));
                        section.store (w);
                        playStart = bar;
                        cycles = 0;
                        justSwitched = true;
                        switchBeat = bar;
                        emit (inject, bar, b1, b0, spb, numSamples);
                        report (b1);
                        return;
                    }
                    // nothing recorded there: the loop just plays on
                }
            }
            else if (w == section.load()) wantSection.store (-1);
        }
        emit (inject, b0, b1, b0, spb, numSamples);
        report (b1);
    }

    // the beat where the loop comes round next (for the drummer's fills)
    double nextWrap (double beat) const
    {
        const double len = sec[(size_t) section.load()].len;
        if (len <= 0) return 1e18;
        return playStart + std::ceil ((beat - playStart) / len + 1e-9) * len;
    }
    double loopStart() const { return playStart; }

    void stopNow (juce::MidiBuffer& inject) { releaseAll (inject, 0); state.store (Off); }

    void commands (double b0, bool synced, juce::MidiBuffer& inject)
    {
        switch (cmd.exchange (0))
        {
            case 1:   // record a new loop into this section (or the one just picked)
                takeWanted();
                releaseAll (inject, 0);
                sec[(size_t) section.load()].evs.clear();
                sec[(size_t) section.load()].len = 0;
                filled.fetch_and (~(1u << section.load()));
                for (auto& c : recHeld) c.fill (false);
                for (auto& c : endHeld) c.fill (false);
                swallowOn = false;
                state.store (Armed);
                break;
            case 2:
                takeWanted();
                if (sec[(size_t) section.load()].len > 0)
                {
                    playStart = synced ? std::ceil (b0 / 4.0 - 1e-6) * 4.0 : b0;
                    cycles = 0;
                    state.store (Playing);
                }
                break;
            case 3:
                releaseAll (inject, 0);
                if (state.load() != Playing) { sec[(size_t) section.load()].evs.clear(); sec[(size_t) section.load()].len = 0; }
                state.store (Off);
                break;
            default: break;
        }

        // not playing: a section change is immediate
        if (state.load() != Playing && state.load() != Recording)
        {
            const int w = wantSection.exchange (-1);
            if (w >= 0 && w < numSections) section.store (w);
        }
    }

private:
    double recStart = 0, playStart = 0, expect = -1;
    void takeWanted() { const int w = wantSection.exchange (-1); if (w >= 0 && w < numSections) section.store (w); }
    std::array<std::array<bool, 128>, 16> recHeld {}, held {}, endHeld {};
    bool swallowOn = false;

    void report (double b1)
    {
        const double len = sec[(size_t) section.load()].len;
        length.store (len);
        position.store (len > 0 ? std::fmod (std::max (0.0, b1 - playStart), len) : 0.0);
    }

    void releaseAll (juce::MidiBuffer& inject, int pos)
    {
        for (int c = 0; c < 16; ++c)
            for (int n = 0; n < 128; ++n)
                if (held[(size_t) c][(size_t) n])
                {
                    inject.addEvent (juce::MidiMessage::noteOff (c + 1, n), pos);
                    held[(size_t) c][(size_t) n] = false;
                }
    }

    // the loop's keys between beats a and b
    void emit (juce::MidiBuffer& inject, double a, double b, double blockStart, double spb, int numSamples)
    {
        const auto& s = sec[(size_t) section.load()];
        if (s.len <= 0 || b <= a) return;
        const double p0 = a - playStart, p1 = b - playStart;
        if (p1 <= 0) return;
        const int k0 = (int) std::floor (std::max (0.0, p0) / s.len), k1 = (int) std::floor ((p1 - 1e-9) / s.len);
        for (int k = k0; k <= k1; ++k)
        {
            const double cycleAt = k * s.len;
            if (k > 0 && cycleAt >= p0 && cycleAt < p1)
            {
                releaseAll (inject, juce::jlimit (0, numSamples - 1, (int) ((playStart + cycleAt - blockStart) * spb)));
                ++cycles;
            }
            for (const auto& e : s.evs)
            {
                const double t = cycleAt + e.beat;
                if (t < p0 || t >= p1 || t < 0) continue;
                const int pos = juce::jlimit (0, numSamples - 1, (int) std::floor ((playStart + t - blockStart) * spb));
                if (e.vel > 0)
                {
                    inject.addEvent (juce::MidiMessage::noteOn (e.ch, e.note, (juce::uint8) e.vel), pos);
                    held[(size_t) (e.ch - 1)][e.note] = true;
                }
                else if (held[(size_t) (e.ch - 1)][e.note])
                {
                    inject.addEvent (juce::MidiMessage::noteOff (e.ch, e.note), pos);
                    held[(size_t) (e.ch - 1)][e.note] = false;
                }
            }
        }
    }
};
