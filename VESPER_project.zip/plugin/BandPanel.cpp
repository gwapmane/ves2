#include "BandPanel.h"
#include "SoundMenu.h"

#include <cmath>

using namespace vesper;

// layout (inside the 1124 x 266 content area)
static constexpr int listTop = 80, loopRowY = 51, stripH = 70, stripGapY = 3, colW = 552, colGap = 10;

//==============================================================================
// KEY STRIP
juce::Rectangle<float> KeyStrip::keyRect (int pc) const
{
    static const int whiteIndex[12] = { 0, -1, 1, -1, 2, 3, -1, 4, -1, 5, -1, 6 };
    static const float blackPos[12] = { 0, 1, 0, 2, 0, 0, 4, 0, 5, 0, 6, 0 };   // the white key it sits after
    const auto b = getLocalBounds().toFloat().reduced (0.5f);
    const float ww = b.getWidth() / 7.0f;
    if (whiteIndex[pc] >= 0)
        return { b.getX() + ww * (float) whiteIndex[pc], b.getY(), ww, b.getHeight() };
    const float bw = ww * 0.62f;
    return { b.getX() + ww * blackPos[pc] - bw * 0.5f, b.getY(), bw, b.getHeight() * 0.58f };
}

int KeyStrip::keyAt (juce::Point<float> p) const
{
    for (int pc : { 1, 3, 6, 8, 10 }) if (keyRect (pc).contains (p)) return pc;
    for (int pc : { 0, 2, 4, 5, 7, 9, 11 }) if (keyRect (pc).contains (p)) return pc;
    return -1;
}

void KeyStrip::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const int m = mask.load();
    const bool scaleMode = ctx.proc().ui.keysMode == 0;
    const bool on = isEnabled();
    static const char* letters[12] = { "C", "", "D", "", "E", "F", "", "G", "", "A", "", "B" };
    static const char* degrees[12] = { "1", "", "2", "", "3", "4", "", "5", "", "6", "", "7" };
    auto drawKey = [&] (int pc, bool black)
    {
        const auto r = keyRect (pc).reduced (black ? 0.0f : 0.6f, 0.0f);
        const bool muted = (m >> pc) & 1;
        juce::Colour fill = muted ? t.cardDark : (black ? t.home.darker (0.45f) : t.home);
        if (! on) fill = fill.withMultipliedSaturation (0.3f).withAlpha (0.5f);
        g.setColour (fill);
        g.fillRoundedRectangle (r, black ? 1.5f : 2.5f);
        g.setColour (t.panelEdge);
        g.drawRoundedRectangle (r, black ? 1.5f : 2.5f, 0.8f);
        if (muted)
        {
            g.setColour (t.dim.withAlpha (0.8f));
            const auto c = r.withSizeKeepingCentre (5.0f, 5.0f).translated (0.0f, black ? -1.0f : -3.0f);
            g.drawLine (c.getX(), c.getY(), c.getRight(), c.getBottom(), 1.1f);
            g.drawLine (c.getRight(), c.getY(), c.getX(), c.getBottom(), 1.1f);
        }
        if (! black && r.getWidth() >= 11.0f)
        {
            g.setFont (uiFont (8.5f, true));
            g.setColour (muted ? t.dim : t.bgBottom);
            g.drawText (scaleMode ? degrees[pc] : letters[pc], r.withTrimmedTop (r.getHeight() * 0.55f), juce::Justification::centred);
        }
    };
    for (int pc : { 0, 2, 4, 5, 7, 9, 11 }) drawKey (pc, false);
    for (int pc : { 1, 3, 6, 8, 10 }) drawKey (pc, true);
}

void KeyStrip::mouseDown (const juce::MouseEvent& e)
{
    const int k = keyAt (e.position);
    if (k < 0) return;
    const int m = mask.load();
    dragTo = ((m >> k) & 1) ? 0 : 1;   // 1 = sit out
    mask.store (dragTo ? (m | (1 << k)) : (m & ~(1 << k)));
    lastKey = k;
    repaint();
}

void KeyStrip::mouseDrag (const juce::MouseEvent& e)
{
    if (dragTo < 0) return;
    const int k = keyAt (e.position);
    if (k < 0 || k == lastKey) return;
    const int m = mask.load();
    mask.store (dragTo ? (m | (1 << k)) : (m & ~(1 << k)));
    lastKey = k;
    repaint();
}

//==============================================================================
void IconButton::paintButton (juce::Graphics& g, bool over, bool down)
{
    const auto& t = ctx.theme();
    const auto r = getLocalBounds().toFloat().reduced (0.5f);
    g.setColour (down ? t.cardDark : (over ? t.cardHi : t.card.brighter (0.06f)));
    g.fillRoundedRectangle (r, 4.0f);
    g.setColour (t.panelEdge);
    g.drawRoundedRectangle (r, 4.0f, 1.0f);
    g.setColour (isEnabled() ? t.text : t.faint);
    const auto c = r.getCentre();
    if (kind == DownArrow || kind == Left || kind == Right)
    {
        juce::Path p;
        if (kind == DownArrow) p.addTriangle (c.x - 4.5f, c.y - 2.5f, c.x + 4.5f, c.y - 2.5f, c.x, c.y + 3.0f);
        else if (kind == Left) p.addTriangle (c.x + 2.5f, c.y - 4.5f, c.x + 2.5f, c.y + 4.5f, c.x - 3.0f, c.y);
        else p.addTriangle (c.x - 2.5f, c.y - 4.5f, c.x - 2.5f, c.y + 4.5f, c.x + 3.0f, c.y);
        g.fillPath (p);
    }
    else
    {
        g.drawLine (c.x - 3.5f, c.y - 3.5f, c.x + 3.5f, c.y + 3.5f, 1.6f);
        g.drawLine (c.x + 3.5f, c.y - 3.5f, c.x - 3.5f, c.y + 3.5f, 1.6f);
    }
}

//==============================================================================
// one track
BandPanel::Strip::Strip (BandPanel& owner, int t)
    : panel (owner), ctx (owner.ctx), track (t),
      typeBtn (owner.ctx, IconButton::DownArrow), remove (owner.ctx, IconButton::Cross),
      drag (owner.ctx, t), keys (owner.ctx, owner.ctx.proc().trackKeys[(size_t) t])
{
    auto& p = ctx.proc();
    auto& apvts = p.apvts;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    type = p.trackType (track);

    on.setButtonText (bandTypeName (type));
    on.setClickingTogglesState (true);
    on.setTooltip ("Track " + juce::String (track + 1) + ": click to turn it on or off. Name it from the arrow menu next to it");
    soundBtn.setTooltip ("SOUND: load an instrument (Omnisphere, Analog Lab, VESPER DRUMS...) and this track plays it right "
                         "inside VESPER - no Patcher needed. Pick its preset in the window that opens. It can play on VESPER's "
                         "main output or its own output (its own mixer track in FL)");
    soundBtn.onClick = [this] { showSoundMenu (ctx.proc(), InstrumentRack::trackSlot (track), soundBtn); };
    addAndMakeVisible (soundBtn);
    on.getProperties().set ("radius", 4.0);
    addAndMakeVisible (on);
    buttonAtt.push_back (std::make_unique<BA> (apvts, ids::track (track, "On"), on));

    typeBtn.setTooltip ("TYPE: what this track is (melody, bass, drums, pad, keys, arp, guitar...). Any slot can be any instrument");
    typeBtn.onClick = [this] { showTypeMenu(); };
    addAndMakeVisible (typeBtn);

    for (int st = 0; st < bandNumStyles (type); ++st) style.addItem (bandStyleName (type, st), st + 1);
    style.onChange = [this]
    {
        const int idx = style.getSelectedItemIndex();
        if (idx >= 0 && lastMidiCount > 0) { ctx.proc().clearTrackMidi (track); lastStyle = -1; }
        if (idx >= 0 && idx != lastStyle)
        {
            lastStyle = idx;
            ctx.proc().setTrackValue (track, TpStyle, (float) idx);
            style.setTooltip (bandStyleBlurb (type, idx));
        }
    };
    addAndMakeVisible (style);

    dice.setTooltip ("A new line in the same style. Each roll is one of billions");
    dice.onClick = [this] { if (! ctx.proc().trackFlag (track, VesperProcessor::FlagLock)) ctx.proc().rollBandSeed (track); };
    addAndMakeVisible (dice);

    for (int ch = 1; ch <= 16; ++ch) channel.addItem ("CH " + juce::String (ch), ch);
    channel.setTooltip ("MIDI channel this track plays on. In Patcher, VFX Color Mapper output N = channel N");
    addAndMakeVisible (channel);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::track (track, "Ch"), channel));

    octave.addItemList ({ "OCT -2", "OCT -1", "OCT 0", "OCT +1", "OCT +2" }, 1);
    octave.setTooltip ("Move the track up or down an octave");
    addAndMakeVisible (octave);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::track (track, "Oct"), octave));

    dyn.addItemList ({ "DYN -", "CC1", "CC11", "1+11" }, 1);
    dyn.setTooltip ("Dynamics for the hand-written lines: sends swells and phrasing as CC. "
                    "Orchestral string libraries (Kontakt, Spitfire...) want CC1. Synths like Omnisphere: CC11 (expression)");
    addChildComponent (dyn);   // DYN lives in the track's arrow menu now
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::track (track, "Dyn"), dyn));

    auto knob = [this] (juce::Slider& s, const juce::String& tip)
    {
        s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        s.setTooltip (tip);
        addAndMakeVisible (s);
    };
    knob (density, "BUSY: how many notes. Low = sparse and laid back, high = busy");
    knob (complexity, "COMPLEX: how adventurous. Low = simple and safe, high = runs, leaps, fills, chromatic notes");
    knob (level, "LEVEL: how hard this track plays (velocity)");
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::track (track, "Dens"), density));
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::track (track, "Cplx"), complexity));
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::track (track, "Lvl"), level));
    knob (reworkKnob, "REWORK: your drum MIDI, played like a drummer of the genre would. Down = exactly as you wrote it; up = the "
                      "same bones (the kick on the one, the backbeat) with new details - hat patterns, ghost notes, kicks where "
                      "that style puts them, a fill at the end of the phrase. Lock the pieces you care about in the MIDI menu");
    reworkKnob.setRange (0.0, 100.0, 1.0);
    reworkKnob.setDoubleClickReturnValue (true, 0.0);
    reworkKnob.onValueChange = [this] { ctx.proc().trackRework[(size_t) track].store ((int) reworkKnob.getValue()); repaint (60, 36, 60, 30); };
    reworkKnob.setVisible (false);

    static const char* modeNames[numBandModes] = { "JAM", "HOLD", "RING" };
    static const char* modeTips[numBandModes] = {
        "JAM: plays its style along with your chords",
        "HOLD: plays exactly what you press, in this track's octave, for as long as you hold the key. No rhythm. "
        "Bass takes the bottom note, melody the top note, everything else the whole chord",
        "RING: one hit when you press a key, ringing until you press the next key (even after you let go). Stops when FL stops" };
    for (int m = 0; m < numBandModes; ++m)
    {
        modeBtns[m].setButtonText (modeNames[m]);
        modeBtns[m].setTooltip (modeTips[m]);
        modeBtns[m].setClickingTogglesState (false);
        modeBtns[m].onClick = [this, m] { ctx.proc().setTrackValue (track, TpMode, (float) m); sync(); };
        addAndMakeVisible (modeBtns[m]);
    }

    midiBtn.setTooltip ("YOUR MIDI: drag MIDI files (or a whole folder) onto this track, or click here. It plays them instead of "
                        "its style, a new file every 16 bars (or 1-8). Drums play as written; melodies and basslines move into "
                        "your key and follow your chords. DICE = another file, BUSY thins it out, COMPLEX varies it");
    midiBtn.onClick = [this] { showMidiMenu(); };
    addAndMakeVisible (midiBtn);
    drag.setTooltip ("Record (AUTO REC or REC), then drag just this track onto its own instrument's channel");
    addAndMakeVisible (drag);

    keys.setTooltip ("KEY STRIP: the keys on your controller (any octave). Lit keys play. Click a key and this track sits out "
                     "whenever you press it (drag across to do several). In SCALE mode the numbers are the chords: "
                     "1 = the I chord on C, 2 = ii on D ... 7 on B");
    addAndMakeVisible (keys);

    remove.setTooltip ("Remove this track (the tracks below move up)");
    remove.onClick = [this] { ctx.proc().removeTrack (track); };   // the panel rebuilds the strips on its next tick
    addAndMakeVisible (remove);

    lastSeed = p.bandSeed[(size_t) track].load();
    sync();
}

bool BandPanel::Strip::isInterestedInFileDrag (const juce::StringArray& files)
{
    for (const auto& f : files)
        if (juce::File (f).isDirectory() || juce::File (f).hasFileExtension ("mid;midi") || VesperProcessor::isBeatboxAudio (juce::File (f))) return true;
    return false;
}

// a note next to something (what BEATBOX heard)
static void showNote (juce::Component& anchor, const juce::String& text)
{
    auto* top = anchor.getTopLevelComponent();
    if (top == nullptr) return;
    auto label = std::make_unique<juce::Label> ("note", text);
    label->setFont (uiFont (13.0f, false));
    label->setJustificationType (juce::Justification::centredLeft);
    label->setMinimumHorizontalScale (1.0f);
    label->setSize (400, 92);
    juce::CallOutBox::launchAsynchronously (std::move (label), top->getLocalArea (&anchor, anchor.getLocalBounds()), top);
}

void BandPanel::Strip::filesDropped (const juce::StringArray& files, int, int)
{
    dropHover = false;
    juce::StringArray midi;
    juce::File audio;
    for (const auto& f : files)
        if (VesperProcessor::isBeatboxAudio (juce::File (f))) { if (audio == juce::File()) audio = juce::File (f); }
        else midi.add (f);
    if (audio != juce::File())
    {   // BEATBOX: a recording of you -> the beat
        showNote (*this, ctx.proc().loadBeatbox (track, audio));
        repaint();
        return;
    }
    ctx.proc().loadTrackMidi (track, midi);
    if (! on.getToggleState()) ctx.proc().setTrackValue (track, TpOn, 1.0f);
    repaint();
}

void BandPanel::Strip::showMidiMenu()
{
    auto& p = ctx.proc();
    const int count = p.trackMidiCount (track);
    juce::PopupMenu m;
    m.addSectionHeader (count > 0 ? "YOUR MIDI: " + juce::String (count) + " FILE" + (count == 1 ? "" : "S") : juce::String ("YOUR MIDI (or drag files onto the track)"));
    m.addItem (1, "Load MIDI files...");
    m.addItem (2, "Load a folder of MIDI...");
    if (bandTypeIsDrums (type))
        m.addItem (5, "BEATBOX: turn a recording of you beatboxing into this beat...");
    if (bandTypeIsDrums (type))
    {   // the map: which note plays which drum (for your channel rack / piano roll), and what the names do
        juce::PopupMenu map;
        map.addSectionHeader ("VESPER DRUMS' PADS (FL note names)");
        for (const auto& d : drumNoteMap())
            map.addItem (9900 + d.note, juce::String (d.name) + "  =  " + juce::String (midiName (d.note, false)) + "  (note " + juce::String (d.note) + ")", false);
        map.addSeparator();
        map.addSectionHeader ("YOUR CHANNEL RACK PARTS");
        map.addItem (9990, "Drop all of them at once (or a folder, or one FL export):", false);
        map.addItem (9991, "named kick / snare / clap / hat / open hat / rim / tom / perc...", false);
        map.addItem (9992, "each part lands on its pad, even if they're all on C5.", false);
        map.addItem (9993, "808 / bass parts go to your bass track.", false);
        m.addSubMenu ("Drum note map (which note plays which drum)", map);
    }
    if (count > 0)
    {
        juce::PopupMenu cyc;
        for (int b : { 1, 2, 4, 8, 16, 32 }) cyc.addItem (100 + b, "Every " + juce::String (b) + (b == 1 ? " bar" : " bars"), true, p.trackCycle (track) == b);
        m.addSubMenu ("New file", cyc);
        m.addItem (3, "Another file now (DICE)");
        m.addItem (4, "Clear: back to the style");
        if (bandTypeIsDrums (type))
        {
            const int rw = p.trackRework[(size_t) track].load();
            const int lk = p.trackReworkLock[(size_t) track].load();
            juce::PopupMenu am, lm;
            static const int amounts[5] = { 0, 25, 50, 75, 100 };
            static const char* amountNames[5] = { "Exactly as I wrote it", "25%: a new touch", "50%: new hats and ghosts",
                                                  "75%: more of the genre", "100%: same bones, new details" };
            for (int i = 0; i < 5; ++i) am.addItem (600 + i, amountNames[i], true, rw == amounts[i]);
            for (int pc = 0; pc < numDrumPieces; ++pc) lm.addItem (700 + pc, drumPieceName (pc), true, ((lk >> pc) & 1) != 0);
            m.addSeparator();
            m.addSubMenu ("REWORK (" + juce::String (rw) + "%)", am);
            m.addSubMenu ("REWORK never touches...", lm);
        }
    }
    juce::Component::SafePointer<Strip> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&midiBtn), [safe] (int r)
    {
        if (safe == nullptr || r == 0 || r >= 9900) return;
        auto& pr = safe->ctx.proc();
        const int tr = safe->track;
        if (r >= 600 && r < 605) { static const int amounts[5] = { 0, 25, 50, 75, 100 }; pr.trackRework[(size_t) tr].store (amounts[r - 600]); return; }
        if (r >= 700 && r < 700 + numDrumPieces) { pr.trackReworkLock[(size_t) tr].fetch_xor (1 << (r - 700)); return; }
        if (r == 5)
        {   // BEATBOX: pick the recording
            auto& panel = safe->panel;
            panel.chooser = std::make_unique<juce::FileChooser> ("A recording of you beatboxing (WAV is safest)",
                                                                 juce::File::getSpecialLocation (juce::File::userDocumentsDirectory),
                                                                 "*.wav;*.aif;*.aiff;*.flac;*.ogg;*.mp3;*.m4a;*.wma");
            juce::Component::SafePointer<Strip> ss (safe);
            panel.chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles, [ss, tr] (const juce::FileChooser& fc)
            {
                if (ss == nullptr || fc.getResult() == juce::File()) return;
                showNote (ss->midiBtn, ss->ctx.proc().loadBeatbox (tr, fc.getResult()));
            });
            return;
        }
        if (r == 3) pr.rollBandSeed (tr);
        else if (r == 4) pr.clearTrackMidi (tr);
        else if (r > 100) pr.setTrackCycle (tr, r - 100);
        else
        {
            auto& panel = safe->panel;
            panel.chooser = std::make_unique<juce::FileChooser> (r == 1 ? "MIDI files for track " + juce::String (tr + 1) : "A folder of MIDI files",
                                                                 juce::File::getSpecialLocation (juce::File::userDocumentsDirectory), "*.mid;*.midi");
            const int flags = juce::FileBrowserComponent::openMode
                            | (r == 1 ? juce::FileBrowserComponent::canSelectFiles | juce::FileBrowserComponent::canSelectMultipleItems
                                      : juce::FileBrowserComponent::canSelectDirectories);
            juce::Component::SafePointer<BandPanel> sp (&panel);
            panel.chooser->launchAsync (flags, [sp, tr] (const juce::FileChooser& fc)
            {
                if (sp == nullptr || fc.getResults().isEmpty()) return;
                juce::StringArray paths;
                for (const auto& f : fc.getResults()) paths.add (f.getFullPathName());
                sp->ctx.proc().loadTrackMidi (tr, paths);
                sp->ctx.proc().setTrackValue (tr, TpOn, 1.0f);
            });
        }
    });
}

namespace
{
// the keys of one octave, as chords in SCALE mode: 1 = C, 2 = D, 3 = E, 4 = F, 5 = G, 6 = A, 7 = B (bit = the key)
constexpr int k1 = 1 << 0, k2 = 1 << 2, k3 = 1 << 4, k4 = 1 << 5, k5 = 1 << 7, k6 = 1 << 9, k7 = 1 << 11;
struct SitPattern { const char* name; int mask; };
const SitPattern sitPatterns[] = {
    { "Plays on every chord", 0 },
    { "Sits out on 1, 4 and 5 (C, F, G keys)", k1 | k4 | k5 },
    { "Sits out on 2, 3 and 6 (D, E, A keys)", k2 | k3 | k6 },
    { "Sits out on 1 (C key)", k1 },
    { "Sits out on 7 (B key)", k7 },
    { "Only plays on 1, 4 and 5", 0xfff & ~(k1 | k4 | k5) },
    { "Only plays on 2, 3 and 6", 0xfff & ~(k2 | k3 | k6) },
    { "Only plays on 1, 3 and 5", 0xfff & ~(k1 | k3 | k5) },
};
constexpr int numSitPatterns = (int) (sizeof (sitPatterns) / sizeof (sitPatterns[0]));
} // namespace

void BandPanel::Strip::showTypeMenu()
{
    juce::PopupMenu m;
    m.addSectionHeader ("TRACK " + juce::String (track + 1) + " IS...");
    for (int ty = 0; ty < BKick; ++ty) m.addItem (ty + 1, bandTypeName (ty), true, ty == type);
    m.addSectionHeader ("ONE PIECE OF THE KIT (plays the GROOVE, on channel 10)");
    for (int ty = BKick; ty < numBandTypes; ++ty) m.addItem (ty + 1, bandTypeName (ty), true, ty == type);
    m.addSeparator();
    if (bandTypeCanHold (type))
    {
        juce::PopupMenu dm;
        const int dv = (int) std::lround (ctx.proc().trackValue (track, TpDyn));
        static const char* dn[4] = { "Off", "CC1 (orchestral string libraries)", "CC11 (synths like Omnisphere)", "CC1 + CC11" };
        for (int i = 0; i < 4; ++i) dm.addItem (2000 + i, dn[i], true, dv == i);
        m.addSubMenu ("Dynamics: swells as MIDI CC", dm);
    }
    {   // sit-outs: on chosen chords (the key strip), or by surprise
        juce::PopupMenu sm;
        const int sv = ctx.proc().trackSurprise[(size_t) track].load();
        sm.addItem (3000, "Off", true, sv == 0);
        sm.addItem (3001, "Now and then (about 1 chord in 5)", true, sv == 20);
        sm.addItem (3002, "Often (about 2 in 5)", true, sv == 40);
        sm.addItem (3003, "Mostly out (about 3 in 5)", true, sv == 60);
        m.addSubMenu ("Surprise sit-outs" + juce::String (sv > 0 ? " (ON)" : ""), sm);
        juce::PopupMenu pm;
        const int km = ctx.proc().trackKeys[(size_t) track].load() & 0xfff;
        for (int i = 0; i < numSitPatterns; ++i) pm.addItem (3100 + i, sitPatterns[i].name, true, km == sitPatterns[i].mask);
        m.addSubMenu ("Sit out on chords...", pm);
    }
    if (bandTypeCanHold (type) && type != BBass && type != BMelody && type != BCounter)
        m.addItem (4000, "On HOLD: play the chord's style (rhythm, strum, EXT)", true, ! ctx.proc().trackFlag (track, VesperProcessor::FlagPlainHold));
    if (! bandTypeIsDrums (type))
    {   // GLIDE for this track only (CC5 glide time + CC65 on, on its channel)
        const int gv = ctx.proc().trackGlide[(size_t) track].load();
        juce::PopupMenu gm;
        gm.addItem (5300, "Follow the GLIDE knob", true, gv == 0);
        gm.addItem (5301, "Never glide", true, gv < 0);
        for (int ms : { 40, 80, 150, 300, 600, 1000 }) gm.addItem (5400 + ms, juce::String (ms) + " ms", true, gv == ms);
        m.addSubMenu ("GLIDE for this track" + (gv > 0 ? " (" + juce::String (gv) + " ms)" : (gv < 0 ? juce::String (" (never)") : juce::String())), gm);
    }
    if (! bandTypeIsDrums (type))
    {   // CALL & RESPONSE: this track answers another one
        auto& pr = ctx.proc();
        const int v = pr.trackRespond[(size_t) track].load();
        const int caller = VesperProcessor::respondCaller (v);
        juce::PopupMenu cm;
        cm.addItem (5000, "Off", true, v == 0);
        for (int t = 0; t < pr.numTracks.load(); ++t)
        {
            if (t == track || bandTypeIsDrums (pr.trackType (t))) continue;
            const auto nm = pr.trackName (t).isNotEmpty() ? pr.trackName (t) : juce::String (bandTypeName (pr.trackType (t)));
            cm.addItem (5001 + t, "Answers track " + juce::String (t + 1) + ": " + nm, true, v != 0 && caller == t);
        }
        cm.addSeparator();
        cm.addItem (5100, "Echo the call (plays it back)", v != 0, v != 0 && VesperProcessor::respondMode (v) == 0);
        cm.addItem (5101, "Its own line (plays its style in the gaps)", v != 0, v != 0 && VesperProcessor::respondMode (v) == 1);
        cm.addItem (5110, "Call 1 bar, answer 1 bar", v != 0, v != 0 && VesperProcessor::respondBars (v) == 1);
        cm.addItem (5111, "Call 2 bars, answer 2 bars", v != 0, v != 0 && VesperProcessor::respondBars (v) == 2);
        m.addSubMenu ("CALL & RESPONSE" + juce::String (v != 0 ? " (ON)" : ""), cm);
    }
    m.addItem (4001, juce::String ("LOCK this track (the dice leave it alone") + (bandTypeIsDrums (type) ? ", and the groove)" : ")"),
               true, ctx.proc().trackFlag (track, VesperProcessor::FlagLock));
    if (bandTypeCanHold (type) && type != BBass)
    {
        const int ek = ctx.proc().trackExtKey[(size_t) track].load();
        juce::PopupMenu em;
        em.addItem (4002, "Use a key on my controller... (press it next)");
        if (ek >= 0) em.addItem (4003, "Forget its key (" + toJ (midiName (ek, ctx.proc().flats())) + ")");
        m.addSubMenu ("EXT key for this track only" + (ek >= 0 ? " (" + toJ (midiName (ek, ctx.proc().flats())) + ")" : juce::String()), em);
    }
    {
        const int ph = ctx.proc().trackPhraseNow[(size_t) track].load();
        juce::PopupMenu lm;
        const juce::String now = ph >= 0 ? juce::String (" (") + phraseVariantName (phraseLibrary()[(size_t) ph].variant) + ")" : juce::String();
        lm.addItem (4100, "LIKE the line it's playing" + now + " - play lines like it more", ph >= 0, ph >= 0 && phraseRating (ph) > 0);
        lm.addItem (4101, "SKIP the line it's playing" + now + " - never play it again", ph >= 0);
        lm.addItem (4102, "No opinion on this line", ph >= 0 && phraseRating (ph) != 0);
        lm.addSeparator();
        lm.addItem (4103, "Forget every like and skip (" + juce::String (ctx.proc().likedLines()) + " liked, "
                          + juce::String (ctx.proc().skippedLines()) + " skipped)");
        if (ph < 0) lm.addItem (4199, "(likes and skips work on lines from the phrase styles while the band plays)", false);
        m.addSubMenu ("LIKE / SKIP this line", lm);
    }
    m.addItem (1000, "Name this track... (" + (ctx.proc().trackName (track).isEmpty() ? juce::String ("e.g. Omnisphere - Warm Pad") : ctx.proc().trackName (track)) + ")");
    juce::Component::SafePointer<Strip> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&typeBtn), [safe] (int r)
    {
        if (r <= 0 || safe == nullptr) return;
        if (r == 1000) { safe->askName(); return; }
        if (r == 4000) { auto& pr = safe->ctx.proc(); pr.setTrackFlag (safe->track, VesperProcessor::FlagPlainHold, ! pr.trackFlag (safe->track, VesperProcessor::FlagPlainHold)); return; }
        if (r == 4001) { auto& pr = safe->ctx.proc(); pr.setTrackFlag (safe->track, VesperProcessor::FlagLock, ! pr.trackFlag (safe->track, VesperProcessor::FlagLock)); safe->repaint(); return; }
        if (r == 4002) { safe->ctx.proc().trackExtLearn.store (safe->track); return; }
        if (r == 5300 || r == 5301 || (r >= 5400 && r <= 6400))
        {
            safe->ctx.proc().trackGlide[(size_t) safe->track].store (r == 5300 ? 0 : (r == 5301 ? -1 : r - 5400));
            return;
        }
        if (r >= 5000 && r < 5200)
        {
            auto& pr = safe->ctx.proc();
            auto& slot = pr.trackRespond[(size_t) safe->track];
            const int v = slot.load();
            if (r == 5000) slot.store (0);
            else if (r < 5100) slot.store (VesperProcessor::packRespond (r - 5001, v != 0 ? VesperProcessor::respondMode (v) : 0, v != 0 ? VesperProcessor::respondBars (v) : 2));
            else if (v != 0 && (r == 5100 || r == 5101)) slot.store (VesperProcessor::packRespond (VesperProcessor::respondCaller (v), r - 5100, VesperProcessor::respondBars (v)));
            else if (v != 0) slot.store (VesperProcessor::packRespond (VesperProcessor::respondCaller (v), VesperProcessor::respondMode (v), r - 5109));
            return;
        }
        if (r == 4100) { safe->ctx.proc().ratePhrase (safe->track, 1); return; }
        if (r == 4101) { safe->ctx.proc().ratePhrase (safe->track, -1); return; }
        if (r == 4102) { safe->ctx.proc().ratePhrase (safe->track, 0); return; }
        if (r == 4103) { safe->ctx.proc().forgetPhraseRatings(); return; }
        if (r == 4003) { safe->ctx.proc().trackExtKey[(size_t) safe->track].store (-1); return; }
        if (r >= 2000 && r < 2004) { safe->ctx.proc().setTrackValue (safe->track, TpDyn, (float) (r - 2000)); return; }
        if (r >= 3000 && r < 3004) { safe->ctx.proc().trackSurprise[(size_t) safe->track].store ((r - 3000) * 20); safe->repaint(); return; }
        if (r >= 3100 && r < 3100 + numSitPatterns)
        {
            safe->ctx.proc().trackKeys[(size_t) safe->track].store (sitPatterns[r - 3100].mask);
            safe->keys.repaint();
            return;
        }
        safe->ctx.proc().setTrackType (safe->track, r - 1);   // the panel rebuilds the strips on its next tick
    });
}

void BandPanel::Strip::askName()
{
    auto* w = new juce::AlertWindow ("Name track " + juce::String (track + 1),
                                     "What's on it? (e.g. Omnisphere - Warm Pad). It shows on the track and in your MIDI exports. "
                                     "Leave it empty to go back to " + juce::String (bandTypeName (type)) + ".",
                                     juce::MessageBoxIconType::NoIcon);
    w->addTextEditor ("name", ctx.proc().trackName (track));
    w->addButton ("OK", 1, juce::KeyPress (juce::KeyPress::returnKey));
    w->addButton ("Cancel", 0, juce::KeyPress (juce::KeyPress::escapeKey));
    juce::Component::SafePointer<Strip> safe (this);
    w->enterModalState (true, juce::ModalCallbackFunction::create ([safe, w] (int r)
    {
        if (r == 1 && safe != nullptr) safe->ctx.proc().setTrackName (safe->track, w->getTextEditorContents ("name"));
    }), true);
}

void BandPanel::Strip::sync()
{
    auto& p = ctx.proc();
    {   // REWORK takes COMPLEX's place on a drum track playing your MIDI
        const bool dm = bandTypeIsDrums (type) && p.trackMidiCount (track) > 0;
        if (dm != drumMidi)
        {
            drumMidi = dm;
            reworkKnob.setVisible (dm);
            complexity.setVisible (! dm);
            repaint();
        }
        if (dm && ! reworkKnob.isMouseButtonDown())
        {
            const int v = p.trackRework[(size_t) track].load();
            if ((int) reworkKnob.getValue() != v) reworkKnob.setValue (v, juce::dontSendNotification);
        }
    }
    {   // LOCK: the dice leave it alone
        const bool locked = p.trackFlag (track, VesperProcessor::FlagLock);
        const juce::String want = locked ? "LOCK" : "DICE";
        if (dice.getButtonText() != want)
        {
            dice.setButtonText (want);
            dice.setToggleState (locked, juce::dontSendNotification);
            dice.setTooltip (locked ? "LOCKED: the dice leave this track's line alone (arrow menu > LOCK to free it)"
                                    : "A new line for this track (same style, new idea)");
        }
    }
    // its name and its SOUND
    if (p.namesChanged.load() != lastNames)
    {
        lastNames = p.namesChanged.load();
        const auto nm = p.trackName (track);
        on.setButtonText (nm.isNotEmpty() ? nm : juce::String (bandTypeName (type)));
        on.setTooltip ((nm.isNotEmpty() ? nm + " (" + juce::String (bandTypeName (type)) + ")" : "Track " + juce::String (track + 1))
                       + ": click to turn it on or off. Name it from the arrow menu next to it");
    }
    if (p.rack.changed.load() != lastRack)
    {
        lastRack = p.rack.changed.load();
        const int slot = InstrumentRack::trackSlot (track);
        soundBtn.setButtonText (soundButtonText (p, slot));
        soundBtn.setToggleState (p.rack.loaded (slot), juce::dontSendNotification);
    }
    // YOUR MIDI: the style box shows the file playing
    const int mc = p.trackMidiCount (track);
    const auto mn = p.trackMidiNow (track);
    if (mc != lastMidiCount || mn != lastMidiName)
    {
        const bool was = lastMidiCount > 0;
        lastMidiCount = mc;
        lastMidiName = mn;
        midiBtn.setToggleState (mc > 0, juce::dontSendNotification);
        if (mc > 0) style.setText ("MIDI: " + mn, juce::dontSendNotification);
        else if (was) lastStyle = -1;   // back to the style
        style.setTooltip (mc > 0 ? "Playing your MIDI (" + juce::String (mc) + " file" + (mc == 1 ? "" : "s") + "). MIDI button > Clear to go back to the style"
                                 : juce::String (bandStyleBlurb (type, juce::jmax (0, lastStyle))));
    }
    const int st = juce::jlimit (0, bandNumStyles (type) - 1, (int) std::lround (p.trackValue (track, TpStyle)));
    if (mc == 0 && st != lastStyle && ! style.isPopupActive())
    {
        lastStyle = st;
        style.setSelectedItemIndex (st, juce::dontSendNotification);
        style.setTooltip (bandStyleBlurb (type, st));
    }
    const bool canHold = bandTypeCanHold (type);
    const int mode = canHold ? juce::jlimit (0, numBandModes - 1, (int) std::lround (p.trackValue (track, TpMode))) : (int) ModeJam;
    const bool isOn = on.getToggleState();
    if (mode != lastMode || isOn != lastOn)
    {
        lastMode = mode;
        lastOn = isOn;
        for (int m = 0; m < numBandModes; ++m)
        {
            modeBtns[m].setToggleState (m == mode, juce::dontSendNotification);
            modeBtns[m].setEnabled (m == ModeJam || canHold);
        }
        const bool jam = mode == ModeJam;
        style.setEnabled (jam);
        dice.setEnabled (jam);
        density.setEnabled (jam);
        complexity.setEnabled (jam);
        dyn.setEnabled (jam);
        repaint();
    }
}

void BandPanel::Strip::resized()
{
    on.setBounds (20, 6, 86, 24);
    typeBtn.setBounds (108, 6, 20, 24);
    style.setBounds (132, 6, 132, 24);
    dice.setBounds (268, 6, 42, 24);
    channel.setBounds (314, 6, 60, 24);
    octave.setBounds (378, 6, 62, 24);
    drag.setBounds (444, 6, 40, 24);
    midiBtn.setBounds (487, 6, 36, 24);
    remove.setBounds (getWidth() - 26, 6, 20, 24);

    density.setBounds (6, 38, 28, 28);
    complexity.setBounds (66, 38, 28, 28);
    reworkKnob.setBounds (66, 38, 28, 28);
    level.setBounds (126, 38, 28, 28);
    for (int m = 0; m < numBandModes; ++m) modeBtns[m].setBounds (180 + m * 42, 41, 40, 22);
    keys.setBounds (312, 40, 112, 25);
    soundBtn.setBounds (428, 41, getWidth() - 434, 22);
}

void BandPanel::Strip::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const auto r = getLocalBounds().toFloat();
    const bool isOn = on.getToggleState();
    g.setColour (isOn ? t.card : t.cardDark);
    g.fillRoundedRectangle (r, 7.0f);
    g.setColour (isOn ? t.panelEdge.brighter (0.2f) : t.panelEdge);
    g.drawRoundedRectangle (r.reduced (0.5f), 7.0f, 1.0f);
    if (dropHover)
    {
        g.setColour (t.home.withAlpha (0.25f));
        g.fillRoundedRectangle (r, 7.0f);
        g.setColour (t.home);
        g.drawRoundedRectangle (r.reduced (1.0f), 7.0f, 2.0f);
    }

    // activity light + track number
    const juce::Rectangle<float> dot (6.0f, 13.0f, 9.0f, 9.0f);
    g.setColour (t.cardDark.interpolatedWith (t.home, isOn ? 0.25f + 0.75f * glow : 0.0f));
    g.fillEllipse (dot);
    g.setColour (t.panelEdge);
    g.drawEllipse (dot, 1.0f);
    g.setFont (uiFont (9.0f, true));
    g.setColour (t.dim);
    g.drawText (juce::String (track + 1), juce::Rectangle<float> (1.0f, 24.0f, 19.0f, 10.0f), juce::Justification::centred);

    const bool jam = lastMode == ModeJam;
    g.setFont (uiFont (9.0f, true));
    g.setColour (jam ? t.dim : t.faint);
    g.drawText ("BUSY", juce::Rectangle<float> (35.0f, 45.0f, 30.0f, 14.0f), juce::Justification::centredLeft);
    if (drumMidi)
    {
        g.setColour (t.accent);
        g.drawText ("RWRK", juce::Rectangle<float> (95.0f, 39.0f, 30.0f, 12.0f), juce::Justification::centredLeft);
        g.setColour (t.dim);
        g.drawText (juce::String ((int) reworkKnob.getValue()) + "%", juce::Rectangle<float> (95.0f, 51.0f, 30.0f, 12.0f), juce::Justification::centredLeft);
    }
    else g.drawText ("CPLX", juce::Rectangle<float> (95.0f, 45.0f, 30.0f, 14.0f), juce::Justification::centredLeft);
    g.setColour (t.dim);
    g.drawText ("LVL", juce::Rectangle<float> (155.0f, 45.0f, 24.0f, 14.0f), juce::Justification::centredLeft);
}

//==============================================================================
BandPanel::BandPanel (EditorContext& c)
    : ctx (c), chordKeys (c, c.proc().chordKeys), groovePrev (c, IconButton::Left), grooveNext (c, IconButton::Right)
{
    auto& p = ctx.proc();
    auto& apvts = p.apvts;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;

    // ---- top row
    bandOnBtn.setClickingTogglesState (true);
    bandOnBtn.setTooltip ("Master switch for the band (every track)");
    addAndMakeVisible (bandOnBtn);
    buttonAtt.push_back (std::make_unique<BA> (apvts, ids::bandOn, bandOnBtn));

    for (int g = 0; g < numGenres; ++g) genreBox.addItem (genreName (g), g + 1);
    genreBox.setTextWhenNothingSelected ("PICK A GENRE");
    genreBox.setTooltip ("Sets every track to that genre's style. If no tracks are on yet, it also turns on the usual lineup");
    genreBox.onChange = [this]
    {
        const int g = genreBox.getSelectedId() - 1;
        if (g < 0) return;
        ctx.proc().applyBandGenre (g);
        lastGenre = g;
        repaint();
    };
    addAndMakeVisible (genreBox);

    phraseBox.addItemList ({ "1", "2", "4", "8" }, 1);
    phraseBox.setTooltip ("How long a phrase is before the tracks come back around (they repeat with small changes, like a real hook)");
    addAndMakeVisible (phraseBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::bandPhrase, phraseBox));

    swingKnob.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    swingKnob.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    swingKnob.setTooltip ("SWING for the whole band. Every pattern is straight; this is the only swing. "
                          "0% = straight, about 33% = a light bounce, about 67% = a triplet shuffle");
    swingKnob.onValueChange = [this] { repaint (480, 0, 140, 44); };
    addAndMakeVisible (swingKnob);
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::bandSwing, swingKnob));

    feelKnob.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    feelKnob.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    feelKnob.setTooltip ("FEEL: how much of the drummer's push and drag the grooves keep. 100% = exactly like the loops they came "
                         "from (laid-back snares, rushing hats); 0% = every hit right on the grid. SWING adds on top");
    feelKnob.onValueChange = [this] { repaint (480, 0, 140, 44); };
    addAndMakeVisible (feelKnob);
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::bandFeel, feelKnob));

    varyKnob.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    varyKnob.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    varyKnob.setTooltip ("DRUM VARY: every time round, the groove plays a little differently - the drummer's other bars swapped in, "
                         "a different turnaround, a ghost note, a hat roll, a kick moved. 0% = exactly the same every time. "
                         "The first time through is always the groove as it is");
    varyKnob.onValueChange = [this] { repaint (720, loopRowY, 120, 24); };
    addAndMakeVisible (varyKnob);
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::bandVary, varyKnob));

    changeBox.addItemList ({ "OFF", "4", "8", "16", "32" }, 1);
    changeBox.setTooltip ("CHANGE: every 4 / 8 / 16 / 32 bars the drums switch to one of the grooves closest to yours, "
                          "so the beat keeps moving without changing character. Your pick stays in the GROOVE box; "
                          "click NOW ... KEEP to keep the one playing");
    addAndMakeVisible (changeBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::bandChange, changeBox));

    keepTag.setTooltip ("The groove CHANGE is playing right now. Click to make it your groove");
    keepTag.onClick = [this]
    {
        const int now = ctx.proc().bandGroovePlaying();
        if (now >= 0) { changeBox.setSelectedItemIndex (0); ctx.proc().setBandGroove (now); }
    };
    addChildComponent (keepTag);

    stopModeBox.addItemList ({ "LET GO", "BAR END", "NEVER" }, 1);
    stopModeBox.setTooltip ("When the band stops: LET GO = when you let go of the chord, BAR END = at the end of that bar, NEVER = keeps going until FL stops (or STOP)");
    addAndMakeVisible (stopModeBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::bandStop, stopModeBox));

    copyBtn.setTooltip ("For a copy of VESPER: make it play ONLY TRACK 3 (etc.) from your main VESPER, out of its own MIDI port. "
                        "(Patcher + VFX Color Mapper is usually easier)");
    copyBtn.onClick = [this] { showCopyMenu(); };
    addAndMakeVisible (copyBtn);
    layoutBtn.setTooltip ("BAND LAYOUTS: the whole band set up in one click, made for the genre - for trap: ALL ARPS, ARPS + PADS, "
                          "PIANO & STRINGS, DARK BELLS, GUITAR TRAP... Which tracks play, their styles, octaves, how busy and how loud. "
                          "Tracks of the same instrument keep their channel (your FL routing stays), new ones get added, the rest "
                          "switch off (nothing is deleted). LOCKED tracks stay as they are. Then pick the sounds in your synths");
    layoutBtn.onClick = [this] { showLayoutMenu(); };
    addAndMakeVisible (layoutBtn);

    grooveBox.setTooltip ("GROOVE: the drum grooves for this genre. Genres built from your loops have 500: each loop as it was "
                          "played (ORIGINAL), then variations of it (new kicks, GHOSTS, hat ROLLS, FILLs). Every drum track plays it "
                          "(DRUMS on GROOVE, or KICK, SNARE, HATS... on their own tracks), so the kit always locks together");
    grooveBox.onChange = [this]
    {
        auto& pr = ctx.proc();
        const int id = grooveBox.getSelectedId();
        if (id == 9000) { pr.openMyGroovesFolder(); syncGrooveBox(); return; }
        if (id >= 5000) { pr.setMyGroove (id - 5000); return; }
        const int i = id - 1;
        if (i >= 0 && (i != lastGroove || pr.myGrooveNow() >= 0)) { lastGroove = i; pr.setBandGroove (i); }
    };
    addAndMakeVisible (grooveBox);
    groovePrev.setTooltip ("Previous groove");
    grooveNext.setTooltip ("Next groove");
    groovePrev.onClick = [this] { ctx.proc().setBandGroove (ctx.proc().bandGrooveNow() - 1); };
    grooveNext.onClick = [this] { ctx.proc().setBandGroove (ctx.proc().bandGrooveNow() + 1); };
    grooveDice.setTooltip ("A random groove for this genre");
    grooveDice.onClick = [this]
    {
        for (int t = 0; t < ctx.proc().numTracks.load(); ++t)   // a LOCKED drum track keeps the groove too
            if (ctx.proc().trackFlag (t, VesperProcessor::FlagLock) && bandTypeIsDrums (ctx.proc().trackType (t))) return;
        const int now = ctx.proc().bandGrooveNow();
        const int n = std::max (2, numGrooves (ctx.proc().bandGenreNow()));
        const int next = (now + 1 + juce::Random::getSystemRandom().nextInt (n - 1)) % n;
        ctx.proc().setBandGroove (next);
    };
    addAndMakeVisible (groovePrev);
    addAndMakeVisible (grooveNext);
    addAndMakeVisible (grooveDice);
    fillGrooves();

    for (int ch = 1; ch <= 16; ++ch) chordChBox.addItem (juce::String (ch), ch);
    chordChBox.setTooltip ("MIDI channel for VESPER's chords");
    addAndMakeVisible (chordChBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::chordCh, chordChBox));

    chordKeys.setTooltip ("KEY STRIP for the chords: click a key and VESPER's own chords sit out whenever you press it "
                          "(the band still follows). In SCALE mode the numbers are the chords: 1 = I on C ... 7 on B");
    addAndMakeVisible (chordKeys);

    allHoldBtn.setTooltip ("ALL HOLD: every melodic track plays exactly what you press, all at once (no patterns). "
                           "Click again to go back to JAM. Drums keep playing their pattern");
    allHoldBtn.onClick = [this] { ctx.proc().setAllHold (! ctx.proc().allHold()); };
    addAndMakeVisible (allHoldBtn);

    addBtn.setTooltip ("Add a track (up to 15: with your chords that's all 16 MIDI channels)");
    addBtn.onClick = [this] { ctx.proc().addTrack(); };
    addAndMakeVisible (addBtn);

    diceAllBtn.setTooltip ("New lines for every track that's on (same styles, new ideas)");
    diceAllBtn.onClick = [this]
    {
        for (int t = 0; t < ctx.proc().numTracks.load(); ++t)
            if (ctx.proc().trackValue (t, TpOn) > 0.5f && ! ctx.proc().trackFlag (t, VesperProcessor::FlagLock)) ctx.proc().rollBandSeed (t);
    };
    addAndMakeVisible (diceAllBtn);

    stopBtn.setTooltip ("Stop the band now (and anything RING is holding)");
    stopBtn.onClick = [this] { ctx.proc().stopBandFromUi(); };
    addAndMakeVisible (stopBtn);

    // ---- the LOOP / SONG row
    recLoopBtn.setTooltip ("REC LOOP: play a progression once and VESPER keeps playing it, in time, as if you kept pressing the keys. "
                           "Recording starts on your first chord (on the bar when FL is playing) and lasts the bars you pick. "
                           "It goes into the section that's lit (A to start)");
    recLoopBtn.onClick = [this]
    {
        auto& L = ctx.proc().looper;
        const int st = L.state.load();
        L.cmd.store (st == Looper::Armed || st == Looper::Recording ? 3 : 1);
    };
    addAndMakeVisible (recLoopBtn);
    loopBtn.setTooltip ("Play / stop the loop. While it plays you can play over it, and the band keeps going");
    loopBtn.onClick = [this]
    {
        auto& p = ctx.proc();
        if (p.looper.busy() || p.looper.state.load() == Looper::Armed) { p.songOn.store (false); p.looper.cmd.store (3); }
        else p.looper.cmd.store (2);
    };
    addAndMakeVisible (loopBtn);
    loopBarsBox.addItemList ({ "1 BAR", "2 BARS", "4 BARS", "8 BARS" }, 1);
    loopBarsBox.setTooltip ("How long a loop is when you record one");
    loopBarsBox.onChange = [this]
    {
        static const int b[4] = { 1, 2, 4, 8 };
        const int i = loopBarsBox.getSelectedItemIndex();
        if (i >= 0) ctx.proc().looper.bars.store (b[i]);
    };
    {
        const int b = ctx.proc().looper.bars.load();
        loopBarsBox.setSelectedItemIndex (b <= 1 ? 0 : b <= 2 ? 1 : b <= 4 ? 2 : 3, juce::dontSendNotification);
    }
    addAndMakeVisible (loopBarsBox);
    for (int i = 0; i < 4; ++i)
    {
        sectionBtns[(size_t) i] = std::make_unique<SectionButton> (ctx, i);
        auto& b = *sectionBtns[(size_t) i];
        const juce::String n = juce::String::charToString ((juce::juce_wchar) ('A' + i));
        b.setTooltip ("SECTION " + n + ": its own loop (and groove). Click to play it (it switches on the next bar line); "
                      "if it's empty, clicking records it. Right-click to give it a key on your controller. "
                      "MAKE IT A SONG uses A as the verse, B as the chorus, C as the bridge");
        b.onPress = [this, i] (bool right)
        {
            if (right) sectionMenu (i);
            else ctx.proc().goToSection (i);
        };
        addAndMakeVisible (b);
    }
    songBtn.setClickingTogglesState (false);
    songBtn.setTooltip ("MAKE IT A SONG: VESPER arranges your sections into a whole song (intro, verse, chorus, verse, chorus, bridge, "
                        "chorus, last chorus, outro: about 2 minutes). The band thins out and builds up on its own. "
                        "A = verse, B = chorus, C = bridge (missing ones fill in). Hit record in FL first and let it run");
    songBtn.onClick = [this] { auto& p = ctx.proc(); p.songOn.store (! p.songOn.load()); syncLoopRow(); };
    addAndMakeVisible (songBtn);
    listenBtn.setTooltip ("DRUMMER LISTENS: the drums play a fill into every change (a new section, the loop coming round) and "
                          "crash on the new one, and hit harder or softer with how hard you play");
    listenBtn.onClick = [this] { auto& p = ctx.proc(); p.drummerListens.store (! p.drummerListens.load()); syncLoopRow(); };
    addAndMakeVisible (listenBtn);
    feelBtn.setTooltip ("BAND FEEL: every player gets their own pocket. The bass sits back, the snare a hair late, the hats push, "
                        "melodies a little loose. Like a real band instead of a grid");
    feelBtn.onClick = [this] { auto& p = ctx.proc(); p.bandFeel.store (! p.bandFeel.load()); syncLoopRow(); };
    addAndMakeVisible (feelBtn);

    // ---- tracks
    viewport.setViewedComponent (&list, false);
    viewport.setScrollBarsShown (true, false);
    viewport.setScrollBarThickness (8);
    addAndMakeVisible (viewport);
    rebuildStrips();

    lastGenre = (int) apvts.getRawParameterValue (ids::bandGenre)->load();
    lastAnyOn = anyPartOn();
    genreBox.setSelectedId (lastAnyOn ? lastGenre + 1 : 0, juce::dontSendNotification);
    startTimerHz (20);
}

BandPanel::~BandPanel() { stopTimer(); }

juce::Rectangle<int> BandPanel::stripBounds (int track)
{
    const int col = track % 2, row = track / 2;
    return { col * (colW + colGap), row * (stripH + stripGapY), colW, stripH };
}

void BandPanel::rebuildStrips()
{
    auto& p = ctx.proc();
    const int n = juce::jlimit (1, maxBandTracks, p.numTracks.load());
    const auto pos = viewport.getViewPosition();
    strips.clear();
    for (int t = 0; t < n; ++t)
    {
        strips.push_back (std::make_unique<Strip> (*this, t));
        list.addAndMakeVisible (*strips.back());
        strips.back()->setBounds (stripBounds (t));
    }
    const int rows = (n + 1) / 2;
    list.setSize (2 * colW + colGap, rows * (stripH + stripGapY) - stripGapY);
    viewport.setViewPosition (pos);
    lastTracks = n;
    lastChanged = p.tracksChanged.load();
    addBtn.setEnabled (n < maxBandTracks);
    chordKeys.repaint();
    repaint();
}

bool BandPanel::anyPartOn() const
{
    const auto& p = ctx.proc();
    for (int t = 0; t < p.numTracks.load(); ++t)
        if (p.trackValue (t, TpOn) > 0.5f) return true;
    return false;
}

void BandPanel::resized()
{
    bandOnBtn.setBounds (0, 14, 60, 24);
    genreBox.setBounds (66, 14, 120, 24);
    grooveBox.setBounds (190, 14, 118, 24);
    keepTag.setBounds (240, 0, 140, 13);
    groovePrev.setBounds (310, 14, 16, 24);
    grooveNext.setBounds (328, 14, 16, 24);
    grooveDice.setBounds (348, 14, 34, 24);
    changeBox.setBounds (386, 14, 50, 24);
    phraseBox.setBounds (440, 14, 44, 24);
    swingKnob.setBounds (488, 10, 30, 30);
    feelKnob.setBounds (552, 10, 30, 30);
    stopModeBox.setBounds (618, 14, 72, 24);
    chordChBox.setBounds (694, 14, 42, 24);
    chordKeys.setBounds (740, 13, 98, 26);
    allHoldBtn.setBounds (844, 14, 64, 24);
    addBtn.setBounds (914, 14, 58, 24);
    diceAllBtn.setBounds (978, 14, 56, 24);
    stopBtn.setBounds (1040, 14, 40, 24);
    copyBtn.setBounds (1084, 14, 40, 24);
    recLoopBtn.setBounds (0, loopRowY, 74, 24);
    loopBtn.setBounds (78, loopRowY, 74, 24);
    loopBarsBox.setBounds (156, loopRowY, 74, 24);
    for (int i = 0; i < 4; ++i) sectionBtns[(size_t) i]->setBounds (238 + i * 36, loopRowY, 32, 24);
    songBtn.setBounds (386, loopRowY, 112, 24);
    listenBtn.setBounds (504, loopRowY, 124, 24);
    feelBtn.setBounds (634, loopRowY, 84, 24);
    varyKnob.setBounds (724, loopRowY - 1, 26, 26);
    layoutBtn.setBounds (846, loopRowY, getWidth() - 846, 24);
    viewport.setBounds (0, listTop, getWidth(), getHeight() - listTop);
}

void BandPanel::sectionMenu (int s)
{
    auto& p = ctx.proc();
    const juce::String n = juce::String::charToString ((juce::juce_wchar) ('A' + s));
    const int key = p.sectionKey[(size_t) s].load();
    const bool has = (p.looper.filled.load() >> s) & 1u;
    juce::PopupMenu m;
    m.addSectionHeader ("SECTION " + n);
    m.addItem (1, "Use a key on my controller for " + n + "... (press it next)");
    if (key >= 0) m.addItem (2, "Forget its key (" + toJ (midiName (key, p.flats())) + ")");
    if (has) m.addItem (3, "Record " + n + " again");
    juce::Component::SafePointer<BandPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (sectionBtns[(size_t) s].get()), [safe, s] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        auto& pr = safe->ctx.proc();
        if (r == 1) pr.sectionLearn.store (s);
        if (r == 2) { pr.sectionKey[(size_t) s].store (-1); pr.sectionKeysChanged.fetch_add (1); }
        if (r == 3) { pr.looper.wantSection.store (s); pr.looper.cmd.store (1); }
        safe->syncLoopRow();
    });
}

void BandPanel::syncLoopRow()
{
    auto& p = ctx.proc();
    auto& L = p.looper;
    const int st = L.state.load(), sec = L.section.load(), learn = p.sectionLearn.load();
    const uint32_t filled = L.filled.load();
    const juce::String n = juce::String::charToString ((juce::juce_wchar) ('A' + sec));
    juce::String text;
    if (learn >= 0)
        text = "Press the key on your controller for section " + juce::String::charToString ((juce::juce_wchar) ('A' + learn));
    else if (p.songOn.load() && p.songSecNow.load() >= 0)
        text = "SONG: " + p.songStatus();
    else if (p.songOn.load())
        text = "SONG: starts on the next bar";
    else if (st == Looper::Armed)
        text = "REC " + n + ": starts on your first chord";
    else if (st == Looper::Recording)
        text = "RECORDING " + n + ": " + juce::String (L.bars.load()) + (L.bars.load() == 1 ? " bar" : " bars") + ", keep playing";
    else if (st == Looper::Playing)
    {
        const double len = juce::jmax (4.0, L.length.load());
        text = "LOOP " + n + "   bar " + juce::String ((int) (L.position.load() / 4.0) + 1) + " of " + juce::String ((int) (len / 4.0))
               + "   play over it, or click another section";
    }
    else if (filled != 0)
        text = "Loops ready: click A-D or PLAY LOOP";
    else
        text = "LOOPER: click REC LOOP, then play your chords";

    // the buttons follow what's going on
    recLoopBtn.setButtonText (st == Looper::Armed || st == Looper::Recording ? "CANCEL" : "REC LOOP");
    recLoopBtn.setToggleState (st == Looper::Armed || st == Looper::Recording, juce::dontSendNotification);
    loopBtn.setButtonText (st == Looper::Playing ? "STOP LOOP" : "PLAY LOOP");
    loopBtn.setEnabled (filled != 0 || st != Looper::Off);
    songBtn.setToggleState (p.songOn.load(), juce::dontSendNotification);
    songBtn.setEnabled (true);
    listenBtn.setToggleState (p.drummerListens.load(), juce::dontSendNotification);
    feelBtn.setToggleState (p.bandFeel.load(), juce::dontSendNotification);

    const bool blink = st == Looper::Armed && (juce::Time::getMillisecondCounter() / 300) % 2 == 0;
    const uint32_t look = (uint32_t) st | (uint32_t) sec << 3 | filled << 5 | (uint32_t) (L.wantSection.load() + 1) << 9
                          | (uint32_t) (learn + 1) << 12 | (blink ? 1u << 15 : 0u) | (p.sectionKeysChanged.load() & 0xffu) << 16;
    if (look != lastLoopLook)
    {
        lastLoopLook = look;
        for (auto& b : sectionBtns) b->repaint();
    }
    if (text != loopStatus)
    {
        loopStatus = text;
        repaint (840, loopRowY, getWidth() - 840, 24);
    }
}

void BandPanel::SectionButton::paintButton (juce::Graphics& g, bool over, bool down)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    auto& L = p.looper;
    const bool has = (L.filled.load() >> index) & 1u;
    const int st = L.state.load();
    const bool cur = L.section.load() == index;
    const bool rec = cur && (st == Looper::Armed || st == Looper::Recording);
    const bool live = cur && st == Looper::Playing;
    const bool next = L.wantSection.load() == index && ! cur;
    const bool learning = p.sectionLearn.load() == index;
    const bool blink = st == Looper::Armed && (juce::Time::getMillisecondCounter() / 300) % 2 == 0;
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    juce::Colour fill = live ? t.accent : (has ? t.cardHi : t.cardDark);
    if (rec) fill = juce::Colour (0xffc23b30).withAlpha (blink ? 0.45f : 0.95f);
    if (learning) fill = t.color;
    if (over) fill = fill.brighter (0.08f);
    if (down) fill = fill.darker (0.12f);
    g.setColour (fill);
    g.fillRoundedRectangle (r, 5.0f);
    g.setColour (next ? t.accent.brighter (0.4f) : (cur ? t.text.withAlpha (0.55f) : t.panelEdge));
    g.drawRoundedRectangle (r, 5.0f, next ? 2.0f : 1.0f);
    const int key = p.sectionKey[(size_t) index].load();
    g.setColour (live || rec || learning ? t.accentText : (has ? t.text : t.dim));
    g.setFont (uiFont (13.0f, true));
    g.drawText (juce::String::charToString ((juce::juce_wchar) ('A' + index)),
                key >= 0 ? r.withTrimmedBottom (8.0f) : r, juce::Justification::centred);
    if (key >= 0)
    {
        g.setFont (uiFont (7.5f, true));
        g.drawText (toJ (midiName (key, p.flats())), r.withTrimmedTop (r.getHeight() - 10.0f), juce::Justification::centred);
    }
    if (has && ! live)   // a dot: there's a loop in here
    {
        g.setColour (t.home);
        g.fillEllipse (r.getRight() - 7.0f, r.getY() + 3.0f, 4.0f, 4.0f);
    }
}

int BandPanel::role() const
{
    return juce::jlimit (0, (int) maxBandTracks, (int) ctx.proc().apvts.getRawParameterValue (ids::bandRole)->load());
}

void BandPanel::showLayoutMenu()
{
    auto& p = ctx.proc();
    const int g = p.bandGenreNow();
    juce::PopupMenu m, others;
    m.addSectionHeader ("BAND LAYOUTS FOR " + juce::String (genreShort (g)));
    for (int i = 0; i < numBandLayouts (g); ++i)
    {
        const auto& L = bandLayout (g, i);
        m.addItem (1 + g * 16 + i, juce::String (L.name) + "  -  " + L.blurb, true, p.layoutShown.load() == g * 16 + i);
    }
    for (int og = 0; og < numGenres; ++og)
    {
        if (og == g) continue;
        juce::PopupMenu sub;
        for (int i = 0; i < numBandLayouts (og); ++i)
            sub.addItem (1 + og * 16 + i, juce::String (bandLayout (og, i).name) + "  -  " + bandLayout (og, i).blurb);
        others.addSubMenu (genreName (og), sub);
    }
    m.addSeparator();
    m.addSubMenu ("Another genre's band (the BAND genre changes to it)", others);
    juce::Component::SafePointer<BandPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&layoutBtn), [safe] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        const int code = r - 1;
        safe->ctx.proc().applyBandLayout (code / 16, code % 16);
        safe->syncGrooveBox();
    });
}

void BandPanel::showCopyMenu()
{
    juce::PopupMenu m;
    m.addSectionHeader ("THIS VESPER PLAYS");
    const int r = role();
    m.addItem (1, "EVERYTHING (the main VESPER)", true, r == 0);
    for (int t = 0; t < maxBandTracks; ++t) m.addItem (t + 2, "ONLY TRACK " + juce::String (t + 1) + " (a copy)", true, r == t + 1);
    juce::Component::SafePointer<BandPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&copyBtn), [safe] (int res)
    {
        if (res <= 0 || safe == nullptr) return;
        if (auto* prm = safe->ctx.proc().apvts.getParameter (ids::bandRole))
            prm->setValueNotifyingHost (prm->convertTo0to1 ((float) (res - 1)));
        safe->repaint();
    });
}

void BandPanel::fillGrooves()
{
    auto& p = ctx.proc();
    const int g = p.bandGenreNow();
    grooveBox.clear (juce::dontSendNotification);
    for (int i = 0; i < numGrooves (g); ++i) grooveBox.addItem (grooveLabel (g, i), i + 1);
    // MY GROOVES: yours, from Documents/VESPER/My Grooves (this genre's folder and ANY GENRE)
    grooveBox.addSeparator();
    const int mine = p.numMyGrooves (g);
    if (mine > 0)
    {
        grooveBox.addSectionHeading ("MY GROOVES (" + juce::String (mine) + ")");
        for (int i = 0; i < mine; ++i) grooveBox.addItem (p.myGrooveName (g, i), 5000 + i);
    }
    grooveBox.addItem ("Open my grooves folder... (add your own drum MIDI)", 9000);
    lastGrooveGenre = g;
    lastMyGrooves = p.myGroovesChanged.load();
    syncGrooveBox();
}

void BandPanel::syncGrooveBox()
{
    auto& p = ctx.proc();
    lastGroove = p.bandGrooveNow();
    const int mine = p.myGrooveNow();
    if (mine >= 0) grooveBox.setSelectedId (5000 + mine, juce::dontSendNotification);
    else grooveBox.setSelectedId (lastGroove + 1, juce::dontSendNotification);
}

void BandPanel::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    drawCaption (g, { 0.0f, 0.0f, 60.0f, 12.0f }, "BAND", t);
    drawCaption (g, { 66.0f, 0.0f, 120.0f, 12.0f }, "GENRE", t);
    if (! keepTag.isVisible())
        drawCaption (g, { 190.0f, 0.0f, 192.0f, 12.0f }, "GROOVE (" + juce::String (numGrooves (p.bandGenreNow())) + ")", t);
    else
        drawCaption (g, { 190.0f, 0.0f, 50.0f, 12.0f }, "GROOVE", t);
    drawCaption (g, { 386.0f, 0.0f, 50.0f, 12.0f }, "CHANGE", t);
    drawCaption (g, { 440.0f, 0.0f, 44.0f, 12.0f }, "PHRASE", t);
    drawCaption (g, { 488.0f, 0.0f, 60.0f, 12.0f }, "SWING", t);
    drawCaption (g, { 552.0f, 0.0f, 62.0f, 12.0f }, "FEEL", t);
    g.setFont (uiFont (11.0f, true));
    g.setColour (t.text);
    g.drawText (juce::String (juce::roundToInt (swingKnob.getValue())) + "%", juce::Rectangle<float> (519.0f, 18.0f, 32.0f, 14.0f), juce::Justification::centredLeft);
    g.drawText (juce::String (juce::roundToInt (feelKnob.getValue())) + "%", juce::Rectangle<float> (583.0f, 18.0f, 34.0f, 14.0f), juce::Justification::centredLeft);
    drawCaption (g, { 618.0f, 0.0f, 72.0f, 12.0f }, "STOPS", t);
    drawCaption (g, { 694.0f, 0.0f, 144.0f, 12.0f }, "CHORDS CH + KEYS", t);
    drawCaption (g, { 914.0f, 0.0f, 58.0f, 12.0f }, juce::String (p.numTracks.load()) + " / " + juce::String (maxBandTracks), t);

    // playing light, on the line under the controls
    const bool playing = p.bandPlaying.load();
    const juce::Rectangle<float> led (1040.0f, 39.5f, 8.0f, 8.0f);
    g.setColour (playing ? t.home : t.cardDark);
    g.fillEllipse (led);
    g.setColour (t.panelEdge);
    g.drawEllipse (led, 1.0f);
    g.setFont (uiFont (9.5f, true));
    const bool anyOn = anyPartOn();
    g.setColour (playing ? t.text : (anyOn ? t.dim : t.color));
    g.drawText (playing ? "PLAYING" : (anyOn ? "PLAY A CHORD" : "ALL OFF"), juce::Rectangle<float> (1052.0f, 38.0f, 72.0f, 11.0f),
                juce::Justification::centredLeft);

    drawCaption (g, { 752.0f, (float) loopRowY, 84.0f, 11.0f }, "DRUM VARY", t);
    g.setFont (uiFont (11.0f, true));
    g.setColour (t.text);
    g.drawText (juce::String (juce::roundToInt (varyKnob.getValue())) + "%", juce::Rectangle<float> (752.0f, (float) loopRowY + 11.0f, 60.0f, 13.0f),
                juce::Justification::centredLeft);
    g.setFont (uiFont (10.5f, true));
    g.setColour (p.looper.state.load() == Looper::Recording || p.looper.state.load() == Looper::Armed ? juce::Colour (0xffe0574b)
                 : p.looper.playing() ? t.text : t.dim);
    g.drawText (loopStatus, juce::Rectangle<float> (842.0f, (float) loopRowY, (float) getWidth() - 842.0f, 24.0f), juce::Justification::centredLeft);

    if (! anyOn && role() == 0)
    {
        g.setFont (uiFont (10.5f, true));
        g.setColour (t.color);
        g.drawText ("Every track is off: pick a GENRE, or click a track's name (MELODY, BASS, DRUMS...) to turn it on",
                    juce::Rectangle<float> (0.0f, 38.0f, (float) getWidth(), 10.0f), juce::Justification::centredLeft);
    }

    // a band copy: explain what it's doing
    const int rl = role();
    if (rl > 0)
    {
        const int f = p.followState.load();
        const juce::String tr = "TRACK " + juce::String (rl);
        juce::String text;
        if (f == 2)
            text = "This VESPER is set to play ONLY " + tr + ", but there's no main VESPER playing yet.\n"
                   "Add a VESPER set to EVERYTHING (your main one), turn " + tr + " on there, and play chords on it.";
        else
            text = "BAND COPY: playing only " + tr + " from your main VESPER, in sync.\n"
                   "Change the band (styles, DICE, channels) on the main VESPER. The main VESPER leaves " + tr + " out.\n"
                   "Give this one its own MIDI output port (FL gear icon > MIDI > Output port) and set that instrument's "
                   "input port to the same number. (HOLD and RING tracks are always played by the main VESPER.)";
        g.setFont (uiFont (13.0f, true));
        g.setColour (t.text);
        g.drawFittedText (text, juce::Rectangle<int> (30, listTop + 10, getWidth() - 60, getHeight() - listTop - 20), juce::Justification::centred, 5);
    }
}

void BandPanel::timerCallback()
{
    auto& p = ctx.proc();
    if (const int ls = p.layoutShown.load(); ls != lastLayoutShown)
    {
        lastLayoutShown = ls;
        layoutBtn.setButtonText (ls >= 0 ? "LAYOUT: " + juce::String (bandLayout (ls / 16, ls % 16).name) : juce::String ("BAND LAYOUTS"));
    }
    if (p.numTracks.load() != lastTracks || p.tracksChanged.load() != lastChanged)
        rebuildStrips();

    const int rl = role();
    viewport.setVisible (rl <= 0);
    if (rl != lastRole)
    {
        lastRole = rl;
        copyBtn.setToggleState (rl > 0, juce::dontSendNotification);
        repaint();
    }
    if (p.bandGenreNow() != lastGrooveGenre || (p.myGroovesChanged.load() != lastMyGrooves && ! grooveBox.isPopupActive())) fillGrooves();
    else if (p.bandGrooveNow() != lastGroove && ! grooveBox.isPopupActive()) syncGrooveBox();
    {   // CHANGE moved the drums somewhere else: show where, click to keep it
        const bool changing = changeBox.getSelectedItemIndex() > 0 && p.bandPlaying.load();
        const int now = changing ? p.bandGroovePlaying() : -1;
        const int show = (now >= 0 && now != p.bandGrooveNow()) ? now : -1;
        if (show != lastNowShown)
        {
            lastNowShown = show;
            keepTag.setVisible (show >= 0);
            keepTag.colour = ctx.theme().accent;
            keepTag.text = show >= 0 ? "NOW " + juce::String (grooveLabel (p.bandGenreNow(), show)).upToFirstOccurrenceOf (" ", false, false) + " - KEEP" : juce::String();
            keepTag.repaint();
            repaint (190, 0, 200, 13);
        }
    }
    for (auto& sp : strips)
    {
        auto& s = *sp;
        bool dirty = false;
        const auto hits = p.partHits[(size_t) s.track].load();
        if (hits != s.lastHits) { s.lastHits = hits; s.glow = 1.0f; dirty = true; }
        else if (s.glow > 0.0f) { s.glow = juce::jmax (0.0f, s.glow - 0.2f); dirty = true; }
        s.sync();
        if (dirty) s.repaint (0, 0, 22, 36);
    }
    allHoldBtn.setToggleState (p.allHold(), juce::dontSendNotification);
    syncLoopRow();
    {   // a red CH box: two parts on one channel (one instrument would play both), or the keyboard's channel with the cable on
        const int chordCh = (int) p.apvts.getRawParameterValue (ids::chordCh)->load();
        const int kb = p.cableName().isNotEmpty() ? p.keyboardCh.load() : -1;
        auto partName = [&] (int t) { return p.trackName (t).isNotEmpty() ? p.trackName (t) : juce::String (bandTypeName (p.trackType (t))); };
        auto setWarn = [] (juce::ComboBox& box, const juce::String& why, const juce::String& normal)
        {
            const bool warn = why.isNotEmpty();
            if ((bool) box.getProperties().getWithDefault ("warn", false) != warn) { box.getProperties().set ("warn", warn); box.repaint(); }
            const auto tip = warn ? why : normal;
            if (box.getTooltip() != tip) box.setTooltip (tip);
        };
        bool chordClash = false;
        for (auto& sp : strips)
        {
            auto& s = *sp;
            const int ch = (int) std::lround (p.trackValue (s.track, TpCh));
            juce::String why;
            if (p.trackValue (s.track, TpOn) > 0.5f)
            {
                if (ch == kb) why = "CH " + juce::String (ch) + " is your keyboard's channel (the cable is on): pick another one";
                else if (ch == chordCh) { why = "The CHORDS are on CH " + juce::String (ch) + " too: one instrument would play both"; chordClash = true; }
                else
                    for (auto& op : strips)
                        if (op.get() != &s && p.trackValue (op->track, TpOn) > 0.5f && (int) std::lround (p.trackValue (op->track, TpCh)) == ch
                            && ! (bandTypeIsDrums (p.trackType (s.track)) && bandTypeIsDrums (p.trackType (op->track))))
                        {
                            why = partName (op->track) + " (track " + juce::String (op->track + 1) + ") is on CH " + juce::String (ch)
                                  + " too: one instrument would play both. Give one of them its own channel";
                            break;
                        }
            }
            setWarn (s.channel, why, "MIDI channel this track plays on. Lock the instrument for this part to this channel "
                                     "(right-click it in the Channel rack > Receive notes from > the cable > this channel)");
        }
        setWarn (chordChBox, chordCh == kb ? "CH " + juce::String (kb) + " is your keyboard's channel (the cable is on): pick another one"
                             : chordClash ? juce::String ("A band track is on this channel too: one instrument would play both") : juce::String(),
                 "MIDI channel for VESPER's chords");
    }

    const int genre = (int) p.apvts.getRawParameterValue (ids::bandGenre)->load();
    const bool anyOn = anyPartOn();
    bool dirty = false;
    if (genre != lastGenre || anyOn != lastAnyOn)
    {
        lastGenre = genre;
        lastAnyOn = anyOn;
        // nothing on yet: show PICK A GENRE, so choosing any genre (even the first one) starts the band
        genreBox.setSelectedId (anyOn ? genre + 1 : 0, juce::dontSendNotification);
        dirty = true;
    }
    const bool playing = p.bandPlaying.load();
    const int follow = p.followState.load();
    if (playing != lastPlaying || follow != lastFollow) { lastPlaying = playing; lastFollow = follow; dirty = true; }
    if (dirty) repaint();
}

//==============================================================================
juce::File BandPanel::PartDrag::exportPart()
{
    auto& p = ctx.proc();
    const int ch = (int) p.trackValue (track, TpCh);
    return p.exportRecording (ch, juce::String (bandTypeShort (p.trackType (track))).toLowerCase());
}

void BandPanel::PartDrag::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const bool have = ctx.proc().recordedNotes() > 0;
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    g.setColour (have ? t.cardHi : t.cardDark);
    g.fillRoundedRectangle (r, 5.0f);
    juce::Path border, dashed;
    border.addRoundedRectangle (r, 5.0f);
    const float dashes[] = { 3.0f, 3.0f };
    juce::PathStrokeType (1.0f).createDashedStroke (dashed, border, dashes, 2);
    g.setColour (have ? t.home : t.faint);
    g.fillPath (dashed);
    g.setFont (uiFont (10.5f, have));
    g.setColour (have ? t.text : t.dim);
    g.drawText ("DRAG", getLocalBounds(), juce::Justification::centred);
}

void BandPanel::PartDrag::mouseDrag (const juce::MouseEvent& e)
{
    if (started || e.getDistanceFromDragStart() < 5 || ctx.proc().recordedNotes() == 0) return;
    started = true;
    const auto f = exportPart();
    if (f.existsAsFile())
        juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
}

void BandPanel::PartDrag::mouseUp (const juce::MouseEvent&)
{
    if (! started && ctx.proc().recordedNotes() > 0)
    {
        const auto f = exportPart();
        if (f.existsAsFile())
        {
            auto dir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER");
            dir.createDirectory();
            auto dest = dir.getNonexistentChildFile (f.getFileNameWithoutExtension(), ".mid");
            if (f.copyFileTo (dest)) dest.revealToUser();
        }
    }
    started = false;
}
