#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_devices/juce_audio_devices.h>

#include "Theory.h"
#include "Voicing.h"
#include "Perform.h"
#include "KeysSynth.h"
#include "Rack.h"
#include "Looper.h"
#include "Band.h"
#include "Song.h"
#include "Fills.h"

#include <functional>
#include "LinkBus.h"

#include <array>
#include <atomic>
#include <vector>

namespace ids
{
    inline constexpr const char* strum     = "strum";
    inline constexpr const char* strumDir  = "strumDir";
    inline constexpr const char* humanize  = "humanize";
    inline constexpr const char* height    = "height";
    inline constexpr const char* keysOn    = "keysOn";
    inline constexpr const char* keysLevel = "keysLevel";
    inline constexpr const char* vary      = "vary";
    inline constexpr const char* smooth    = "smooth";
    inline constexpr const char* hold      = "hold";
    inline constexpr const char* bassMode  = "bassMode";
    inline constexpr const char* velMode   = "velMode";
    // playing styles (the per-style switches use the ids in vesper::rhythmInfo / feelInfo / timingInfo)
    inline constexpr const char* rate      = "rate";
    inline constexpr const char* swing     = "swing";
    inline constexpr const char* multi     = "multi";
    inline constexpr const char* extType   = "extType";
    inline constexpr const char* extMode   = "extMode";
    inline constexpr const char* extRate   = "extRate";
    inline constexpr const char* extStyles = "extStyles";
    inline constexpr const char* extLatch  = "extLatch";
    // STACK: what each key plays (the whole chord, one note, octaves, stacked 3rds...)
    inline constexpr const char* stack      = "stack";
    inline constexpr const char* stackNotes = "stackNotes";
    // band (per-track ids are "t1".."t15" + On / Type / Mode / Style / Dens / Cplx / Oct / Lvl / Ch / Dyn)
    inline constexpr const char* bandOn     = "bandOn";
    inline constexpr const char* bandGenre  = "bandGenre";
    inline constexpr const char* bandGroove = "bandGroove";
    inline constexpr const char* bandPhrase = "bandPhrase";
    inline constexpr const char* bandSwing  = "bandSwing";
    inline constexpr const char* bandFeel   = "bandFeel";
    inline constexpr const char* bandChange = "bandChange";
    inline constexpr const char* bandVary   = "bandVary";
    inline constexpr const char* bandStop   = "bandStop";
    inline constexpr const char* bandRole   = "bandRole";
    // MOOD (dark .. bright) and GLIDE (chords slide into each other)
    inline constexpr const char* mood       = "mood";
    inline constexpr const char* glide      = "glide";
    inline constexpr const char* chordCh    = "chordCh";
    inline juce::String track (int t, const char* what) { return "t" + juce::String (t + 1) + what; }
    // version 1.5 and older: six fixed parts ("bMelOn" ...), loaded into tracks 1-6
    inline juce::String legacyBand (int part, const char* what) { return juce::String (vesper::bandPartId (part)) + what; }
}

// per-track parameters, in the order VesperProcessor::trackParams holds them
enum TrackParam { TpOn = 0, TpType, TpMode, TpStyle, TpDens, TpCplx, TpOct, TpLvl, TpCh, TpDyn, numTrackParams };
const char* trackParamSuffix (int which);

// What the audio thread needs to turn keys into chords. Trivially copyable.
struct EngineConfig
{
    int keyRoot = 0, scale = 0, genre = 0, style = vesper::Lush;
    int keysMode = 0;          // 0 = SCALE (every chord in the key), 1 = PADS (the 24-chord palette)
    int paletteStart = 48;     // first key of the pads in PADS mode (FL: C4)
    // SPLIT: chords under the left hand, the right hand plays its own notes
    bool split = false;
    int splitNote = 60;        // first key of the right hand (FL: C5)
    int rightCh = 0;           // MIDI channel for the right hand, 0 = same as the chords
    int rightOct = 0;          // right hand octave shift
    bool rightSnap = false;    // right hand: wrong notes snap into the key
    int leftRow = -1;          // SCALE mode: chord family for the octave left of the split (-1 = by octave)
    int padBank = 0;           // PADS mode: 0 = pads 1-12 left of the split, 1 = pads 13-24
    uint16_t scaleMask = 0;    // pitch classes in the key
    std::array<vesper::KeySlot, 128> scaleKeys {};
    vesper::Palette palette {};
};

// The last chord played, for the display. Audio thread -> UI.
struct PlayedInfo
{
    vesper::Chord chord;
    vesper::Notes notes;       // the voicing
    int bassNote = -1;
    int style = 0, variant = 0;
    int rhythm = -1;           // playing style, -1 = plain chord
    int source = -1;           // MIDI key (0..127) or a UI id (>= 1000)
};

// Everything the editor edits. Message thread only.
struct UiState
{
    int keyRoot = 0, scale = 0, genre = vesper::Soul, style = vesper::Lush;
    int keysMode = 0, theme = 0, uiScale = 1, tab = 0, selectedCard = 0;
    bool autoRec = true;       // follow FL's record button
    uint32_t diceSeed = 0;
    uint32_t padLocks = 0;     // LOCKED pads (bit per pad): DICE leaves them alone
    vesper::Palette palette {};
    // split keyboard (see EngineConfig)
    bool split = false, rightSnap = false;
    bool hideChordPanel = false, hidePreview = false, hideNext = false;   // MENU > Show / hide
    juce::String skin;                                               // a picture behind VESPER (MENU > Skin)
    bool songTab = true;                                             // the SONG tab (always shown now)
    int splitNote = 60, rightCh = 0, rightOct = 0, leftRow = -1, padBank = 0;
};

class VesperProcessor;
std::unique_ptr<juce::Thread> makeVoiceLink (VesperProcessor&);   // ProcessorLive.cpp
void loadPhraseRatings();                                         // ProcessorPerform.cpp

class VesperProcessor : public juce::AudioProcessor, private juce::Timer
{
public:
    VesperProcessor();
    ~VesperProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override { rack.release(); }
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "VESPER"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 2.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return "Default"; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    //==============================================================================
    // Message-thread API used by the editor
    juce::AudioProcessorValueTreeState apvts;
    UiState ui;
    vesper::ScaleMap scaleMap;

    void applyUiState();                                   // rebuild the key map and hand it to the audio thread
    void setKeyScaleGenre (int key, int scale, int genre, bool rebuildPalette);
    void setPalette (const vesper::Palette&);              // undoable
    bool undo();
    bool redo();
    bool canUndo() const { return historyPos > 0; }
    bool canRedo() const { return historyPos + 1 < (int) history.size(); }

    void uiPlayChord (int source, const vesper::Chord&, int style, int variant);
    void uiPlayNotes (int source, const vesper::Notes&, const vesper::Chord& label);
    void uiRelease (int source);
    void uiExt (bool down);                                // the on-screen EXT pad
    void panic();

    bool getLastPlayed (PlayedInfo& out);
    uint32_t playedCounter() const { return playedCount.load(); }

    bool isInputKeyDown (int note) const;
    bool isOutputNoteOn (int note) const;

    std::atomic<uint32_t> loopEvents { 0 };   // bumps each time a MIDI feedback loop is caught

    // upper extension trigger: 0 = none, 1 = a key (note number), 2 = a CC (pedal, wheel, pad)
    std::atomic<int> extTrigType { 0 }, extTrigNum { -1 };
    std::atomic<bool> learnArmed { false };
    std::atomic<uint32_t> learnCount { 0 };
    std::atomic<bool> extOn { false };        // extension currently playing (for the UI light)
    // split keyboard: learn the split point from the next key pressed
    std::atomic<bool> splitLearnArmed { false };
    std::atomic<int> splitLearned { -1 };
    std::atomic<uint32_t> splitLearnCount { 0 };
    juce::String extTriggerName() const;

    std::atomic<bool> recording { false };
    std::atomic<bool> autoRec { true };       // start/stop REC with FL's own record button
    std::atomic<bool> takeSynced { false };   // the take is lined up with FL's song position
    void clearRecording() { clearRequested.store (true); }
    int recordedNotes() const { return recordedNoteOns.load(); }
    int recordedParts() const { return juce::countNumberOfBits (recChannelMask.load()); }
    juce::File exportRecording (int onlyChannel = 0, const juce::String& label = {});   // 0 = every channel, one track each
    juce::File exportPartsFolder();        // every channel as its own file in Documents/VESPER/Takes
    std::vector<int> takeChannels();       // channels with notes in the take, chords first
    juce::String channelName (int channel);
    bool writeTake (const juce::File&, int onlyChannel);
    juce::File exportChord (const vesper::Chord&, int style, int variant);

    bool flats() const { return vesper::keyPrefersFlats (ui.keyRoot, ui.scale); }

    // band
    std::array<std::atomic<uint32_t>, vesper::maxBandTracks> bandSeed;     // DICE per track
    void rollBandSeed (int track);
    void applyBandGenre (int genre);       // every track's style for the genre (+ its usual lineup if nothing is on)
    std::atomic<bool> bandPlaying { false };
    std::atomic<int> followState { 0 };    // copies: 0 = this is the main VESPER, 1 = following one, 2 = no main VESPER found
    std::array<std::atomic<uint32_t>, vesper::maxBandTracks> partHits;   // bumps when a track plays (lights)
    void stopBandFromUi();

    // tracks: how many are showing, and the key strips (bit per key C..B: that key is skipped)
    std::atomic<int> numTracks { vesper::defaultBandTracks };
    std::array<std::atomic<int>, vesper::maxBandTracks> trackKeys;
    std::atomic<int> chordKeys { 0 };      // the main chord output's key strip
    std::atomic<uint32_t> tracksChanged { 0 };   // bumps when tracks are added, removed or retyped (UI rebuilds)
    // chord LOOPER, sections A-D, MAKE IT A SONG, the listening drummer, band feel, surprise sit-outs
    Looper looper;
    std::atomic<bool> songOn { false }, drummerListens { false }, bandFeel { false };
    std::atomic<int> songSecNow { -1 }, songBarNow { -1 };                           // the section of the song playing (-1 = none), its bar
    // ---- SONG: whole songs for every genre (the hidden SONG tab; MAKE IT A SONG on the BAND tab plays one)
    std::atomic<int> songNumber { 1 };
    std::atomic<bool> songLoopSection { false }, followMe { false };
    std::atomic<int> songJump { -1 };            // a section you launched: it starts on the next bar line
    std::atomic<int> momentTap { 0 };            // a moment pad (FILL, STOP, DROP, BUILD, CRASH, HALF)
    std::atomic<int> momentShown { 0 };          // the moment playing this bar (for the pads to light)
    std::atomic<uint32_t> songPlanChanged { 0 };
    void newSong (int number);                                     // message thread: a new song for the band's genre
    vesper::SongPlan songPlanCopy() const;                                 // message thread
    void editSong (const std::function<void (vesper::SongPlan&)>& fn);     // message thread: cells, moments, lengths
    void rerollSongSection (int index);
    juce::String songStatus() const;                               // "HOOK   bar 3 of 8   next: VERSE"
    vesper::BandConfig songLineup() const;                                 // the tracks, as the song engine sees them
    void songFollowLineup();                                       // timer: a new genre / new tracks -> the song follows
    std::array<std::atomic<int>, Looper::numSections> sectionKey {};   // a key on your controller that switches to A-D
    std::atomic<int> sectionLearn { -1 };                         // the next key you press becomes that section's key
    std::atomic<uint32_t> sectionKeysChanged { 0 };
    std::array<std::atomic<int>, vesper::maxBandTracks> trackSurprise {};   // % chance a track sits a chord out
    // per-track switches (a bit each): PLAIN HOLD = a HOLD track plays plain held notes instead of the chord exactly as
    // it's styled (rhythm, strum, EXT); LOCK = the dice (and new songs) leave this track alone
    enum TrackFlag { FlagPlainHold = 1, FlagLock = 2 };
    std::array<std::atomic<int>, vesper::maxBandTracks> trackFlags {};
    bool trackFlag (int track, int flag) const { return track >= 0 && track < vesper::maxBandTracks && (trackFlags[(size_t) track].load() & flag) != 0; }
    void setTrackFlag (int track, int flag, bool on)
    {
        if (track < 0 || track >= vesper::maxBandTracks) return;
        if (on) trackFlags[(size_t) track].fetch_or (flag); else trackFlags[(size_t) track].fetch_and (~flag);
    }
    // the chords' channel with the cable on: when it's your keyboard's, the chords go out somewhere else (see the BAND tab)
    bool chordsOnKeyboardChannel() const;
    // MENU > Send MIDI through a cable: everything VESPER plays goes straight into a virtual MIDI cable (loopMIDI)
    // instead of FL's MIDI output port. In FL each instrument picks its part with Receive notes from > cable > channel.
    static juce::StringArray cableDevices();
    juce::String cableName() const;                                   // "" = off
    bool setCable (const juce::String& device, juce::String& error);  // message thread; "" turns it off
    bool cableTestMode = false;
    // with the cable on, channel 1 (or whatever your keyboard sends on) belongs to your keyboard: VESPER only takes keys
    // from it and never sends anything on it, so nothing VESPER plays can ever come back in as a key
    std::atomic<int> keyboardCh { 1 };
    juce::String keepKeyboardChannelFree();                           // moves the chords / tracks off it; says what moved
    std::atomic<uint32_t> cableSent { 0 }, cableIgnored { 0 };        // for MENU: notes sent, notes coming back that were ignored                                       // tests only: act as if a cable were on (MIDI still comes out)
    void goToSection (int s);                                      // A-D: play it (at the next bar line), or record it if it's empty

    // ---- PLAY THE SONG LIVE: call sections, fills, solos and jams from the SONG tab, keys on your controller, or your
    // voice (VESPER VOICE). Every call lands on time: the next bar, the end of the phrase or the end of the section.
    enum Command { CmdNone = 0, CmdSection, CmdNextSection, CmdMoment, CmdSolo, CmdJam, CmdTransition, CmdLoopSection,
                   CmdSongStart, CmdSongStop, CmdCatch, CmdGoTo, numCommands };
    void command (int cmd, int arg = -1);          // message thread
    void postCommand (int cmd, int arg = -1);      // any thread (your keys, the voice listener): done within a few ms
    bool voiceCommand (const juce::String& words); // "hook", "fill", "solo keys", "jam"... -> a command (false = not understood)
    std::atomic<int> switchAt { 1 };               // a section you call starts: 0 the next bar, 1 the end of the phrase, 2 the end of the section
    std::atomic<int> soloBars { 8 }, jamBars { 8 }, soloPick { -1 };   // soloPick -1 = VESPER picks who solos
    std::atomic<int> soloShown { -1 }, jamShown { 0 };   // for the screen: the track soloing (-1 none), bars of jam left (0 none)
    std::atomic<int> songJumpType { -1 };          // the section type you called (for the fill into it)
    std::atomic<bool> fillIntoCalls { true };      // the drummer fills into every section you call
    juce::String lastCommandText() const;
    std::atomic<uint32_t> commandCount { 0 };
    int pickSoloist() const;                       // the track that takes a solo when you don't say who
    // command keys: any key on your controller can call a section, a fill, a solo...
    static constexpr int numCommandKeys = 21;
    static const char* commandKeyName (int k);     // "HOOK", "FILL", "SOLO"...
    std::array<std::atomic<int>, numCommandKeys> commandKey {};   // the key for each (-1 = none)
    std::atomic<int> commandLearn { -1 };          // the next key you press becomes this command's key
    std::atomic<uint32_t> commandKeysChanged { 0 };
    int commandKeyOf (int note) const;
    void commandForKey (int k, int& cmd, int& arg) const;
    // SHAPES: a whole song from an arrangement (the genre's own, or one you saved)
    void songFromShape (const vesper::SongShape&);
    juce::StringArray savedShapeNames() const;
    bool loadSavedShape (const juce::String& name, vesper::SongShape&) const;
    void saveShape (const juce::String& name);     // the song as it is now
    void deleteShape (const juce::String& name);
    // the song as a list you can edit: add, remove, move, retype sections
    void songInsertSection (int afterIndex, int type, int bars);
    void songRemoveSection (int index);
    void songMoveSection (int index, int delta);
    void songRetypeSection (int index, int type);
    void songDuplicateSection (int index);

    // MIDI RECALL: VESPER always keeps the last few minutes of what it played. CATCH turns the last 16 bars into the
    // take (drag it from DRAG MIDI) and saves it in Documents/VESPER/Takes - no need to have pressed record.
    bool catchRecall();                         // message thread; false = nothing played yet, or a take is recording
    juce::File lastCatchFile;
    // PERFORMANCE: the sections you played and the calls you made, as they happened (since the song started)
    juce::String performanceText() const;      // "INTRO 4 > VERSE 8 (FILL) > HOOK 8 ..."
    bool keepPerformanceAsSong();               // the take becomes the song: lengths and moments as you played them
    void clearPerformance();
    void perfLog (int cmd, int arg);            // message thread: a call you made
    std::atomic<uint32_t> perfChanged { 0 };
    // per-track EXT: hold that track's key and only that track adds the upper extension
    std::array<std::atomic<int>, vesper::maxBandTracks> trackExtKey {};   // -1 none
    std::atomic<int> trackExtLearn { -1 };      // the next key you press becomes this track's EXT key
    std::atomic<uint32_t> trackExtKeysChanged { 0 }, trackExtLit { 0 };
    // SOUND slots: instruments played inside VESPER (0 = the chords, track t = slot t + 1)
    InstrumentRack rack;
    juce::String slotTitle (int slot) const;              // "VESPER - TRACK 2 (PAD) - Omnisphere"
    juce::String slotChannelName (int slot) const;        // what plays on that slot: "CHORDS", "PAD"...
    // track names ("Omnisphere - Warm Pad"): shown on the track and used in MIDI exports
    juce::String trackName (int track) const;
    void setTrackName (int track, const juce::String& name);
    std::atomic<uint32_t> namesChanged { 0 };
    float trackValue (int track, int which) const;
    void setTrackValue (int track, int which, float plainValue);
    int trackType (int track) const;
    bool addTrack();                       // false when all 15 are in use
    void removeTrack (int track);
    void setTrackType (int track, int type);
    void setAllHold (bool hold);           // ALL HOLD: every melodic track plays what you press
    bool allHold() const;
    int freeChannel (int exceptTrack) const;
    // YOUR MIDI: files (or folders of them) dropped on a track play instead of its style
    void loadTrackMidi (int track, const juce::StringArray& filesOrFolders);
    void clearTrackMidi (int track);
    void setTrackCycle (int track, int bars);
    int trackCycle (int track) const;
    int trackMidiCount (int track) const;
    juce::String trackMidiNow (int track) const;          // the file playing right now
    std::array<juce::StringArray, vesper::maxBandTracks> trackMidiFiles;
    std::array<std::atomic<int>, vesper::maxBandTracks> trackClipNow;
    // LIKE / SKIP the line a track is playing (kept for every project, in VESPER's settings folder)
    std::array<std::atomic<int>, vesper::maxBandTracks> trackPhraseNow {};
    void ratePhrase (int track, int rating);    // +1 like, -1 skip (never again), 0 forget
    void forgetPhraseRatings();
    int likedLines() const;
    int skippedLines() const;
    int bandGenreNow() const;              // the BAND tab's genre and groove
    int bandGrooveNow() const;
    int bandGroovePlaying() const { return grooveNowPlaying.load(); }   // where CHANGE has moved the drums (-1 = not playing)
    void setBandGroove (int index);

    // VESPER DRUMS follows the band's genre: VESPER writes it to a small file both plugins can see
    static juce::File drumLinkFile();

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    //==============================================================================
    // audio thread
    struct UiEvent
    {
        int type = 0;          // 0 play chord, 1 play notes, 2 release, 3 panic, 4 ext down, 5 ext up
        int source = 0;
        vesper::Chord chord;
        int style = -1, variant = -1;
        vesper::Notes notes;
    };

    struct Slot
    {
        bool active = false;
        int source = -1;
        uint32_t age = 0;
        vesper::Notes sent;                                  // notes this slot is sounding
        std::array<uint8_t, vesper::Notes::cap> chans {};

        // performance
        bool isExt = false;        // an upper-extension layer
        int parent = -1;           // ext layers: the chord slot they sit on
        bool applyFeel = true;
        vesper::Chord chord;
        vesper::Notes upper;       // chord tones, sorted
        vesper::Notes ext;         // extension notes merged into this chord's pattern
        int bass = -1, bassCh = 1;
        int velocity = 100;
        int rhythm = -1;           // -1 = plain chord
        double stepBeats = 0.5, anchor = 0, nextBeat = 0;
        int64_t gridIndex = 0;
        int stepCount = 0, memory = -1;
        bool synced = false, loopBar = false, done = false, swingOK = false, restartPending = false;
        bool muted = false;        // the chord output's key strip skips this key (band and layers still play)
        bool spreadOctave = true;  // waterfall / rising also use the octave above
        uint16_t mirror = 0;       // HOLD tracks that play this chord exactly as it's styled (bit per track)
    };

    struct Pending
    {
        int64_t due = 0;
        int note = 0, velocity = 0, channel = 1, slot = 0;
        int64_t offAfter = -1;     // note-ons: samples until the matching note-off, -1 = ring until release
        bool isOff = false;
        uint32_t gen = 0;          // note-offs: which strike of the note they belong to
    };

    struct VaryMemory { int id = -1; vesper::Notes notes; };

    struct RecEvent { double beat = 0; uint8_t kind = 0, channel = 1, d1 = 0, d2 = 0, synced = 0; };   // kind 0 on, 1 off, 2 cc

    // per-block snapshot of the playing-style switches
    struct StyleNow
    {
        bool rhythm[vesper::numRhythms] {};
        bool feel[vesper::numFeels] {};
        bool timing[vesper::numTimings] {};
        int rate = 0;              // 0 = each style's own, else index + 1
        float swing = 0.25f;       // fraction of a step
        int multi = 0;
        int extType = 0, extMode = 0, extRate = 3;
        bool extStyles = false, extLatch = false;
        float strumMs = 0, human = 0.35f;
        int strumDir = 0;
    };

    void readStyle();
    void handleUiEvent (const UiEvent&, juce::MidiBuffer& out);
    void triggerChord (int source, const vesper::Chord&, int style, int variant, int velocity, int pos, juce::MidiBuffer& out);
    void triggerNotes (int source, const vesper::Notes&, const vesper::Chord& label, int velocity, int pos, juce::MidiBuffer& out);
    int allocSlot (int source, int pos, juce::MidiBuffer& out);
    void releaseSource (int source, int pos, juce::MidiBuffer& out);
    void releaseSlot (int index, int pos, juce::MidiBuffer& out);
    void releaseAll (int pos, juce::MidiBuffer& out);
    void strike (int slot, const vesper::Notes& notes, int velocity, int accent, int pos, int64_t offAfter,
                 int stepParity, bool useFeel, bool useKnobStrum);
    void playStep (int slot, int pos, juce::MidiBuffer& out);
    void advancePatterns (int upToPos, juce::MidiBuffer& out);
    void setupRhythm (int slot, int rhythm, int rateIndex, int pos, juce::MidiBuffer& out);
    void extPress (int pos, juce::MidiBuffer& out);
    void extRelease (int pos, juce::MidiBuffer& out);
    void startExt (int parent, int pos, juce::MidiBuffer& out);
    void stopExt (int pos, juce::MidiBuffer& out);
    void noteOffOwned (int slot, int note, int channel, int pos, juce::MidiBuffer& out);
    void schedule (int64_t due, int note, int velocity, int channel, int slot, int64_t offAfter);
    void emitNoteOn (int note, int velocity, int channel, int slot, int pos, juce::MidiBuffer& out);
    void flushPending (int upTo, juce::MidiBuffer& out);
    void publish (const vesper::Chord&, const vesper::Notes&, int bass, int style, int variant, int rhythm, int source);
    void clearSlotNotes (int index, int pos, juce::MidiBuffer& out);
    // band
    void readBand();
    bool bandPartHere (int part) const;
    void bandChordChanged (const vesper::Chord&, int pos, juce::MidiBuffer& out, int key);
    void startBand (int pos, juce::MidiBuffer& out);
    void stopBand (int pos, juce::MidiBuffer& out);
    void adoptHarmony (int pos, juce::MidiBuffer& out);
    void advanceBand (int upToPos, juce::MidiBuffer& out, bool inclusive = false);
    void fireBandStep (int64_t step, double stepBeat, bool pitchedOnly, int64_t minDue, juce::MidiBuffer& out);
    void bandHousekeeping (int pos, juce::MidiBuffer& out);
    void playLayers (int source, const vesper::Chord&, const vesper::Notes& pressed, int velocity, int pos, juce::MidiBuffer& out,
                     uint16_t styled = 0);
    uint16_t holdMirrorMask (int keyPc) const;      // HOLD tracks that play the chord as styled (not plain held notes)
    void mirrorNote (int slot, int64_t due, int note, int velocity, int64_t offAfter);
    void clearRings (int pos, juce::MidiBuffer& out);
    void followLeader (juce::MidiBuffer& out);
    void publishLink();
    bool anyChordHeld() const;
    void startExpression (int pos, juce::MidiBuffer& out);
    void updateExpression (juce::MidiBuffer& out);
    double beatAt (int pos) const { return blockBeat + pos / samplesPerBeat; }
    int posOfBeat (double beat) const { return juce::jlimit (0, juce::jmax (0, blockSamples - 1), (int) std::floor ((beat - blockBeat) * samplesPerBeat)); }
    double stepTime (const Slot& s, int64_t index) const;

    EngineConfig cfg, pendingCfg;
    juce::SpinLock cfgLock;
    std::atomic<bool> cfgDirty { false };

    juce::AbstractFifo uiFifo { 256 };
    std::array<UiEvent, 256> uiEvents;

    static constexpr int numChordSlots = 32;
    // chord slots (keys you hold, plus their HOLD layers), then one per band track, then one RING slot per track
    std::array<Slot, numChordSlots + 3 * vesper::maxBandTracks> slots;
    static constexpr int trackExtSlot (int track) { return numChordSlots + 2 * vesper::maxBandTracks + track; }
    static constexpr int bandSlot (int track) { return numChordSlots + track; }
    static constexpr int ringSlot (int track) { return numChordSlots + vesper::maxBandTracks + track; }
    std::array<Pending, 1024> pending, dueList;
    int numPending = 0;
    std::array<std::array<int16_t, 128>, 16> owner {};
    std::array<std::array<uint32_t, 128>, 16> strikeGen {};
    std::array<VaryMemory, 64> varyMemory;
    vesper::Notes lastVoicing;
    int lastChordId = -1;                 // the chord struck last (the same key again keeps its voicing)
    vesper::Rng rng;
    uint32_t slotAge = 0;
    bool strumFlip = false;
    bool lastHold = false;
    bool lastHostRec = false;
    bool extHeld = false;
    int rhythmTurn = 0, lastRhythm = -1;

    StyleNow st;
    std::array<std::atomic<float>*, vesper::numRhythms> rhythmParams {};
    std::array<std::atomic<float>*, vesper::numFeels> feelParams {};
    std::array<std::atomic<float>*, vesper::numTimings> timingParams {};

    // expression (CC11) swell / fade
    int exprMode = 0;          // 0 off, 1 swell, 2 fade
    double exprStartBeat = 0;
    int lastExprSent = 127;
    float synthExpr = 1.0f;

    // block timing
    double blockBeat = 0, samplesPerBeat = 22050.0, bpm = 120.0;
    int blockSamples = 0;
    bool hostPlaying = false;

    // band (audio thread)
    vesper::Band band;
    vesper::BandConfig bandCfg;
    vesper::Harmony bandHarm;
    double bandHarmBeat = 0;
    int bandHarmCounter = 0;
    bool bandRunning = false, bandSynced = false, bandEnabled = true;
    double bandOrigin = 0, bandStopAt = -1, bandLastStepBeat = -1e9;
    int64_t bandNextStep = 0, bandLastStep = -1;
    uint32_t bandStarts = 0;
    int bandStopMode = 0, bandRoleNow = 0, chordChannel = 1;
    uint16_t keysSkip = 0;                 // channels the built-in keys sound leaves alone (drums)
    std::array<std::array<std::atomic<float>*, numTrackParams>, vesper::maxBandTracks> bandParams {};
    std::atomic<float>* stackParam = nullptr;
    std::atomic<float>* stackNotesParam = nullptr;
    uint32_t ringMask = 0;                 // RING tracks currently ringing
    bool lastHostPlaying = false;
    void migrateOldState (juce::XmlElement&);
    void timerCallback() override;         // keeps the VESPER DRUMS link file up to date
    std::atomic<int> grooveNowPlaying { -1 };
    std::array<juce::String, vesper::maxBandTracks> trackNames;
    juce::MidiBuffer loopInject, loopKeep;
    std::unique_ptr<juce::MidiOutput> cable;
    juce::SpinLock cableLock;
    juce::String cableOpen, cableWanted;     // what's open / what the project asked for (the timer opens it)
    bool cableDirty = false;
    double cableClock = 0, cableBlockMs = 0;
    // what went out through the cable, so it's thrown away if FL hands it straight back to VESPER
    std::array<std::array<uint8_t, 128>, 16> cableOnLeft {}, cableOffLeft {}, cableOnVel {};
    std::array<std::array<int64_t, 128>, 16> cableOnAt {}, cableOffAt {};
    int64_t cableEchoUntil = 0, cableEchoWin = 0, lastSingleEcho = -1000000000;
    int singleEchoes = 0;
    bool cableLive = false;
    // the same key handed over twice (VESPER's channel locked to your keyboard AND selected in FL)
    std::array<bool, 128> keyRawDown {};
    std::array<int64_t, 128> keyRawOnAt {}, keyDupUntil {};
    std::array<std::array<uint8_t, 128>, 16> cableHeld {};   // notes on in the instruments right now (for clean note-offs)
    void closeCable();
    double songStart = 0, crashBeat = -1;
    bool songActive = false;
    int songPartLast = -1, lastGrooveParam = -1;
    float lastPressVel = 100.0f;
    bool songTick (int numSamples);   // true = a new bar of the song starts in this block (the band re-reads)
    mutable juce::SpinLock songLock;
    vesper::SongPlan songPlan;
    struct SongBar { int sec = -1, bar = 0, bars = 0, type = 0, looper = 0, grooveBlock = 0, moment = 0, nextType = -1;
                     uint16_t mask = 0xffff; float energy = 0.5f; bool changeNext = false; double start = -1; };
    SongBar curBar, prevBar;
    int songSec = 0, songBar = -1, followJump = -1;
    double songNextBar = 0;
    struct FollowBar { int notes = 0; float vel = 0; std::array<int, 4> chords {}; int numChords = 0; };
    std::array<FollowBar, 8> followHist {};
    FollowBar followNow;
    int followCount = 0, padMoment = 0;
    int64_t padBar = -1;
    uint32_t songLineupSig = 0;
    int songGenreBuilt = -1;
    void applySongBar (const SongBar&);
    void followDecide (int curSec, int nextBarIndex);
    int momentFor (int64_t step, double stepBeat, int& inBar) const;
    void songMomentStep (int64_t step, double stepBeat, int64_t minDue);
    void drumTargets (int& kit, int& kick, int& snare, int& hats, int& cym) const;
    int sectionOfKey (int note) const;
    int resolveSection (int s) const;
    // FILLS (Fills.h): one per bar at most, built when it's needed and played step by step
    struct FillNow
    {
        int64_t bar = INT64_MIN;
        int startStep = 0, n = 0, size = 0;
        bool crash = false, keeps = false;
        std::array<vesper::FillHit, vesper::maxFillHits> hits {};
    };
    FillNow fillNow;
    uint32_t fillCounter = 0;
    std::array<uint32_t, 8> recentFills {};
    int fillWant (int64_t step, double stepBeat, int inBar, int& beats);   // 0 = no fill this bar, else FillSize + 1
    bool fillStep (int64_t step, double stepBeat, int64_t minDue);          // true = the fill has the drums on this step
    int drumTrackFor (int note) const;
    // JAM / SOLO / TRANSITION (band bars, counted in 16 steps)
    std::atomic<int> jamReq { 0 }, soloReq { 0 }, soloReqTrack { -1 };
    std::atomic<bool> transitionReq { false };
    int64_t jamFrom = -1, jamTo = -1, soloFrom = -1, soloTo = -1;
    int soloTrack = -1;
    bool transitionArmed = false;
    int64_t transitionSince = 0;
    void startPendingJamSolo (int64_t absBar);
    void applyJamSolo();
    bool boundaryAfterBar (int64_t absBar, int mode) const;   // the bar playing now ends a phrase (1) / a section (2); mode 0 = always
    bool jumpAllowedAfter (int bar, int bars) const;         // song bars: a called section may start after this bar
    bool songChangeComing() const;
    int songNextTypeNow() const;
    // the command queue (any thread -> the processor's timer)
    juce::SpinLock cmdLock;
    std::array<std::pair<int, int>, 64> cmdQueue {};
    int cmdCount = 0;
    juce::String lastCmdText;
    mutable juce::CriticalSection cmdTextLock;
    int timerTicks = 0;
    void drainCommands();
    std::unique_ptr<juce::Thread> voiceLink;   // VESPER VOICE talks to this (a local network port, 127.0.0.1 only)
    // MIDI RECALL: a ring of everything that went out
    std::vector<RecEvent> recall;
    std::atomic<int64_t> recallWrite { 0 };
    // PERFORMANCE: the sections as they were played (audio thread writes), the calls you made (message thread)
    std::array<std::atomic<int>, 256> perfSegSec {}, perfSegBars {};
    std::atomic<int> perfSegCount { 0 };
    struct PerfCall { int seg = 0, bar = 0, cmd = 0, arg = 0; };
    mutable std::vector<PerfCall> perfCalls;
    mutable vesper::SongPlan perfPlan;         // the song the take was played from
    std::atomic<uint32_t> perfStarts { 0 };    // bumps when the song starts (a new performance)
    mutable uint32_t perfStartsSeen = 0;
    void perfSync() const;                     // message thread: a new performance clears the old calls
    mutable juce::CriticalSection perfLock;
    void perfBar (int sec, bool newSection);   // audio thread: one more bar of the song
    // per-track EXT
    uint16_t trackExtHeld = 0, trackExtOn = 0;
    int trackExtHarm = -1;
    void updateTrackExt (int pos, juce::MidiBuffer& out);
    // MOOD and GLIDE: what was last sent to the instruments
    int lastMoodCC = -1, lastGlideCC = -1;
    void sendMoodGlide (juce::MidiBuffer& out);
    juce::CriticalSection rackStateLock;
    std::unique_ptr<juce::XmlElement> pendingRack;   // a saved rack to open on the message thread
    static BusesProperties makeBuses();
    int linkGenreWritten = -1, linkGrooveWritten = -1;
    std::array<std::atomic<vesper::ClipSet*>, vesper::maxBandTracks> trackClips;
    std::vector<std::unique_ptr<vesper::ClipSet>> clipOwned;
    struct RetiredClips { vesper::ClipSet* s; double at; };
    std::vector<RetiredClips> clipRetired;
    void installClips (int track, std::unique_ptr<vesper::ClipSet>);
    double linkWrittenAt = 0;
    // link between VESPER copies
    int linkId = 0;
    double linkDelta = 0, linkDeltaBest = -1e18, linkDeltaSince = 0;
    uint32_t linkStarts = 0;
    int linkHarmId = -1;
    bool linkHaveDelta = false;
    double linkNowMs = 0, linkOriginSeen = 0;
    bool linkSyncedSeen = false;
    int lastRole = 0, linkLeaderSeen = 0;
    bool anyBandPartOn() const;
    double lateWindowBeats() const;
    void checkBandClock (int pos, juce::MidiBuffer& out);
    void activateBandSlots();
    void updateKeysSkip();

    juce::MidiBuffer outBuffer;
    KeysSynth synth;
    double sr = 44100.0;
    int64_t sampleClock = 0;
    double freeBeat = 0;

    std::array<std::atomic<uint32_t>, 4> inDown {}, outOn {};
    std::array<int, 128> passthroughOn {};
    // per input key: the single note it is sounding (right hand / pass-through) and the
    // key whose chord it started (left hand), so note-offs match even if settings change
    std::array<int16_t, 128> keyOutNote {}, keyChordKey {};
    std::array<uint8_t, 128> keyOutCh {};
    void resetKeyMaps();

    // MIDI loop guard: if VESPER's own output gets routed back into it, its chords would
    // retrigger more chords forever. Remember what went out and drop it when it comes back.
    std::array<int64_t, 128> sentOnAt {}, sentOffAt {};
    std::array<std::array<int64_t, 128>, 16> chOnAt {}, chOffAt {};   // the same, per MIDI channel
    uint16_t bandChannels = 0;     // channels the band / HOLD / RING tracks play on (not the chords' channel)
    void loopCleanup (int pos, juce::MidiBuffer& out);
    std::array<int, 128> sentOnVel {};
    int64_t loopActiveUntil = 0, burstStart = 0, mutedUntil = 0;
    bool loopReported = false;   // the MIDI LOOP warning went up for this stretch of the guard
    int burstCount = 0;
    float sentEnergy = 0, matchEnergy = 0;   // recent notes sent vs. notes that came straight back
    void resetLoopGuard();

    juce::SpinLock playedLock;
    PlayedInfo played;
    std::atomic<uint32_t> playedCount { 0 };

    std::vector<RecEvent> rec;
    std::atomic<int> recCount { 0 };
    std::atomic<int> recordedNoteOns { 0 };
    std::atomic<uint32_t> recChannelMask { 0 };
    std::atomic<bool> clearRequested { false };

    // message thread
    std::vector<vesper::Palette> history;
    int historyPos = -1;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VesperProcessor)
};
