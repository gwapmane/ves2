#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "Look.h"
#include "PluginProcessor.h"
#include "Widgets.h"
#include "StylePanel.h"
#include "BandPanel.h"
#include "SongPanel.h"

class VesperEditor : public juce::AudioProcessorEditor,
                     public EditorContext,
                     private juce::Timer
{
public:
    explicit VesperEditor (VesperProcessor&);
    ~VesperEditor() override;

    void paint (juce::Graphics&) override;              // the desk and the unit's shadow
    void paintOverChildren (juce::Graphics&) override;  // the chrome unibody, over the face's edges
    void resized() override {}

    // EditorContext
    VesperProcessor& proc() override { return p; }
    const Theme& theme() const override { return look.theme(); }
    void play (int source, const vesper::Chord& c, int style, int variant) override { p.uiPlayChord (source, c, style, variant); }
    void playNotes (int source, const vesper::Notes& n, const vesper::Chord& label) override { p.uiPlayNotes (source, n, label); }
    void release (int source) override { p.uiRelease (source); }
    const Focus& focus() const override { return focus_; }
    void setFocus (const Focus&) override;
    void selectCard (int index) override;
    void sendToSelectedCard (const vesper::Chord&, int style, int variant) override;
    void paletteEdited() override;
    void dragChordOut (const vesper::Chord&, int style, int variant) override;
    const PlayedInfo& lastPlayed() const override { return played_; }

    static constexpr int baseW = 1180, baseH = 760;
    // TROUPE: the face sits in a chrome unibody: bezel = the chrome's width round the face, margin = the desk round it
    static constexpr int bezel = 22, margin = 8, edge = bezel + margin;

private:
    struct Canvas : public juce::Component
    {
        std::function<void (juce::Graphics&)> painter;
        void paint (juce::Graphics& g) override { if (painter) painter (g); }
    };

    juce::Image bodyImage;              // the unibody, drawn once per size
    float bodyImageScale = 0.0f;
    juce::Rectangle<int> bodyImageFor;
    float uiScaleNow() const;

    void timerCallback() override;
    void layout();
    void applyScale();
    void applyTheme();
    void showTab (int);
    void updateHeader();
    void refreshAll();
    void paintCanvas (juce::Graphics&);
    void onPlayed();
    void showMenu();
    void showRoutingHelp();
    void showCableHelp();
    // MENU > Skin: your own picture behind everything (the panels go see-through)
    juce::Image skinImage;
    void loadSkin();
    void pickSkin();
    Theme skinnedTheme() const;
    bool lowerHidden() const { return p.ui.hideChordPanel && p.ui.hidePreview && p.ui.hideNext; }
    void showSplitMenu();
    void updateSplitUi();
    void savePalette();
    void loadPalette();

    VesperProcessor& p;
    VesperLook look;
    Focus focus_;
    PlayedInfo played_;
    uint32_t lastCounter = 0, lastLightsHash = 0, lastSplitLearn = 0;
    int lastRecCount = -1;
    uint32_t lastLoopEvents = 0, loopWarnUntil = 0;

    Canvas canvas;

    // header
    juce::ComboBox keyBox, scaleBox, styleBox, genreBox, stackBox, stackNotesBox;
    juce::ToggleButton varyBtn { "VARY" };
    juce::Slider spiceKnob;                       // SPICE: how adventurous the chords get
    juce::ComboBox chordSetBox;                   // PALETTE tab: CHORD SETS (six progressions of four)
    juce::TextButton toLoopsBtn { "TO LOOPS A-D" };  // the chord set's rows become loops A-D: the song plays itself
    juce::String toLoopsNote;                     // what TO LOOPS just did (shown next to it for a few seconds)
    juce::uint32 toLoopsAt = 0;
    void showToLoopsMenu();
    int styleBoxGenre = -1, chordSetGenre = -1, chordSetMajor = -1;
    void fillStyleBox();
    void fillChordSetBox();
    juce::TextButton diceBtn { "DICE" }, menuBtn { "MENU" };

    // tabs
    static constexpr int numTabs = 6;   // the 6th (SONG) is hidden until you right-click the logo
    juce::TextButton tabBtns[numTabs];
    juce::TextButton modeBtns[2];
    juce::TextButton undoBtn { "UNDO" }, redoBtn { "REDO" };
    juce::TextButton splitBtn { "SPLIT" }, splitMenuBtn { "SETUP" };
    PaletteGrid palette { *this };
    ScaleGrid scaleGrid { *this };
    LibraryView library { *this };
    StylePanel stylePanel { *this };
    BandPanel bandPanel { *this };
    SongPanel songPanel { *this };
    struct LogoSpot : public juce::Component
    {
        std::function<void()> onRightClick;
        void mouseDown (const juce::MouseEvent& e) override { if (e.mods.isPopupMenu() && onRightClick) onRightClick(); }
    };
    LogoSpot logoSpot;

    // lower panels
    ChordPanel chordPanel { *this };
    PreviewPanel preview { *this };
    NextPanel nextPanel { *this };

    // controls
    juce::Slider strumKnob, humanKnob, heightKnob, levelKnob;
    juce::ComboBox strumDirBox, bassBox, velBox;
    juce::ToggleButton smoothBtn { "SMOOTH" }, holdBtn { "HOLD" }, keysBtn { "KEYS SOUND" };
    juce::TextButton panicBtn { "PANIC" };
    KeyboardStrip keyboard { *this };

    // footer
    juce::TextButton recBtn { "REC" }, clearBtn { "CLEAR" }, helpBtn { "PLAY MY SOUNDS?" }, savePartsBtn { "SAVE PARTS" };
    juce::TextButton chordSoundBtn;   // SOUND for the chords: an instrument played inside VESPER
    uint32_t lastRackSeen = 0xffffffffu;
    juce::ToggleButton autoRecBtn { "AUTO REC" };
    DragTile dragTile { *this };
    juce::TextButton sizeBtns[3];

    std::unique_ptr<juce::FileChooser> chooser;

    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtt;

    juce::TooltipWindow tooltips { this, 600 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VesperEditor)
};
