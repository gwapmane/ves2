// VESPER's SOUND slots: real instruments (VST3) played right inside VESPER - one for the chords and one for every
// band track. A slot plays the notes on its track's channel; those notes then stay inside VESPER (they no longer go
// out as MIDI), so nothing doubles if you still have a Patcher set up. Each slot can go to the MAIN output or its own
// output (send that to its own mixer track in FL).
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>

#include <array>
#include <atomic>

class InstrumentRack
{
public:
    static constexpr int numSlots = 16;           // 0 = the chords, track t = slot t + 1
    static constexpr int chordSlot = 0;
    static int trackSlot (int track) { return track + 1; }
    static juce::String outputName (int slot);     // "CHORDS OUT" / "TRACK 3 OUT"

    InstrumentRack();
    ~InstrumentRack();

    // ---- message thread
    static juce::Array<juce::File> installedInstruments();   // every .vst3 in the usual folders, by name
    bool load (int slot, const juce::File& file, juce::String& error, const juce::MemoryBlock* state = nullptr);
    void unload (int slot);
    void swap (int a, int b);                      // tracks moving around (one removed)
    bool loaded (int slot) const;
    juce::String name (int slot) const;            // "Omnisphere", or "" (empty slot)
    juce::String missing (int slot) const;         // a saved instrument that couldn't be found / opened
    void showWindow (int slot, const juce::String& title);
    void hideWindow (int slot);
    bool windowShowing (int slot) const;
    std::unique_ptr<juce::XmlElement> toXml() const;
    void fromXml (const juce::XmlElement&);
    std::array<std::atomic<int>, numSlots> ownOutput {};   // 1 = its own output, 0 = MAIN
    std::atomic<uint32_t> changed { 0 };                   // bumps on every load / unload (the UI follows)
    bool hasInstrument (int slot) const { return slot >= 0 && slot < numSlots && has[(size_t) slot].load(); }   // any thread

    // ---- audio
    void prepare (double sampleRate, int blockSize);
    void release();
    // every loaded slot plays the notes on its channel (taken out of `midi`) into the main output or its own one
    void process (juce::AudioProcessor& host, juce::AudioBuffer<float>& io, juce::MidiBuffer& midi,
                  const std::array<int, numSlots>& channelOf);

private:
    struct Slot
    {
        std::unique_ptr<juce::AudioPluginInstance> inst;
        juce::File file;
        juce::String name, missing;
        mutable juce::SpinLock lock;
        std::unique_ptr<juce::DocumentWindow> window;
    };
    std::array<Slot, numSlots> slots;
    std::array<std::atomic<bool>, numSlots> has {};
    juce::AudioPluginFormatManager formats;
    double sr = 44100.0;
    int block = 512;
    juce::AudioBuffer<float> scratch;
    juce::MidiBuffer slotMidi, keep;
};
