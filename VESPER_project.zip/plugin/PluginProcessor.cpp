#include "PluginProcessor.h"
#include "PluginEditor.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <limits>

using namespace vesper;

static constexpr int extSource = 1 << 20;

const char* trackParamSuffix (int which)
{
    static const char* const w[numTrackParams] = { "On", "Type", "Mode", "Style", "Dens", "Cplx", "Oct", "Lvl", "Ch", "Dyn" };
    return w[juce::jlimit (0, numTrackParams - 1, which)];
}

//==============================================================================
juce::AudioProcessorValueTreeState::ParameterLayout VesperProcessor::createLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::strum, 1 }, "Strum",
                                                              juce::NormalisableRange<float> (0.0f, 250.0f, 0.1f, 0.5f), 0.0f,
                                                              juce::AudioParameterFloatAttributes().withLabel ("ms")));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::strumDir, 1 }, "Strum Direction",
                                                               juce::StringArray { "Up", "Down", "Up/Down", "Random" }, 0));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::humanize, 1 }, "Humanize",
                                                              juce::NormalisableRange<float> (0.0f, 1.0f), 0.35f));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::height, 1 }, "Height",
                                                              juce::NormalisableRange<float> (40.0f, 84.0f, 1.0f), 60.0f));
    p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { ids::keysOn, 1 }, "Keys Sound", true));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::keysLevel, 1 }, "Keys Level",
                                                              juce::NormalisableRange<float> (0.0f, 1.0f), 0.7f));
    p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { ids::vary, 1 }, "Vary", false));
    p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { ids::smooth, 1 }, "Smooth", true));
    p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { ids::hold, 1 }, "Hold", false));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::bassMode, 1 }, "Bass",
                                                               juce::StringArray { "Off", "Low", "Channel 2" }, 0));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::velMode, 1 }, "Velocity",
                                                               juce::StringArray { "Played", "Fixed" }, 0));
    {
        juce::StringArray stacks;
        for (int m = 0; m < numStackModes; ++m) stacks.add (stackName (m));
        p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::stack, 1 }, "Stack", stacks, 0));
        p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::stackNotes, 1 }, "Stack Notes",
                                                                   juce::StringArray { "2 notes", "3 notes", "4 notes" }, 0));
    }

    // playing styles: one switch each
    for (int r = 0; r < numRhythms; ++r)
        p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { rhythmInfo (r).id, 1 },
                                                                 juce::String ("Style ") + rhythmInfo (r).name, false));
    for (int f = 0; f < numFeels; ++f)
        p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { feelInfo (f).id, 1 },
                                                                 juce::String ("Feel ") + feelInfo (f).name, false));
    for (int t = 0; t < numTimings; ++t)
        p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { timingInfo (t).id, 1 },
                                                                 juce::String ("Timing ") + timingInfo (t).name, false));

    juce::StringArray rates { "Style default" };
    juce::StringArray extRates;
    for (int r = 0; r < numRates; ++r) { rates.add (rateName (r)); extRates.add (rateName (r)); }
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::rate, 1 }, "Style Rate", rates, 0));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::swing, 1 }, "Swing",
                                                              juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 50.0f,
                                                              juce::AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::multi, 1 }, "Several Styles",
                                                               juce::StringArray { "Take turns", "Random" }, 0));

    juce::StringArray extTypes, extModes;
    for (int t = 0; t < numExtTypes; ++t) extTypes.add (extTypeName (t));
    for (int m = 0; m < numExtModes; ++m) extModes.add (extModeName (m));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::extType, 1 }, "Extension Type", extTypes, 0));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::extMode, 1 }, "Extension Mode", extModes, 0));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::extRate, 1 }, "Extension Rate", extRates, 3));
    p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { ids::extStyles, 1 }, "Styles On Extension", false));
    p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { ids::extLatch, 1 }, "Extension Latch", false));

    // band
    p.push_back (std::make_unique<juce::AudioParameterInt> (juce::ParameterID { ids::chordCh, 1 }, "Chord Channel", 1, 16, 1));
    p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { ids::bandOn, 1 }, "Band", true));
    juce::StringArray genres, roles { "Everything" };
    for (int g = 0; g < numGenres; ++g) genres.add (genreName (g));
    for (int t = 0; t < maxBandTracks; ++t) roles.add ("Only track " + juce::String (t + 1));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::bandGenre, 1 }, "Band Genre", genres, 0));
    p.push_back (std::make_unique<juce::AudioParameterInt> (juce::ParameterID { ids::bandGroove, 1 }, "Band Groove", 0, maxGroovesPerGenre - 1, 0));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::bandPhrase, 1 }, "Band Phrase",
                                                               juce::StringArray { "1 bar", "2 bars", "4 bars", "8 bars" }, 2));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::bandSwing, 1 }, "Band Swing",
                                                              juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 0.0f,
                                                              juce::AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::bandFeel, 1 }, "Band Feel",
                                                              juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 100.0f,
                                                              juce::AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::bandVary, 1 }, "Band Vary",
                                                              juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 30.0f,
                                                              juce::AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::bandChange, 1 }, "Band Groove Change",
                                                               juce::StringArray { "Off", "Every 4 bars", "Every 8 bars", "Every 16 bars", "Every 32 bars" }, 0));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::bandStop, 1 }, "Band Stops",
                                                               juce::StringArray { "When you let go", "At the end of the bar", "Never (until FL stops)" }, 0));
    p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::bandRole, 1 }, "This VESPER Plays", roles, 0));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::mood, 1 }, "Mood (dark - bright)",
                                                              juce::NormalisableRange<float> (-1.0f, 1.0f), 0.0f));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::glide, 1 }, "Glide",
                                                              juce::NormalisableRange<float> (0.0f, 1.0f, 0.0f, 0.5f), 0.0f,
                                                              juce::AudioParameterFloatAttributes().withLabel ("s")));
    juce::StringArray types;
    for (int ty = 0; ty < numBandTypes; ++ty) types.add (bandTypeShort (ty));
    const auto soul = bandGenrePreset (0);
    for (int t = 0; t < maxBandTracks; ++t)
    {
        const juce::String name = "Track " + juce::String (t + 1);
        const int type = bandDefaultType (t);
        p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { ids::track (t, "On"), 1 }, name, false));
        p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::track (t, "Type"), 1 }, name + " Type", types, type));
        p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::track (t, "Mode"), 1 }, name + " Plays",
                                                                   juce::StringArray { "Jam", "Hold", "Ring" }, 0));
        p.push_back (std::make_unique<juce::AudioParameterInt> (juce::ParameterID { ids::track (t, "Style"), 1 }, name + " Style",
                                                                0, bandMaxStyles() - 1, soul.style[type]));
        p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::track (t, "Dens"), 1 }, name + " Density",
                                                                  juce::NormalisableRange<float> (0.0f, 1.0f), 0.5f));
        p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::track (t, "Cplx"), 1 }, name + " Complexity",
                                                                  juce::NormalisableRange<float> (0.0f, 1.0f), 0.5f));
        p.push_back (std::make_unique<juce::AudioParameterInt> (juce::ParameterID { ids::track (t, "Oct"), 1 }, name + " Octave", -2, 2, 0));
        p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { ids::track (t, "Lvl"), 1 }, name + " Level",
                                                                  juce::NormalisableRange<float> (0.0f, 1.0f), 0.75f));
        p.push_back (std::make_unique<juce::AudioParameterInt> (juce::ParameterID { ids::track (t, "Ch"), 1 }, name + " Channel", 1, 16,
                                                                bandDefaultChannel (t)));
        p.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { ids::track (t, "Dyn"), 1 }, name + " Dynamics",
                                                                   juce::StringArray { "OFF", "CC1", "CC11", "CC1+11" },
                                                                   type == BStrings ? 2 : 0));
    }
    return { p.begin(), p.end() };
}

VesperProcessor::VesperProcessor()
    : AudioProcessor (makeBuses()),
      apvts (*this, nullptr, "PARAMS", createLayout())
{
    for (int g = 0; g < numGenres; ++g) numGrooves (g);   // build every genre's grooves now, not on the audio thread
    for (auto& k : sectionKey) k.store (-1);
    for (auto& k : commandKey) k.store (-1);
    for (auto& k : trackExtKey) k.store (-1);
    for (auto& s : trackSurprise) s.store (0);
    for (auto& f : trackFlags) f.store (0);
    recall.resize (1 << 16);   // MIDI RECALL: the last few minutes of a busy band
    loopInject.ensureSize (8192);
    loopKeep.ensureSize (8192);
    rec.resize (1 << 18);   // about an hour of a busy band
    resetLoopGuard();
    for (auto& a : inDown) a.store (0);
    for (auto& a : outOn) a.store (0);
    for (int r = 0; r < numRhythms; ++r) rhythmParams[(size_t) r] = apvts.getRawParameterValue (rhythmInfo (r).id);
    for (int f = 0; f < numFeels; ++f) feelParams[(size_t) f] = apvts.getRawParameterValue (feelInfo (f).id);
    for (int t = 0; t < numTimings; ++t) timingParams[(size_t) t] = apvts.getRawParameterValue (timingInfo (t).id);
    for (int t = 0; t < maxBandTracks; ++t)
    {
        for (int w = 0; w < numTrackParams; ++w) bandParams[(size_t) t][(size_t) w] = apvts.getRawParameterValue (ids::track (t, trackParamSuffix (w)));
        bandSeed[(size_t) t].store ((uint32_t) (t * 7919 + 101));
        partHits[(size_t) t].store (0);
        trackKeys[(size_t) t].store (0);
    }
    stackParam = apvts.getRawParameterValue (ids::stack);
    stackNotesParam = apvts.getRawParameterValue (ids::stackNotes);
    linkId = LinkBus::get().newId();
    for (auto& c : trackClips) c.store (nullptr);
    setSongFeel (FeelNormal);
    for (auto& c : trackClipNow) c.store (0);
    startTimer (25);   // commands (your keys, your voice) every 25 ms; the slow chores every half second
    voiceLink = makeVoiceLink (*this);
    loadPhraseRatings();
    for (auto& ph : trackPhraseNow) ph.store (-1);
    ui.palette = buildPalette (ui.keyRoot, ui.scale, ui.genre, 0);
    ui.style = genreDefaultStyle (ui.genre);
    history.push_back (ui.palette);
    historyPos = 0;
    resetKeyMaps();
    applyUiState();
}

VesperProcessor::~VesperProcessor()
{
    stopTimer();
    LinkBus::get().leave (linkId);
    if (voiceLink != nullptr) voiceLink->stopThread (2000);
    closeCable();
}

//==============================================================================
// the MIDI cable (loopMIDI)
juce::StringArray VesperProcessor::cableDevices()
{
    juce::StringArray names;
    for (const auto& d : juce::MidiOutput::getAvailableDevices())
        if (! d.name.containsIgnoreCase ("GS Wavetable")) names.add (d.name);
    return names;
}

juce::String VesperProcessor::cableName() const { return cableOpen; }

void VesperProcessor::closeCable()
{
    std::unique_ptr<juce::MidiOutput> old;
    std::array<std::array<uint8_t, 128>, 16> held {};
    {
        const juce::SpinLock::ScopedLockType sl (cableLock);
        old = std::move (cable);
        held = cableHeld;
        for (auto& c : cableHeld) c.fill (0);
    }
    if (old != nullptr)   // nothing left hanging: a note-off for every note still on, then all notes off
    {
        for (int ch = 0; ch < 16; ++ch)
            for (int n = 0; n < 128; ++n)
                if (held[(size_t) ch][(size_t) n] > 0) old->sendMessageNow (juce::MidiMessage::noteOff (ch + 1, n));
        for (int ch = 1; ch <= 16; ++ch) old->sendMessageNow (juce::MidiMessage::allNotesOff (ch));
    }
    cableOpen = {};
}

bool VesperProcessor::chordsOnKeyboardChannel() const
{
    return cableName().isNotEmpty() && (int) apvts.getRawParameterValue (ids::chordCh)->load() == juce::jlimit (1, 16, keyboardCh.load());
}

juce::String VesperProcessor::keepKeyboardChannelFree()
{
    const int kb = juce::jlimit (1, 16, keyboardCh.load());
    juce::StringArray moved;
    auto chordNow = [this] { return (int) apvts.getRawParameterValue (ids::chordCh)->load(); };
    auto used = [&] (int ch)
    {
        if (chordNow() == ch) return true;
        for (int t = 0; t < numTracks.load(); ++t) if ((int) std::lround (trackValue (t, TpCh)) == ch) return true;
        return false;
    };
    auto freeCh = [&]
    {
        for (int ch = 16; ch >= 1; --ch) if (ch != kb && ch != 10 && ! used (ch)) return ch;
        return kb == 16 ? 15 : 16;
    };
    if (chordNow() == kb)
    {
        const int c = freeCh();
        if (auto* prm = apvts.getParameter (ids::chordCh)) prm->setValueNotifyingHost (prm->convertTo0to1 ((float) c));
        moved.add ("the CHORDS to CH " + juce::String (c));
    }
    for (int t = 0; t < numTracks.load(); ++t)
        if ((int) std::lround (trackValue (t, TpCh)) == kb)
        {
            const int c = freeCh();
            setTrackValue (t, TpCh, (float) c);
            const auto nm = trackName (t).isNotEmpty() ? trackName (t) : juce::String (bandTypeName (trackType (t)));
            moved.add (nm + " (track " + juce::String (t + 1) + ") to CH " + juce::String (c));
        }
    if (moved.isEmpty()) return {};
    return "Channel " + juce::String (kb) + " now belongs to your keyboard, so VESPER moved " + moved.joinIntoString (", ")
           + ". Lock those instruments to their new channels (right-click > Receive notes from > the cable > that channel).";
}

bool VesperProcessor::setCable (const juce::String& device, juce::String& error)
{
    cableWanted = device;
    cableDirty = false;
    closeCable();
    if (device.isEmpty()) return true;
    for (const auto& d : juce::MidiOutput::getAvailableDevices())
    {
        if (d.name != device) continue;
        auto out = juce::MidiOutput::openDevice (d.identifier);
        if (out == nullptr)
        {
            error = "VESPER couldn't open \"" + device + "\". If it's selected in FL's MIDI Settings OUTPUT list, unselect it "
                    "there (VESPER sends into it by itself now) and pick it again.";
            return false;
        }
        out->startBackgroundThread();
        cableClock = 0;
        const juce::SpinLock::ScopedLockType sl (cableLock);
        cable = std::move (out);
        cableOpen = device;
        return true;
    }
    error = "\"" + device + "\" isn't there. Open loopMIDI and check the port is still in its list.";
    return false;
}

juce::File VesperProcessor::drumLinkFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("VESPER").getChildFile ("drum-link.xml");
}

//==============================================================================
// YOUR MIDI
void VesperProcessor::installClips (int track, std::unique_ptr<ClipSet> cs)
{
    ClipSet* next = cs.get();
    if (cs != nullptr) clipOwned.push_back (std::move (cs));
    ClipSet* old = trackClips[(size_t) track].exchange (next);
    if (old != nullptr) clipRetired.push_back ({ old, juce::Time::getMillisecondCounterHiRes() });
    tracksChanged.fetch_add (1);
}

void VesperProcessor::loadTrackMidi (int track, const juce::StringArray& paths)
{
    if (track < 0 || track >= maxBandTracks) return;
    juce::Array<juce::File> files;
    for (const auto& pth : paths)
    {
        const juce::File f (pth);
        if (f.isDirectory())
        {
            auto found = f.findChildFiles (juce::File::findFiles, true, "*.mid;*.midi;*.MID;*.MIDI");
            found.sort();
            files.addArray (found);
        }
        else if (f.hasFileExtension ("mid;midi")) files.add (f);
        if (files.size() > 2000) break;
    }
    const bool drums = bandTypeIsDrums (trackType (track));
    auto set = std::make_unique<ClipSet>();
    set->cycleBars = trackCycle (track);
    juce::StringArray loaded;

    // DRUM PARTS: the files (or the tracks of one FL export) are one sound each - kick, snare, hats... Together they're
    // ONE groove, each part on its pad. The 808 / bass parts go to the bass track.
    {
        std::vector<DrumPart> parts;
        if (files.size() <= 64)
            for (const auto& f : files) readMidiParts (f, parts);
        if (looksLikeDrumParts (parts))
        {
            if (drums)
            {
                std::vector<ClipNote> bass;
                const auto name = files.size() == 1 ? files[0].getFileNameWithoutExtension() : files[0].getParentDirectory().getFileName();
                auto merged = mergeDrumParts (parts, name.toStdString(), &bass);
                if (! merged.notes.empty())
                {
                    set->clips.push_back (std::move (merged));
                    for (const auto& f : files) loaded.add (f.getFullPathName());
                }
                trackMidiFiles[(size_t) track] = loaded;
                installClips (track, set->clips.empty() ? nullptr : std::move (set));
                if (! bass.empty())
                    for (int t = 0; t < numTracks.load(); ++t)
                        if (t != track && trackType (t) == BBass)
                        {
                            juce::StringArray same;
                            for (const auto& f : files) same.add (f.getFullPathName());
                            loadTrackMidi (t, same);   // (the bass track takes just the 808 / bass parts)
                            if (trackValue (t, TpOn) < 0.5f) setTrackValue (t, TpOn, 1.0f);
                            break;
                        }
                return;
            }
            // a pitched track given drum parts: just the 808 / bass ones
            MidiClip clip;
            clip.name = "808";
            for (const auto& pt : parts)
                if (drumNoteForName (pt.name) == -2) clip.notes.insert (clip.notes.end(), pt.notes.begin(), pt.notes.end());
            if (! clip.notes.empty())
            {
                finishClip (clip);
                set->clips.push_back (std::move (clip));
                for (const auto& f : files) loaded.add (f.getFullPathName());
                trackMidiFiles[(size_t) track] = loaded;
                installClips (track, std::move (set));
                return;
            }
        }
    }
    for (const auto& f : files)
    {
        juce::FileInputStream in (f);
        juce::MidiFile mf;
        if (! in.openedOk() || ! mf.readFrom (in)) continue;
        const int tpq = mf.getTimeFormat() > 0 ? mf.getTimeFormat() : 960;
        MidiClip clip;
        clip.name = f.getFileNameWithoutExtension().toStdString();
        std::vector<ClipNote> other, ch10;
        for (int t = 0; t < mf.getNumTracks(); ++t)
        {
            juce::MidiMessageSequence seq (*mf.getTrack (t));
            seq.updateMatchedPairs();
            for (int i = 0; i < seq.getNumEvents(); ++i)
            {
                const auto& m = seq.getEventPointer (i)->message;
                if (! m.isNoteOn()) continue;
                ClipNote cn;
                cn.start = (float) (m.getTimeStamp() * 4.0 / tpq);
                const int up = seq.getIndexOfMatchingKeyUp (i);
                const double end = up >= 0 ? seq.getEventPointer (up)->message.getTimeStamp() : m.getTimeStamp() + tpq / 4.0;
                cn.len = (float) juce::jmax (0.1, (end - m.getTimeStamp()) * 4.0 / tpq);
                cn.note = m.getNoteNumber();
                cn.vel = juce::jlimit (1, 127, (int) m.getVelocity());
                (m.getChannel() == 10 ? ch10 : other).push_back (cn);
            }
        }
        // a melodic track skips the file's drums (channel 10), unless that's all there is
        if (drums) { clip.notes = other; clip.notes.insert (clip.notes.end(), ch10.begin(), ch10.end()); }
        else clip.notes = other.empty() ? ch10 : other;
        if (clip.notes.empty()) continue;
        finishClip (clip);
        if (drums) mapDrumRoles (clip);
        set->clips.push_back (std::move (clip));
        loaded.add (f.getFullPathName());
    }
    trackMidiFiles[(size_t) track] = loaded;
    installClips (track, set->clips.empty() ? nullptr : std::move (set));
}

void VesperProcessor::clearTrackMidi (int track)
{
    if (track < 0 || track >= maxBandTracks) return;
    trackMidiFiles[(size_t) track].clear();
    installClips (track, nullptr);
}

int VesperProcessor::trackCycle (int track) const
{
    const auto* cs = trackClips[(size_t) juce::jlimit (0, maxBandTracks - 1, track)].load();
    return cs != nullptr ? cs->cycleBars : 16;
}

void VesperProcessor::setTrackCycle (int track, int bars)
{
    if (track < 0 || track >= maxBandTracks || trackMidiFiles[(size_t) track].isEmpty()) return;
    const auto files = trackMidiFiles[(size_t) track];
    auto* cs = trackClips[(size_t) track].load();
    if (cs == nullptr) return;
    auto copy = std::make_unique<ClipSet> (*cs);
    copy->cycleBars = juce::jlimit (1, 64, bars);
    installClips (track, std::move (copy));
}

int VesperProcessor::trackMidiCount (int track) const
{
    const auto* cs = trackClips[(size_t) juce::jlimit (0, maxBandTracks - 1, track)].load();
    return cs != nullptr ? (int) cs->clips.size() : 0;
}

juce::String VesperProcessor::trackMidiNow (int track) const
{
    const auto* cs = trackClips[(size_t) juce::jlimit (0, maxBandTracks - 1, track)].load();
    if (cs == nullptr || cs->clips.empty()) return {};
    const int i = juce::jlimit (0, (int) cs->clips.size() - 1, trackClipNow[(size_t) track].load());
    return juce::String (cs->clips[(size_t) i].name);
}

void VesperProcessor::timerCallback()
{
    drainCommands();
    if (++timerTicks % 20 != 0) return;   // the rest every half second, as before
    if (timerTicks % 80 == 0 || myGroovesSig < 0) scanMyGrooves();   // MY GROOVES: every two seconds
    {
        std::unique_ptr<juce::XmlElement> r;
        {
            const juce::ScopedLock sl (rackStateLock);
            r = std::move (pendingRack);
        }
        if (r != nullptr) rack.fromXml (*r);
    }
    songFollowLineup();   // the SONG follows the band's genre and tracks
    if (cableDirty)   // a project that sends through a cable
    {
        juce::String err;
        setCable (cableWanted, err);
    }
    // MIDI sets nobody plays any more
    const double nowMs = juce::Time::getMillisecondCounterHiRes();
    for (int i = (int) clipRetired.size() - 1; i >= 0; --i)
    {
        if (nowMs - clipRetired[(size_t) i].at < 10000.0) continue;
        auto* s = clipRetired[(size_t) i].s;
        bool inUse = false;
        for (auto& c : trackClips) if (c.load() == s) inUse = true;
        if (! inUse)
            for (auto it = clipOwned.begin(); it != clipOwned.end(); ++it)
                if (it->get() == s) { clipOwned.erase (it); break; }
        clipRetired.erase (clipRetired.begin() + i);
    }

    // only the main VESPER speaks for the band; write when the genre or groove changes, and now and
    // then so VESPER DRUMS knows a VESPER is around
    if ((int) apvts.getRawParameterValue (ids::bandRole)->load() != 0) return;
    const int g = bandGenreNow(), gr = bandGrooveNow();
    const double now = juce::Time::getMillisecondCounterHiRes();
    if (g == linkGenreWritten && gr == linkGrooveWritten && now - linkWrittenAt < 5000.0) return;
    juce::XmlElement x ("VESPER_LINK");
    x.setAttribute ("genre", g);
    x.setAttribute ("genreName", genreName (g));
    x.setAttribute ("groove", gr);
    x.setAttribute ("time", juce::String (juce::Time::currentTimeMillis()));
    const auto f = drumLinkFile();
    f.getParentDirectory().createDirectory();
    if (x.writeTo (f, juce::XmlElement::TextFormat().singleLine()))
    {
        linkGenreWritten = g;
        linkGrooveWritten = gr;
        linkWrittenAt = now;
    }
}

int VesperProcessor::bandGenreNow() const { return juce::jlimit (0, numGenres - 1, (int) apvts.getRawParameterValue (ids::bandGenre)->load()); }
int VesperProcessor::bandGrooveNow() const { return juce::jlimit (0, numGrooves (bandGenreNow()) - 1, (int) apvts.getRawParameterValue (ids::bandGroove)->load()); }

void VesperProcessor::setBandGroove (int index)
{
    setMyGroove (-1);   // one of the genre's grooves: not one of yours
    const int n = std::max (1, numGrooves (bandGenreNow()));
    index = ((index % n) + n) % n;
    if (auto* prm = apvts.getParameter (ids::bandGroove))
        prm->setValueNotifyingHost (prm->convertTo0to1 ((float) index));
}

// MAIN, plus an output for the chords and for every band track (a SOUND slot set to its own output plays there:
// send it to its own mixer track in FL). They're off until FL switches them on.
juce::AudioProcessor::BusesProperties VesperProcessor::makeBuses()
{
    auto b = BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true);
    b = b.withOutput ("Chords", juce::AudioChannelSet::stereo(), false);
    for (int t = 0; t < maxBandTracks; ++t) b = b.withOutput ("Track " + juce::String (t + 1), juce::AudioChannelSet::stereo(), false);
    return b;
}

bool VesperProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::stereo() && out != juce::AudioChannelSet::mono()) return false;
    for (int i = 1; i < layouts.outputBuses.size(); ++i)
    {
        const auto& s = layouts.outputBuses.getReference (i);
        if (! s.isDisabled() && s != juce::AudioChannelSet::stereo()) return false;
    }
    for (const auto& s : layouts.inputBuses) if (! s.isDisabled()) return false;
    return true;
}

void VesperProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    sr = sampleRate > 0 ? sampleRate : 44100.0;
    rack.prepare (sr, samplesPerBlock);
    synth.prepare (sr);
    outBuffer.ensureSize (16384);
    numPending = 0;
    for (auto& s : slots) s = Slot();
    for (auto& ch : owner) ch.fill (0);
    passthroughOn.fill (0);
    resetKeyMaps();
    extHeld = false;
    extOn.store (false);
    exprMode = 0;
    resetLoopGuard();
    lastMoodCC = -1;            // MOOD / GLIDE go out again after a restart (only once you've used them)
    lastGlideChCC.fill (-1);
}

void VesperProcessor::resetKeyMaps()
{
    keyOutNote.fill (-1);
    keyChordKey.fill (-1);
    keyOutCh.fill (1);
}

// nearest note in the key (ties go down)
static int snapToKey (int note, uint16_t mask)
{
    if (mask == 0) return note;
    for (int d = 0; d <= 6; ++d)
    {
        if ((mask >> (((note - d) % 12 + 12) % 12)) & 1) return note - d;
        if ((mask >> ((note + d) % 12)) & 1) return note + d;
    }
    return note;
}

void VesperProcessor::resetLoopGuard()
{
    sentOnAt.fill (std::numeric_limits<int64_t>::min() / 4);
    sentOffAt.fill (std::numeric_limits<int64_t>::min() / 4);
    for (auto& ch : chOnAt) ch.fill (std::numeric_limits<int64_t>::min() / 4);
    for (auto& ch : chOffAt) ch.fill (std::numeric_limits<int64_t>::min() / 4);
    sentOnVel.fill (-100);
    loopActiveUntil = burstStart = mutedUntil = 0;
    loopReported = false;
    burstCount = 0;
    sentEnergy = matchEnergy = 0;
}

// A MIDI loop was just caught: notes that came back in may have started chords nobody is holding.
// Let everything go once; from here on the loop guard keeps VESPER's own notes out.
void VesperProcessor::loopCleanup (int pos, juce::MidiBuffer& out)
{
    releaseAll (pos, out);
    clearRings (pos, out);
    for (int k = 0; k < 128; ++k)
        if (keyOutNote[(size_t) k] >= 0)
        {
            const int on = keyOutNote[(size_t) k];
            out.addEvent (juce::MidiMessage::noteOff (keyOutCh[(size_t) k], on), pos);
            passthroughOn[(size_t) on] = juce::jmax (0, passthroughOn[(size_t) on] - 1);
        }
    resetKeyMaps();
    for (auto& w : inDown) w.store (0);
}

juce::String VesperProcessor::extTriggerName() const
{
    const int type = extTrigType.load(), num = extTrigNum.load();
    if (type == 1 && num >= 0) return "Key " + juce::String (midiName (num, flats()));
    if (type == 2 && num >= 0)
    {
        if (num == 64) return "Sustain pedal";
        if (num == 1) return "Mod wheel";
        return "CC " + juce::String (num);
    }
    return "Not set";
}

//==============================================================================
// message thread
void VesperProcessor::applyUiState()
{
    scaleMap = buildScaleMap (ui.keyRoot, ui.scale, ui.genre);
    EngineConfig c;
    c.keyRoot = ui.keyRoot;
    c.scale = ui.scale;
    c.genre = ui.genre;
    c.style = ui.style;
    c.voiceSet = juce::jlimit (-1, numVoiceSets (ui.genre) - 1, ui.voiceSet);
    c.spice = juce::jlimit (0, 100, ui.spice);
    c.keysMode = ui.keysMode;
    c.split = ui.split;
    c.splitNote = juce::jlimit (1, 127, ui.splitNote);
    c.rightCh = juce::jlimit (0, 16, ui.rightCh);
    c.rightOct = juce::jlimit (-3, 3, ui.rightOct);
    c.rightSnap = ui.rightSnap;
    c.leftRow = juce::jlimit (-1, numRows - 1, ui.leftRow);
    c.padBank = juce::jlimit (0, 1, ui.padBank);
    c.scaleMask = 0;
    for (int iv : scales()[(size_t) juce::jlimit (0, numScales() - 1, ui.scale)].iv)
        c.scaleMask = (uint16_t) (c.scaleMask | (1u << (((ui.keyRoot + iv) % 12 + 12) % 12)));
    c.scaleKeys = scaleMap.keys;
    c.palette = ui.palette;
    {
        const juce::SpinLock::ScopedLockType sl (cfgLock);
        pendingCfg = c;
    }
    cfgDirty.store (true);
}

void VesperProcessor::setKeyScaleGenre (int key, int scale, int genre, bool rebuildPalette)
{
    key = ((key % 12) + 12) % 12;
    const int delta = key - ui.keyRoot;
    const bool typeChanged = scaleIsMajorType (scale) != scaleIsMajorType (ui.scale);
    const bool genreChanged = genre != ui.genre;
    ui.keyRoot = key;
    ui.scale = scale;
    if (genreChanged)
    {
        ui.genre = genre;
        ui.style = genreDefaultStyle (genre);
        // the same VOICE SET slot in the new genre (its own sets), starting on its first voicing
        ui.voiceSet = juce::jlimit (-1, numVoiceSets (genre) - 1, ui.voiceSet);
        if (ui.voiceSet >= 0) ui.style = voiceSetFor (genre, ui.voiceSet).styles[0];
        ui.chordSet = 0;
    }
    if (rebuildPalette || genreChanged || typeChanged)
    {
        ui.chordSet = 0;
        setPalette (buildPalette (key, scale, genre, ui.diceSeed));
        return;
    }
    if (delta != 0)
    {
        auto p = ui.palette;
        for (auto& card : p)
        {
            if (! card.chord.valid()) continue;
            card.chord.root = ((card.chord.root + delta) % 12 + 12) % 12;
            if (card.chord.bass >= 0) card.chord.bass = ((card.chord.bass + delta) % 12 + 12) % 12;
        }
        setPalette (p);
        return;
    }
    applyUiState();
}

void VesperProcessor::setPalette (const Palette& p)
{
    ui.palette = p;
    if (historyPos + 1 < (int) history.size())
        history.erase (history.begin() + historyPos + 1, history.end());
    history.push_back (p);
    if (history.size() > 100) history.erase (history.begin());
    historyPos = (int) history.size() - 1;
    applyUiState();
}

bool VesperProcessor::undo()
{
    if (! canUndo()) return false;
    ui.palette = history[(size_t) --historyPos];
    applyUiState();
    return true;
}

bool VesperProcessor::redo()
{
    if (! canRedo()) return false;
    ui.palette = history[(size_t) ++historyPos];
    applyUiState();
    return true;
}

void VesperProcessor::uiPlayChord (int source, const Chord& c, int style, int variant)
{
    int s1, z1, s2, z2;
    uiFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    auto& e = uiEvents[(size_t) (z1 > 0 ? s1 : s2)];
    e = UiEvent();
    e.type = 0;
    e.source = source;
    e.chord = c;
    e.style = style;
    e.variant = variant;
    uiFifo.finishedWrite (1);
}

void VesperProcessor::uiPlayNotes (int source, const Notes& notes, const Chord& label)
{
    int s1, z1, s2, z2;
    uiFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    auto& e = uiEvents[(size_t) (z1 > 0 ? s1 : s2)];
    e = UiEvent();
    e.type = 1;
    e.source = source;
    e.chord = label;
    e.notes = notes;
    uiFifo.finishedWrite (1);
}

void VesperProcessor::uiRelease (int source)
{
    int s1, z1, s2, z2;
    uiFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    auto& e = uiEvents[(size_t) (z1 > 0 ? s1 : s2)];
    e = UiEvent();
    e.type = 2;
    e.source = source;
    uiFifo.finishedWrite (1);
}

void VesperProcessor::uiExt (bool down)
{
    int s1, z1, s2, z2;
    uiFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    auto& e = uiEvents[(size_t) (z1 > 0 ? s1 : s2)];
    e = UiEvent();
    e.type = down ? 4 : 5;
    uiFifo.finishedWrite (1);
}

void VesperProcessor::panic()
{
    int s1, z1, s2, z2;
    uiFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    auto& e = uiEvents[(size_t) (z1 > 0 ? s1 : s2)];
    e = UiEvent();
    e.type = 3;
    uiFifo.finishedWrite (1);
}

bool VesperProcessor::getLastPlayed (PlayedInfo& out)
{
    const juce::SpinLock::ScopedLockType sl (playedLock);
    out = played;
    return out.chord.valid() || ! out.notes.empty();
}

bool VesperProcessor::isInputKeyDown (int note) const
{
    if (note < 0 || note > 127) return false;
    return (inDown[(size_t) (note >> 5)].load (std::memory_order_relaxed) >> (note & 31)) & 1u;
}

bool VesperProcessor::isOutputNoteOn (int note) const
{
    if (note < 0 || note > 127) return false;
    return (outOn[(size_t) (note >> 5)].load (std::memory_order_relaxed) >> (note & 31)) & 1u;
}

//==============================================================================
// audio thread: note bookkeeping
void VesperProcessor::readStyle()
{
    for (int r = 0; r < numRhythms; ++r) st.rhythm[r] = rhythmParams[(size_t) r]->load() > 0.5f;
    for (int f = 0; f < numFeels; ++f) st.feel[f] = feelParams[(size_t) f]->load() > 0.5f;
    for (int t = 0; t < numTimings; ++t) st.timing[t] = timingParams[(size_t) t]->load() > 0.5f;
    st.rate = (int) apvts.getRawParameterValue (ids::rate)->load();
    st.swing = apvts.getRawParameterValue (ids::swing)->load() / 100.0f * 0.5f;
    st.multi = (int) apvts.getRawParameterValue (ids::multi)->load();
    st.extType = (int) apvts.getRawParameterValue (ids::extType)->load();
    st.extMode = (int) apvts.getRawParameterValue (ids::extMode)->load();
    st.extRate = (int) apvts.getRawParameterValue (ids::extRate)->load();
    st.extStyles = apvts.getRawParameterValue (ids::extStyles)->load() > 0.5f;
    st.extLatch = apvts.getRawParameterValue (ids::extLatch)->load() > 0.5f;
    st.strumMs = apvts.getRawParameterValue (ids::strum)->load();
    st.strumDir = (int) apvts.getRawParameterValue (ids::strumDir)->load();
    st.human = apvts.getRawParameterValue (ids::humanize)->load();
}

void VesperProcessor::schedule (int64_t due, int note, int velocity, int channel, int slot, int64_t offAfter)
{
    if (numPending >= (int) pending.size() || note < 0 || note > 127) return;
    auto& p = pending[(size_t) numPending++];
    p = Pending();
    p.due = due;
    p.note = note;
    p.velocity = juce::jlimit (1, 127, velocity);
    p.channel = juce::jlimit (1, 16, channel);
    p.slot = slot;
    p.offAfter = offAfter;
}

void VesperProcessor::emitNoteOn (int note, int velocity, int channel, int slot, int pos, juce::MidiBuffer& out)
{
    auto& own = owner[(size_t) (channel - 1)][(size_t) note];
    // a band part landing on a note your chord is already playing on the same channel (MELODY on the chords'
    // channel): the chord keeps it. Taking it over would let the melody's note-off cut your chord.
    if (own != 0 && slot >= numChordSlots && own - 1 < numChordSlots) return;
    if (own != 0)
    {
        out.addEvent (juce::MidiMessage::noteOff (channel, note), pos);
        auto& prev = slots[(size_t) (own - 1)];
        for (int i = 0; i < prev.sent.size(); ++i)
            if (prev.sent[i] == note && prev.chans[(size_t) i] == channel)
            {
                for (int k = i; k < prev.sent.size() - 1; ++k) prev.chans[(size_t) k] = prev.chans[(size_t) (k + 1)];
                prev.sent.removeAt (i);
                break;
            }
    }
    out.addEvent (juce::MidiMessage::noteOn (channel, note, (juce::uint8) velocity), pos);
    own = (int16_t) (slot + 1);
    ++strikeGen[(size_t) (channel - 1)][(size_t) note];
    auto& s = slots[(size_t) slot];
    if (s.sent.size() < Notes::cap)
    {
        s.chans[(size_t) s.sent.size()] = (uint8_t) channel;
        s.sent.add (note);
    }
}

void VesperProcessor::noteOffOwned (int slot, int note, int channel, int pos, juce::MidiBuffer& out)
{
    auto& own = owner[(size_t) (channel - 1)][(size_t) note];
    if (own != slot + 1) return;
    out.addEvent (juce::MidiMessage::noteOff (channel, note), pos);
    own = 0;
    auto& s = slots[(size_t) slot];
    for (int i = 0; i < s.sent.size(); ++i)
        if (s.sent[i] == note && s.chans[(size_t) i] == channel)
        {
            for (int k = i; k < s.sent.size() - 1; ++k) s.chans[(size_t) k] = s.chans[(size_t) (k + 1)];
            s.sent.removeAt (i);
            break;
        }
}

void VesperProcessor::flushPending (int upTo, juce::MidiBuffer& out)
{
    const int64_t limit = sampleClock + upTo;
    for (int pass = 0; pass < 8; ++pass)
    {
        int nd = 0, w = 0;
        for (int i = 0; i < numPending; ++i)
        {
            if (pending[(size_t) i].due < limit) dueList[(size_t) nd++] = pending[(size_t) i];
            else pending[(size_t) w++] = pending[(size_t) i];
        }
        numPending = w;
        if (nd == 0) break;
        std::sort (dueList.begin(), dueList.begin() + nd, [] (const Pending& a, const Pending& b)
        {
            return a.due < b.due || (a.due == b.due && a.isOff && ! b.isOff);
        });
        for (int i = 0; i < nd; ++i)
        {
            const auto e = dueList[(size_t) i];
            if (! slots[(size_t) e.slot].active) continue;
            const int pos = (int) juce::jlimit<int64_t> (0, juce::jmax (0, blockSamples - 1), e.due - sampleClock);
            if (e.isOff)
            {
                if (strikeGen[(size_t) (e.channel - 1)][(size_t) e.note] == e.gen)
                    noteOffOwned (e.slot, e.note, e.channel, pos, out);
                continue;
            }
            emitNoteOn (e.note, e.velocity, e.channel, e.slot, pos, out);
            if (e.offAfter >= 0 && numPending < (int) pending.size())
            {
                auto& off = pending[(size_t) numPending++];
                off = Pending();
                off.due = sampleClock + pos + juce::jmax<int64_t> (1, e.offAfter);
                off.note = e.note;
                off.channel = e.channel;
                off.slot = e.slot;
                off.isOff = true;
                off.gen = strikeGen[(size_t) (e.channel - 1)][(size_t) e.note];
            }
        }
    }
}

int VesperProcessor::allocSlot (int source, int pos, juce::MidiBuffer& out)
{
    int idx = -1;
    for (int i = 0; i < numChordSlots; ++i)
        if (! slots[(size_t) i].active) { idx = i; break; }
    if (idx < 0)
    {
        int oldest = 0;
        for (int i = 1; i < numChordSlots; ++i)
            if (slots[(size_t) i].age < slots[(size_t) oldest].age) oldest = i;
        releaseSlot (oldest, pos, out);
        for (int i = 0; i < numChordSlots; ++i)
            if (! slots[(size_t) i].active) { idx = i; break; }
        if (idx < 0) idx = oldest;
    }
    auto& s = slots[(size_t) idx];
    s = Slot();
    s.active = true;
    s.source = source;
    s.age = ++slotAge;
    return idx;
}

void VesperProcessor::releaseSlot (int index, int pos, juce::MidiBuffer& out)
{
    auto& s = slots[(size_t) index];
    if (! s.active) return;
    for (int j = 0; j < (int) slots.size(); ++j)
        if (j != index && slots[(size_t) j].active && slots[(size_t) j].isExt && slots[(size_t) j].parent == index)
            releaseSlot (j, pos, out);

    int w = 0;
    for (int i = 0; i < numPending; ++i)
        if (pending[(size_t) i].slot != index) pending[(size_t) w++] = pending[(size_t) i];
    numPending = w;
    for (int ch = 0; ch < 16; ++ch)
        for (int note = 0; note < 128; ++note)
            if (owner[(size_t) ch][(size_t) note] == index + 1)
            {
                out.addEvent (juce::MidiMessage::noteOff (ch + 1, note), pos);
                owner[(size_t) ch][(size_t) note] = 0;
            }
    s = Slot();
}

void VesperProcessor::releaseSource (int source, int pos, juce::MidiBuffer& out)
{
    for (int i = 0; i < (int) slots.size(); ++i)
        if (slots[(size_t) i].active && slots[(size_t) i].source == source)
            releaseSlot (i, pos, out);
}

void VesperProcessor::releaseAll (int pos, juce::MidiBuffer& out)
{
    for (int i = 0; i < numChordSlots; ++i)
        releaseSlot (i, pos, out);
}

void VesperProcessor::clearSlotNotes (int index, int pos, juce::MidiBuffer& out)
{
    auto& s = slots[(size_t) index];
    int w = 0;
    for (int i = 0; i < numPending; ++i)
        if (pending[(size_t) i].slot != index) pending[(size_t) w++] = pending[(size_t) i];
    numPending = w;
    // every note this slot owns, including any that didn't fit in its list
    for (int ch = 0; ch < 16; ++ch)
        for (int note = 0; note < 128; ++note)
            if (owner[(size_t) ch][(size_t) note] == index + 1)
            {
                out.addEvent (juce::MidiMessage::noteOff (ch + 1, note), pos);
                owner[(size_t) ch][(size_t) note] = 0;
            }
    s.sent.clear();
}

void VesperProcessor::publish (const Chord& c, const Notes& notes, int bass, int style, int variant, int rhythm, int source)
{
    const juce::SpinLock::ScopedTryLockType tl (playedLock);
    if (! tl.isLocked()) return;
    played.chord = c;
    played.notes = notes;
    played.bassNote = bass;
    played.style = style;
    played.variant = variant;
    played.rhythm = rhythm;
    played.source = source;
    playedCount.fetch_add (1);
}

//==============================================================================
// audio thread: playing
void VesperProcessor::strike (int slot, const Notes& notesIn, int velocity, int accent, int pos, int64_t offAfter,
                              int stepParity, bool useFeel, bool useKnobStrum)
{
    auto& s = slots[(size_t) slot];
    if (s.muted && s.mirror == 0) return;   // the chord output's key strip skips this key (HOLD tracks following it still play)
    Notes ns = notesIn;
    ns.unique();
    if (ns.empty()) return;

    const int lowestUpper = s.upper.empty() ? 0 : s.upper.lowest();
    if (useFeel && st.feel[FOctaves])
    {
        const int top = ns.highest();
        if (top + 12 <= 120 && ! ns.contains (top + 12)) ns.add (top + 12);
        if (s.bass >= 0 && ns.contains (s.bass) && s.bass - 12 >= 21) ns.add (s.bass - 12);
        ns.unique();
    }
    const int n = ns.size();

    int order[Notes::cap];
    for (int i = 0; i < n; ++i) order[i] = i;
    double perNote = 0.0;
    if (useFeel && st.timing[TRolled])
        perNote = samplesPerBeat * 0.125;                       // 1/32 note per string, bottom up
    else if (useFeel && st.timing[TStrummed])
    {
        perNote = juce::jmax (18.0f, st.strumMs) * 0.001 * sr;
        if (stepParity % 2 == 0) std::reverse (order, order + n);   // down-strum on the beat
    }
    else if (useKnobStrum && st.strumMs > 0.0f)
    {
        perNote = st.strumMs * 0.001 * sr;
        bool down = st.strumDir == 1;
        if (st.strumDir == 2) { down = strumFlip; strumFlip = ! strumFlip; }
        if (st.strumDir == 3) for (int i = n - 1; i > 0; --i) std::swap (order[i], order[rng.below (i + 1)]);
        else if (down) std::reverse (order, order + n);
    }

    int64_t base = sampleClock + pos;
    if (useFeel && st.timing[TLaidBack]) base += (int64_t) (0.025 * sr);

    for (int k = 0; k < n; ++k)
    {
        const int i = order[k];
        const int note = ns[i];
        const bool isBassNote = s.bass >= 0 && note < lowestUpper && note <= s.bass + 12;
        const int ch = isBassNote ? s.bassCh : chordChannel;
        const bool isTop = i == n - 1, isBottom = i == 0;
        float v = (float) (velocity + accent);
        if (isTop) v += 4.0f;
        if (useFeel)
        {
            if (st.feel[FSoft]) v = 18.0f + v * 0.55f;
            if (st.feel[FHard]) v = 40.0f + v * 0.75f;
            if (st.feel[FAccentTop]) v += isTop ? 18.0f : (isBottom ? 0.0f : -10.0f);
        }
        v += (rng.unit() * 2.0f - 1.0f) * st.human * 12.0f;
        const int64_t delay = (int64_t) (k * perNote) + (int64_t) (rng.unit() * st.human * 0.012 * sr);
        if (! s.muted) schedule (base + delay, note, juce::jlimit (1, 127, (int) v), ch, slot, offAfter);
        // HOLD tracks play the chord exactly as it's styled: same rhythm, strum, feel and EXT, on their own channel
        if (s.mirror != 0 && ! isBassNote) mirrorNote (slot, base + delay, note, juce::jlimit (1, 127, (int) v), offAfter);
    }
}

uint16_t VesperProcessor::holdMirrorMask (int keyPc) const
{
    if (bandRoleNow != 0 || ! bandEnabled) return 0;
    uint16_t m = 0;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const auto& tc = bandCfg.part[(size_t) t];
        if (! tc.on || tc.mode != ModeHold || ! bandTypeCanHold (tc.type)) continue;
        if (tc.type == BBass || tc.type == BMelody || tc.type == BCounter) continue;   // one-note parts keep their own note
        if (keyPc >= 0 && ((tc.keyMask >> keyPc) & 1)) continue;
        if (trackFlag (t, FlagPlainHold)) continue;
        m = (uint16_t) (m | (1u << t));
    }
    return m;
}

void VesperProcessor::mirrorNote (int slot, int64_t due, int note, int velocity, int64_t offAfter)
{
    const auto& s = slots[(size_t) slot];
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        if (! ((s.mirror >> t) & 1u)) continue;
        const auto& tc = bandCfg.part[(size_t) t];
        if (! tc.on || tc.mode != ModeHold) continue;
        const int n = note + 12 * tc.octave;
        if (n < 0 || n > 127) continue;
        const int vel = juce::jlimit (1, 127, juce::roundToInt ((float) velocity * (0.45f + 0.75f * tc.level)));
        schedule (due, n, vel, tc.channel, slot, offAfter);
    }
}

double VesperProcessor::stepTime (const Slot& s, int64_t index) const
{
    double t = s.anchor + (double) index * s.stepBeats;
    if (s.applyFeel && st.timing[TSwing] && s.swingOK && (index & 1)) t += st.swing * s.stepBeats;
    return t;
}

void VesperProcessor::setupRhythm (int slot, int rhythm, int rateSel, int pos, juce::MidiBuffer& out)
{
    auto& s = slots[(size_t) slot];
    s.rhythm = rhythm;
    const int rateIdx = rateSel > 0 ? rateSel - 1 : rhythmDefaultRate (rhythm);
    s.stepBeats = rateBeats (rateIdx);
    s.swingOK = rateIsStraight (rateIdx);
    s.stepCount = 0;
    s.memory = -1;
    s.done = false;
    const double now = beatAt (pos);
    s.synced = hostPlaying;
    if (s.synced) { s.anchor = 0; s.gridIndex = (int64_t) std::floor (now / s.stepBeats + 1e-6); }
    else          { s.anchor = now; s.gridIndex = 0; }

    // a bass note the pattern doesn't play itself rings underneath
    if (s.bass >= 0 && ! rhythmPlaysBass (rhythm))
    {
        Notes b;
        b.add (s.bass);
        strike (slot, b, s.velocity, -4, pos, -1, 0, s.applyFeel, false);
    }
    playStep (slot, pos, out);   // the first hit lands right away
}

void VesperProcessor::playStep (int slot, int pos, juce::MidiBuffer&)
{
    auto& s = slots[(size_t) slot];
    if (s.done || s.rhythm < 0) return;

    PatternInput in;
    in.upper = s.upper;
    for (int i = 0; i < s.ext.size(); ++i) in.upper.add (s.ext[i]);
    in.upper.unique();
    in.bass = s.bass;
    in.poolMask = poolMask (cfg.keyRoot, cfg.scale);
    in.addOctave = s.spreadOctave;

    const int len = rhythmLength (s.rhythm, in);
    const bool oneShot = rhythmOneShot (s.rhythm);
    const int k = (s.synced && rhythmBarAligned (s.rhythm)) ? (int) (s.gridIndex % 1000000) : s.stepCount;
    const Hit h = rhythmStep (s.rhythm, oneShot ? s.stepCount : k, in, rng, s.memory);

    const double stepSamples = s.stepBeats * samplesPerBeat;
    float gate = h.gate;
    if (s.applyFeel && gate > 0.0f)
    {
        if (st.feel[FStaccato]) gate = juce::jmin (gate, 0.25f);
        if (st.feel[FLegato]) gate = juce::jmax (gate, 1.05f);
    }
    const int64_t offAfter = gate > 0.0f ? juce::jmax<int64_t> (1, (int64_t) (gate * stepSamples)) : -1;

    if (h.rest)
    {
        if (s.applyFeel && st.feel[FGhost] && ! oneShot && rhythmBarAligned (s.rhythm))
            strike (slot, s.upper, (int) (s.velocity * 0.28f), 0, pos, (int64_t) (0.15 * stepSamples), k, false, false);
    }
    else
    {
        strike (slot, h.notes, s.velocity, h.accent, pos, offAfter, k, s.applyFeel, false);
        if (! h.hold.empty()) strike (slot, h.hold, s.velocity, -6, pos, -1, k, s.applyFeel, false);
    }

    ++s.stepCount;
    ++s.gridIndex;
    s.nextBeat = stepTime (s, s.gridIndex);
    if (oneShot && s.stepCount >= len)
    {
        if (s.loopBar)
        {
            const double bar = 4.0;
            s.nextBeat = s.synced ? std::ceil (s.nextBeat / bar - 1e-9) * bar
                                  : s.anchor + std::ceil ((s.nextBeat - s.anchor) / bar - 1e-9) * bar;
            s.restartPending = true;
        }
        else s.done = true;
    }
}

void VesperProcessor::advancePatterns (int upToPos, juce::MidiBuffer& out)
{
    const double limit = beatAt (upToPos);
    const double pushBeats = 0.018 * bpm / 60.0;
    for (int i = 0; i < (int) slots.size(); ++i)
    {
        auto& s = slots[(size_t) i];
        int guard = 0;
        while (s.active && s.rhythm >= 0 && ! s.done && guard++ < 64)
        {
            const double t = s.nextBeat - ((s.applyFeel && st.timing[TPushed] && s.stepCount > 0) ? pushBeats : 0.0);
            if (t >= limit) break;
            const int pos = posOfBeat (t);
            if (s.restartPending)
            {
                // waterfall loop: let the last cascade go and start a new one on the bar
                for (int k = s.sent.size() - 1; k >= 0; --k)
                    noteOffOwned (i, s.sent[k], s.chans[(size_t) k], pos, out);
                s.restartPending = false;
                s.stepCount = 0;
                s.gridIndex = (int64_t) std::llround ((s.nextBeat - s.anchor) / s.stepBeats);
            }
            playStep (i, pos, out);
        }
    }
}

//==============================================================================
// upper extension
void VesperProcessor::extPress (int pos, juce::MidiBuffer& out)
{
    if (st.extLatch && extHeld)
    {
        extHeld = false;
        stopExt (pos, out);
        return;
    }
    extHeld = true;
    extOn.store (true);
    int parent = -1;
    uint32_t newest = 0;
    for (int i = 0; i < (int) slots.size(); ++i)
    {
        const auto& s = slots[(size_t) i];
        if (s.active && ! s.isExt && s.chord.valid() && s.age >= newest) { newest = s.age; parent = i; }
    }
    if (parent >= 0) startExt (parent, pos, out);
}

void VesperProcessor::extRelease (int pos, juce::MidiBuffer& out)
{
    if (st.extLatch) return;
    extHeld = false;
    stopExt (pos, out);
}

void VesperProcessor::stopExt (int pos, juce::MidiBuffer& out)
{
    extOn.store (false);
    for (int i = 0; i < (int) slots.size(); ++i)
        if (slots[(size_t) i].active && slots[(size_t) i].isExt) releaseSlot (i, pos, out);

    for (int i = 0; i < (int) slots.size(); ++i)
    {
        auto& s = slots[(size_t) i];
        if (! s.active || s.ext.empty()) continue;
        // drop merged extension notes that are still waiting or ringing
        int w = 0;
        for (int p = 0; p < numPending; ++p)
        {
            const auto& e = pending[(size_t) p];
            bool extNote = e.slot == i && ! e.isOff && s.ext.contains (e.note) && ! s.upper.contains (e.note);
            if (! extNote && e.slot == i && ! e.isOff && s.mirror != 0)
                for (int t = 0; t < bandCfg.numTracks; ++t)
                {
                    const auto& tc = bandCfg.part[(size_t) t];
                    const int src = e.note - 12 * tc.octave;
                    if (((s.mirror >> t) & 1u) && e.channel == tc.channel && s.ext.contains (src) && ! s.upper.contains (src)) extNote = true;
                }
            if (! extNote) pending[(size_t) w++] = e;
        }
        numPending = w;
        for (int k = 0; k < s.ext.size(); ++k)
            if (! s.upper.contains (s.ext[k]))
            {
                noteOffOwned (i, s.ext[k], chordChannel, pos, out);
                for (int t = 0; t < bandCfg.numTracks; ++t)
                    if ((s.mirror >> t) & 1u)
                        noteOffOwned (i, s.ext[k] + 12 * bandCfg.part[(size_t) t].octave, bandCfg.part[(size_t) t].channel, pos, out);
            }
        s.ext.clear();
    }
}

void VesperProcessor::startExt (int parent, int pos, juce::MidiBuffer& out)
{
    for (int i = 0; i < (int) slots.size(); ++i)
        if (slots[(size_t) i].active && slots[(size_t) i].isExt) releaseSlot (i, pos, out);

    if (parent < 0 || ! slots[(size_t) parent].active) return;
    const Chord chord = slots[(size_t) parent].chord;
    const Notes chordNotes = slots[(size_t) parent].upper;
    const int parentVel = slots[(size_t) parent].velocity;
    const int parentRhythm = slots[(size_t) parent].rhythm;

    const Notes e = upperExtension (chord, chordNotes, st.extType, effKeyRoot(), effScale());
    if (e.empty()) return;
    extOn.store (true);

    // STYLES ON EXT with a playing style: the extension joins the chord's pattern
    if (st.extStyles && parentRhythm >= 0)
    {
        slots[(size_t) parent].ext = e;
        return;
    }

    const int si = allocSlot (extSource, pos, out);
    auto& x = slots[(size_t) si];
    x.isExt = true;
    x.parent = parent;
    x.chord = chord;
    x.velocity = juce::jmax (1, (int) (parentVel * 0.9f));
    x.applyFeel = st.extStyles;
    x.bass = -1;
    x.mirror = slots[(size_t) parent].mirror;

    const int mode = st.extMode;
    if (mode == ExtHold)
    {
        x.upper = e;
        strike (si, e, x.velocity, 0, pos, -1, 0, x.applyFeel, false);
        return;
    }

    Notes pool = e;
    int rhythm = RPulse;
    if (mode == ExtArp) rhythm = RArpUpDown;
    else if (mode == ExtWaterfall || mode == ExtWaterfallLoop || mode == ExtRising)
    {
        rhythm = mode == ExtRising ? RRising : RWaterfall;
        // cascade from the top of the extension down through the chord, an octave up so it never
        // steps on the notes the chord is already holding
        const int top = chordNotes.highest();
        for (int i = 0; i < chordNotes.size(); ++i)
            if (chordNotes[i] + 12 > top && chordNotes[i] + 12 <= 112) pool.add (chordNotes[i] + 12);
        x.spreadOctave = false;
    }
    pool.unique();
    x.upper = pool;
    x.loopBar = mode == ExtWaterfallLoop;
    setupRhythm (si, rhythm, st.extRate + 1, pos, out);
}

//==============================================================================
// expression (CC11) for SWELL / FADE
void VesperProcessor::startExpression (int pos, juce::MidiBuffer& out)
{
    exprMode = st.feel[FSwell] ? 1 : (st.feel[FFade] ? 2 : 0);
    exprStartBeat = beatAt (pos);
    const int v = exprMode == 1 ? 20 : 127;
    if (exprMode != 0 || lastExprSent != 127)
    {
        out.addEvent (juce::MidiMessage::controllerEvent (chordChannel, 11, v), pos);
        if (chordChannel != 2) out.addEvent (juce::MidiMessage::controllerEvent (2, 11, v), pos);
        lastExprSent = v;
    }
}

void VesperProcessor::updateExpression (juce::MidiBuffer& out)
{
    if (exprMode == 0) return;
    const double elapsed = beatAt (blockSamples) - exprStartBeat;
    int v = 127;
    if (exprMode == 1) v = 20 + (int) (107.0 * juce::jlimit (0.0, 1.0, elapsed / 4.0));
    else v = 127 - (int) (102.0 * juce::jlimit (0.0, 1.0, elapsed / 8.0));
    if (v != lastExprSent)
    {
        const int pos = juce::jmax (0, blockSamples - 1);
        out.addEvent (juce::MidiMessage::controllerEvent (chordChannel, 11, v), pos);
        if (chordChannel != 2) out.addEvent (juce::MidiMessage::controllerEvent (2, 11, v), pos);
        lastExprSent = v;
    }
}

//==============================================================================
// KEY CHANGE: where a chord / note lands in the key the song is in now
Chord VesperProcessor::keyed (const Chord& c) const
{
    if (keyShift == 0 && keyScale < 0) return c;
    return moveChordKey (c, cfg.keyRoot, cfg.scale, cfg.keyRoot + keyShift, effScale());
}

int VesperProcessor::keyedNote (int note) const
{
    if (keyShift == 0 && keyScale < 0) return note;
    int n = moveNoteKey (note, cfg.keyRoot, cfg.scale, cfg.keyRoot + keyShift, effScale());
    while (n > 127) n -= 12;
    while (n < 0) n += 12;
    return n;
}

void VesperProcessor::applyKeyChange (int move, int pos, juce::MidiBuffer& out)
{
    int s = keyShift, sc = keyScale;
    applyKeyMove (move, cfg.scale, s, sc);
    if (s == keyShift && sc == keyScale) return;
    keyShift = s;
    keyScale = sc;
    keyShiftShown.store (s);
    keyScaleShown.store (sc);
    // the chords you're holding (or the loop is holding for you) move with it, right on the line
    struct Again { int source; Chord chord; int style, variant, vel; };
    std::array<Again, 16> again;
    int n = 0;
    for (const auto& sl : slots)
        if (sl.active && ! sl.isExt && sl.source >= 0 && sl.source < 128 && sl.baseChord.valid() && n < (int) again.size())
            again[(size_t) n++] = { sl.source, sl.baseChord, sl.baseStyle, sl.baseVariant, sl.velocity };
    for (int i = 0; i < n; ++i)
    {
        const auto& a = again[(size_t) i];
        triggerChord (a.source, a.chord, a.style, a.variant, a.vel, pos, out);
    }
    keyChanges.fetch_add (1);
}

juce::String VesperProcessor::keyNowText() const
{
    const int s = keyShiftShown.load(), sc = keyScaleShown.load();
    const int home = ui.keyRoot, homeScale = ui.scale;
    const int scale = sc >= 0 ? sc : homeScale;
    const int root = ((home + s) % 12 + 12) % 12;
    const juce::String name = juce::String (noteName (root, keyPrefersFlats (root, scale))) + " "
                              + juce::String (scales()[(size_t) juce::jlimit (0, numScales() - 1, scale)].name).toUpperCase();
    if (s == 0 && sc < 0) return "HOME KEY (" + name + ")";
    return (s > 0 ? "UP " + juce::String (s) : (s < 0 ? "DOWN " + juce::String (-s) : juce::String ("SAME ROOT"))) + " (" + name + ")";
}

void VesperProcessor::triggerChord (int source, const Chord& chordIn, int style, int variant, int velocity, int pos, juce::MidiBuffer& out)
{
    if (! chordIn.valid()) return;
    // the song's key now (KEY CHANGE), then SPICE (below the middle: plainer chords)
    const Chord chord = simplifyChord (keyed (chordIn), (float) cfg.spice / 100.0f);
    const bool hold = apvts.getRawParameterValue (ids::hold)->load() > 0.5f;
    if (hold) releaseAll (pos, out);
    else releaseSource (source, pos, out);

    if (style < 0) style = cfg.style;
    const bool vary = apvts.getRawParameterValue (ids::vary)->load() > 0.5f;
    const bool smooth = apvts.getRawParameterValue (ids::smooth)->load() > 0.5f;
    const float mood = apvts.getRawParameterValue (ids::mood)->load();
    const int center = (int) apvts.getRawParameterValue (ids::height)->load() + juce::roundToInt (mood * 6.0f);
    const float spice = (float) cfg.spice / 100.0f;
    velocity = juce::jlimit (1, 127, juce::roundToInt ((float) velocity * (1.0f + 0.15f * mood)));

    const int id = chord.id();
    VaryMemory* mem = nullptr;
    for (auto& m : varyMemory) if (m.id == id) { mem = &m; break; }
    const Notes avoid = mem != nullptr ? mem->notes : Notes();

    auto pick = chooseVoicing (chord, style, variant, center, smooth, lastVoicing, vary, avoid, cfg.genre, rng, cfg.voiceSet, spice, lastChordRoot);
    lastChordRoot = chord.root;
    // the same key again (VARY off): exactly the same chord, in the same place
    if (! vary && variant < 0 && id == lastChordId && ! lastVoicing.empty() && std::abs (lastVoicing.mean() - center) <= 7)
        pick.notes = lastVoicing;
    lastChordId = id;
    {   // FOLLOW ME: the chords of this bar (a new progression starts a new section)
        bool seen = false;
        for (int i = 0; i < followNow.numChords; ++i) if (followNow.chords[(size_t) i] == id) seen = true;
        if (! seen && followNow.numChords < 4) followNow.chords[(size_t) followNow.numChords++] = id;
    }
    if (mem == nullptr)
    {
        for (auto& m : varyMemory) if (m.id < 0) { mem = &m; break; }
        if (mem == nullptr) mem = &varyMemory[(size_t) rng.below ((int) varyMemory.size())];
    }
    mem->id = id;
    mem->notes = pick.notes;
    lastVoicing = pick.notes;

    // which playing style (several switched on: take turns or pick at random)
    int rhythm = -1;
    {
        int enabled[numRhythms];
        int count = 0;
        for (int r = 0; r < numRhythms; ++r) if (st.rhythm[r]) enabled[count++] = r;
        if (count > 0)
        {
            if (st.multi == 1)
            {
                int pickIdx = rng.below (count);
                if (count > 1 && enabled[pickIdx] == lastRhythm) pickIdx = (pickIdx + 1) % count;
                rhythm = enabled[pickIdx];
            }
            else
            {
                rhythm = enabled[0];
                for (int c = 0; c < count; ++c)
                    if (enabled[c] >= rhythmTurn) { rhythm = enabled[c]; break; }
                rhythmTurn = rhythm + 1;
            }
        }
        lastRhythm = rhythm;
    }

    // STACK: one note, octaves, stacked 3rds... instead of the whole chord, in the octave of the key you pressed
    const int stackMode = juce::jlimit (0, numStackModes - 1, (int) stackParam->load());
    Notes sounding = pick.notes;
    if (stackMode != StackChord)
    {
        const int ref = (source >= 0 && source < 128) ? source : center;
        const Notes stacked = stackVoicing (chord, stackMode, 2 + (int) stackNotesParam->load(), ref, poolMask (effKeyRoot(), effScale()));
        if (! stacked.empty()) sounding = stacked;
    }

    int bassMode = (int) apvts.getRawParameterValue (ids::bassMode)->load();
    if (bandEnabled)
        for (int t = 0; t < bandCfg.numTracks; ++t)
        {
            const auto& tc = bandCfg.part[(size_t) t];
            if (tc.on && tc.type == BBass && (tc.mode != ModeJam || bandPartHere (t))) bassMode = 0;   // the band's bass takes over
        }
    int bassNote = -1, bassChannel = chordChannel;
    if (bassMode > 0 || (chord.bass >= 0 && stackMode == StackChord))
    {
        bassNote = bassNoteFor (chord, sounding);
        bassChannel = bassMode == 2 ? 2 : chordChannel;
    }
    if (rhythm >= 0 && rhythmNeedsBass (rhythm) && bassNote < 0)
        bassNote = bassNoteFor (chord, sounding);

    const int slot = allocSlot (source, pos, out);
    auto& s = slots[(size_t) slot];
    s.chord = chord;
    s.baseChord = chordIn;
    s.baseStyle = style;
    s.baseVariant = variant;
    s.upper = sounding;
    s.upper.sort();
    s.bass = bassNote;
    s.bassCh = bassChannel;
    s.velocity = velocity;
    s.applyFeel = true;
    const int keyPc = (source >= 0 && source < 128) ? source % 12 : -1;
    s.muted = keyPc >= 0 && ((chordKeys.load (std::memory_order_relaxed) >> keyPc) & 1);
    s.mirror = holdMirrorMask (keyPc);
    const uint16_t styledHolds = s.mirror;

    startExpression (pos, out);
    if (rhythm < 0)
    {
        Notes all = s.upper;
        if (bassNote >= 0) all.add (bassNote);
        const int64_t offAfter = st.feel[FStaccato] ? (int64_t) (0.25 * samplesPerBeat) : -1;
        strike (slot, all, velocity, 0, pos, offAfter, strumFlip ? 1 : 0, true, true);
        if (st.timing[TStrummed]) strumFlip = ! strumFlip;
    }
    else setupRhythm (slot, rhythm, st.rate, pos, out);

    if (extHeld) startExt (slot, pos, out);
    publish (chord, sounding, bassNote, pick.style, pick.variant, rhythm, source);
    playLayers (source, chord, sounding, velocity, pos, out, styledHolds);
    bandChordChanged (chord, pos, out, keyPc);
}

void VesperProcessor::triggerNotes (int source, const Notes& notes, const Chord& label, int velocity, int pos, juce::MidiBuffer& out)
{
    const bool hold = apvts.getRawParameterValue (ids::hold)->load() > 0.5f;
    if (hold) releaseAll (pos, out);
    else releaseSource (source, pos, out);
    const int slot = allocSlot (source, pos, out);
    auto& s = slots[(size_t) slot];
    s.chord = label;
    s.upper = notes;
    s.upper.sort();
    s.velocity = velocity;
    strike (slot, notes, velocity, 0, pos, -1, 0, false, true);
    lastVoicing = notes;
    publish (label, notes, -1, -1, -1, -1, source);
    playLayers (source, label, notes, velocity, pos, out);
    if (label.valid()) bandChordChanged (label, pos, out, -1);
}

void VesperProcessor::handleUiEvent (const UiEvent& e, juce::MidiBuffer& out)
{
    const bool hold = apvts.getRawParameterValue (ids::hold)->load() > 0.5f;
    switch (e.type)
    {
        case 0: triggerChord (e.source, e.chord, e.style, e.variant, 100, 0, out); break;
        case 1: triggerNotes (e.source, e.notes, e.chord, 100, 0, out); break;
        case 2: if (! hold) releaseSource (e.source, 0, out); break;
        case 3:
            if (cableLive)
                for (int ch = 0; ch < 16; ++ch)
                    for (int n = 0; n < 128; ++n)
                        if (cableHeld[(size_t) ch][(size_t) n] > 0) out.addEvent (juce::MidiMessage::noteOff (ch + 1, n), 0);
            releaseAll (0, out);
            stopBand (0, out);
            clearRings (0, out);
            extHeld = false;
            extOn.store (false);
            exprMode = 0;
            for (int ch = 1; ch <= 16; ++ch)
            {
                out.addEvent (juce::MidiMessage::allNotesOff (ch), 0);
                out.addEvent (juce::MidiMessage::controllerEvent (ch, 64, 0), 0);
                out.addEvent (juce::MidiMessage::controllerEvent (ch, 11, 127), 0);
            }
            lastExprSent = 127;
            synth.allOff();
            passthroughOn.fill (0);
            resetKeyMaps();
            for (auto& w : inDown) w.store (0);
            break;
        case 4: extPress (0, out); break;
        case 5: extRelease (0, out); break;
        case 6: stopBand (0, out); clearRings (0, out); break;
        default: break;
    }
}

void VesperProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    const int numSamples = buffer.getNumSamples();
    blockSamples = numSamples;
    outBuffer.clear();
    auto& out = outBuffer;

    if (cfgDirty.load())
    {
        const juce::SpinLock::ScopedTryLockType tl (cfgLock);
        if (tl.isLocked())
        {
            cfg = pendingCfg;
            cfgDirty.store (false);
        }
    }
    readStyle();
    readBand();

    // tempo / song position
    double ppq = 0.0;
    bool playing = false, ppqValid = false, hostRecording = false;
    bpm = 120.0;
    if (auto* ph = getPlayHead())
        if (auto pos = ph->getPosition())
        {
            if (auto b = pos->getBpm()) bpm = *b;
            playing = pos->getIsPlaying();
            hostRecording = pos->getIsRecording();
            if (auto p = pos->getPpqPosition()) { ppq = *p; ppqValid = true; }
        }

    // AUTO REC: a fresh take starts when FL starts recording and stops when FL stops
    if (autoRec.load())
    {
        if (hostRecording && ! lastHostRec)
        {
            recCount.store (0);
        recChannelMask.store (0);
            recChannelMask.store (0);
            recordedNoteOns.store (0);
            recording.store (true);
        }
        else if (! hostRecording && lastHostRec)
            recording.store (false);
    }
    lastHostRec = hostRecording;
    if (lastHostPlaying && ! playing) clearRings (0, out);   // RING notes stop when FL stops
    lastHostPlaying = playing;
    const bool songSynced = playing && ppqValid;
    if (bpm < 20.0 || bpm > 999.0) bpm = 120.0;
    samplesPerBeat = sr * 60.0 / bpm;
    hostPlaying = songSynced;
    blockBeat = songSynced ? ppq : freeBeat;
    freeBeat += numSamples / samplesPerBeat;

    // keep running patterns locked to the right clock (FL started/stopped, looped or jumped)
    for (auto& s : slots)
    {
        if (! s.active || s.rhythm < 0 || s.done) continue;
        if (s.synced != hostPlaying)
        {
            s.synced = hostPlaying;
            if (s.synced) { s.anchor = 0; s.gridIndex = (int64_t) std::ceil (blockBeat / s.stepBeats - 1e-9); }
            else          { s.anchor = blockBeat; s.gridIndex = 0; }
            s.nextBeat = stepTime (s, s.gridIndex);
        }
        else if (s.synced && (s.nextBeat < blockBeat - 2.0 * s.stepBeats || s.nextBeat > blockBeat + 4.0 + 2.0 * s.stepBeats))
        {
            s.gridIndex = (int64_t) std::ceil (blockBeat / s.stepBeats - 1e-9);
            s.nextBeat = stepTime (s, s.gridIndex);
        }
    }

    const bool hold = apvts.getRawParameterValue (ids::hold)->load() > 0.5f;
    if (lastHold && ! hold) releaseAll (0, out);
    lastHold = hold;

    if (bandRoleNow != lastRole)
    {
        stopBand (0, out);
        lastRole = bandRoleNow;
        linkStarts = 0;
        linkHarmId = -1;
        linkLeaderSeen = 0;
        followState.store (0);
    }
    if (bandRoleNow != 0) followLeader (out);
    else bandHousekeeping (0, out);

    // UI events (mouse clicks) at the start of the block
    {
        int s1, z1, s2, z2;
        uiFifo.prepareToRead (uiFifo.getNumReady(), s1, z1, s2, z2);
        for (int i = 0; i < z1; ++i) handleUiEvent (uiEvents[(size_t) (s1 + i)], out);
        for (int i = 0; i < z2; ++i) handleUiEvent (uiEvents[(size_t) (s2 + i)], out);
        uiFifo.finishedRead (z1 + z2);
    }

    auto setBit = [] (std::array<std::atomic<uint32_t>, 4>& bits, int note, bool on)
    {
        auto& word = bits[(size_t) (note >> 5)];
        const uint32_t mask = 1u << (note & 31);
        if (on) word.fetch_or (mask, std::memory_order_relaxed);
        else word.fetch_and (~mask, std::memory_order_relaxed);
    };

    const bool fixedVel = (int) apvts.getRawParameterValue (ids::velMode)->load() == 1;

    // ---- with the cable on, only your keyboard's channel comes in: VESPER never sends on it, so nothing it plays can come back
    if (cableLive)
    {
        const int kb = juce::jlimit (1, 16, keyboardCh.load());
        bool dropped = false;
        loopKeep.clear();
        for (const auto meta : midi)
        {
            const auto m = meta.getMessage();
            if (m.getChannel() > 0 && m.getChannel() != kb)
            {
                dropped = true;
                if (m.isNoteOn()) cableIgnored.fetch_add (1, std::memory_order_relaxed);
                continue;
            }
            loopKeep.addEvent (m, meta.samplePosition);
        }
        if (dropped) midi.swapWith (loopKeep);
    }

    // ---- VESPER's own notes coming straight back (a loopMIDI cable, FL handing them to VESPER's channel) are
    // thrown away the first time, before they can play anything. A burst of them (a chord, the bass, the drums)
    // proves they're echoes; after that every one is caught, key-ups too.
    if (cableLive)   // (without the cable a fast player can match VESPER's own notes by chance: the loop guard handles that case)
    {
        cableEchoWin = juce::jmax ((int64_t) (0.3 * sr), (int64_t) (8 * numSamples));
        // FL also feeds the cable into whichever channel is SELECTED - and when that's VESPER, its own notes come back
        // relabelled as channel 1, your keyboard's. VESPER never sends on that channel, so a note arriving there that
        // matches one VESPER just sent on ANY channel (same note, same velocity, a moment later) is its own note.
        // That match is kept tight (a fast player repeating a key can't hit it), and it only counts once it's proven.
        const int kbCh = juce::jlimit (1, 16, keyboardCh.load());
        const int64_t crossWin = juce::jmax ((int64_t) (0.06 * sr), (int64_t) (4 * numSamples));
        auto chansFor = [&] (const juce::MidiMessage& m, int& from, int& to)
        {
            const int c = juce::jlimit (1, 16, m.getChannel());
            if (c == kbCh) { from = 0; to = 15; } else { from = to = c - 1; }
            return c == kbCh;
        };
        auto expectOn = [&] (const juce::MidiMessage& m, int64_t t) -> uint8_t*
        {
            const auto n = (size_t) m.getNoteNumber();
            int from = 0, to = 0;
            const bool cross = chansFor (m, from, to);
            const int64_t win = cross ? crossWin : cableEchoWin;
            for (int c = from; c <= to; ++c)
            {
                auto& left = cableOnLeft[(size_t) c][n];
                if (left == 0) continue;
                const int64_t at = cableOnAt[(size_t) c][n];
                if (t < at) continue;
                if (t - at >= cableEchoWin) { left = 0; continue; }
                if (t - at < win && std::abs ((int) m.getVelocity() - (int) cableOnVel[(size_t) c][n]) <= 2) return &left;
            }
            return nullptr;
        };
        auto expectOff = [&] (const juce::MidiMessage& m, int64_t t) -> uint8_t*
        {
            const auto n = (size_t) m.getNoteNumber();
            int from = 0, to = 0;
            const bool cross = chansFor (m, from, to);
            const int64_t win = cross ? crossWin : cableEchoWin;
            for (int c = from; c <= to; ++c)
            {
                auto& left = cableOffLeft[(size_t) c][n];
                if (left == 0) continue;
                const int64_t at = cableOffAt[(size_t) c][n];
                if (t < at) continue;
                if (t - at >= cableEchoWin) { left = 0; continue; }
                if (t - at < win) return &left;
            }
            return nullptr;
        };
        int burst = 0;
        for (const auto meta : midi)
            if (meta.getMessage().isNoteOn() && expectOn (meta.getMessage(), sampleClock + meta.samplePosition) != nullptr) ++burst;
        // proof it's VESPER hearing itself: several of its notes at once (a chord, the band, kick + hat). A player never
        // matches several just-sent notes in the same instant; a lone match proves nothing (a fast repeated key can
        // look like one). Once it's proven, every note that keeps coming back keeps the filter up. (A lone note
        // coming back before that - a melody passing through - lands on the key you're still holding: the double-key
        // check below takes it.)
        if (burst >= 2 || (burst >= 1 && sampleClock < cableEchoUntil)) cableEchoUntil = sampleClock + (int64_t) (5.0 * sr);
        if (sampleClock < cableEchoUntil)
        {
            bool dropped = false;
            loopKeep.clear();
            for (const auto meta : midi)
            {
                const auto m = meta.getMessage();
                const int64_t t = sampleClock + meta.samplePosition;
                bool echo = false;
                if (m.isNoteOn())
                {
                    if (auto* left = expectOn (m, t)) { --*left; echo = true; cableIgnored.fetch_add (1, std::memory_order_relaxed); }
                }
                else if (m.isNoteOff())
                {
                    if (auto* left = expectOff (m, t)) { --*left; echo = true; }
                }
                if (echo) dropped = true;
                else loopKeep.addEvent (m, meta.samplePosition);
            }
            if (dropped) midi.swapWith (loopKeep);
        }

        // ---- the same key handed over twice (VESPER's channel locked to your keyboard AND selected in FL): the second
        // key-down is the same press, and a key-up right behind it is FL cutting the first copy - the chord keeps going
        // until you really let go
        {
            const int64_t dupWin = juce::jmax ((int64_t) (0.06 * sr), (int64_t) (2 * numSamples));
            bool dropped = false;
            loopKeep.clear();
            for (const auto meta : midi)
            {
                const auto m = meta.getMessage();
                const int64_t t = sampleClock + meta.samplePosition;
                bool skip = false;
                if (m.isNoteOn() || m.isNoteOff())
                {
                    const auto n = (size_t) m.getNoteNumber();
                    if (m.isNoteOn())
                    {
                        if (keyRawDown[n] && t - keyRawOnAt[n] < dupWin) { keyDupUntil[n] = t + dupWin; skip = true; }
                        else { keyRawDown[n] = true; keyRawOnAt[n] = t; }
                    }
                    else if (keyDupUntil[n] > t) { keyDupUntil[n] = 0; skip = true; }
                    else keyRawDown[n] = false;
                }
                if (skip) dropped = true;
                else loopKeep.addEvent (m, meta.samplePosition);
            }
            if (dropped) midi.swapWith (loopKeep);
        }
    }

    // ---- loop guard: spot our own notes coming back in
    const int64_t echoWindow = (int64_t) (0.3 * sr);
    auto isEchoOn = [&] (const juce::MidiMessage& m, int64_t now)
    {
        const int n = m.getNoteNumber();
        const int64_t age = now - sentOnAt[(size_t) n];
        return age >= 0 && age < echoWindow && std::abs (m.getVelocity() - sentOnVel[(size_t) n]) <= 2;
    };
    // channels VESPER plays band / HOLD / RING tracks on (not the chords' own channel): a note that
    // comes in on one of those, right after VESPER sent that very note there, is VESPER hearing itself
    bandChannels = 0;
    if (bandRoleNow == 0)
        for (int t = 0; t < bandCfg.numTracks; ++t)
            if (bandCfg.part[(size_t) t].on) bandChannels = (uint16_t) (bandChannels | (1u << (bandCfg.part[(size_t) t].channel - 1)));
    if ((int) apvts.getRawParameterValue (ids::bassMode)->load() == 2) bandChannels = (uint16_t) (bandChannels | 2u);
    bandChannels = (uint16_t) (bandChannels & ~(1u << (chordChannel - 1)));
    if (cfg.split && cfg.rightCh > 0) bandChannels = (uint16_t) (bandChannels & ~(1u << (cfg.rightCh - 1)));
    auto isOwnBandNote = [&] (const juce::MidiMessage& m, int64_t now)
    {
        const int ch = m.getChannel();
        if (ch < 1 || ch > 16 || ! ((bandChannels >> (ch - 1)) & 1u)) return false;
        const int64_t age = now - (m.isNoteOn() ? chOnAt : chOffAt)[(size_t) (ch - 1)][(size_t) m.getNoteNumber()];
        return age >= 0 && age < echoWindow;
    };
    if (cableLive) { loopActiveUntil = 0; loopReported = false; matchEnergy = 0; }   // the cable: nothing VESPER sends can come in (channel rule), so the
    else                                                                            // guard would only mistake quick repeated keys for echoes
    {
        int blockMatches = 0, chordMatches = 0;
        bool ownBand = false;
        for (const auto meta : midi)
        {
            const auto m = meta.getMessage();
            const int64_t t = sampleClock + meta.samplePosition;
            const bool band = (m.isNoteOn() || m.isNoteOff()) && isOwnBandNote (m, t);
            ownBand |= band;
            if (! m.isNoteOn()) continue;
            const bool echo = isEchoOn (m, t);
            if (band || echo) ++blockMatches;
            if (echo && ! band) ++chordMatches;
        }
        // A real loop sends back nearly everything we play (every chord tone). A player
        // re-hitting a key only ever matches one note of each chord, so compare the two.
        // Only notes on the chords' channels count: band / drum notes coming back are already
        // kept out note by note and must never cut the chords you're holding.
        const float decay = std::exp (-(float) numSamples / (float) (0.5 * sr));
        sentEnergy *= decay;
        matchEnergy = matchEnergy * decay + (float) chordMatches;
        const bool wasActive = sampleClock < loopActiveUntil;
        const bool chordLoop = chordMatches > 0 && matchEnergy >= 2.5f && matchEnergy >= 0.5f * sentEnergy;
        if (! wasActive) loopReported = false;
        if (chordLoop || (wasActive && blockMatches > 0) || ownBand)
        {
            if (chordLoop && ! loopReported)   // the chords themselves are coming back: say so (the help button lights up)
            {
                loopEvents.fetch_add (1);
                loopReported = true;
                if (! wasActive) loopCleanup (0, out);   // they got in before the guard was up: let go of anything they started, once
            }
            loopActiveUntil = sampleClock + (int64_t) (5.0 * sr);
        }
    }
    const bool loopActive = sampleClock < loopActiveUntil;

    const int trigType = extTrigType.load(), trigNum = extTrigNum.load();

    // ---- the chord LOOPER: your keys go into a recording; a playing loop presses the keys for you
    {
        loopInject.clear();
        looper.begin (blockBeat, samplesPerBeat, numSamples, hostPlaying, loopInject);
        for (const auto meta : midi)
        {
            const auto m = meta.getMessage();
            if (! (m.isNoteOn() || m.isNoteOff())) continue;
            if (sectionOfKey (m.getNoteNumber()) >= 0 || sectionLearn.load() >= 0 || (trigType == 1 && m.getNoteNumber() == trigNum)) continue;
            if (commandKeyOf (m.getNoteNumber()) >= 0 || commandLearn.load() >= 0 || trackExtLearn.load() >= 0) continue;
            {
                bool extKey = false;
                for (auto& k : trackExtKey) if (k.load (std::memory_order_relaxed) == m.getNoteNumber()) extKey = true;
                if (extKey) continue;
            }
            const int64_t t = sampleClock + meta.samplePosition;
            if (isOwnBandNote (m, t) || (loopActive && m.isNoteOn() && isEchoOn (m, t))) continue;   // VESPER hearing itself
            looper.record (m, beatAt (meta.samplePosition), hostPlaying);
        }
        const bool newPart = songTick (numSamples);
        looper.process (blockBeat, samplesPerBeat, numSamples, hostPlaying, bandCfg.groove, loopInject);
        if (looper.justSwitched && drummerListens.load()) crashBeat = looper.switchBeat;
        if (newPart || looper.justSwitched) readBand();   // the new part / section's band (and groove) from its first beat
        if (looper.swallowing())
        {
            loopKeep.clear();
            for (const auto meta : midi)
                if (! looper.swallowOff (meta.getMessage())) loopKeep.addEvent (meta.getMessage(), meta.samplePosition);
            midi.swapWith (loopKeep);
        }
        if (! loopInject.isEmpty()) midi.addEvents (loopInject, 0, numSamples, 0);
    }

    for (const auto meta : midi)
    {
        const auto m = meta.getMessage();
        const int pos = juce::jlimit (0, juce::jmax (0, numSamples - 1), meta.samplePosition);
        advancePatterns (pos, out);
        advanceBand (pos, out);
        flushPending (pos, out);

        if (m.isNoteOn() || m.isNoteOff())
        {
            const int n = m.getNoteNumber();
            const int64_t now = sampleClock + pos;

            // a PAD the loop presses (CHORD SET > LOOPS): that pad's chord, whatever KEYS PLAY is set to
            if (m.getChannel() == Looper::padChannel && n < Looper::numPads && looper.padMark[(size_t) n])
            {
                if (bandRoleNow != 0) continue;   // a band copy follows the main VESPER's chords
                const int srcId = loopPadSource + n, lit = cfg.paletteStart + n;
                if (m.isNoteOn())
                {
                    const auto& card = cfg.palette[(size_t) n];
                    if (card.chord.valid())
                    {
                        lastPressVel = (float) m.getVelocity();
                        ++followNow.notes;
                        followNow.vel += (float) m.getVelocity();
                        if (lit >= 0 && lit < 128) setBit (inDown, lit, true);
                        triggerChord (srcId, card.chord, card.style, card.variant, fixedVel ? 100 : m.getVelocity(), pos, out);
                    }
                }
                else
                {
                    if (lit >= 0 && lit < 128) setBit (inDown, lit, false);
                    if (! hold)
                    {
                        releaseSource (srcId, pos, out);
                        bandHousekeeping (pos, out);
                    }
                }
                continue;
            }

            // VESPER's own band / HOLD notes coming back in are never keys
            if (! cableLive && isOwnBandNote (m, now)) continue;
            if (loopActive)
            {
                if (m.isNoteOn() && isEchoOn (m, now)) continue;
                const int64_t offAge = now - sentOffAt[(size_t) n];
                // a key that's down always gets its note-off (better a chord cut short than one that never stops)
                const bool keyDown = keyChordKey[(size_t) n] >= 0 || keyOutNote[(size_t) n] >= 0;
                if (m.isNoteOff() && offAge >= 0 && offAge < echoWindow && ! keyDown) continue;
            }

            // learning the upper-extension button
            if (learnArmed.load() && m.isNoteOn())
            {
                extTrigType.store (1);
                extTrigNum.store (n);
                learnArmed.store (false);
                learnCount.fetch_add (1);
                continue;
            }
            // command keys (a section, a fill, a solo, a jam...): learning one, or calling one
            if (commandLearn.load() >= 0 && m.isNoteOn())
            {
                const int k = juce::jlimit (0, numCommandKeys - 1, commandLearn.load());
                for (auto& other : commandKey) if (other.load() == n) other.store (-1);   // one key, one job
                commandKey[(size_t) k].store (n);
                commandLearn.store (-1);
                commandKeysChanged.fetch_add (1);
                continue;
            }
            if (const int ck = commandKeyOf (n); ck >= 0)
            {
                if (m.isNoteOn()) { int c = 0, a = -1; commandForKey (ck, c, a); postCommand (c, a); }
                continue;
            }
            // a track's own EXT key: held, only that track adds the upper extension
            if (trackExtLearn.load() >= 0 && m.isNoteOn())
            {
                const int t = juce::jlimit (0, maxBandTracks - 1, trackExtLearn.load());
                trackExtKey[(size_t) t].store (n);
                trackExtLearn.store (-1);
                trackExtKeysChanged.fetch_add (1);
                continue;
            }
            {
                int extTrack = -1;
                for (int t = 0; t < maxBandTracks; ++t) if (trackExtKey[(size_t) t].load (std::memory_order_relaxed) == n) { extTrack = t; break; }
                if (extTrack >= 0)
                {
                    if (m.isNoteOn()) trackExtHeld = (uint16_t) (trackExtHeld | (1u << extTrack));
                    else trackExtHeld = (uint16_t) (trackExtHeld & ~(1u << extTrack));
                    updateTrackExt (pos, out);
                    continue;
                }
            }
            // section keys: A-D (and learning one)
            if (sectionLearn.load() >= 0 && m.isNoteOn())
            {
                sectionKey[(size_t) juce::jlimit (0, Looper::numSections - 1, sectionLearn.load())].store (n);
                sectionLearn.store (-1);
                sectionKeysChanged.fetch_add (1);
                continue;
            }
            if (const int sk = sectionOfKey (n); sk >= 0)
            {
                if (m.isNoteOn()) goToSection (sk);
                continue;
            }
            // learning the split point (the key pressed becomes the first right-hand key)
            if (splitLearnArmed.load() && m.isNoteOn())
            {
                splitLearned.store (n);
                splitLearnArmed.store (false);
                splitLearnCount.fetch_add (1);
                continue;
            }
            if (trigType == 1 && n == trigNum)
            {
                setBit (inDown, n, m.isNoteOn());
                if (m.isNoteOn()) extPress (pos, out);
                else extRelease (pos, out);
                continue;
            }

            if (m.isNoteOn())
            {
                // last line of defence: nobody plays 48 notes in a quarter second
                if (now - burstStart > (int64_t) (0.25 * sr)) { burstStart = now; burstCount = 0; }
                if (++burstCount > 48)
                {
                    if (now >= mutedUntil) loopEvents.fetch_add (1);
                    mutedUntil = now + (int64_t) (0.5 * sr);
                }
                if (now < mutedUntil) continue;
            }
            const bool splitOn = cfg.split && bandRoleNow == 0;
            const int vel = fixedVel ? 100 : m.getVelocity();
            if (m.isNoteOn())
            {
                lastPressVel = (float) m.getVelocity();   // the listening drummer follows how hard you play
                ++followNow.notes;                        // FOLLOW ME: how much you're playing this bar
                followNow.vel += (float) m.getVelocity();
            }

            // ---- note-offs follow whatever their key started, even if the settings changed since
            if (m.isNoteOff())
            {
                if (keyOutNote[(size_t) n] >= 0)
                {
                    const int on = keyOutNote[(size_t) n];
                    out.addEvent (juce::MidiMessage::noteOff (keyOutCh[(size_t) n], on), pos);
                    passthroughOn[(size_t) on] = juce::jmax (0, passthroughOn[(size_t) on] - 1);
                    keyOutNote[(size_t) n] = -1;
                    setBit (inDown, n, false);
                    continue;
                }
                if (keyChordKey[(size_t) n] >= 0)
                {
                    setBit (inDown, keyChordKey[(size_t) n], false);
                    keyChordKey[(size_t) n] = -1;
                    if (! hold)
                    {
                        releaseSource (n, pos, out);
                        bandHousekeeping (pos, out);
                    }
                    continue;
                }
                setBit (inDown, n, false);
                if (! splitOn && bandRoleNow == 0 && cfg.keysMode == 0 && ! hold)
                    releaseSource (n, pos, out);
                if (! splitOn && ! (bandRoleNow == 0 && cfg.keysMode == 0)) out.addEvent (m, pos);
                continue;
            }

            // a key that is somehow still sounding gets cut before it plays again
            if (keyOutNote[(size_t) n] >= 0)
            {
                const int on = keyOutNote[(size_t) n];
                out.addEvent (juce::MidiMessage::noteOff (keyOutCh[(size_t) n], on), pos);
                passthroughOn[(size_t) on] = juce::jmax (0, passthroughOn[(size_t) on] - 1);
                keyOutNote[(size_t) n] = -1;
            }

            // ---- SPLIT: right hand plays its own notes
            if (splitOn && n >= cfg.splitNote)
            {
                int on = keyedNote (n) + 12 * cfg.rightOct;
                if (cfg.rightSnap) on = snapToKey (on, keyShift == 0 && keyScale < 0 ? cfg.scaleMask : (uint16_t) scaleMask (effKeyRoot(), effScale()));
                while (on > 127) on -= 12;
                while (on < 0) on += 12;
                const int ch = cfg.rightCh > 0 ? cfg.rightCh : chordChannel;
                out.addEvent (juce::MidiMessage::noteOn (ch, on, (juce::uint8) vel), pos);
                keyOutNote[(size_t) n] = (int16_t) on;
                keyOutCh[(size_t) n] = (uint8_t) ch;
                ++passthroughOn[(size_t) on];
                setBit (inDown, n, true);
                continue;
            }

            // ---- chords
            bool mapped = false;
            Chord chord;
            int style = -1, variant = -1, key = n;
            if (bandRoleNow != 0) {}   // a band copy only plays its part: keys pass straight through
            else if (cfg.keysMode == 0)
            {
                // SCALE mode: every key belongs to VESPER. With SPLIT, the octave left of the split
                // can play any chord family.
                if (splitOn && cfg.leftRow >= 0)
                    key = n + 12 * (cfg.leftRow - (cfg.splitNote - 1) / 12);
                if (key >= 0 && key < 128)
                {
                    mapped = true;
                    chord = cfg.scaleKeys[(size_t) key].chord;
                }
            }
            else
            {
                // PADS mode: with SPLIT the 12 keys left of the split are pads 1-12 (or 13-24)
                const int idx = splitOn ? n - (cfg.splitNote - 12) + 12 * cfg.padBank : n - cfg.paletteStart;
                if (idx >= 0 && idx < paletteSize)
                {
                    const auto& card = cfg.palette[(size_t) idx];
                    if (card.chord.valid())
                    {
                        mapped = true;
                        chord = card.chord;
                        style = card.style;
                        variant = card.variant;
                        key = cfg.paletteStart + idx;    // lights the right pad
                    }
                }
            }

            if (mapped)
            {
                setBit (inDown, key, true);
                keyChordKey[(size_t) n] = (int16_t) key;
                triggerChord (n, chord, style, variant, vel, pos, out);
                continue;
            }
            if (splitOn) continue;   // left of the split, but no chord on this key

            // melody / anything outside the pads passes straight through (in the song's key now, after a key change)
            setBit (inDown, n, true);
            const int thru = keyedNote (n);
            keyOutNote[(size_t) n] = (int16_t) thru;
            keyOutCh[(size_t) n] = (uint8_t) m.getChannel();
            ++passthroughOn[(size_t) thru];
            if (thru == n) out.addEvent (m, pos);
            else out.addEvent (juce::MidiMessage::noteOn (m.getChannel(), thru, m.getVelocity()), pos);
            continue;
        }

        if (m.isController())
        {
            const int cc = m.getControllerNumber(), val = m.getControllerValue();
            if (learnArmed.load() && val >= 64 && cc != 120 && cc != 121 && cc != 123)
            {
                extTrigType.store (2);
                extTrigNum.store (cc);
                learnArmed.store (false);
                learnCount.fetch_add (1);
                continue;
            }
            if (trigType == 2 && cc == trigNum)
            {
                const bool down = val >= 64;
                if (down && ! extHeld) extPress (pos, out);
                else if (down && st.extLatch) extPress (pos, out);
                else if (! down && extHeld) extRelease (pos, out);
                continue;
            }
        }

        if (m.isAllNotesOff() || m.isAllSoundOff())
            releaseAll (pos, out);
        out.addEvent (m, pos);
    }
    advancePatterns (numSamples, out);
    advanceBand (numSamples, out);
    if (trackExtHeld != 0 || trackExtOn != 0) updateTrackExt (juce::jmax (0, numSamples - 1), out);
    flushPending (numSamples, out);
    updateExpression (out);
    sendMoodGlide (out);
    if (bandRoleNow == 0) publishLink();
    bandPlaying.store (bandRunning);

    // built-in keys
    // the built-in keys step aside when the chords have their own SOUND loaded
    const bool keysOn = apvts.getRawParameterValue (ids::keysOn)->load() > 0.5f && ! rack.hasInstrument (InstrumentRack::chordSlot);
    const float level = apvts.getRawParameterValue (ids::keysLevel)->load();
    float* left = buffer.getWritePointer (0);
    const bool stereo = buffer.getNumChannels() > 1;
    float* right = stereo ? buffer.getWritePointer (1) : left;
    const float gain = level * level * (stereo ? 1.0f : 0.5f);

    int cursor = 0;
    for (const auto meta : out)
    {
        const auto m = meta.getMessage();
        const int p = juce::jlimit (0, numSamples, meta.samplePosition);
        if (p > cursor && keysOn) synth.render (left + cursor, right + cursor, p - cursor, gain);
        cursor = juce::jmax (cursor, p);
        if ((m.isNoteOn() || m.isNoteOff()) && ((keysSkip >> (m.getChannel() - 1)) & 1)) continue;
        if (m.isNoteOn()) { if (keysOn) synth.noteOn (m.getNoteNumber(), m.getVelocity()); }
        else if (m.isNoteOff()) synth.noteOff (m.getNoteNumber());
        else if (m.isSustainPedalOn()) synth.setSustain (true);
        else if (m.isSustainPedalOff()) synth.setSustain (false);
        else if (m.isController() && m.getControllerNumber() == 11 && m.getChannel() == chordChannel) synth.setExpression (m.getControllerValue() / 127.0f);
        else if (m.isAllNotesOff() || m.isAllSoundOff()) synth.allOff();
    }
    if (cursor < numSamples && keysOn) synth.render (left + cursor, right + cursor, numSamples - cursor, gain);

    // recording
    if (clearRequested.exchange (false))
    {
        recCount.store (0);
        recordedNoteOns.store (0);
    }
    if (recording.load())
    {
        int idx = recCount.load (std::memory_order_relaxed);
        for (const auto meta : out)
        {
            if (idx >= (int) rec.size()) break;
            const auto m = meta.getMessage();
            RecEvent e;
            e.beat = blockBeat + meta.samplePosition / samplesPerBeat;
            e.synced = songSynced ? 1 : 0;
            if (idx == 0) takeSynced.store (songSynced);
            e.channel = (uint8_t) juce::jlimit (1, 16, m.getChannel());
            if (m.isNoteOn()) { e.kind = 0; e.d1 = (uint8_t) m.getNoteNumber(); e.d2 = m.getVelocity(); recordedNoteOns.fetch_add (1); recChannelMask.fetch_or (1u << (e.channel - 1)); }
            else if (m.isNoteOff()) { e.kind = 1; e.d1 = (uint8_t) m.getNoteNumber(); }
            else if (m.isController() && (m.getControllerNumber() == 64 || m.getControllerNumber() == 11))
            {
                e.kind = 2;
                e.d1 = (uint8_t) m.getControllerNumber();
                e.d2 = (uint8_t) m.getControllerValue();
            }
            else continue;
            rec[(size_t) idx++] = e;
        }
        recCount.store (idx, std::memory_order_release);
    }

    // MIDI RECALL: everything that goes out, always (CATCH takes the last 16 bars from here)
    {
        int64_t w = recallWrite.load (std::memory_order_relaxed);
        const int64_t cap = (int64_t) recall.size();
        for (const auto meta : out)
        {
            const auto m = meta.getMessage();
            RecEvent e;
            e.beat = blockBeat + meta.samplePosition / samplesPerBeat;
            e.synced = songSynced ? 1 : 0;
            e.channel = (uint8_t) juce::jlimit (1, 16, m.getChannel());
            if (m.isNoteOn()) { e.kind = 0; e.d1 = (uint8_t) m.getNoteNumber(); e.d2 = m.getVelocity(); }
            else if (m.isNoteOff()) { e.kind = 1; e.d1 = (uint8_t) m.getNoteNumber(); }
            else if (m.isController() && (m.getControllerNumber() == 64 || m.getControllerNumber() == 11))
            {
                e.kind = 2;
                e.d1 = (uint8_t) m.getControllerNumber();
                e.d2 = (uint8_t) m.getControllerValue();
            }
            else continue;
            recall[(size_t) (w % cap)] = e;
            ++w;
        }
        recallWrite.store (w, std::memory_order_release);
    }

    // lights for the on-screen keyboard
    for (int w = 0; w < 4; ++w)
    {
        uint32_t bits = 0;
        for (int b = 0; b < 32; ++b)
        {
            const int note = w * 32 + b;
            if (owner[(size_t) (chordChannel - 1)][(size_t) note] != 0 || owner[1][(size_t) note] != 0 || passthroughOn[(size_t) note] > 0)
                bits |= 1u << b;
        }
        outOn[(size_t) w].store (bits, std::memory_order_relaxed);
    }

    // the cable: nothing goes out on your keyboard's channel (melody passing through, anything left on it goes to the chords' channel)
    if (cableLive)
    {
        const int kb = juce::jlimit (1, 16, keyboardCh.load());
        const int safeCh = chordChannel != kb ? chordChannel : (kb == 16 ? 15 : 16);
        bool moved = false;
        for (const auto meta : out) if (meta.getMessage().getChannel() == kb) { moved = true; break; }
        if (moved)
        {
            loopKeep.clear();
            for (const auto meta : out)
            {
                auto m = meta.getMessage();
                if (m.getChannel() == kb) m.setChannel (safeCh);
                loopKeep.addEvent (m, meta.samplePosition);
            }
            out.swapWith (loopKeep);
        }
    }

    // SOUND slots: a track (or the chords) with an instrument loaded plays it right here; its notes stay inside VESPER
    {
        std::array<int, InstrumentRack::numSlots> chOf {};
        chOf[(size_t) InstrumentRack::chordSlot] = chordChannel;
        const int nt = juce::jlimit (0, (int) maxBandTracks, bandCfg.numTracks);
        for (int t = 0; t < nt; ++t) chOf[(size_t) InstrumentRack::trackSlot (t)] = bandCfg.part[(size_t) t].channel;
        rack.process (*this, buffer, out, chOf);
    }

    // remember what we sent, for the loop guard
    for (const auto meta : out)
    {
        const auto m = meta.getMessage();
        if (! (m.isNoteOn() || m.isNoteOff())) continue;
        const auto n = (size_t) m.getNoteNumber();
        const auto ch = (size_t) (juce::jlimit (1, 16, m.getChannel()) - 1);
        if (m.isNoteOn()) { sentOnAt[n] = chOnAt[ch][n] = sampleClock + meta.samplePosition; sentOnVel[n] = m.getVelocity(); sentEnergy += 1.0f; }
        else sentOffAt[n] = chOffAt[ch][n] = sampleClock + meta.samplePosition;
    }

    // remember every note that goes out (FL's output port or the cable), so it's known if FL hands it straight back
    {
        const int64_t win = juce::jmax ((int64_t) (0.3 * getSampleRate()), (int64_t) (8 * numSamples));
        for (const auto meta : out)
        {
            const auto m = meta.getMessage();
            if (! (m.isNoteOn() || m.isNoteOff())) continue;
            const auto ch = (size_t) (juce::jlimit (1, 16, m.getChannel()) - 1), n = (size_t) m.getNoteNumber();
            const int64_t t = sampleClock + meta.samplePosition;
            auto& left = m.isNoteOn() ? cableOnLeft[ch][n] : cableOffLeft[ch][n];
            auto& at = m.isNoteOn() ? cableOnAt[ch][n] : cableOffAt[ch][n];
            if (t - at >= win) left = 0;
            left = (uint8_t) juce::jmin (255, left + 1);
            at = t;
            if (m.isNoteOn()) cableOnVel[ch][n] = (uint8_t) m.getVelocity();
        }
    }

    // MENU > Send MIDI through a cable: it all goes into the cable (timed to the sample) instead of FL's output port
    {
        const juce::SpinLock::ScopedTryLockType tl (cableLock);
        if (tl.isLocked() && (cable != nullptr || cableTestMode) && ! isNonRealtime())
        {
            // the same clock JUCE's MIDI output thread waits on (on Windows the hi-res one counts from somewhere else,
            // and every note would wait forever or be thrown away as too late)
            const double now = (double) juce::Time::getMillisecondCounter();
            double start = cableClock + cableBlockMs;          // blocks follow each other evenly...
            if (cableClock <= 0 || std::abs (start - now) > 15.0) start = now;   // ...unless FL fell behind or ran ahead
            cableClock = start;
            cableBlockMs = 1000.0 * numSamples / getSampleRate();
            for (const auto meta : out)
            {
                const auto m = meta.getMessage();
                const auto ch = (size_t) (juce::jlimit (1, 16, m.getChannel()) - 1);
                if (m.isNoteOn()) { auto& h = cableHeld[ch][(size_t) m.getNoteNumber()]; h = (uint8_t) juce::jmin (255, h + 1); cableSent.fetch_add (1, std::memory_order_relaxed); }
                else if (m.isNoteOff()) { auto& h = cableHeld[ch][(size_t) m.getNoteNumber()]; if (h > 0) --h; }
                else if (m.isAllNotesOff() || m.isAllSoundOff()) cableHeld[ch].fill (0);
            }
            if (cable != nullptr)
            {
                if (! out.isEmpty()) cable->sendBlockOfMessages (out, start, getSampleRate());
                out.clear();
            }
        }
        if (tl.isLocked()) cableLive = (cable != nullptr || cableTestMode) && ! isNonRealtime();
    }

    midi.swapWith (out);
    sampleClock += numSamples;
}

//==============================================================================
// What plays on each MIDI channel, for track and file names ("Chords", "Bass", "Melody + Counter").
juce::String VesperProcessor::trackName (int track) const
{
    return track >= 0 && track < maxBandTracks ? trackNames[(size_t) track] : juce::String();
}

void VesperProcessor::setTrackName (int track, const juce::String& name)
{
    if (track < 0 || track >= maxBandTracks) return;
    trackNames[(size_t) track] = name.trim().substring (0, 40);
    namesChanged.fetch_add (1);
}

juce::String VesperProcessor::slotChannelName (int slot) const
{
    if (slot == InstrumentRack::chordSlot) return "CHORDS";
    const int t = slot - 1;
    if (trackNames[(size_t) juce::jlimit (0, maxBandTracks - 1, t)].isNotEmpty()) return trackNames[(size_t) t];
    return "TRACK " + juce::String (t + 1) + " (" + juce::String (bandTypeName (trackType (t))) + ")";
}

juce::String VesperProcessor::slotTitle (int slot) const
{
    return "VESPER - " + slotChannelName (slot) + " - " + rack.name (slot);
}

juce::String VesperProcessor::channelName (int ch)
{
    juce::StringArray names;
    const int chordChan = (int) apvts.getRawParameterValue (ids::chordCh)->load();
    if (ch == chordChan) names.add ("Chords");
    if (ui.split && ui.rightCh == ch && ch != chordChan) names.add ("Right hand");
    if (ch == 2 && chordChan != 2 && (int) apvts.getRawParameterValue (ids::bassMode)->load() == 2) names.add ("Bass");
    const int count = juce::jlimit (0, maxBandTracks, numTracks.load());
    int perType[numBandTypes] = {};
    for (int t = 0; t < count; ++t) ++perType[trackType (t)];
    int seen[numBandTypes] = {};
    for (int t = 0; t < count; ++t)
    {
        const int type = trackType (t);
        const int nth = ++seen[type];
        if ((int) trackValue (t, TpCh) != ch || trackValue (t, TpOn) < 0.5f) continue;
        if (trackNames[(size_t) t].isNotEmpty()) { names.add (trackNames[(size_t) t]); continue; }
        juce::String n = bandTypeShort (type);
        if (perType[type] > 1) n << " " << nth;
        names.addIfNotAlreadyThere (n);
    }
    if (names.isEmpty()) names.add ("Channel " + juce::String (ch));
    return names.joinIntoString (" + ");
}

std::vector<int> VesperProcessor::takeChannels()
{
    const int total = recCount.load (std::memory_order_acquire);
    uint32_t mask = 0;
    for (int i = 0; i < total; ++i)
        if (rec[(size_t) i].kind == 0) mask |= 1u << (rec[(size_t) i].channel - 1);
    std::vector<int> chans;
    const int chordChan = (int) apvts.getRawParameterValue (ids::chordCh)->load();
    if ((mask >> (chordChan - 1)) & 1u) chans.push_back (chordChan);   // chords first
    for (int ch = 1; ch <= 16; ++ch)
        if (ch != chordChan && ((mask >> (ch - 1)) & 1u)) chans.push_back (ch);
    return chans;
}

// One take as a MIDI file: one named track per channel (FL can turn each into its own channel),
// every note closed, nothing overlapping itself.
bool VesperProcessor::writeTake (const juce::File& f, int onlyChannel)
{
    const int total = recCount.load (std::memory_order_acquire);
    if (total == 0) return false;
    std::vector<int> chans;
    if (onlyChannel > 0) chans.push_back (onlyChannel);
    else chans = takeChannels();
    if (chans.empty()) return false;

    // recorded while FL was playing: keep the song position, so every part lines up when dropped at bar 1
    const bool synced = rec[0].synced != 0;
    const double start = synced ? 0.0 : std::floor (rec[0].beat);
    double last = rec[0].beat;
    for (int i = 0; i < total; ++i) last = std::max (last, rec[(size_t) i].beat);
    const double endT = (last - start + 1.0) * 960.0;

    juce::MidiFile mf;
    mf.setTicksPerQuarterNote (960);
    if (chans.size() > 1)   // several parts: a tempo-map track first, like any multi-track file
    {
        juce::MidiMessageSequence conductor;
        auto name = juce::MidiMessage::textMetaEvent (3, "VESPER");
        name.setTimeStamp (0);
        conductor.addEvent (name);
        auto ts = juce::MidiMessage::timeSignatureMetaEvent (4, 4);
        ts.setTimeStamp (0);
        conductor.addEvent (ts);
        auto eot = juce::MidiMessage::endOfTrack();
        eot.setTimeStamp (endT);
        conductor.addEvent (eot);
        mf.addTrack (conductor);
    }

    int notes = 0;
    for (int ch : chans)
    {
        juce::MidiMessageSequence seq;
        auto name = juce::MidiMessage::textMetaEvent (3, channelName (ch));
        name.setTimeStamp (0);
        seq.addEvent (name);
        std::array<double, 128> onAt;
        onAt.fill (-1.0);
        for (int i = 0; i < total; ++i)
        {
            const auto& e = rec[(size_t) i];
            if (e.channel != ch) continue;
            const double t = juce::jmax (0.0, std::round ((e.beat - start) * 960.0));
            if (e.kind == 0)
            {
                if (onAt[e.d1] >= 0.0 && t <= onAt[e.d1]) continue;   // the same note twice on one tick
                if (onAt[e.d1] >= 0.0)   // re-struck before it was let go: close the old one first
                {
                    auto off = juce::MidiMessage::noteOff (ch, e.d1);
                    off.setTimeStamp (juce::jmax (onAt[e.d1] + 1.0, t));
                    seq.addEvent (off);
                }
                auto m = juce::MidiMessage::noteOn (ch, e.d1, (juce::uint8) juce::jlimit (1, 127, (int) e.d2));
                m.setTimeStamp (t);
                seq.addEvent (m);
                onAt[e.d1] = t;
                ++notes;
            }
            else if (e.kind == 1)
            {
                if (onAt[e.d1] < 0.0) continue;   // stray note-off
                auto m = juce::MidiMessage::noteOff (ch, e.d1);
                m.setTimeStamp (juce::jmax (onAt[e.d1] + 1.0, t));   // never zero length
                seq.addEvent (m);
                onAt[e.d1] = -1.0;
            }
            else
            {
                auto m = juce::MidiMessage::controllerEvent (ch, e.d1, e.d2);
                m.setTimeStamp (t);
                seq.addEvent (m);
            }
        }
        for (int note = 0; note < 128; ++note)
            if (onAt[(size_t) note] >= 0.0)
            {
                auto m = juce::MidiMessage::noteOff (ch, note);
                m.setTimeStamp (juce::jmax (onAt[(size_t) note] + 1.0, endT));
                seq.addEvent (m);
            }
        seq.updateMatchedPairs();
        auto eot = juce::MidiMessage::endOfTrack();
        eot.setTimeStamp (seq.getEndTime());
        seq.addEvent (eot);
        mf.addTrack (seq);
    }
    if (notes == 0) return false;

    f.deleteFile();
    juce::FileOutputStream os (f);
    if (! os.openedOk()) return false;
    mf.writeTo (os, 1);
    os.flush();
    return true;
}

juce::File VesperProcessor::exportRecording (int onlyChannel, const juce::String& label)
{
    if (recCount.load (std::memory_order_acquire) == 0) return {};
    const bool synced = rec[0].synced != 0;
    juce::String name = synced ? "VESPER take " : "VESPER progression ";
    if (label.isNotEmpty()) name << label << " ";
    else if (onlyChannel == 0 && takeChannels().size() > 1) name << "all parts ";
    name << juce::Time::getCurrentTime().formatted ("%H-%M-%S") << ".mid";
    auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("VESPER");
    dir.createDirectory();
    const auto f = dir.getChildFile (name);
    return writeTake (f, onlyChannel) ? f : juce::File();
}

juce::File VesperProcessor::exportPartsFolder()
{
    const auto chans = takeChannels();
    if (chans.empty()) return {};
    auto dir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER").getChildFile ("Takes")
                   .getChildFile ("Take " + juce::Time::getCurrentTime().formatted ("%Y-%m-%d %H-%M-%S"));
    dir.createDirectory();
    int index = 1;
    for (int ch : chans)
    {
        const auto name = juce::String (index++).paddedLeft ('0', 2) + " " + juce::File::createLegalFileName (channelName (ch))
                          + " (ch " + juce::String (ch) + ").mid";
        writeTake (dir.getChildFile (name), ch);
    }
    if (chans.size() > 1) writeTake (dir.getChildFile ("All parts (one track each).mid"), 0);
    return dir;
}

juce::File VesperProcessor::exportChord (const Chord& c, int style, int variant)
{
    if (! c.valid()) return {};
    Rng r;
    r.s = (uint32_t) juce::Time::getMillisecondCounter() | 1u;
    const int center = (int) apvts.getRawParameterValue (ids::height)->load();
    const auto pick = chooseVoicing (c, style >= 0 ? style : ui.style, variant, center, false, Notes(), false, Notes(), ui.genre, r);

    juce::MidiMessageSequence seq;
    auto add = [&seq] (int ch, int note, int vel)
    {
        auto a = juce::MidiMessage::noteOn (ch, note, (juce::uint8) vel);
        a.setTimeStamp (0);
        seq.addEvent (a);
        auto b = juce::MidiMessage::noteOff (ch, note);
        b.setTimeStamp (3840.0);
        seq.addEvent (b);
    };
    const int chordChan = (int) apvts.getRawParameterValue (ids::chordCh)->load();
    for (int i = 0; i < pick.notes.size(); ++i) add (chordChan, pick.notes[i], 100);
    const int bassMode = (int) apvts.getRawParameterValue (ids::bassMode)->load();
    if (bassMode > 0 || c.bass >= 0) add (bassMode == 2 ? 2 : chordChan, bassNoteFor (c, pick.notes), 95);
    seq.updateMatchedPairs();

    juce::MidiFile mf;
    mf.setTicksPerQuarterNote (960);
    mf.addTrack (seq);

    auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("VESPER");
    dir.createDirectory();
    auto name = juce::String::fromUTF8 (chordName (c, flats()).c_str()).replace ("/", " over ");
    auto f = dir.getChildFile ("VESPER " + juce::File::createLegalFileName (name) + ".mid");
    f.deleteFile();
    juce::FileOutputStream os (f);
    if (! os.openedOk()) return {};
    mf.writeTo (os);
    os.flush();
    return f;
}

//==============================================================================
void VesperProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    if (xml == nullptr) return;
    auto* u = xml->createNewChildElement ("VESPER_UI");
    for (int t = 0; t < maxBandTracks; ++t)
        if (trackNames[(size_t) t].isNotEmpty()) u->setAttribute ("nameT" + juce::String (t + 1), trackNames[(size_t) t]);
    xml->addChildElement (rack.toXml().release());
    for (int t = 0; t < maxBandTracks; ++t)
        if (trackSurprise[(size_t) t].load() > 0) u->setAttribute ("surpriseT" + juce::String (t + 1), trackSurprise[(size_t) t].load());
    u->setAttribute ("drummerListens", drummerListens.load() ? 1 : 0);
    u->setAttribute ("bandFeel", bandFeel.load() ? 1 : 0);
    u->setAttribute ("loopBars", looper.bars.load());
    for (int s = 0; s < Looper::numSections; ++s) u->setAttribute ("sectionKey" + juce::String (s), sectionKey[(size_t) s].load());
    u->setAttribute ("hideChord", ui.hideChordPanel ? 1 : 0);
    u->setAttribute ("hidePreview", ui.hidePreview ? 1 : 0);
    u->setAttribute ("hideNext", ui.hideNext ? 1 : 0);
    u->setAttribute ("skin", ui.skin);
    u->setAttribute ("midiCable", cableWanted);
    u->setAttribute ("keyboardCh", keyboardCh.load());
    u->setAttribute ("songNumber", songNumber.load());
    u->setAttribute ("songLoop", songLoopSection.load() ? 1 : 0);
    u->setAttribute ("followMe", followMe.load() ? 1 : 0);
    u->setAttribute ("songTab", ui.songTab ? 1 : 0);
    // playing the song live
    u->setAttribute ("switchAt", switchAt.load());
    if (myGrooveSel.load() >= 0 && myGrooveFile.isNotEmpty()) u->setAttribute ("myGroove", myGrooveFile);
    u->setAttribute ("soloBars", soloBars.load());
    u->setAttribute ("jamBars", jamBars.load());
    u->setAttribute ("soloPick", soloPick.load());
    u->setAttribute ("fillCalls", fillIntoCalls.load() ? 1 : 0);
    u->setAttribute ("songFeel", songFeel.load());
    for (int k = 0; k < numFeelDials; ++k) u->setAttribute ("feelDial" + juce::String (k), (double) feelDial[(size_t) k].load());
    u->setAttribute ("songMoments", songMoments.load() ? 1 : 0);
    u->setAttribute ("learnChords", learnChords.load() ? 1 : 0);
    u->setAttribute ("liftHook", liftLastHook.load() ? 1 : 0);
    u->setAttribute ("keyKind", keyMoveKind.load());
    for (int k = 0; k < numCommandKeys; ++k) if (commandKey[(size_t) k].load() >= 0) u->setAttribute ("cmdKey" + juce::String (k), commandKey[(size_t) k].load());
    for (int t = 0; t < maxBandTracks; ++t) if (trackExtKey[(size_t) t].load() >= 0) u->setAttribute ("extKeyT" + juce::String (t + 1), trackExtKey[(size_t) t].load());
    {   // the song as you've shaped it (cells, moments, lengths)
        const auto plan = songPlanCopy();
        auto* sx = u->createNewChildElement ("SONG");
        sx->setAttribute ("genre", plan.genre);
        sx->setAttribute ("number", plan.number);
        for (const auto& sec : plan.sections)
        {
            auto* e = sx->createNewChildElement ("SECTION");
            e->setAttribute ("type", sec.type);
            e->setAttribute ("label", juce::String (sec.label));
            e->setAttribute ("bars", sec.bars);
            e->setAttribute ("e0", sec.energyFrom);
            e->setAttribute ("e1", sec.energyTo);
            e->setAttribute ("looper", sec.looper);
            e->setAttribute ("groove", sec.grooveBlock);
            if (sec.feel >= 0) e->setAttribute ("feel", sec.feel);
            if (sec.soloTrack >= 0) e->setAttribute ("solo", sec.soloTrack);
            if (sec.keyMove != KeyNone) e->setAttribute ("key", sec.keyMove);
            juce::String mk, mo;
            for (int b = 0; b < sec.bars; ++b) { mk << (int) sec.mask[(size_t) b] << ","; mo << (int) sec.moment[(size_t) b] << ","; }
            e->setAttribute ("mask", mk);
            e->setAttribute ("moments", mo);
        }
    }
    {
        auto* lx = xml->createNewChildElement ("LOOPER");
        lx->setAttribute ("section", looper.section.load());
        for (int s = 0; s < Looper::numSections; ++s)
        {
            const auto& sec = looper.sec[(size_t) s];
            if (sec.len <= 0) continue;
            juce::String evs;
            for (const auto& e : sec.evs)
                evs << juce::String (e.beat, 4) << ":" << (int) e.note << ":" << (int) e.vel << ":" << (int) e.ch << (e.pad ? ":1" : "") << ";";
            auto* sx = lx->createNewChildElement ("SEC");
            sx->setAttribute ("index", s);
            sx->setAttribute ("len", sec.len);
            sx->setAttribute ("groove", sec.groove);
            sx->setAttribute ("evs", evs);
        }
    }
    u->setAttribute ("key", ui.keyRoot);
    u->setAttribute ("scale", ui.scale);
    u->setAttribute ("genre", ui.genre);
    u->setAttribute ("style", ui.style);
    u->setAttribute ("voiceSet", ui.voiceSet);
    u->setAttribute ("spice", ui.spice);
    u->setAttribute ("chordSet", ui.chordSet);
    u->setAttribute ("keysMode", ui.keysMode);
    u->setAttribute ("split", ui.split ? 1 : 0);
    u->setAttribute ("splitNote", ui.splitNote);
    u->setAttribute ("rightCh", ui.rightCh);
    u->setAttribute ("rightOct", ui.rightOct);
    u->setAttribute ("rightSnap", ui.rightSnap ? 1 : 0);
    u->setAttribute ("leftRow", ui.leftRow);
    u->setAttribute ("padBank", ui.padBank);
    u->setAttribute ("autoRec", ui.autoRec ? 1 : 0);
    u->setAttribute ("theme", ui.theme);
    u->setAttribute ("uiScale", ui.uiScale);
    u->setAttribute ("tab", ui.tab);
    u->setAttribute ("dice", (int) ui.diceSeed);
    u->setAttribute ("padLocks", (int) ui.padLocks);
    u->setAttribute ("extTrigType", extTrigType.load());
    u->setAttribute ("extTrigNum", extTrigNum.load());
    u->setAttribute ("tracks", numTracks.load());
    for (int t = 0; t < maxBandTracks; ++t)
    {
        if (trackMidiFiles[(size_t) t].isEmpty()) continue;
        auto* m = u->createNewChildElement ("MIDI");
        m->setAttribute ("track", t);
        m->setAttribute ("cycle", trackCycle (t));
        for (const auto& f : trackMidiFiles[(size_t) t]) m->createNewChildElement ("F")->setAttribute ("path", f);
    }
    u->setAttribute ("chordKeys", chordKeys.load());
    for (int t = 0; t < maxBandTracks; ++t)
    {
        u->setAttribute ("seedT" + juce::String (t + 1), juce::String ((juce::int64) bandSeed[(size_t) t].load()));
        u->setAttribute ("keysT" + juce::String (t + 1), trackKeys[(size_t) t].load());
        if (trackFlags[(size_t) t].load() != 0) u->setAttribute ("flagsT" + juce::String (t + 1), trackFlags[(size_t) t].load());
        if (trackRework[(size_t) t].load() != 0) u->setAttribute ("reworkT" + juce::String (t + 1), trackRework[(size_t) t].load());
        if (trackRespond[(size_t) t].load() != 0) u->setAttribute ("respT" + juce::String (t + 1), trackRespond[(size_t) t].load());
        if (trackGlide[(size_t) t].load() != 0) u->setAttribute ("glideT" + juce::String (t + 1), trackGlide[(size_t) t].load());
        if (trackReworkLock[(size_t) t].load() != 0) u->setAttribute ("rwLockT" + juce::String (t + 1), trackReworkLock[(size_t) t].load());
    }
    for (const auto& card : ui.palette)
    {
        auto* c = u->createNewChildElement ("CARD");
        c->setAttribute ("valid", card.chord.valid() ? 1 : 0);
        c->setAttribute ("root", card.chord.root);
        c->setAttribute ("type", card.chord.valid() ? juce::String (qualities()[(size_t) card.chord.quality].suffix) : juce::String());
        c->setAttribute ("bass", card.chord.bass);
        c->setAttribute ("style", card.style);
        c->setAttribute ("variant", card.variant);
    }
    copyXmlToBinary (*xml, dest);
}

void VesperProcessor::setStateInformation (const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, size));
    if (xml == nullptr) return;
    migrateOldState (*xml);

    if (auto* lx = xml->getChildByName ("LOOPER"))
    {
        looper.state.store (Looper::Off);
        uint32_t filled = 0;
        for (auto& s : looper.sec) { s.evs.clear(); s.len = 0; s.groove = -1; }
        for (auto* sx : lx->getChildWithTagNameIterator ("SEC"))
        {
            const int s = sx->getIntAttribute ("index", -1);
            if (s < 0 || s >= Looper::numSections) continue;
            auto& sec = looper.sec[(size_t) s];
            juce::StringArray evs;
            evs.addTokens (sx->getStringAttribute ("evs"), ";", "");
            for (const auto& ev : evs)
            {
                juce::StringArray f;
                f.addTokens (ev, ":", "");
                if ((f.size() != 4 && f.size() != 5) || (int) sec.evs.size() >= Looper::cap) continue;
                const bool pad = f.size() == 5 && f[4].getIntValue() == 1;
                sec.evs.push_back ({ f[0].getDoubleValue(), (uint8_t) juce::jlimit (0, pad ? Looper::numPads - 1 : 127, f[1].getIntValue()),
                                     (uint8_t) juce::jlimit (0, 127, f[2].getIntValue()),
                                     (uint8_t) (pad ? Looper::padChannel : juce::jlimit (1, 16, f[3].getIntValue())), (uint8_t) (pad ? 1 : 0) });
            }
            sec.len = juce::jlimit (0.0, 64.0, sx->getDoubleAttribute ("len", 0.0));
            sec.groove = sx->getIntAttribute ("groove", -1);
            if (sec.len > 0) filled |= 1u << s;
        }
        looper.filled.store (filled);
        looper.section.store (juce::jlimit (0, Looper::numSections - 1, lx->getIntAttribute ("section", 0)));
    }
    if (auto* r = xml->getChildByName ("SOUNDS"))
    {
        if (juce::MessageManager::existsAndIsCurrentThread()) rack.fromXml (*r);
        else
        {
            const juce::ScopedLock sl (rackStateLock);
            pendingRack = std::make_unique<juce::XmlElement> (*r);
        }
    }
    if (auto* u = xml->getChildByName ("VESPER_UI"))
    {
        for (int t = 0; t < maxBandTracks; ++t) trackNames[(size_t) t] = u->getStringAttribute ("nameT" + juce::String (t + 1)).substring (0, 40);
        for (int t = 0; t < maxBandTracks; ++t) trackSurprise[(size_t) t].store (juce::jlimit (0, 100, u->getIntAttribute ("surpriseT" + juce::String (t + 1), 0)));
        for (int t = 0; t < maxBandTracks; ++t) trackFlags[(size_t) t].store (u->getIntAttribute ("flagsT" + juce::String (t + 1), 0) & 3);
        for (int t = 0; t < maxBandTracks; ++t) trackRework[(size_t) t].store (juce::jlimit (0, 100, u->getIntAttribute ("reworkT" + juce::String (t + 1), 0)));
        for (int t = 0; t < maxBandTracks; ++t) trackReworkLock[(size_t) t].store (u->getIntAttribute ("rwLockT" + juce::String (t + 1), 0) & 0xff);
        for (int t = 0; t < maxBandTracks; ++t) trackRespond[(size_t) t].store (u->getIntAttribute ("respT" + juce::String (t + 1), 0) & 0x3f);
        for (int t = 0; t < maxBandTracks; ++t) trackGlide[(size_t) t].store (juce::jlimit (-1, 1000, u->getIntAttribute ("glideT" + juce::String (t + 1), 0)));
        liveOutReq.store (0);
        liveOutNow.store (0);
        myGrooveFile = u->getStringAttribute ("myGroove");
        myGroovesSig = -1;   // look again: the project's groove is found by its file
        drummerListens.store (u->getIntAttribute ("drummerListens", 0) != 0);
        bandFeel.store (u->getIntAttribute ("bandFeel", 0) != 0);
        looper.bars.store (juce::jlimit (1, 16, u->getIntAttribute ("loopBars", 4)));
        for (int s = 0; s < Looper::numSections; ++s) sectionKey[(size_t) s].store (juce::jlimit (-1, 127, u->getIntAttribute ("sectionKey" + juce::String (s), -1)));
        sectionKeysChanged.fetch_add (1);
        ui.hideChordPanel = u->getIntAttribute ("hideChord", 0) != 0;
        ui.hidePreview = u->getIntAttribute ("hidePreview", 0) != 0;
        ui.hideNext = u->getIntAttribute ("hideNext", 0) != 0;
        ui.skin = u->getStringAttribute ("skin");
        cableWanted = u->getStringAttribute ("midiCable");
        keyboardCh.store (juce::jlimit (1, 16, u->getIntAttribute ("keyboardCh", 1)));
        songNumber.store (juce::jlimit (1, maxSongNumber, u->getIntAttribute ("songNumber", 1)));
        songLoopSection.store (u->getIntAttribute ("songLoop", 0) != 0);
        followMe.store (u->getIntAttribute ("followMe", 0) != 0);
        ui.songTab = true;   // the SONG tab is always there now
        switchAt.store (juce::jlimit (0, 2, u->getIntAttribute ("switchAt", 1)));
        soloBars.store (juce::jlimit (1, 64, u->getIntAttribute ("soloBars", 8)));
        jamBars.store (juce::jlimit (1, 64, u->getIntAttribute ("jamBars", 8)));
        soloPick.store (juce::jlimit (-1, maxBandTracks - 1, u->getIntAttribute ("soloPick", -1)));
        fillIntoCalls.store (u->getIntAttribute ("fillCalls", 1) != 0);
        setSongFeel (FeelNormal);
        if (u->hasAttribute ("feelDial0"))
            for (int k = 0; k < numFeelDials; ++k)
                feelDial[(size_t) k].store ((float) juce::jlimit (0.0, 1.0, u->getDoubleAttribute ("feelDial" + juce::String (k), 0.5)));
        songFeel.store (juce::jlimit (-1, numSongFeels - 1, u->getIntAttribute ("songFeel", FeelNormal)));
        songMoments.store (u->getIntAttribute ("songMoments", 1) != 0);
        learnChords.store (u->getIntAttribute ("learnChords", 0) != 0);
        liftLastHook.store (u->getIntAttribute ("liftHook", 0) != 0);
        keyMoveKind.store (juce::jlimit (1, numKeyMoves - 1, u->getIntAttribute ("keyKind", KeyUpHalf)));
        for (int k = 0; k < numCommandKeys; ++k) commandKey[(size_t) k].store (juce::jlimit (-1, 127, u->getIntAttribute ("cmdKey" + juce::String (k), -1)));
        for (int t = 0; t < maxBandTracks; ++t) trackExtKey[(size_t) t].store (juce::jlimit (-1, 127, u->getIntAttribute ("extKeyT" + juce::String (t + 1), -1)));
        if (auto* sx = u->getChildByName ("SONG"))
        {
            SongPlan plan;
            plan.genre = sx->getIntAttribute ("genre", 0);
            plan.number = sx->getIntAttribute ("number", 1);
            for (auto* e : sx->getChildWithTagNameIterator ("SECTION"))
            {
                SongSection sec;
                sec.type = juce::jlimit (0, numSongSectionTypes - 1, e->getIntAttribute ("type", SecVerse));
                sec.label = e->getStringAttribute ("label", songSectionName (sec.type)).toStdString();
                sec.bars = juce::jlimit (1, 64, e->getIntAttribute ("bars", 8));
                sec.energyFrom = (float) e->getDoubleAttribute ("e0", 0.5);
                sec.energyTo = (float) e->getDoubleAttribute ("e1", 0.5);
                sec.looper = juce::jlimit (0, 3, e->getIntAttribute ("looper", 0));
                sec.grooveBlock = e->getIntAttribute ("groove", 0);
                sec.feel = juce::jlimit (-1, numSongFeels - 1, e->getIntAttribute ("feel", -1));
                sec.soloTrack = juce::jlimit (-1, maxBandTracks - 1, e->getIntAttribute ("solo", -1));
                sec.keyMove = juce::jlimit (0, numKeyMoves - 1, e->getIntAttribute ("key", KeyNone));
                sec.mask.assign ((size_t) sec.bars, 0xffff);
                sec.moment.assign ((size_t) sec.bars, 0);
                const auto mk = juce::StringArray::fromTokens (e->getStringAttribute ("mask"), ",", "");
                const auto mo = juce::StringArray::fromTokens (e->getStringAttribute ("moments"), ",", "");
                for (int b = 0; b < sec.bars; ++b)
                {
                    if (b < mk.size() && mk[b].isNotEmpty()) sec.mask[(size_t) b] = (uint16_t) mk[b].getIntValue();
                    if (b < mo.size() && mo[b].isNotEmpty()) sec.moment[(size_t) b] = (uint8_t) juce::jlimit (0, numSongMoments - 1, mo[b].getIntValue());
                }
                plan.sections.push_back (std::move (sec));
            }
            if (! plan.sections.empty())
            {
                {
                    const juce::SpinLock::ScopedLockType sl (songLock);
                    songPlan = std::move (plan);
                }
                songGenreBuilt = songPlan.genre;
                songLineupSig = 0xffffffffu;   // keep the saved cells (the lineup check runs again only if tracks change)
                songPlanChanged.fetch_add (1);
            }
        }
        cableDirty = cableWanted != cableOpen;
        namesChanged.fetch_add (1);
        ui.keyRoot = juce::jlimit (0, 11, u->getIntAttribute ("key", 0));
        ui.scale = juce::jlimit (0, numScales() - 1, u->getIntAttribute ("scale", 0));
        ui.genre = juce::jlimit (0, numGenres - 1, u->getIntAttribute ("genre", 0));
        ui.style = juce::jlimit (0, numStyles - 1, u->getIntAttribute ("style", genreDefaultStyle (ui.genre)));
        ui.voiceSet = juce::jlimit (-1, 7, u->getIntAttribute ("voiceSet", 0));
        ui.spice = juce::jlimit (0, 100, u->getIntAttribute ("spice", 50));
        ui.chordSet = juce::jlimit (0, 31, u->getIntAttribute ("chordSet", 0));
        ui.keysMode = juce::jlimit (0, 1, u->getIntAttribute ("keysMode", 0));
        ui.split = u->getIntAttribute ("split", 0) != 0;
        ui.splitNote = juce::jlimit (1, 127, u->getIntAttribute ("splitNote", 60));
        ui.rightCh = juce::jlimit (0, 16, u->getIntAttribute ("rightCh", 0));
        ui.rightOct = juce::jlimit (-3, 3, u->getIntAttribute ("rightOct", 0));
        ui.rightSnap = u->getIntAttribute ("rightSnap", 0) != 0;
        ui.leftRow = juce::jlimit (-1, numRows - 1, u->getIntAttribute ("leftRow", -1));
        ui.padBank = juce::jlimit (0, 1, u->getIntAttribute ("padBank", 0));
        ui.autoRec = u->getIntAttribute ("autoRec", 1) != 0;
        autoRec.store (ui.autoRec);
        ui.theme = juce::jlimit (0, 2, u->getIntAttribute ("theme", 0));
        ui.uiScale = juce::jlimit (0, 2, u->getIntAttribute ("uiScale", 1));
        ui.tab = juce::jlimit (0, 4, u->getIntAttribute ("tab", 0));
        numTracks.store (juce::jlimit (1, maxBandTracks, u->getIntAttribute ("tracks", defaultBandTracks)));
        for (int t = 0; t < maxBandTracks; ++t) if (! trackMidiFiles[(size_t) t].isEmpty()) clearTrackMidi (t);
        for (auto* m : u->getChildWithTagNameIterator ("MIDI"))
        {
            const int t = m->getIntAttribute ("track", -1);
            if (t < 0 || t >= maxBandTracks) continue;
            juce::StringArray files;
            for (auto* f : m->getChildWithTagNameIterator ("F")) files.add (f->getStringAttribute ("path"));
            loadTrackMidi (t, files);
            setTrackCycle (t, m->getIntAttribute ("cycle", 16));
        }
        chordKeys.store (u->getIntAttribute ("chordKeys", 0) & 0xfff);
        for (int t = 0; t < maxBandTracks; ++t)
        {
            const auto key = "seedT" + juce::String (t + 1);
            if (u->hasAttribute (key)) bandSeed[(size_t) t].store ((uint32_t) u->getStringAttribute (key).getLargeIntValue());
            trackKeys[(size_t) t].store (u->getIntAttribute ("keysT" + juce::String (t + 1), 0) & 0xfff);
        }
        tracksChanged.fetch_add (1);
        ui.diceSeed = (uint32_t) u->getIntAttribute ("dice", 0);
        ui.padLocks = (uint32_t) u->getIntAttribute ("padLocks", 0) & 0xffffffu;
        extTrigType.store (juce::jlimit (0, 2, u->getIntAttribute ("extTrigType", 0)));
        extTrigNum.store (juce::jlimit (-1, 127, u->getIntAttribute ("extTrigNum", -1)));
        int i = 0;
        for (auto* c : u->getChildWithTagNameIterator ("CARD"))
        {
            if (i >= paletteSize) break;
            Card card;
            if (c->getIntAttribute ("valid", 0) != 0)
                card.chord = makeChord (c->getIntAttribute ("root", 0), c->getStringAttribute ("type").toStdString(), c->getIntAttribute ("bass", -1));
            card.style = c->getIntAttribute ("style", -1);
            card.variant = c->getIntAttribute ("variant", -1);
            ui.palette[(size_t) i++] = card;
        }
        xml->removeChildElement (u, true);
    }
    if (xml->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));

    history.clear();
    history.push_back (ui.palette);
    historyPos = 0;
    applyUiState();
}

// Projects saved with VESPER 1.5 or older had six fixed band parts ("bMelOn", "bBassStyle"...).
// They become tracks 1-6 (melody, counter, bass, strings, horns, drums), exactly as they were.
void VesperProcessor::migrateOldState (juce::XmlElement& xml)
{
    bool old = false;
    for (auto* e : xml.getChildWithTagNameIterator ("PARAM"))
    {
        const auto id = e->getStringAttribute ("id");
        for (int part = 0; part < numBandParts; ++part)
        {
            const juce::String prefix = bandPartId (part);
            if (! id.startsWith (prefix)) continue;
            const auto suffix = id.substring (prefix.length());
            // "bBass" also starts with "b" + ... make sure the rest is one of the per-part suffixes
            bool known = false;
            for (int w = 0; w < numTrackParams; ++w) if (suffix == trackParamSuffix (w)) known = true;
            if (! known) continue;
            e->setAttribute ("id", ids::track (part, suffix.toRawUTF8()));
            old = true;
            break;
        }
    }
    if (! old) return;
    auto setParam = [&xml] (const juce::String& id, double value)
    {
        for (auto* e : xml.getChildWithTagNameIterator ("PARAM"))
            if (e->getStringAttribute ("id") == id) { e->setAttribute ("value", value); return; }
        auto* e = xml.createNewChildElement ("PARAM");
        e->setAttribute ("id", id);
        e->setAttribute ("value", value);
    };
    for (int part = 0; part < numBandParts; ++part)
    {
        setParam (ids::track (part, "Type"), (double) part);   // the six parts were in type order
        setParam (ids::track (part, "Mode"), 0.0);
    }
    for (int t = numBandParts; t < maxBandTracks; ++t) setParam (ids::track (t, "On"), 0.0);
    if (auto* u = xml.getChildByName ("VESPER_UI"))
    {
        u->setAttribute ("tracks", defaultBandTracks);
        for (int part = 0; part < numBandParts; ++part)
        {
            const auto key = juce::String ("seed") + bandPartId (part);
            if (u->hasAttribute (key)) u->setAttribute ("seedT" + juce::String (part + 1), u->getStringAttribute (key));
        }
    }
}

juce::AudioProcessorEditor* VesperProcessor::createEditor() { return new VesperEditor (*this); }

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new VesperProcessor(); }
