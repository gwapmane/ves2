// VESPER band: plays the generated parts (core/Band) in time with FL, following the chords you play,
// each part on its own MIDI channel. Also keeps band copies of VESPER in step (LinkBus.h).
#include "PluginProcessor.h"

#include <algorithm>
#include <cmath>

using namespace vesper;

static constexpr double stepBeats = 0.25;   // the band runs on a 16th grid

//==============================================================================
// message thread
void VesperProcessor::rollBandSeed (int track)
{
    auto& r = juce::Random::getSystemRandom();
    bandSeed[(size_t) juce::jlimit (0, maxBandTracks - 1, track)].store ((uint32_t) r.nextInt() | 1u);
}

float VesperProcessor::trackValue (int track, int which) const
{
    return bandParams[(size_t) juce::jlimit (0, maxBandTracks - 1, track)][(size_t) juce::jlimit (0, numTrackParams - 1, which)]->load();
}

void VesperProcessor::setTrackValue (int track, int which, float plain)
{
    if (auto* prm = apvts.getParameter (ids::track (track, trackParamSuffix (which))))
        prm->setValueNotifyingHost (prm->convertTo0to1 (plain));
}

int VesperProcessor::trackType (int track) const
{
    return juce::jlimit (0, numBandTypes - 1, (int) std::lround (trackValue (track, TpType)));
}

int VesperProcessor::freeChannel (int exceptTrack) const
{
    uint32_t used = 1u << (juce::jlimit (1, 16, (int) apvts.getRawParameterValue (ids::chordCh)->load()) - 1);
    const int count = juce::jlimit (0, maxBandTracks, numTracks.load());
    for (int t = 0; t < count; ++t)
        if (t != exceptTrack) used |= 1u << (juce::jlimit (1, 16, (int) trackValue (t, TpCh)) - 1);
    static const int order[16] = { 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 10, 1 };
    const bool drums = exceptTrack >= 0 && bandTypeIsDrums (trackType (exceptTrack));
    if (drums) return 10;   // every drum track shares channel 10, so one drum plugin (VESPER DRUMS, FPC...) plays the whole kit
    for (int ch : order) if (! ((used >> (ch - 1)) & 1u)) return ch;
    return 16;
}

bool VesperProcessor::addTrack()
{
    const int n = numTracks.load();
    if (n >= maxBandTracks) return false;
    const int t = n;
    // start as an instrument the band doesn't have yet
    bool have[numBandTypes] = {};
    for (int k = 0; k < n; ++k) have[trackType (k)] = true;
    static const int prefer[] = { BKeys, BPad, BArp, BGuitar, BStrings, BHorns, BMelody, BCounter, BBass, BDrums };
    int type = bandDefaultType (t);
    for (int ty : prefer) if (! have[ty]) { type = ty; break; }
    const int genre = (int) apvts.getRawParameterValue (ids::bandGenre)->load();
    const auto preset = bandGenrePreset (genre);
    setTrackValue (t, TpType, (float) type);
    setTrackValue (t, TpMode, (float) ModeJam);
    setTrackValue (t, TpStyle, (float) preset.style[type]);
    setTrackValue (t, TpDens, 0.5f);
    setTrackValue (t, TpCplx, 0.5f);
    setTrackValue (t, TpOct, 0.0f);
    setTrackValue (t, TpLvl, 0.75f);
    setTrackValue (t, TpDyn, type == BStrings ? 2.0f : 0.0f);
    trackKeys[(size_t) t].store (0);
    trackFlags[(size_t) t].store (0);
    trackRework[(size_t) t].store (0);
    trackReworkLock[(size_t) t].store (0);
    trackRespond[(size_t) t].store (0);
    trackGlide[(size_t) t].store (0);
    rollBandSeed (t);
    numTracks.store (n + 1);
    setTrackValue (t, TpCh, (float) freeChannel (t));
    setTrackValue (t, TpOn, 1.0f);
    tracksChanged.fetch_add (1);
    return true;
}

void VesperProcessor::removeTrack (int track)
{
    const int n = numTracks.load();
    if (n <= 1 || track < 0 || track >= n) return;
    // every track below it moves up one (its name and SOUND too)
    rack.unload (InstrumentRack::trackSlot (track));
    for (int t = track; t < n - 1; ++t)
    {
        trackNames[(size_t) t] = trackNames[(size_t) (t + 1)];
        trackSurprise[(size_t) t].store (trackSurprise[(size_t) (t + 1)].load());
        rack.swap (InstrumentRack::trackSlot (t), InstrumentRack::trackSlot (t + 1));
        for (int w = 0; w < numTrackParams; ++w) setTrackValue (t, w, trackValue (t + 1, w));
        bandSeed[(size_t) t].store (bandSeed[(size_t) (t + 1)].load());
        trackKeys[(size_t) t].store (trackKeys[(size_t) (t + 1)].load());
        trackFlags[(size_t) t].store (trackFlags[(size_t) (t + 1)].load());
        trackRework[(size_t) t].store (trackRework[(size_t) (t + 1)].load());
        trackReworkLock[(size_t) t].store (trackReworkLock[(size_t) (t + 1)].load());
        trackRespond[(size_t) t].store (trackRespond[(size_t) (t + 1)].load());
        trackGlide[(size_t) t].store (trackGlide[(size_t) (t + 1)].load());
        trackClips[(size_t) t].store (trackClips[(size_t) (t + 1)].load());
        trackMidiFiles[(size_t) t] = trackMidiFiles[(size_t) (t + 1)];
    }
    if (auto* gone = trackClips[(size_t) track].load(); gone != nullptr && track == n - 1) clipRetired.push_back ({ gone, juce::Time::getMillisecondCounterHiRes() });
    trackClips[(size_t) (n - 1)].store (nullptr);
    trackMidiFiles[(size_t) (n - 1)].clear();
    trackNames[(size_t) (n - 1)].clear();
    trackSurprise[(size_t) (n - 1)].store (0);
    namesChanged.fetch_add (1);
    setTrackValue (n - 1, TpOn, 0.0f);
    trackKeys[(size_t) (n - 1)].store (0);
    trackFlags[(size_t) (n - 1)].store (0);
    trackRework[(size_t) (n - 1)].store (0);
    trackReworkLock[(size_t) (n - 1)].store (0);
    trackRespond[(size_t) (n - 1)].store (0);
    trackGlide[(size_t) (n - 1)].store (0);
    liveOutReq.store (0);
    liveOutNow.store (0);
    for (int t = 0; t < n - 1; ++t)   // a track that answered the one removed (or one below it) follows it up the list
    {
        const int v = trackRespond[(size_t) t].load();
        const int c = respondCaller (v);
        if (c == track) trackRespond[(size_t) t].store (0);
        else if (c > track) trackRespond[(size_t) t].store (packRespond (c - 1, respondMode (v), respondBars (v)));
    }
    numTracks.store (n - 1);
    tracksChanged.fetch_add (1);
}

void VesperProcessor::setTrackType (int track, int type)
{
    type = juce::jlimit (0, numBandTypes - 1, type);
    if (type == trackType (track)) return;
    const int genre = (int) apvts.getRawParameterValue (ids::bandGenre)->load();
    const auto preset = bandGenrePreset (genre);
    setTrackValue (track, TpType, (float) type);
    setTrackValue (track, TpStyle, (float) preset.style[type]);
    setTrackValue (track, TpDens, preset.density[type]);
    setTrackValue (track, TpCplx, preset.complexity[type]);
    setTrackValue (track, TpDyn, type == BStrings ? 2.0f : 0.0f);
    if (! bandTypeCanHold (type)) setTrackValue (track, TpMode, (float) ModeJam);
    if (bandTypeIsDrums (type))
        setTrackValue (track, TpCh, 10.0f);   // drums go to channel 10 (the General MIDI drum channel), all together
    tracksChanged.fetch_add (1);
}

void VesperProcessor::setAllHold (bool hold)
{
    const int n = numTracks.load();
    for (int t = 0; t < n; ++t)
        if (bandTypeCanHold (trackType (t)))
            setTrackValue (t, TpMode, (float) (hold ? ModeHold : ModeJam));
}

bool VesperProcessor::allHold() const
{
    const int n = numTracks.load();
    bool any = false;
    for (int t = 0; t < n; ++t)
    {
        if (! bandTypeCanHold (trackType (t)) || trackValue (t, TpOn) < 0.5f) continue;
        any = true;
        if ((int) std::lround (trackValue (t, TpMode)) != ModeHold) return false;
    }
    return any;
}

void VesperProcessor::applyBandGenre (int genre)
{
    const BandGenrePreset preset = bandGenrePreset (genre);
    const int n = numTracks.load();
    bool anyOn = false;
    for (int t = 0; t < n; ++t) anyOn = anyOn || trackValue (t, TpOn) > 0.5f;
    for (int t = 0; t < n; ++t)
    {
        const int type = trackType (t);
        setTrackValue (t, TpStyle, (float) preset.style[type]);
        setTrackValue (t, TpDens, preset.density[type]);
        setTrackValue (t, TpCplx, preset.complexity[type]);
        if (! anyOn) setTrackValue (t, TpOn, ((preset.lineup >> type) & 1) ? 1.0f : 0.0f);
    }
    if (auto* prm = apvts.getParameter (ids::bandGenre))
        prm->setValueNotifyingHost (prm->convertTo0to1 ((float) genre));
}

void VesperProcessor::stopBandFromUi()
{
    int s1, z1, s2, z2;
    uiFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    auto& e = uiEvents[(size_t) (z1 > 0 ? s1 : s2)];
    e = UiEvent();
    e.type = 6;
    uiFifo.finishedWrite (1);
}

//==============================================================================
// audio thread
void VesperProcessor::readBand()
{
    linkNowMs = juce::Time::getMillisecondCounterHiRes();
    chordChannel = juce::jlimit (1, 16, (int) apvts.getRawParameterValue (ids::chordCh)->load());
    bandEnabled = apvts.getRawParameterValue (ids::bandOn)->load() > 0.5f;
    bandStopMode = (int) apvts.getRawParameterValue (ids::bandStop)->load();
    bandRoleNow = juce::jlimit (0, (int) maxBandTracks, (int) apvts.getRawParameterValue (ids::bandRole)->load());
    if (bandRoleNow != 0) return;   // a band copy takes everything from the main VESPER

    static const int phrases[4] = { 1, 2, 4, 8 };
    bandCfg.phraseBars = phrases[juce::jlimit (0, 3, (int) apvts.getRawParameterValue (ids::bandPhrase)->load())];
    bandCfg.swing = apvts.getRawParameterValue (ids::bandSwing)->load() / 100.0f * 0.5f;
    bandCfg.numTracks = juce::jlimit (0, (int) maxBandTracks, numTracks.load());
    bandCfg.genre = juce::jlimit (0, numGenres - 1, (int) apvts.getRawParameterValue (ids::bandGenre)->load());
    bandCfg.groove = juce::jlimit (0, numGrooves (bandCfg.genre) - 1, (int) apvts.getRawParameterValue (ids::bandGroove)->load());
    bandCfg.feel = apvts.getRawParameterValue (ids::bandFeel)->load() / 100.0f;
    bandCfg.vary = apvts.getRawParameterValue (ids::bandVary)->load() / 100.0f;
    static const int changes[5] = { 0, 4, 8, 16, 32 };
    bandCfg.grooveChange = changes[juce::jlimit (0, 4, (int) apvts.getRawParameterValue (ids::bandChange)->load())];
    for (int t = 0; t < maxBandTracks; ++t)
    {
        const auto& prm = bandParams[(size_t) t];
        auto& pc = bandCfg.part[(size_t) t];
        pc.type = juce::jlimit (0, numBandTypes - 1, (int) std::lround (prm[TpType]->load()));
        pc.on = prm[TpOn]->load() > 0.5f && t < bandCfg.numTracks;
        pc.mode = bandTypeCanHold (pc.type) ? juce::jlimit (0, numBandModes - 1, (int) std::lround (prm[TpMode]->load())) : (int) ModeJam;
        pc.style = juce::jlimit (0, bandNumStyles (pc.type) - 1, (int) std::lround (prm[TpStyle]->load()));
        pc.density = prm[TpDens]->load();
        pc.complexity = prm[TpCplx]->load();
        pc.octave = juce::jlimit (-2, 2, (int) std::lround (prm[TpOct]->load()));
        pc.level = prm[TpLvl]->load();
        pc.channel = juce::jlimit (1, 16, (int) std::lround (prm[TpCh]->load()));
        pc.dyn = juce::jlimit (0, 3, (int) prm[TpDyn]->load());
        pc.keyMask = (uint16_t) (trackKeys[(size_t) t].load (std::memory_order_relaxed) & 0xfff);
        pc.seed = bandSeed[(size_t) t].load();
        bandCfg.clips[(size_t) t] = trackClips[(size_t) t].load();
        pc.surprise = trackSurprise[(size_t) t].load();
        pc.rework = (float) juce::jlimit (0, 100, trackRework[(size_t) t].load (std::memory_order_relaxed)) / 100.0f;
        pc.reworkLock = (uint16_t) trackReworkLock[(size_t) t].load (std::memory_order_relaxed);
    }
    // "drums out", "bass out", "everybody out": those tracks sit out until they're called back in
    if (const int out = liveOutNow.load (std::memory_order_relaxed); out != 0)
        for (int t = 0; t < bandCfg.numTracks; ++t) if ((out >> t) & 1) bandCfg.part[(size_t) t].on = false;
    // MY GROOVES: one of yours instead of the genre's GROOVE
    bandCfg.userGroove = nullptr;
    if (const auto* mg = myGrooves.load (std::memory_order_acquire))
    {
        const int sel = myGrooveSel.load (std::memory_order_relaxed);
        const auto& list = mg->perGenre[(size_t) bandCfg.genre];
        if (sel >= 0 && sel < (int) list.size() && myGrooveGenre.load (std::memory_order_relaxed) == bandCfg.genre) bandCfg.userGroove = &list[(size_t) sel];
    }
    // the LOOPER keeps the band going between the keys it presses, and each section plays its own groove
    if (looper.busy()) bandStopMode = 2;
    if (bandCfg.groove != lastGrooveParam)
    {
        if (lastGrooveParam >= 0 && looper.playing()) looper.sec[(size_t) looper.section.load()].groove = bandCfg.groove;   // you changed it: that section keeps it
        lastGrooveParam = bandCfg.groove;
    }
    if (looper.playing())
    {
        const int g = looper.sec[(size_t) looper.section.load()].groove;
        if (g >= 0) bandCfg.groove = juce::jlimit (0, numGrooves (bandCfg.genre) - 1, g);
    }
    // MAKE IT A SONG: the part decides who plays and how busy
    if (songActive && curBar.sec >= 0) applySongBar (curBar);
    if (transitionReq.exchange (false)) transitionArmed = true;
    applyJamSolo();
    updateKeysSkip();
}

//==============================================================================
int VesperProcessor::sectionOfKey (int note) const
{
    for (int s = 0; s < Looper::numSections; ++s) if (sectionKey[(size_t) s].load() == note) return s;
    return -1;
}

void VesperProcessor::goToSection (int s)
{
    s = juce::jlimit (0, Looper::numSections - 1, s);
    const int st = looper.state.load();
    looper.wantSection.store (s);
    if (((looper.filled.load() >> s) & 1u) == 0) looper.cmd.store (1);                       // empty: record it
    else if (st != Looper::Playing && st != Looper::Recording) looper.cmd.store (2);        // play it
}

int VesperProcessor::resolveSection (int s) const
{
    // a part whose section has no loop uses the nearest one that does (C -> B -> A)
    const uint32_t f = looper.filled.load();
    for (int k = s; k >= 0; --k) if ((f >> k) & 1u) return k;
    for (int k = 0; k < Looper::numSections; ++k) if ((f >> k) & 1u) return k;
    return 0;
}

bool VesperProcessor::songTick (int numSamples)
{
    const bool want = songOn.load();
    if (want && ! songActive)
    {
        songActive = true;
        perfSegCount.store (0);   // a new performance (the calls are cleared on the message thread)
        perfStarts.fetch_add (1);
        perfChanged.fetch_add (1);
        songSec = 0;
        songBar = -1;
        followJump = -1;
        followCount = 0;
        followNow = FollowBar();
        if (looper.playing())   // on the loop's next bar line
        {
            const double ls = looper.loopStart();
            songNextBar = ls + std::ceil ((blockBeat - ls) / 4.0 - 1e-6) * 4.0;
        }
        else
        {
            songNextBar = hostPlaying ? std::ceil (blockBeat / 4.0 - 1e-6) * 4.0 : blockBeat;
            if (looper.filled.load() != 0) { looper.wantSection.store (resolveSection (0)); looper.cmd.store (2); }
        }
        const int j = songJump.load();
        if (j >= 0) { songSec = j; songJump.store (-1); songBar = -2; }   // started from a section you clicked
    }
    if (! want && songActive)
    {
        songActive = false;
        songSecNow.store (-1);
        songBarNow.store (-1);
        curBar = prevBar = SongBar();
        return true;
    }
    if (! songActive) return false;

    const double b1 = blockBeat + numSamples / samplesPerBeat;
    bool changed = false;
    for (int guard = 0; guard < 4 && b1 > songNextBar + 1e-9; ++guard)
    {
        // the bar just finished: what your hands did (FOLLOW ME)
        if (songBar >= 0)
        {
            for (int i = (int) followHist.size() - 1; i > 0; --i) followHist[(size_t) i] = followHist[(size_t) (i - 1)];
            followHist[0] = followNow;
            followNow = FollowBar();
            ++followCount;
        }
        int sec = songSec, bar = songBar + 1;
        bool ended = false;
        {
            const juce::SpinLock::ScopedTryLockType tl (songLock);
            const int n = (int) songPlan.sections.size();
            if (! tl.isLocked() || n == 0)
            {
                if (n == 0 && tl.isLocked()) ended = true;   // no song: nothing to play
                else { songBar = bar; songNextBar += 4.0; curBar.bar = bar; continue; }
            }
            else
            {
                int jump = -1;
                if (const int pending = songJump.load(); pending >= 0)
                {
                    const int curBars = songPlan.sections[(size_t) juce::jlimit (0, n - 1, sec)].bars;
                    if (songBar < 0 || jumpAllowedAfter (songBar, curBars))
                    {
                        jump = songJump.exchange (-1);
                        songJumpType.store (-1);
                    }
                }
                if (jump < 0 && followJump >= 0) jump = followJump;
                followJump = -1;
                if (songBar == -2) { bar = 0; }                   // started on a section you picked
                else if (jump >= 0 && jump < n) { sec = jump; bar = 0; }
                else if (songBar < 0) { sec = 0; bar = 0; }
                else if (bar >= songPlan.sections[(size_t) juce::jlimit (0, n - 1, sec)].bars)
                {
                    bar = 0;
                    if (! songLoopSection.load()) ++sec;
                }
                if (sec >= n) ended = true;
                else
                {
                    const auto& S = songPlan.sections[(size_t) sec];
                    prevBar = curBar;
                    curBar.sec = sec;
                    curBar.bar = bar;
                    curBar.bars = S.bars;
                    curBar.type = S.type;
                    curBar.looper = S.looper;
                    curBar.grooveBlock = S.grooveBlock;
                    curBar.mask = bar < (int) S.mask.size() ? S.mask[(size_t) bar] : (uint16_t) 0xffff;
                    curBar.moment = bar < (int) S.moment.size() ? S.moment[(size_t) bar] : 0;
                    curBar.energy = S.energyAt (bar);
                    curBar.changeNext = (bar == S.bars - 1 && ! songLoopSection.load() && sec + 1 < n)
                                        || (songJump.load() >= 0 && jumpAllowedAfter (bar, S.bars));
                    curBar.nextType = songLoopSection.load() ? S.type : (sec + 1 < n ? songPlan.sections[(size_t) (sec + 1)].type : -1);
                    if (prevBar.sec != sec) transitionArmed = false;   // the change came: TRANSITION is done
                    curBar.start = songNextBar;
                    if (prevBar.sec != sec && looper.filled.load() != 0) looper.wantSection.store (resolveSection (S.looper));
                }
            }
        }
        if (ended)
        {
            songActive = false;
            songOn.store (false);
            songSecNow.store (-1);
            songBarNow.store (-1);
            curBar = prevBar = SongBar();
            if (looper.busy()) looper.cmd.store (3);
            return true;
        }
        perfBar (sec, sec != songSec || bar == 0 || songBar < 0);
        songSec = sec;
        songBar = bar;
        songNextBar += 4.0;
        jumpAtLine = songJump.load();
        // FOLLOW ME: at the start of a phrase's last bar, decide where the next phrase goes (and fill into it)
        if (followMe.load() && bar % 4 == 3) followDecide (sec, bar);
        changed = true;
    }
    // LATE CATCH: a call that arrives just after the line it was meant for (you said it on the one, and the voice app or
    // your hands were a hair late) still makes it: the section starts now, as if it had started on that line
    if (songActive && curBar.sec >= 0 && jumpAtLine < 0 && curBar.start >= 0)
    {
        const int pending = songJump.load();
        const int mode = switchAt.load();
        const bool line = mode == 0 || (mode == 1 && curBar.bar % 4 == 0) || (mode == 2 && curBar.bar == 0);
        const double into = blockBeat - curBar.start;
        const double window = juce::jmin (1.25, 0.8 * bpm / 60.0);
        if (pending >= 0 && line && into >= 0.0 && into < window)
        {
            const juce::SpinLock::ScopedTryLockType tl (songLock);
            const int n = (int) songPlan.sections.size();
            if (tl.isLocked() && pending < n)
            {
                songJump.store (-1);
                songJumpType.store (-1);
                const auto& S = songPlan.sections[(size_t) pending];
                const double start = curBar.start;
                prevBar = curBar;
                curBar.sec = pending;
                curBar.bar = 0;
                curBar.bars = S.bars;
                curBar.type = S.type;
                curBar.looper = S.looper;
                curBar.grooveBlock = S.grooveBlock;
                curBar.mask = S.mask.empty() ? (uint16_t) 0xffff : S.mask[0];
                curBar.moment = S.moment.empty() ? 0 : S.moment[0];
                curBar.energy = S.energyAt (0);
                curBar.changeNext = S.bars == 1 && ! songLoopSection.load() && pending + 1 < n;
                curBar.nextType = songLoopSection.load() ? S.type : (pending + 1 < n ? songPlan.sections[(size_t) (pending + 1)].type : -1);
                curBar.start = start;
                if (looper.filled.load() != 0) looper.wantSection.store (resolveSection (S.looper));
                // the bar that already started belongs to the new section in the take
                const int segs = perfSegCount.load();
                if (segs > 0 && perfSegBars[(size_t) (segs - 1)].load() > 1) { perfSegBars[(size_t) (segs - 1)].fetch_sub (1); perfBar (pending, true); }
                else if (segs > 0) perfSegSec[(size_t) (segs - 1)].store (pending);
                songSec = pending;
                songBar = 0;
                transitionArmed = false;
                if (drummerListens.load() || fillIntoCalls.load()) crashBeat = blockBeat;   // the crash, a hair late
                changed = true;
            }
        }
    }
    if (curBar.start >= 0) songBeatInBar.store ((float) juce::jlimit (0.0, 4.0, blockBeat - curBar.start));
    songSecNow.store (songSec);
    songBarNow.store (songBar);
    return changed;
}

void VesperProcessor::followDecide (int curSec, int)
{
    if (followCount < 2) return;
    const juce::SpinLock::ScopedTryLockType tl (songLock);
    if (! tl.isLocked()) return;
    const auto& secs = songPlan.sections;
    const int n = (int) secs.size();
    if (curSec < 0 || curSec >= n) return;
    const int type = secs[(size_t) curSec].type;
    auto energyOf = [] (const FollowBar& f) { return std::min (1.0f, f.notes / 6.0f) * 0.5f + (f.notes > 0 ? f.vel / f.notes / 127.0f : 0.0f) * 0.5f; };
    const float played = 0.5f * (energyOf (followHist[0]) + energyOf (followHist[1]));
    const float sectionE = curBar.energy;
    auto findNext = [&] (std::initializer_list<int> types) -> int
    {
        for (int k = 1; k < n; ++k)
        {
            const int i = (curSec + k) % n;
            for (int t : types) if (secs[(size_t) i].type == t) return i;
        }
        return -1;
    };
    int target = -1;
    // your hands stopped (and no loop is playing for you): the band plays the ending
    if (! looper.playing() && followHist[0].notes == 0 && followHist[1].notes == 0 && followNow.notes == 0 && type != SecOutro)
        target = n - 1;
    // you dug in: the hook (or the drop) comes now
    else if (played > sectionE + 0.25f && (type == SecIntro || type == SecVerse || type == SecPre || type == SecBreak || type == SecBridge || type == SecBuild))
        target = findNext ({ SecHook, SecDrop });
    // you pulled back: a breakdown
    else if (played < sectionE - 0.3f && (type == SecHook || type == SecDrop))
        target = findNext ({ SecBreak, SecBridge, SecVerse });
    // a new progression: the next section starts with it
    else if (followCount >= 8)
    {
        int newChords = 0, total = 0;
        for (int i = 0; i < 4; ++i)
            for (int c = 0; c < followHist[(size_t) i].numChords; ++c)
            {
                ++total;
                bool seen = false;
                for (int j = 4; j < 8 && ! seen; ++j)
                    for (int d = 0; d < followHist[(size_t) j].numChords; ++d) if (followHist[(size_t) j].chords[(size_t) d] == followHist[(size_t) i].chords[(size_t) c]) seen = true;
                if (! seen) ++newChords;
            }
        if (total >= 2 && newChords * 10 >= total * 6 && curSec + 1 < n) target = curSec + 1;
    }
    if (target >= 0 && target != curSec)
    {
        followJump = target;
        if (curBar.moment == MomNone) curBar.moment = secs[(size_t) target].type == SecOutro ? MomStop : MomFill;   // into the change
        curBar.changeNext = true;
    }
}

void VesperProcessor::applySongBar (const SongBar& b)
{
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        auto& pc = bandCfg.part[(size_t) t];
        if (! pc.on) continue;
        if (! ((b.mask >> t) & 1u)) { pc.on = false; continue; }
        pc.density = juce::jlimit (0.0f, 1.0f, pc.density * (0.7f + 0.6f * b.energy));
        pc.complexity = juce::jlimit (0.0f, 1.0f, pc.complexity + (b.energy - 0.6f) * 0.25f);
    }
    if (b.grooveBlock > 0)
    {
        const int n = juce::jmax (1, numGrooves (bandCfg.genre));
        if (b.grooveBlock >= 100) bandCfg.groove = (bandCfg.groove + n / 2 + b.grooveBlock) % n;   // a beat switch
        else bandCfg.groove = juce::jlimit (0, n - 1, grooveRelated (bandCfg.genre, bandCfg.groove, b.grooveBlock));
    }
}

BandConfig VesperProcessor::songLineup() const
{
    BandConfig bc;
    bc.numTracks = juce::jlimit (0, (int) maxBandTracks, numTracks.load());
    for (int t = 0; t < bc.numTracks; ++t)
    {
        bc.part[(size_t) t].type = trackType (t);
        bc.part[(size_t) t].on = trackValue (t, TpOn) > 0.5f;
    }
    return bc;
}

void VesperProcessor::newSong (int number)
{
    number = juce::jlimit (1, maxSongNumber, number);
    songNumber.store (number);
    auto plan = makeSongPlan (bandGenreNow(), number, songLineup());
    {
        const juce::SpinLock::ScopedLockType sl (songLock);
        songPlan = std::move (plan);
    }
    songGenreBuilt = bandGenreNow();
    songPlanChanged.fetch_add (1);
}

void VesperProcessor::songFollowLineup()
{
    // a new genre: a new song (same number); new / changed tracks: who plays in every bar is worked out again
    const auto bc = songLineup();
    uint32_t sig = (uint32_t) bc.numTracks;
    for (int t = 0; t < bc.numTracks; ++t) sig = sig * 31u + (uint32_t) bc.part[(size_t) t].type + 1u;
    if (bandGenreNow() != songGenreBuilt) { newSong (songNumber.load()); songLineupSig = sig; return; }
    if (sig == songLineupSig) return;
    songLineupSig = sig;
    editSong ([&] (SongPlan& p)
    {
        for (size_t i = 0; i < p.sections.size(); ++i) songFillMasks (p.sections[i], p.genre, bc, (uint32_t) (p.number * 131 + (int) i * 17 + p.genre));
    });
}

SongPlan VesperProcessor::songPlanCopy() const
{
    const juce::SpinLock::ScopedLockType sl (songLock);
    return songPlan;
}

void VesperProcessor::editSong (const std::function<void (SongPlan&)>& fn)
{
    auto copy = songPlanCopy();
    fn (copy);
    {
        const juce::SpinLock::ScopedLockType sl (songLock);
        songPlan = std::move (copy);
    }
    songPlanChanged.fetch_add (1);
}

void VesperProcessor::rerollSongSection (int index)
{
    const auto bc = songLineup();
    const uint32_t seed = (uint32_t) juce::Random::getSystemRandom().nextInt (1 << 30);
    editSong ([&] (SongPlan& p) { vesper::songRerollSection (p, index, bc, seed); });
}

juce::String VesperProcessor::songStatus() const
{
    const int sec = songSecNow.load(), bar = songBarNow.load();
    const auto plan = songPlanCopy();
    if (! songOn.load() || sec < 0 || sec >= (int) plan.sections.size())
        return "SONG " + juce::String (songNumber.load()) + ":  " + juce::String (plan.totalBars()) + " bars, " + juce::String ((int) plan.sections.size()) + " sections";
    const auto& S = plan.sections[(size_t) sec];
    juce::String t = juce::String (S.label) + "   bar " + juce::String (bar + 1) + " of " + juce::String (S.bars);
    const int j = songJump.load();
    static const char* when[3] = { " (on the next bar)", " (at the end of the phrase)", " (at the end of this section)" };
    if (j >= 0 && j < (int) plan.sections.size()) t << "   next: " << plan.sections[(size_t) j].label << when[juce::jlimit (0, 2, switchAt.load())];
    else if (songLoopSection.load()) t << "   looping it";
    else if (sec + 1 < (int) plan.sections.size()) t << "   next: " << plan.sections[(size_t) (sec + 1)].label;
    else t << "   then the end";
    return t;
}


namespace
{
// BAND FEEL: every player's own push and drag, in 16ths
float feelShift (int type, int note, int64_t step)
{
    if (bandTypeIsDrums (type))
    {
        if (note == 37 || note == 38 || note == 39 || note == 40) return 0.04f;   // snare and clap a hair behind
        if (note == 42 || note == 44 || note == 46) return -0.025f;               // hats push
        return 0.0f;
    }
    switch (type)
    {
        case BBass: return 0.07f;                                                  // the bass sits back
        case BPad: case BStrings: case BKeys: return 0.03f;
        case BGuitar: return 0.02f;
        case BMelody: case BCounter: case BHorns:
        {
            uint32_t x = (uint32_t) step * 2654435761u ^ (uint32_t) note * 40503u;
            x ^= x >> 13;
            return ((float) (x % 9u) - 4.0f) * 0.01f;                              // a singer's looseness
        }
        default: return 0.0f;
    }
}
} // namespace

// which drum track plays a fill note: the piece's own track, else the whole kit, else the nearest piece
int VesperProcessor::drumTrackFor (int note) const
{
    int want = BSnare;
    if (note == 35 || note == 36) want = BKick;
    else if (note == 37 || note == 38 || note == 40) want = BSnare;
    else if (note == 39) want = BClap;
    else if (note == 42 || note == 44) want = BHats;
    else if (note == 46) want = BOpenHat;
    else if (note == 41 || note == 43 || note == 45 || note == 47 || note == 48 || note == 50) want = BTom;
    else if (note == 49 || note == 51 || note == 52 || note == 53 || note == 55 || note == 57 || note == 59) want = BCymbal;
    else want = BPerc;
    int own = -1, kit = -1, snare = -1, hats = -1, tom = -1, perc = -1;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const auto& pc = bandCfg.part[(size_t) t];
        if (! pc.on || ! bandPartHere (t) || pc.mode != ModeJam || ! bandTypeIsDrums (pc.type)) continue;
        if (pc.type == want && own < 0) own = t;
        if (pc.type == BDrums && kit < 0) kit = t;
        if ((pc.type == BSnare || pc.type == BClap) && snare < 0) snare = t;
        if (pc.type == BHats && hats < 0) hats = t;
        if (pc.type == BTom && tom < 0) tom = t;
        if (pc.type == BPerc && perc < 0) perc = t;
    }
    if (own >= 0) return own;
    if (kit >= 0) return kit;
    switch (want)
    {
        case BClap: return snare;
        case BOpenHat: case BCymbal: return hats >= 0 ? hats : snare;
        case BTom: return snare;
        case BPerc: return tom >= 0 ? tom : snare;
        default: return snare >= 0 ? snare : hats;
    }
}

namespace
{
int64_t barOfStep (int64_t step) { return step >= 0 ? step / 16 : (step - 15) / 16; }
int stepInBar (int64_t step) { return (int) (((step % 16) + 16) % 16); }
uint32_t mixSeed (uint32_t a, uint32_t b) { uint32_t x = a * 2654435761u ^ (b + 0x9e3779b9u + (a << 6) + (a >> 2)); x ^= x >> 15; x *= 2246822519u; x ^= x >> 13; return x; }
} // namespace

bool VesperProcessor::jumpAllowedAfter (int bar, int bars) const
{
    switch (switchAt.load())
    {
        case 0: return true;                                       // the next bar line
        case 2: return bar + 1 >= bars;                            // the end of the section
        default: return (bar + 1) % 4 == 0 || bar + 1 >= bars;     // the end of the phrase (4 bars)
    }
}

bool VesperProcessor::boundaryAfterBar (int64_t absBar, int mode) const
{
    if (mode == 0) return true;
    if (songActive && curBar.sec >= 0)
        return mode == 2 ? curBar.bar + 1 >= curBar.bars : ((curBar.bar + 1) % 4 == 0 || curBar.bar + 1 >= curBar.bars);
    return (absBar + 1) % 4 == 0;
}

bool VesperProcessor::songChangeComing() const
{
    if (! songActive || curBar.sec < 0) return false;
    return curBar.changeNext || (songJump.load() >= 0 && jumpAllowedAfter (curBar.bar, curBar.bars));
}

int VesperProcessor::songNextTypeNow() const
{
    if (songJump.load() >= 0 && jumpAllowedAfter (curBar.bar, curBar.bars) && songJumpType.load() >= 0) return songJumpType.load();
    return curBar.nextType;
}

// does this bar end with a fill, and how big? (0 = no; else FillSize + 1)
int VesperProcessor::fillWant (int64_t step, double stepBeat, int inBar, int& beats)
{
    (void) inBar;
    const int64_t absBar = barOfStep (step);
    int want = -1;
    int ib = 0;
    const int m = momentFor (step, stepBeat, ib);
    const bool changing = songChangeComing();
    const int next = changing ? songNextTypeNow() : -1;
    if (m == MomStop || m == MomDrop || m == MomBuild || m == MomHalf) return 0;   // that moment plays instead
    if (m == MomFill)
        want = changing ? fillSizeFor (next, curBar.type, true)
                        : ((padBar == absBar || (songActive && (curBar.bar + 1) % 4 == 0)) ? (int) FillMedium : (int) FillSmall);
    else if (changing && (songJump.load() >= 0 ? (fillIntoCalls.load() || drummerListens.load()) : drummerListens.load()))
        want = fillSizeFor (next, curBar.type, true);
    else if (drummerListens.load())
    {
        // the looper: a fill into a new section, and every other time the loop comes round
        const int wantSec = looper.wantSection.load();
        if (looper.playing() && wantSec >= 0 && wantSec != looper.section.load() && ((looper.filled.load() >> wantSec) & 1u)) want = FillMedium;
        else if (looper.playing() && looper.sec[(size_t) looper.section.load()].len >= 8.0 && (looper.cycles % 2) == 1
                 && std::abs (looper.nextWrap (stepBeat) - (stepBeat + (16 - stepInBar (step)) * stepBeats)) < 1e-3)
            want = FillSmall;
    }
    // JAM: a fill every bar - a short one most bars, a bigger one at the end of a phrase, the biggest at the end
    if (jamFrom >= 0 && absBar >= jamFrom && absBar < jamTo)
    {
        int j = (int) FillSmall;
        if (absBar == jamTo - 1) j = FillBig;
        else if ((absBar - jamFrom + 1) % 4 == 0) j = FillMedium;
        else if ((mixSeed ((uint32_t) absBar, 77u) % 100u) < 30u) j = -1;   // some bars just groove
        want = std::max (want, j);
    }
    // a solo or a jam about to start: lead into it
    if ((jamReq.load() > 0 || soloReq.load() > 0) && boundaryAfterBar (absBar, switchAt.load())) want = std::max (want, (int) FillMedium);
    if (soloFrom >= 0 && absBar == soloTo - 1) want = std::max (want, (int) FillMedium);   // out of the solo
    // TRANSITION: you said a change is coming - the biggest fill there is
    const bool transitionNow = transitionArmed && (changing || boundaryAfterBar (absBar, switchAt.load()));
    if (transitionNow) want = FillBig;
    if (want < 0) return 0;
    beats = transitionNow ? 4 : fillBeatsFor (want, mixSeed ((uint32_t) absBar, (uint32_t) want + 5u));
    return want + 1;
}

bool VesperProcessor::fillStep (int64_t step, double stepBeat, int64_t minDue)
{
    const int64_t absBar = barOfStep (step);
    const int inBar = stepInBar (step);
    if (inBar == 0) startPendingJamSolo (absBar);
    if (fillNow.bar != absBar)
    {
        int beats = 1;
        const int w = fillWant (step, stepBeat, inBar, beats);
        if (w > 0 && inBar >= 16 - 4 * beats)
        {
            // squeeze it into what's left of the bar when it was called late
            const int whole = std::min (beats, (16 - inBar + 3) / 4);
            fillNow.bar = absBar;
            fillNow.size = w - 1;
            fillNow.startStep = 16 - 4 * whole;
            vesper::FillInfo info;
            for (int attempt = 0; attempt < 6; ++attempt)
            {
                const uint32_t seed = mixSeed (++fillCounter, (uint32_t) bandCfg.genre * 977u + (uint32_t) absBar * 31u);
                fillNow.n = makeFill (bandCfg.genre, fillNow.size, whole, seed, fillNow.hits.data(), maxFillHits, info);
                const uint32_t sig = fillSignature (fillNow.hits.data(), fillNow.n);
                bool seen = false;
                for (auto r : recentFills) if (r == sig) seen = true;
                if (! seen || attempt == 5)
                {
                    for (size_t i = recentFills.size() - 1; i > 0; --i) recentFills[i] = recentFills[i - 1];
                    recentFills[0] = sig;
                    break;
                }
            }
            fillNow.crash = info.crashAfter;
            fillNow.keeps = info.grooveKeeps;
            if (transitionArmed && fillNow.size == FillBig && ! songChangeComing()) transitionArmed = false;   // done: no change to wait for
        }
    }
    if (fillNow.bar != absBar) return false;

    const float velScale = drummerListens.load() ? (0.55f + 0.45f * std::min (1.15f, lastPressVel / 105.0f)) : 1.0f;
    for (int i = 0; i < fillNow.n; ++i)
    {
        const auto& h = fillNow.hits[(size_t) i];
        const float at = (float) fillNow.startStep + h.step;
        const bool here = (at >= (float) inBar - 1e-4f && at < (float) inBar + 1.0f - 1e-4f)
                          || (inBar == fillNow.startStep && at < (float) inBar);   // a flam's grace note just before
        if (! here) continue;
        const int t = drumTrackFor (h.note);
        if (t < 0) continue;
        const auto& pc = bandCfg.part[(size_t) t];
        const double beat = stepBeat + ((double) at - (double) inBar) * stepBeats;
        int64_t due = sampleClock + (int64_t) std::llround ((beat - blockBeat) * samplesPerBeat);
        due = std::max (due, minDue);
        const int vel = juce::jlimit (1, 127, (int) std::lround ((float) h.vel * velScale * (0.55f + 0.6f * pc.level)));
        schedule (due, h.note, vel, pc.channel, bandSlot (t), (int64_t) (0.4 * stepBeats * samplesPerBeat));
        partHits[(size_t) t].fetch_add (1, std::memory_order_relaxed);
    }
    if (inBar == 15 && fillNow.crash && crashBeat < 0) crashBeat = stepBeat + stepBeats;   // land on the one with a crash
    return inBar >= fillNow.startStep && ! fillNow.keeps;
}

// a solo or a jam you called starts here when the timing allows (the next bar, a phrase or a section)
void VesperProcessor::startPendingJamSolo (int64_t absBar)
{
    const int mode = switchAt.load();
    const bool phraseStart = (songActive && curBar.sec >= 0) ? (curBar.bar % 4 == 0) : (absBar % 4 == 0);
    const bool sectionStart = (songActive && curBar.sec >= 0) ? curBar.bar == 0 : phraseStart;
    const bool ok = mode == 0 || (mode == 1 && phraseStart) || (mode == 2 && sectionStart);
    if (! ok) return;
    if (const int jb = jamReq.load(); jb > 0)
    {
        jamReq.store (0);
        jamFrom = absBar;
        jamTo = absBar + jb;
        if (crashBeat < 0) crashBeat = bandOrigin + (double) absBar * 16.0 * stepBeats;
    }
    if (const int sb = soloReq.load(); sb > 0)
    {
        soloReq.store (0);
        soloTrack = soloReqTrack.load() >= 0 ? soloReqTrack.load() : pickSoloist();
        if (soloTrack >= 0)
        {
            soloFrom = absBar;
            soloTo = absBar + sb;
        }
    }
    if (jamFrom >= 0 && absBar >= jamTo) jamFrom = jamTo = -1;
    if (soloFrom >= 0 && absBar >= soloTo) { soloFrom = soloTo = -1; soloTrack = -1; }
    jamShown.store (jamFrom >= 0 ? (int) (jamTo - absBar) : 0);
    soloShown.store (soloFrom >= 0 ? soloTrack : -1);
}

int VesperProcessor::pickSoloist() const
{
    // the lead first: a melody, then horns, guitar, keys, arp, strings, the counter-melody
    static const int order[] = { BMelody, BHorns, BGuitar, BKeys, BArp, BStrings, BCounter, BPad };
    const int pick = soloPick.load();
    if (pick >= 0 && pick < numTracks.load() && trackValue (pick, TpOn) > 0.5f) return pick;
    for (int ty : order)
        for (int t = 0; t < numTracks.load(); ++t)
            if (trackValue (t, TpOn) > 0.5f && trackType (t) == ty) return t;
    return -1;
}

// JAM: everyone digs in. SOLO: one player takes it, the other leads lay out and the bed thins under them.
void VesperProcessor::applyJamSolo()
{
    const int64_t absBar = bandRunning ? barOfStep (bandNextStep) : -1;
    const bool jam = jamFrom >= 0 && absBar >= jamFrom && absBar < jamTo;
    const bool solo = soloFrom >= 0 && soloTrack >= 0 && absBar >= soloFrom && absBar < soloTo;
    if (! jam && ! solo) return;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        auto& pc = bandCfg.part[(size_t) t];
        if (! pc.on || pc.mode != ModeJam) continue;
        if (jam)
        {
            pc.density = juce::jlimit (0.0f, 1.0f, pc.density * 1.3f + 0.2f);
            pc.complexity = juce::jlimit (0.0f, 1.0f, pc.complexity + 0.3f);
        }
        if (solo)
        {
            const bool lead = pc.type == BMelody || pc.type == BCounter || pc.type == BHorns || pc.type == BArp;
            if (t == soloTrack)
            {
                pc.density = 1.0f;
                pc.complexity = 1.0f;
                pc.level = juce::jmin (1.0f, pc.level + 0.12f);
            }
            else if (lead) pc.on = false;
            else if (! bandTypeIsDrums (pc.type) && pc.type != BBass) pc.density *= 0.6f;
        }
    }
}

// SONG moments: the song's own (this bar) or a pad you hit; where in the bar this step is
int VesperProcessor::momentFor (int64_t step, double stepBeat, int& inBar) const
{
    inBar = (int) (((step % 16) + 16) % 16);
    if (padBar >= 0 && (step >= 0 ? step / 16 : (step - 15) / 16) == padBar) return padMoment;
    if (! songActive || curBar.sec < 0) return MomNone;
    const SongBar& b = stepBeat >= curBar.start - 1e-6 ? curBar : prevBar;
    if (b.sec < 0 || b.start < 0) return MomNone;
    inBar = juce::jlimit (0, 15, (int) std::floor ((stepBeat - b.start) / stepBeats + 1e-6));
    return b.moment;
}

void VesperProcessor::drumTargets (int& kit, int& kick, int& snare, int& hats, int& cym) const
{
    kit = kick = snare = hats = cym = -1;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const auto& pc = bandCfg.part[(size_t) t];
        if (! pc.on || ! bandPartHere (t) || pc.mode != ModeJam) continue;
        if (pc.type == BDrums && kit < 0) kit = t;
        if (pc.type == BKick && kick < 0) kick = t;
        if ((pc.type == BSnare || pc.type == BClap) && snare < 0) snare = t;
        if (pc.type == BHats && hats < 0) hats = t;
        if (pc.type == BCymbal && cym < 0) cym = t;
    }
    if (kick < 0) kick = kit;
    if (snare < 0) snare = kit;
    if (hats < 0) hats = kit;
    if (cym < 0) cym = kit >= 0 ? kit : hats;
}

void VesperProcessor::songMomentStep (int64_t step, double stepBeat, int64_t minDue)
{
    // a pad you hit: FILL / STOP / BUILD land at the end of this bar (if there's time), the rest on the next one
    if (const int tap = momentTap.exchange (0); tap > 0 && tap < numSongMoments)
    {
        const int64_t bar = step >= 0 ? step / 16 : (step - 15) / 16;
        const int in = (int) (((step % 16) + 16) % 16);
        padMoment = tap;
        padBar = (songMomentAtEnd (tap) && in < 11) ? bar : bar + 1;
    }
    int inBar = 0;
    const int m = momentFor (step, stepBeat, inBar);
    if (inBar == 0) momentShown.store (m);
    int kit, kick, snare, hats, cym;
    drumTargets (kit, kick, snare, hats, cym);
    auto hit = [&] (int t, int note, int vel, double beat)
    {
        if (t < 0) return;
        const auto& pc = bandCfg.part[(size_t) t];
        int64_t due = sampleClock + (int64_t) std::llround ((beat - blockBeat) * samplesPerBeat);
        due = std::max (due, minDue);
        schedule (due, note, juce::jlimit (1, 127, vel), pc.channel, bandSlot (t), (int64_t) (0.4 * stepBeats * samplesPerBeat));
    };
    // the crash on a change (a new section, the end of a build, a looper switch)
    if (crashBeat >= 0 && crashBeat >= stepBeat - 1e-6 && crashBeat < stepBeat + stepBeats - 1e-6)
    {
        hit (cym, Band::Crash, 110, crashBeat);
        crashBeat = -1;
    }
    switch (m)
    {
        case MomCrash:
            if (inBar == 0) hit (cym, Band::Crash, 112, stepBeat);
            break;
        case MomFill:   // played by the fill player (fillStep): a different fill every time, sized for what comes next
            break;
        case MomBuild:   // a snare roll that speeds up and gets louder, then a crash on the one
        {
            const int vel = 42 + inBar * 5;
            if (inBar < 8) { if (inBar % 2 == 0) hit (snare, Band::Snare, vel, stepBeat); }
            else
            {
                hit (snare, Band::Snare, vel, stepBeat);
                if (inBar >= 12) hit (snare, Band::Snare, vel + 3, stepBeat + 0.5 * stepBeats);
            }
            if (inBar == 15) crashBeat = stepBeat + stepBeats;
            break;
        }
        case MomHalf:    // half time: kick on 1, snare on 3, quarter-note hats
            if (inBar == 0 || inBar == 10) hit (kick, Band::Kick, inBar == 0 ? 110 : 92, stepBeat);
            if (inBar == 8) hit (snare, Band::Snare, 108, stepBeat);
            if (inBar % 4 == 0) hit (hats, Band::ClosedHat, inBar == 0 ? 80 : 66, stepBeat);
            break;
        case MomStop:    // everything stops on beat 4; back in with a crash
            if (inBar == 15) crashBeat = stepBeat + stepBeats;
            break;
        case MomDrop:    // the beat drops out for the bar; back in with a crash
            if (inBar == 15) crashBeat = stepBeat + stepBeats;
            break;
        default: break;
    }
}

void VesperProcessor::updateKeysSkip()
{
    keysSkip = 0;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const auto& d = bandCfg.part[(size_t) t];
        if (d.on && bandTypeIsDrums (d.type) && bandPartHere (t) && d.channel != chordChannel)
            keysSkip = (uint16_t) (keysSkip | (1u << (d.channel - 1)));   // the keys sound doesn't play drum notes
    }
}

bool VesperProcessor::bandPartHere (int track) const
{
    if (bandRoleNow == 0) return ! LinkBus::get().isClaimed (track, linkNowMs);
    return bandRoleNow - 1 == track;
}

bool VesperProcessor::anyBandPartOn() const
{
    // the band clock is only needed for tracks that play their style (HOLD / RING follow your hands)
    for (int t = 0; t < bandCfg.numTracks; ++t)
        if (bandCfg.part[(size_t) t].on && bandCfg.part[(size_t) t].mode == ModeJam) return true;
    return false;
}

bool VesperProcessor::anyChordHeld() const
{
    for (int i = 0; i < numChordSlots; ++i)
        if (slots[(size_t) i].active && ! slots[(size_t) i].isExt) return true;
    return false;
}

double VesperProcessor::lateWindowBeats() const
{
    // a chord that lands just after a band step still makes that step (players are rarely dead on the grid)
    return juce::jmin (0.45 * stepBeats, 0.08 * bpm / 60.0);
}

void VesperProcessor::activateBandSlots()
{
    for (int t = 0; t < maxBandTracks; ++t)
    {
        auto& s = slots[(size_t) bandSlot (t)];
        s = Slot();
        s.active = true;
        s.source = -100 - t;
    }
}

void VesperProcessor::bandChordChanged (const Chord& chord, int pos, juce::MidiBuffer& out, int key)
{
    if (bandRoleNow != 0 || ! chord.valid()) return;
    bandHarm.chord = chord;
    bandHarm.key = key;
    bandHarm.keyRoot = cfg.keyRoot;
    bandHarm.scale = cfg.scale;
    bandHarm.id = ++bandHarmCounter;
    bandHarmBeat = beatAt (pos);
    bandStopAt = -1;
    if (! bandRunning)
    {
        if (bandEnabled && anyBandPartOn()) startBand (pos, out);
        return;
    }
    adoptHarmony (pos, out);
}

void VesperProcessor::startBand (int pos, juce::MidiBuffer& out)
{
    for (int t = 0; t < maxBandTracks; ++t) clearSlotNotes (bandSlot (t), pos, out);
    band.reset();
    activateBandSlots();
    bandRunning = true;
    ++bandStarts;
    bandStopAt = -1;
    bandSynced = hostPlaying;
    const double now = beatAt (pos);
    if (bandSynced)
    {
        bandOrigin = 0;
        auto k = (int64_t) std::floor (now / stepBeats + 1e-9);
        if (now - (double) k * stepBeats > lateWindowBeats()) ++k;
        bandNextStep = k;
    }
    else
    {
        bandOrigin = now;     // FL stopped: your first chord is bar 1
        bandNextStep = 0;
    }
    bandLastStep = -1;
    bandLastStepBeat = -1e9;
    advanceBand (pos, out, true);
}

void VesperProcessor::stopBand (int pos, juce::MidiBuffer& out)
{
    for (int t = 0; t < maxBandTracks; ++t)
    {
        const int si = bandSlot (t);
        if (slots[(size_t) si].active) releaseSlot (si, pos, out);
    }
    if (bandRunning)
        for (int t = 0; t < bandCfg.numTracks; ++t)
        {
            const auto& tc = bandCfg.part[(size_t) t];
            if (tc.on && tc.mode == ModeJam && (tc.type == BStrings || tc.type == BHorns || tc.type == BPad))
                out.addEvent (juce::MidiMessage::controllerEvent (tc.channel, 11, 127), pos);   // swells back to full
        }
    bandRunning = false;
    bandStopAt = -1;
    bandLastStep = -1;
    bandLastStepBeat = -1e9;
}

void VesperProcessor::adoptHarmony (int pos, juce::MidiBuffer& out)
{
    // the old chord's notes stop where the new chord starts
    for (int t = 0; t < maxBandTracks; ++t)
        if (! bandTypeIsDrums (bandCfg.part[(size_t) t].type)) clearSlotNotes (bandSlot (t), pos, out);

    // landed just after a step: play that step again with the new chord instead of waiting for the next one
    if (bandLastStep >= 0 && bandHarmBeat < bandLastStepBeat + lateWindowBeats())
        fireBandStep (bandLastStep, bandLastStepBeat, true, sampleClock + pos, out);
}

void VesperProcessor::fireBandStep (int64_t step, double stepBeat, bool pitchedOnly, int64_t minDue, juce::MidiBuffer& out)
{
    // "drums out" / "drums in": on the bar line itself, so the one is already without them (or with them again)
    if (! pitchedOnly && stepInBar (step) == 0)
        if (const int req = liveOutReq.load(); req != liveOutNow.load())
        {
            liveOutNow.store (req);
            readBand();
        }
    BandEvent ev[Band::maxEventsPerStep];
    const int n = band.step (bandCfg, bandHarm, step, ev, Band::maxEventsPerStep);
    int inBarNow = 0;
    const int momentNow = pitchedOnly ? (int) MomNone : momentFor (step, stepBeat, inBarNow);
    const bool fillHasDrums = ! pitchedOnly && fillStep (step, stepBeat, minDue);
    const int inBarStep = (int) (((step % 16) + 16) % 16);
    // CALL & RESPONSE settings for this step (a track answering itself, or an answering track that's off, doesn't count)
    std::array<int, maxBandTracks> respondNow {};
    bool respondAny = false;
    for (int r = 0; r < bandCfg.numTracks; ++r)
    {
        const int v = trackRespond[(size_t) r].load (std::memory_order_relaxed);
        const int caller = respondCaller (v);
        if (v == 0 || caller < 0 || caller == r || caller >= bandCfg.numTracks) continue;
        if (! bandCfg.part[(size_t) r].on || bandCfg.part[(size_t) r].mode != ModeJam || bandTypeIsDrums (bandCfg.part[(size_t) r].type)) continue;
        respondNow[(size_t) r] = v;
        respondAny = true;
    }
    grooveNowPlaying.store (band.grooveNow);
    for (int t = 0; t < maxBandTracks; ++t) trackClipNow[(size_t) t].store (band.clipNow[(size_t) t], std::memory_order_relaxed);
    for (int t = 0; t < maxBandTracks; ++t) trackPhraseNow[(size_t) t].store (band.phraseNow[(size_t) t], std::memory_order_relaxed);
    uint32_t hit = 0;
    for (int i = 0; i < n; ++i)
    {
        const BandEvent& e = ev[i];
        if (e.part < 0 || e.part >= maxBandTracks) continue;
        const auto& tc = bandCfg.part[(size_t) e.part];
        if (pitchedOnly && (bandTypeIsDrums (tc.type) || e.isCC)) continue;
        if (! bandPartHere (e.part)) continue;
        if (bandHarm.sitsOut (tc)) continue;   // the track's key strip skips the key you're holding
        // a fill has the kit: the groove steps aside (the kick keeps the quarter notes, and a piece you locked on your
        // drum MIDI keeps playing - the snare you locked never moves)
        if (fillHasDrums && bandTypeIsDrums (tc.type) && ! (e.note == Band::Kick && inBarStep % 4 == 0)
            && ! ((tc.reworkLock >> drumPieceOf (e.note)) & 1u)) continue;
        // CALL & RESPONSE: the caller rests while it's answered (and its call is kept for an echo); an answering track only
        // plays in the answer bars (and not at all when it echoes)
        if (! e.isCC && respondAny)
        {
            bool skip = false;
            for (int r = 0; r < bandCfg.numTracks && ! skip; ++r)
            {
                const int v = respondNow[(size_t) r];
                if (v == 0) continue;
                const int caller = respondCaller (v), bars = respondBars (v);
                const int64_t absBar = step >= 0 ? step / 16 : (step - 15) / 16;
                const int64_t unit = absBar >= 0 ? absBar / bars : (absBar - bars + 1) / bars;
                const bool answerTime = (unit & 1) != 0;
                if (e.part == caller)
                {
                    if (answerTime) skip = true;
                    else if (callCount[(size_t) r] < 128)
                    {
                        if (callUnit[(size_t) r] != unit) { callUnit[(size_t) r] = unit; callCount[(size_t) r] = 0; }
                        auto& cn = callBuf[(size_t) r][(size_t) callCount[(size_t) r]++];
                        cn.at = (float) ((absBar - unit * bars) * 16 + inBarStep) + e.offset;
                        cn.note = e.note;
                        cn.vel = e.velocity;
                        cn.len = e.length;
                    }
                }
                if (e.part == r && (respondMode (v) == 0 || ! answerTime)) skip = true;
            }
            if (skip) continue;
        }
        if (momentNow != MomNone)
        {
            const bool drum = bandTypeIsDrums (tc.type);
            if (momentNow == MomStop && inBarNow >= 12) continue;                       // the band stops on beat 4
            if (drum && (momentNow == MomDrop || momentNow == MomHalf)) continue;       // the beat drops out / half time
            if (drum && momentNow == MomBuild && ! (e.note == Band::ClosedHat || e.note == Band::PedalHat || e.note == Band::OpenHat)) continue;
        }
        // BAND FEEL: each player's own push and drag; the LISTENING DRUMMER plays as hard as you do
        const float shift = (bandFeel.load() && ! e.isCC) ? feelShift (tc.type, e.note, step) : 0.0f;
        int vel = e.velocity;
        if (! e.isCC && bandTypeIsDrums (tc.type) && drummerListens.load())
            vel = juce::jlimit (1, 127, (int) std::lround ((float) vel * (0.55f + 0.45f * std::min (1.15f, lastPressVel / 105.0f))));
        const double t = stepBeat + (e.offset + shift) * stepBeats;
        int64_t due = sampleClock + (int64_t) std::llround ((t - blockBeat) * samplesPerBeat);
        due = std::max (due, minDue);
        if (e.isCC)
        {
            const int pos = (int) juce::jlimit<int64_t> (0, juce::jmax (0, blockSamples - 1), due - sampleClock);
            out.addEvent (juce::MidiMessage::controllerEvent (e.channel, e.note, e.velocity), pos);
            continue;
        }
        const int64_t len = e.length < 0.0f ? -1 : std::max<int64_t> (1, (int64_t) std::llround (e.length * stepBeats * samplesPerBeat));
        schedule (due, e.note, vel, e.channel, bandSlot (e.part), len);
        hit |= 1u << e.part;
    }
    // CALL & RESPONSE: the echo - the call played back by the answering track, in its own register
    if (! pitchedOnly && respondAny)
        for (int r = 0; r < bandCfg.numTracks; ++r)
        {
            const int v = respondNow[(size_t) r];
            if (v == 0 || respondMode (v) != 0) continue;
            const int caller = respondCaller (v), bars = respondBars (v);
            if (caller < 0 || caller >= bandCfg.numTracks) continue;
            const auto& rc = bandCfg.part[(size_t) r];
            const auto& cc = bandCfg.part[(size_t) caller];
            if (! rc.on || ! cc.on || ! bandPartHere (r)) continue;
            const int64_t absBar = step >= 0 ? step / 16 : (step - 15) / 16;
            const int64_t unit = absBar >= 0 ? absBar / bars : (absBar - bars + 1) / bars;
            if ((unit & 1) == 0 || callUnit[(size_t) r] != unit - 1) continue;   // answer bars, right after their call
            const float here = (float) ((absBar - unit * bars) * 16 + inBarStep);
            for (int i = 0; i < callCount[(size_t) r]; ++i)
            {
                const auto& cn = callBuf[(size_t) r][(size_t) i];
                if (cn.at < here - 1e-4f || cn.at >= here + 1.0f - 1e-4f) continue;
                int note = cn.note + 12 * (rc.octave - cc.octave);
                if (rc.type == BBass) while (note > 55) note -= 12;
                while (note > 108) note -= 12;
                while (note < 24) note += 12;
                const double t = stepBeat + (double) (cn.at - here) * stepBeats;
                int64_t due = sampleClock + (int64_t) std::llround ((t - blockBeat) * samplesPerBeat);
                due = std::max (due, minDue);
                const int vel = juce::jlimit (1, 127, juce::roundToInt ((float) cn.vel * (0.6f + 0.5f * rc.level)));
                const int64_t len = cn.len < 0.0f ? (int64_t) (2.0 * stepBeats * samplesPerBeat)
                                                  : std::max<int64_t> (1, (int64_t) std::llround (cn.len * stepBeats * samplesPerBeat));
                schedule (due, note, vel, rc.channel, bandSlot (r), len);
                hit |= 1u << r;
            }
        }
    if (! pitchedOnly) songMomentStep (step, stepBeat, minDue);
    for (int t = 0; t < maxBandTracks; ++t)
        if ((hit >> t) & 1u) partHits[(size_t) t].fetch_add (1, std::memory_order_relaxed);
}

void VesperProcessor::advanceBand (int upToPos, juce::MidiBuffer& out, bool inclusive)
{
    if (! bandRunning) return;
    const double limit = beatAt (upToPos) + (inclusive ? 1e-6 : 0.0);
    const int64_t minDue = sampleClock + (inclusive ? upToPos : 0);
    for (int guard = 0; guard < 64; ++guard)
    {
        const double stepBeat = bandOrigin + (double) bandNextStep * stepBeats;
        if (stepBeat >= limit) break;
        if (bandStopAt >= 0 && stepBeat >= bandStopAt - 1e-9)
        {
            stopBand (posOfBeat (stepBeat), out);
            return;
        }
        fireBandStep (bandNextStep, stepBeat, false, minDue, out);
        bandLastStep = bandNextStep;
        bandLastStepBeat = stepBeat;
        ++bandNextStep;
    }
}

void VesperProcessor::checkBandClock (int pos, juce::MidiBuffer& out)
{
    if (! bandSynced) return;
    const double now = beatAt (pos);
    const double next = bandOrigin + (double) bandNextStep * stepBeats;
    if (next < now - 0.5 || next > now + 1.0)
    {
        // FL looped or jumped: pick the band up at the new spot
        for (int t = 0; t < maxBandTracks; ++t) clearSlotNotes (bandSlot (t), pos, out);
        bandNextStep = (int64_t) std::ceil ((now - bandOrigin) / stepBeats - 1e-9);
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
    }
}

void VesperProcessor::bandHousekeeping (int pos, juce::MidiBuffer& out)
{
    // RING tracks that were switched off (or out of RING) let go
    for (int t = 0; t < maxBandTracks; ++t)
    {
        if (! ((ringMask >> t) & 1u)) continue;
        const auto& tc = bandCfg.part[(size_t) t];
        if (! bandEnabled || ! tc.on || tc.mode != ModeRing)
        {
            clearSlotNotes (ringSlot (t), pos, out);
            ringMask &= ~(1u << t);
        }
    }

    if (! bandRunning)
    {
        // a part switched on while a chord is down: start right away
        if (bandEnabled && anyBandPartOn() && anyChordHeld() && bandHarm.valid()) startBand (pos, out);
        return;
    }
    if (! bandEnabled || ! anyBandPartOn())
    {
        stopBand (pos, out);
        return;
    }

    if (bandSynced != hostPlaying)
    {
        if (! hostPlaying && bandStopMode == 2)
        {
            stopBand (pos, out);   // NEVER mode stops with FL
            return;
        }
        bandSynced = hostPlaying;
        const double now = beatAt (pos);
        if (bandSynced) { bandOrigin = 0; bandNextStep = (int64_t) std::ceil (now / stepBeats - 1e-9); }
        else            { bandOrigin = now; bandNextStep = 0; }
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
    }
    else checkBandClock (pos, out);

    // tracks switched off, out of JAM, or taken over by a band copy go quiet
    for (int t = 0; t < maxBandTracks; ++t)
    {
        const auto& tc = bandCfg.part[(size_t) t];
        if (! (tc.on && tc.mode == ModeJam && bandPartHere (t)))
        {
            const auto& s = slots[(size_t) bandSlot (t)];
            if (! s.sent.empty()) clearSlotNotes (bandSlot (t), pos, out);
        }
    }

    if (anyChordHeld()) { bandStopAt = -1; return; }
    if (bandStopAt >= 0 || bandStopMode == 2) return;
    const double now = beatAt (pos);
    if (bandStopMode == 0)
        bandStopAt = now + 0.15 * bpm / 60.0;   // a short grace, so moving between chords doesn't stop the band
    else
    {
        const double bars = std::ceil ((now - bandOrigin) / 4.0 - 1e-9);
        bandStopAt = bandOrigin + bars * 4.0;
        if (bandStopAt < now + 0.01) bandStopAt = now + 0.15 * bpm / 60.0;
    }
}

//==============================================================================
// link between VESPER copies
void VesperProcessor::publishLink()
{
    LinkSnapshot s;
    s.leaderId = linkId;
    s.wallMs = linkNowMs;
    s.cfg = bandCfg;
    s.harm = bandHarm;
    s.harmBeat = bandHarmBeat;
    s.running = bandRunning;
    s.starts = bandStarts;
    s.synced = bandSynced;
    s.origin = bandOrigin;
    s.clock = sampleClock;
    s.beat = blockBeat;
    s.spb = samplesPerBeat;
    LinkBus::get().publish (s);
}

void VesperProcessor::followLeader (juce::MidiBuffer& out)
{
    const int part = juce::jlimit (0, maxBandTracks - 1, bandRoleNow - 1);
    LinkSnapshot L;
    auto& bus = LinkBus::get();
    if (! bus.read (L) || linkNowMs - L.wallMs > 1000.0 || L.leaderId == linkId)
    {
        followState.store (2);
        if (bandRunning) stopBand (0, out);
        return;
    }
    followState.store (1);
    bus.claim (part, linkNowMs + 600.0);
    bandCfg = L.cfg;
    updateKeysSkip();

    // where the leader's band clock is right now, in our own clock
    const double obs = (double) (L.clock - sampleClock);
    if (L.leaderId != linkLeaderSeen)
    {
        linkLeaderSeen = L.leaderId;
        linkDeltaBest = obs;
        linkStarts = 0;
        linkHarmId = -1;
    }
    linkDeltaBest = std::max (linkDeltaBest, obs);   // same audio cycle = the largest difference we see
    const double offset = (L.synced && hostPlaying) ? 0.0
                        : (L.beat + ((double) sampleClock + linkDeltaBest - (double) L.clock) / L.spb) - blockBeat;

    const bool wanted = L.running && L.cfg.part[(size_t) part].on && L.cfg.part[(size_t) part].mode == ModeJam;
    if (! wanted)
    {
        if (bandRunning) stopBand (0, out);
        linkStarts = L.starts;
        linkHarmId = L.harm.id;
        return;
    }

    const double now = blockBeat;
    auto anchor = [&]
    {
        bandSynced = L.synced;
        bandOrigin = L.origin - offset;
        auto k = (int64_t) std::floor ((now - bandOrigin) / stepBeats + 1e-9);
        if (now - (bandOrigin + (double) k * stepBeats) > lateWindowBeats()) ++k;
        bandNextStep = bandSynced ? k : std::max<int64_t> (0, k);
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
        linkOriginSeen = L.origin;
        linkSyncedSeen = L.synced;
    };

    if (! bandRunning || L.starts != linkStarts)
    {
        if (bandRunning) stopBand (0, out);
        band.reset();
        activateBandSlots();
        bandRunning = true;
        linkStarts = L.starts;
        bandHarm = L.harm;
        linkHarmId = L.harm.id;
        bandHarmBeat = L.harmBeat - offset;
        anchor();
        advanceBand (0, out, true);   // the leader's first step, if we're a moment behind it
        return;
    }

    if (L.synced != linkSyncedSeen || std::abs (L.origin - linkOriginSeen) > 1e-9)
        anchor();                         // FL started or stopped
    else
        checkBandClock (0, out);

    if (L.harm.id != linkHarmId)
    {
        linkHarmId = L.harm.id;
        bandHarm = L.harm;
        bandHarmBeat = L.harmBeat - offset;
        adoptHarmony (0, out);
    }
}

//==============================================================================
// HOLD and RING tracks: they play what you press (not a style), each on its own channel
void VesperProcessor::playLayers (int source, const Chord& chord, const Notes& pressed, int velocity, int pos, juce::MidiBuffer& out,
                                  uint16_t styled)
{
    if (bandRoleNow != 0) return;   // the main VESPER plays HOLD / RING tracks
    const int keyPc = (source >= 0 && source < 128) ? source % 12 : -1;
    int layer = -1;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const auto& tc = bandCfg.part[(size_t) t];
        if ((ringMask >> t) & 1u)
        {
            // RING: the last note lets go now that you've pressed another key
            clearSlotNotes (ringSlot (t), pos, out);
            ringMask &= ~(1u << t);
        }
        if (! bandEnabled || ! tc.on || tc.mode == ModeJam || ! bandTypeCanHold (tc.type)) continue;
        if (keyPc >= 0 && ((tc.keyMask >> keyPc) & 1)) continue;   // key strip: this track sits this key out
        if ((styled >> t) & 1u)   // it plays the chord as styled (strike() sends its notes)
        {
            partHits[(size_t) t].fetch_add (1, std::memory_order_relaxed);
            continue;
        }
        const Notes notes = bandHoldNotes (tc, pressed, chord);
        if (notes.empty()) continue;
        const int vel = juce::jlimit (1, 127, juce::roundToInt ((float) velocity * (0.45f + 0.75f * tc.level)));
        int slot;
        if (tc.mode == ModeHold)
        {
            // a second slot for the same key: it lets go when the key does (or when HOLD lets the chord go)
            if (layer < 0) layer = allocSlot (source, pos, out);
            slot = layer;
        }
        else
        {
            slot = ringSlot (t);
            auto& rs = slots[(size_t) slot];
            rs = Slot();
            rs.active = true;
            rs.source = -200 - t;
            ringMask |= 1u << t;
        }
        for (int i = 0; i < notes.size(); ++i) schedule (sampleClock + pos, notes[i], vel, tc.channel, slot, -1);
        partHits[(size_t) t].fetch_add (1, std::memory_order_relaxed);
    }
}

void VesperProcessor::clearRings (int pos, juce::MidiBuffer& out)
{
    for (int t = 0; t < maxBandTracks; ++t)
    {
        clearSlotNotes (ringSlot (t), pos, out);
        slots[(size_t) ringSlot (t)].active = false;
    }
    ringMask = 0;
}
