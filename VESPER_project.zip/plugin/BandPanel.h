#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "Widgets.h"

#include <array>
#include <functional>

// One octave of the keys on your controller (C..B, any octave). Lit keys play; click one to make
// this track (or the chords) sit out whenever you press that key.
class KeyStrip : public juce::Component, public juce::SettableTooltipClient
{
public:
    KeyStrip (EditorContext& c, std::atomic<int>& m) : ctx (c), mask (m) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override { dragTo = -1; }

private:
    int keyAt (juce::Point<float>) const;
    juce::Rectangle<float> keyRect (int pc) const;
    EditorContext& ctx;
    std::atomic<int>& mask;
    int dragTo = -1, lastKey = -1;
};

// A small square button with a drawn icon (drawn, not a font symbol, so it looks the same everywhere)
struct IconButton : public juce::Button
{
    enum Kind { DownArrow = 0, Cross, Left, Right };
    IconButton (EditorContext& c, Kind k) : juce::Button ({}), ctx (c), kind (k) {}
    void paintButton (juce::Graphics&, bool over, bool down) override;
    EditorContext& ctx;
    Kind kind;
};

// The BAND tab: up to 15 tracks that play along with your chords, each on its own MIDI channel.
// a bit of clickable text (NOW 123 - KEEP over the GROOVE box)
struct ClickText : public juce::Component, public juce::SettableTooltipClient
{
    juce::String text;
    juce::Colour colour;
    std::function<void()> onClick;
    void paint (juce::Graphics& g) override
    {
        g.setColour (colour);
        g.setFont (juce::Font (juce::FontOptions (10.5f, juce::Font::bold)));
        g.drawText (text, getLocalBounds(), juce::Justification::centredRight);
    }
    void mouseUp (const juce::MouseEvent& e) override { if (onClick && getLocalBounds().contains (e.getPosition())) onClick(); }
};

class BandPanel : public juce::Component, private juce::Timer
{
public:
    explicit BandPanel (EditorContext& c);
    ~BandPanel() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct PartDrag : public juce::Component, public juce::SettableTooltipClient
    {
        PartDrag (EditorContext& c, int t) : ctx (c), track (t) {}
        void paint (juce::Graphics&) override;
        void mouseDrag (const juce::MouseEvent&) override;
        void mouseUp (const juce::MouseEvent&) override;
        juce::File exportPart();
        EditorContext& ctx;
        int track;
        bool started = false;
    };

    // one track's controls
    struct Strip : public juce::Component, public juce::FileDragAndDropTarget
    {
        Strip (BandPanel& owner, int track);
        bool isInterestedInFileDrag (const juce::StringArray&) override;
        void filesDropped (const juce::StringArray&, int, int) override;
        void fileDragEnter (const juce::StringArray&, int, int) override { dropHover = true; repaint(); }
        void fileDragExit (const juce::StringArray&) override { dropHover = false; repaint(); }
        void showMidiMenu();
        juce::TextButton midiBtn { "MIDI" };
        juce::TextButton soundBtn;          // SOUND: an instrument played right inside VESPER
        uint32_t lastRack = 0xffffffffu, lastNames = 0xffffffffu;
        void askName();
        bool dropHover = false;
        int lastMidiCount = -1;
        juce::String lastMidiName;
        void paint (juce::Graphics&) override;
        void resized() override;
        void sync();              // follow the parameters (style, mode, what's enabled)
        void showTypeMenu();

        BandPanel& panel;
        EditorContext& ctx;
        const int track;
        int type = 0;
        juce::TextButton on, dice { "DICE" };
        IconButton typeBtn, remove;
        juce::TextButton modeBtns[vesper::numBandModes];
        juce::ComboBox style, channel, octave, dyn;
        juce::Slider density, complexity, level;
        juce::Slider reworkKnob;          // REWORK: in COMPLEX's place on a drum track playing your MIDI
        bool drumMidi = false;
        PartDrag drag;
        KeyStrip keys;
        uint32_t lastHits = 0, lastSeed = 0;
        float glow = 0.0f;
        int lastMode = -1, lastStyle = -1;
        bool lastOn = false;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtt;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAtt;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
    };

    // A-D on the LOOP / SONG row: click = play that section (or record it if it's empty), right-click = its key
    struct SectionButton : public juce::Button
    {
        SectionButton (EditorContext& c, int i) : juce::Button ({}), ctx (c), index (i) {}
        void paintButton (juce::Graphics&, bool over, bool down) override;
        void mouseDown (const juce::MouseEvent& e) override { right = e.mods.isPopupMenu(); juce::Button::mouseDown (e); }
        void clicked() override { if (onPress) onPress (right); }
        std::function<void (bool right)> onPress;
        EditorContext& ctx;
        const int index;
        bool right = false;
    };

    struct TrackList : public juce::Component
    {
        void paint (juce::Graphics&) override {}
    };

    void timerCallback() override;
    void rebuildStrips();
    bool anyPartOn() const;
    static juce::Rectangle<int> stripBounds (int track);

    EditorContext& ctx;
    juce::Viewport viewport;
    TrackList list;
    std::vector<std::unique_ptr<Strip>> strips;
    KeyStrip chordKeys;
    juce::TextButton bandOnBtn { "BAND ON" }, diceAllBtn { "DICE ALL" }, stopBtn { "STOP" };
    juce::TextButton allHoldBtn { "ALL HOLD" }, addBtn { "+ TRACK" }, copyBtn { "COPY" };
    juce::TextButton grooveDice { "DICE" };
    IconButton groovePrev, grooveNext;
    juce::ComboBox genreBox, grooveBox, phraseBox, stopModeBox, chordChBox;
    juce::Slider swingKnob, feelKnob, varyKnob;
    juce::ComboBox changeBox;
    ClickText keepTag;
    // the LOOP / SONG row
    juce::TextButton recLoopBtn { "REC LOOP" }, loopBtn { "PLAY LOOP" }, songBtn { "MAKE IT A SONG" };
    juce::TextButton listenBtn { "DRUMMER LISTENS" }, feelBtn { "BAND FEEL" };
    juce::ComboBox loopBarsBox;
    std::array<std::unique_ptr<SectionButton>, 4> sectionBtns;
    juce::String loopStatus;
    uint32_t lastLoopLook = 0;
    void sectionMenu (int s);
    void syncLoopRow();
    int lastNowShown = -2;
    int lastGenre = -1, lastFollow = -1, lastTracks = -1, lastGrooveGenre = -1, lastGroove = -1, lastRole = -1;
    uint32_t lastMyGrooves = 0xffffffffu;
    void syncGrooveBox();
    void fillGrooves();
    std::unique_ptr<juce::FileChooser> chooser;
    int role() const;
    void showCopyMenu();
    uint32_t lastChanged = 0;
    bool lastPlaying = false, lastAnyOn = false;

    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
};
