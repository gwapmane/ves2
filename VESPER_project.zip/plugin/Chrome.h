#pragma once
// TROUPE hardware look: the chrome unibody the face sits in, the chrome knobs, and the emblem.
// The light comes from above, a little to the left, like a unit on a desk under a lamp.
#include <juce_gui_basics/juce_gui_basics.h>

struct Theme;

namespace troupe
{
// polished chrome over r: bright sky on top, the dark horizon line just under the middle, the desk's glow below
juce::ColourGradient chromeGradient (juce::Rectangle<float> r);

// the shadow the unit throws on the desk (drawn under it)
void drawUnibodyShadow (juce::Graphics&, juce::Rectangle<float> body, float radius);
// the unibody: rounded chrome with the face's opening cut into it. Drawn OVER the face, so the face's corners round off
// and its edge drops into the cut
void drawUnibody (juce::Graphics&, juce::Rectangle<float> body, juce::Rectangle<float> face, float bodyRadius, float faceRadius);
// writing cut into the chrome (the model plate on the bottom edge)
void drawEngraved (juce::Graphics&, const juce::String&, juce::Rectangle<float>, float size, juce::Justification);

// chrome accents on the face: a thin polished rim (bright on top, dark underneath), and a polished chrome face for
// whatever is switched on
void drawRim (juce::Graphics&, juce::Rectangle<float>, float radius, float strength = 1.0f);
void drawChromeFace (juce::Graphics&, juce::Rectangle<float>, float radius, bool pressed = false);
constexpr juce::uint32 chromeInk = 0xff1b1e22;   // writing on chrome

// the emblem: the Troupe signature in raised chrome, CHORD and ENGINE either side of the p's stem
void drawEmblem (juce::Graphics&, juce::Rectangle<float> area);

// a chrome knob: a round body that comes to a point (the point is the value), a domed cap with a dark mirror centre,
// and a ring of dots round it that light up to the value
void drawKnob (juce::Graphics&, juce::Rectangle<float> bounds, float pos, float startAngle, float endAngle,
               const Theme&, bool enabled);
}
