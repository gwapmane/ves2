#pragma once

#include <juce_gui_basics/juce_gui_basics.h>

struct Theme
{
    juce::String name;
    juce::Colour bgTop, bgBottom, panel, panelEdge, card, cardHi, cardDark;
    juce::Colour text, dim, faint, accent, accentText, silver, wine;
    juce::Colour home, move, pull, color;
};

const Theme& themeFor (int index);   // 0 Forest, 1 Smoke, 2 Midnight, 3 Graphite
int numThemes();

juce::Font uiFont (float size, bool bold = false);

class VesperLook : public juce::LookAndFeel_V4
{
public:
    VesperLook();
    void setTheme (const Theme&);
    const Theme& theme() const { return t; }

    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float startAngle, float endAngle, juce::Slider&) override;
    void drawComboBox (juce::Graphics&, int w, int h, bool down, int bx, int by, int bw, int bh, juce::ComboBox&) override;
    void positionComboBoxText (juce::ComboBox&, juce::Label&) override;
    juce::Font getComboBoxFont (juce::ComboBox&) override;
    juce::Font getPopupMenuFont() override;
    void drawPopupMenuBackground (juce::Graphics&, int w, int h) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&, bool over, bool down) override;
    void drawButtonText (juce::Graphics&, juce::TextButton&, bool over, bool down) override;
    juce::Font getTextButtonFont (juce::TextButton&, int buttonHeight) override;
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool over, bool down) override;
    void drawScrollbar (juce::Graphics&, juce::ScrollBar&, int x, int y, int w, int h, bool vertical,
                        int thumbStart, int thumbSize, bool over, bool down) override;
    int getDefaultScrollbarWidth() override { return 8; }

private:
    Theme t;
};

// small drawing helpers shared by the panels
void drawPanel (juce::Graphics&, juce::Rectangle<float>, const Theme&, const juce::String& title = {});
void drawCaption (juce::Graphics&, juce::Rectangle<float>, const juce::String&, const Theme&,
                  juce::Justification = juce::Justification::centredLeft);
