// VESPER: playing the song live. Sections, fills, solos and jams called from the SONG tab, from keys on your
// controller, or by voice (VESPER VOICE sends the words it hears to 127.0.0.1, port 47321). Every call is lined up
// with the music: the next bar, the end of the phrase or the end of the section (SWITCH AT).
// Also: song SHAPES (the genre's arrangements and your own saved ones) and editing the song as a list.
#include "PluginProcessor.h"

using namespace vesper;

namespace
{
constexpr int voicePort = 47321;

// listens for VESPER VOICE on this computer only
class VoiceLinkThread : public juce::Thread
{
public:
    explicit VoiceLinkThread (VesperProcessor& p) : juce::Thread ("VESPER VOICE link"), proc (p) {}
    void run() override
    {
        juce::DatagramSocket sock (false);
        if (! sock.bindToPort (voicePort, "127.0.0.1")) return;   // another VESPER is already listening (the main one)
        char buf[512];
        while (! threadShouldExit())
        {
            if (sock.waitUntilReady (true, 200) != 1) continue;
            juce::String ip;
            int port = 0;
            const int n = sock.read (buf, (int) sizeof (buf) - 1, false, ip, port);
            if (n <= 0) continue;
            const auto text = juce::String::fromUTF8 (buf, n).trim();
            if (text.equalsIgnoreCase ("ping"))
            {
                proc.voiceSeenMs.store (juce::Time::getMillisecondCounterHiRes());
                const char reply[] = "VESPER";
                sock.write (ip, port, reply, 6);
                continue;
            }
            proc.voiceCommand (text);
        }
    }

private:
    VesperProcessor& proc;
};

juce::File shapesFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("VESPER").getChildFile ("Song Shapes.txt");
}

juce::StringArray shapeLines()
{
    juce::StringArray lines;
    shapesFile().readLines (lines);
    lines.removeEmptyStrings();
    return lines;
}
} // namespace

std::unique_ptr<juce::Thread> makeVoiceLink (VesperProcessor& p)
{
    auto t = std::make_unique<VoiceLinkThread> (p);
    t->startThread (juce::Thread::Priority::low);
    return t;
}

//==============================================================================
const char* VesperProcessor::commandKeyName (int k)
{
    static const char* names[numCommandKeys] = {
        "INTRO", "VERSE", "PRE", "HOOK", "BRIDGE", "BREAK", "BUILD (section)", "DROP (section)", "SOLO (section)", "OUTRO",
        "NEXT SECTION", "FILL", "STOP", "DROP-OUT", "BUILD-UP (snare roll)", "CRASH", "HALF TIME", "SOLO (a player)", "JAM",
        "TRANSITION", "CATCH (save the last 16 bars)" };
    return k >= 0 && k < numCommandKeys ? names[k] : "";
}

void VesperProcessor::commandForKey (int k, int& cmd, int& arg) const
{
    cmd = CmdNone;
    arg = -1;
    if (k >= 0 && k < numSongSectionTypes) { cmd = CmdSection; arg = k; return; }
    switch (k)
    {
        case 10: cmd = CmdNextSection; break;
        case 11: cmd = CmdMoment; arg = MomFill; break;
        case 12: cmd = CmdMoment; arg = MomStop; break;
        case 13: cmd = CmdMoment; arg = MomDrop; break;
        case 14: cmd = CmdMoment; arg = MomBuild; break;
        case 15: cmd = CmdMoment; arg = MomCrash; break;
        case 16: cmd = CmdMoment; arg = MomHalf; break;
        case 17: cmd = CmdSolo; break;
        case 18: cmd = CmdJam; break;
        case 19: cmd = CmdTransition; break;
        case 20: cmd = CmdCatch; break;
        default: break;
    }
}

int VesperProcessor::commandKeyOf (int note) const
{
    if (note < 0) return -1;
    for (int k = 0; k < numCommandKeys; ++k) if (commandKey[(size_t) k].load (std::memory_order_relaxed) == note) return k;
    return -1;
}

void VesperProcessor::postCommand (int cmd, int arg)
{
    if (cmd <= CmdNone || cmd >= numCommands) return;
    // the audio thread never waits: if the queue is busy this instant, the call is dropped (it never is in practice)
    const juce::SpinLock::ScopedTryLockType tl (cmdLock);
    if (! tl.isLocked() || cmdCount >= (int) cmdQueue.size()) return;
    cmdQueue[(size_t) cmdCount++] = { cmd, arg };
}

void VesperProcessor::drainCommands()
{
    std::array<std::pair<int, int>, 64> q;
    int n = 0;
    {
        const juce::SpinLock::ScopedLockType sl (cmdLock);
        n = cmdCount;
        for (int i = 0; i < n; ++i) q[(size_t) i] = cmdQueue[(size_t) i];
        cmdCount = 0;
    }
    for (int i = 0; i < n; ++i) command (q[(size_t) i].first, q[(size_t) i].second);
}

juce::String VesperProcessor::lastCommandText() const
{
    const juce::ScopedLock sl (cmdTextLock);
    return lastCmdText;
}

void VesperProcessor::command (int cmd, int arg)
{
    const auto plan = songPlanCopy();
    const int n = (int) plan.sections.size();
    const int cur = songOn.load() ? songSecNow.load() : -1;
    juce::String said;
    auto queue = [&] (int index)
    {
        if (index < 0 || index >= n) return;
        songJumpType.store (plan.sections[(size_t) index].type);
        songJump.store (index);
        if (! songOn.load()) songOn.store (true);   // not playing yet: the song starts there
        said = juce::String (plan.sections[(size_t) index].label);
    };
    switch (cmd)
    {
        case CmdSection:
        {
            const int type = juce::jlimit (0, numSongSectionTypes - 1, arg);
            int target = -1;
            for (int k = 1; k <= n && target < 0; ++k)
            {
                const int i = cur < 0 ? k - 1 : (cur + k) % n;
                if (plan.sections[(size_t) i].type == type) target = i;
            }
            if (target < 0)   // the song has none: one goes in right after the section playing
            {
                songInsertSection (cur < 0 ? n - 1 : cur, type, -1);
                const auto now = songPlanCopy();
                const int idx = juce::jlimit (0, (int) now.sections.size() - 1, cur < 0 ? n : cur + 1);
                songJumpType.store (type);
                songJump.store (idx);
                if (! songOn.load()) songOn.store (true);
                said = juce::String (songSectionName (type)) + " (added)";
            }
            else queue (target);
            break;
        }
        case CmdGoTo: queue (arg); break;
        case CmdNextSection: queue (cur < 0 ? 0 : juce::jmin (n - 1, cur + 1)); break;
        case CmdMoment:
            if (arg > 0 && arg < numSongMoments) { momentTap.store (arg); said = songMomentName (arg); }
            break;
        case CmdSolo:
        {
            soloReqTrack.store (arg);
            soloReq.store (juce::jlimit (1, 64, soloBars.load()));
            const int who = arg >= 0 ? arg : pickSoloist();
            said = "SOLO" + (who >= 0 ? ": " + (trackName (who).isNotEmpty() ? trackName (who) : juce::String (bandTypeName (trackType (who)))) : juce::String());
            break;
        }
        case CmdJam: jamReq.store (juce::jlimit (1, 64, jamBars.load())); said = "JAM " + juce::String (jamBars.load()) + " bars"; break;
        case CmdTransition:
            if (songOn.load() && songJump.load() < 0 && cur >= 0 && cur + 1 < n) queue (cur + 1);
            transitionReq.store (true);
            said = "TRANSITION" + (said.isNotEmpty() ? " into " + said : juce::String());
            break;
        case CmdLoopSection: songLoopSection.store (! songLoopSection.load()); said = songLoopSection.load() ? "LOOP ON" : "LOOP OFF"; break;
        case CmdSongStart: songOn.store (true); said = "SONG"; break;
        case CmdSongStop: songOn.store (false); said = "SONG STOPPED"; break;
        case CmdCatch: said = catchRecall() ? "CAUGHT the last 16 bars" : "nothing to catch yet"; break;
        case CmdOut: case CmdIn:
        {
            // which tracks: one type (every drum track for the drums), or everybody but the drums
            int mask = 0;
            for (int t = 0; t < numTracks.load(); ++t)
            {
                const int ty = trackType (t);
                const bool match = arg < 0 ? ! bandTypeIsDrums (ty) : (arg == BDrums ? bandTypeIsDrums (ty) : ty == arg);
                if (match) mask |= 1 << t;
            }
            if (mask == 0) return;
            if (cmd == CmdOut) liveOutReq.fetch_or (mask); else liveOutReq.fetch_and (~mask);
            const juce::String who = arg < 0 ? juce::String ("EVERYBODY") : (arg == BDrums ? juce::String ("DRUMS") : juce::String (bandTypeName (arg)));
            said = who + (cmd == CmdOut ? " OUT" : " IN") + " (next bar)";
            break;
        }
        case CmdAgain: queue (cur < 0 ? 0 : cur); break;
        case CmdBack: queue (cur <= 0 ? 0 : cur - 1); break;
        case CmdMood:
            if (auto* prm = apvts.getParameter (ids::mood))
            {
                const float now = apvts.getRawParameterValue (ids::mood)->load();
                prm->setValueNotifyingHost (prm->convertTo0to1 (juce::jlimit (-1.0f, 1.0f, now + (arg > 0 ? 0.25f : -0.25f))));
                said = arg > 0 ? "BRIGHTER" : "DARKER";
            }
            break;
        case CmdGlide:
            if (auto* prm = apvts.getParameter (ids::glide))
            {
                prm->setValueNotifyingHost (prm->convertTo0to1 (arg > 0 ? 0.18f : 0.0f));
                said = arg > 0 ? "GLIDE ON" : "GLIDE OFF";
            }
            break;
        case CmdCallResponse: said = toggleCallResponse() ? "CALL & RESPONSE ON" : "CALL & RESPONSE OFF"; break;
        default: return;
    }
    perfLog (cmd, arg);
    {
        const juce::ScopedLock sl (cmdTextLock);
        lastCmdText = said;
    }
    commandCount.fetch_add (1);
}

// words -> a command. Short and forgiving: "hook", "go to the hook", "chorus", "fill", "drop out", "solo keys", "jam"
bool VesperProcessor::voiceCommand (const juce::String& wordsIn)
{
    auto words = wordsIn.toLowerCase().retainCharacters ("abcdefghijklmnopqrstuvwxyz -");
    words = words.replace ("-", " ").trim();
    if (words.isEmpty()) return false;
    auto has = [&] (const char* w) { return (" " + words + " ").contains (" " + juce::String (w) + " "); };
    const auto plan = songPlanCopy();
    auto songHas = [&] (int type) { for (auto& s : plan.sections) if (s.type == type) return true; return false; };

    if (has ("transition")) { postCommand (CmdTransition); return true; }
    if (words.contains ("call and response") || words.contains ("call response") || has ("answer")) { postCommand (CmdCallResponse); return true; }
    if (has ("brighter")) { postCommand (CmdMood, 1); return true; }
    if (has ("darker")) { postCommand (CmdMood, -1); return true; }
    if (words.contains ("glide on")) { postCommand (CmdGlide, 1); return true; }
    if (words.contains ("glide off")) { postCommand (CmdGlide, 0); return true; }
    if (has ("again") || words.contains ("one more time")) { postCommand (CmdAgain); return true; }
    if (words.contains ("go back") || has ("previous") || words == "back") { postCommand (CmdBack); return true; }
    // "drums out", "bass back in", "everybody out", "all in"
    if (! words.contains ("drop out") && (has ("out") || has ("in")))
    {
        const bool out = has ("out");
        int who = -2;
        if (has ("everybody") || has ("everyone") || has ("all") || has ("band")) who = -1;
        else if (has ("drums") || has ("drum") || has ("beat")) who = BDrums;
        else if (has ("bass")) who = BBass;
        else if (has ("keys") || has ("piano")) who = BKeys;
        else if (has ("strings") || has ("violin") || has ("violins")) who = BStrings;
        else if (has ("horns") || has ("sax") || has ("brass")) who = BHorns;
        else if (has ("melody") || has ("lead")) who = BMelody;
        else if (has ("counter")) who = BCounter;
        else if (has ("guitar")) who = BGuitar;
        else if (has ("pad") || has ("pads")) who = BPad;
        else if (has ("arp")) who = BArp;
        if (who != -2) { postCommand (out ? CmdOut : CmdIn, who); return true; }
    }
    if (has ("jam")) { postCommand (CmdJam); return true; }
    if (has ("catch") || words.contains ("keep that") || words.contains ("save that")) { postCommand (CmdCatch); return true; }
    if (has ("next")) { postCommand (CmdNextSection); return true; }
    if (words.contains ("drop out") || has ("dropout")) { postCommand (CmdMoment, MomDrop); return true; }
    if (words.contains ("half time") || has ("half")) { postCommand (CmdMoment, MomHalf); return true; }
    if (has ("fill")) { postCommand (CmdMoment, MomFill); return true; }
    if (has ("crash")) { postCommand (CmdMoment, MomCrash); return true; }
    if (words.contains ("stop song") || words.contains ("stop the song") || words.contains ("end song")) { postCommand (CmdSongStop); return true; }
    if (has ("stop")) { postCommand (CmdMoment, MomStop); return true; }
    if (has ("loop") || has ("stay")) { postCommand (CmdLoopSection); return true; }
    if (words.contains ("pre chorus") || words.contains ("pre hook") || words.contains ("prechorus")) { postCommand (CmdSection, SecPre); return true; }
    if (has ("solo"))
    {
        if (has ("section")) { postCommand (CmdSection, SecSolo); return true; }
        // "solo keys", "solo guitar", "solo strings", or a track's own name
        int who = -1;
        for (int t = 0; t < numTracks.load() && who < 0; ++t)
        {
            if (trackValue (t, TpOn) < 0.5f) continue;
            const auto type = juce::String (bandTypeName (trackType (t))).toLowerCase();
            const auto name = trackName (t).toLowerCase();
            for (const auto& w : juce::StringArray::fromTokens (words, " ", ""))
                if (w != "solo" && w.length() >= 3 && (type.contains (w) || name.contains (w))) { who = t; break; }
        }
        postCommand (CmdSolo, who);
        return true;
    }
    if (has ("build") || has ("buildup")) { postCommand (songHas (SecBuild) ? CmdSection : CmdMoment, songHas (SecBuild) ? (int) SecBuild : (int) MomBuild); return true; }
    if (has ("drop")) { postCommand (songHas (SecDrop) ? CmdSection : CmdMoment, songHas (SecDrop) ? (int) SecDrop : (int) MomDrop); return true; }
    for (const auto& w : juce::StringArray::fromTokens (words, " ", ""))
    {
        const int type = songSectionTypeFromName (w.toStdString());
        if (type >= 0 && w.length() >= 3) { postCommand (CmdSection, type); return true; }
    }
    if (has ("start") || has ("play") || has ("go")) { postCommand (CmdSongStart); return true; }
    return false;
}

//==============================================================================
// SHAPES
void VesperProcessor::songFromShape (const SongShape& shape)
{
    auto plan = makeSongFromShape (bandGenreNow(), songNumber.load(), songLineup(), shape);
    {
        const juce::SpinLock::ScopedLockType sl (songLock);
        songPlan = std::move (plan);
    }
    songGenreBuilt = bandGenreNow();
    songPlanChanged.fetch_add (1);
}

juce::StringArray VesperProcessor::savedShapeNames() const
{
    juce::StringArray names;
    for (const auto& l : shapeLines()) names.add (l.upToFirstOccurrenceOf ("|", false, false));
    return names;
}

bool VesperProcessor::loadSavedShape (const juce::String& name, SongShape& shape) const
{
    for (const auto& l : shapeLines())
        if (l.upToFirstOccurrenceOf ("|", false, false) == name)
        {
            shape.name = name.toStdString();
            return songShapeFromText (l.fromFirstOccurrenceOf ("|", false, false).toStdString(), shape);
        }
    return false;
}

void VesperProcessor::saveShape (const juce::String& nameIn)
{
    const auto name = nameIn.removeCharacters ("|\r\n").trim().substring (0, 40);
    if (name.isEmpty()) return;
    auto lines = shapeLines();
    for (int i = lines.size() - 1; i >= 0; --i) if (lines[i].upToFirstOccurrenceOf ("|", false, false) == name) lines.remove (i);
    lines.add (name + "|" + juce::String (songShapeText (songPlanCopy())));
    shapesFile().getParentDirectory().createDirectory();
    shapesFile().replaceWithText (lines.joinIntoString ("\n") + "\n");
}

void VesperProcessor::deleteShape (const juce::String& name)
{
    auto lines = shapeLines();
    for (int i = lines.size() - 1; i >= 0; --i) if (lines[i].upToFirstOccurrenceOf ("|", false, false) == name) lines.remove (i);
    shapesFile().replaceWithText (lines.joinIntoString ("\n") + (lines.isEmpty() ? "" : "\n"));
}

//==============================================================================
// the song as a list
void VesperProcessor::songInsertSection (int afterIndex, int type, int bars)
{
    const auto bc = songLineup();
    const uint32_t seed = (uint32_t) juce::Random::getSystemRandom().nextInt (1 << 30);
    editSong ([&] (SongPlan& p)
    {
        const int at = juce::jlimit (0, (int) p.sections.size(), afterIndex + 1);
        p.sections.insert (p.sections.begin() + at, songMakeSection (p.genre, type, bars, bc, seed));
        songReplaceMoments (p, juce::jmax (0, at - 1), seed);
    });
}

void VesperProcessor::songRemoveSection (int index)
{
    const uint32_t seed = (uint32_t) juce::Random::getSystemRandom().nextInt (1 << 30);
    editSong ([&] (SongPlan& p)
    {
        if (p.sections.size() <= 1 || index < 0 || index >= (int) p.sections.size()) return;
        p.sections.erase (p.sections.begin() + index);
        songReplaceMoments (p, juce::jmax (0, index - 1), seed);
    });
    if (songJump.load() >= index) songJump.store (-1);
}

void VesperProcessor::songMoveSection (int index, int delta)
{
    const uint32_t seed = (uint32_t) juce::Random::getSystemRandom().nextInt (1 << 30);
    editSong ([&] (SongPlan& p)
    {
        const int to = index + delta;
        if (index < 0 || to < 0 || index >= (int) p.sections.size() || to >= (int) p.sections.size()) return;
        std::swap (p.sections[(size_t) index], p.sections[(size_t) to]);
        songReplaceMoments (p, juce::jmax (0, juce::jmin (index, to) - 1), seed);
    });
}

void VesperProcessor::songRetypeSection (int index, int type)
{
    const auto bc = songLineup();
    const uint32_t seed = (uint32_t) juce::Random::getSystemRandom().nextInt (1 << 30);
    editSong ([&] (SongPlan& p)
    {
        if (index < 0 || index >= (int) p.sections.size()) return;
        const int bars = p.sections[(size_t) index].bars;
        p.sections[(size_t) index] = songMakeSection (p.genre, type, bars, bc, seed);
        songReplaceMoments (p, juce::jmax (0, index - 1), seed);
    });
}

void VesperProcessor::songDuplicateSection (int index)
{
    editSong ([&] (SongPlan& p)
    {
        if (index < 0 || index >= (int) p.sections.size()) return;
        const auto copy = p.sections[(size_t) index];
        p.sections.insert (p.sections.begin() + index + 1, copy);
    });
}

//==============================================================================
// CALL & RESPONSE, the quick way: the first horns / strings / counter / keys / guitar / arp track answers the melody
bool VesperProcessor::toggleCallResponse()
{
    bool any = false;
    for (auto& r : trackRespond) if (r.load() != 0) any = true;
    if (any) { for (auto& r : trackRespond) r.store (0); return false; }
    const int n = numTracks.load();
    int caller = -1;
    for (int ty : { (int) BMelody, (int) BHorns, (int) BGuitar, (int) BKeys })
        for (int t = 0; t < n && caller < 0; ++t)
            if (trackValue (t, TpOn) > 0.5f && trackType (t) == ty) caller = t;
    if (caller < 0) return false;
    for (int ty : { (int) BHorns, (int) BStrings, (int) BCounter, (int) BKeys, (int) BGuitar, (int) BArp, (int) BPad })
        for (int t = 0; t < n; ++t)
            if (t != caller && trackValue (t, TpOn) > 0.5f && trackType (t) == ty)
            {
                trackRespond[(size_t) t].store (packRespond (caller, 0, 2));
                return true;
            }
    return false;
}

//==============================================================================
// the VOICE button: open VESPER VOICE (installed next to VESPER, or wherever you pointed it)
namespace
{
juce::File voicePathFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("VESPER").getChildFile ("VESPER VOICE path.txt");
}
} // namespace

void VesperProcessor::setVoiceAppPath (const juce::File& f)
{
    voicePathFile().getParentDirectory().createDirectory();
    voicePathFile().replaceWithText (f.getFullPathName());
}

bool VesperProcessor::launchVoiceApp()
{
    juce::Array<juce::File> tries;
    const auto saved = voicePathFile().loadFileAsString().trim();
    if (saved.isNotEmpty()) tries.add (juce::File (saved));
   #if JUCE_WINDOWS
    for (auto where : { juce::File::globalApplicationsDirectory, juce::File::globalApplicationsDirectoryX86 })
   #else
    for (auto where : { juce::File::globalApplicationsDirectory })
   #endif
    {
        const auto dir = juce::File::getSpecialLocation (where).getChildFile ("VESPER VOICE");
        tries.add (dir.getChildFile ("VESPER VOICE.exe"));
        tries.add (dir.getChildFile ("VESPER VOICE (PowerShell).bat"));
    }
    const auto docs = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER").getChildFile ("VESPER VOICE");
    tries.add (docs.getChildFile ("VESPER VOICE.exe"));
    for (const auto& f : tries)
        if (f.existsAsFile() && f.startAsProcess()) return true;
    return false;
}
