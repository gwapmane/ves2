// The SONG tab (hidden: right-click the VESPER logo). A whole song for the band's genre - every section, who plays
// in every bar, and the moments (fills, stops, drops, builds, crashes, half-time). DJ it: tap a section and it starts
// on the next bar line, LOOP SECTION to stay where you are, the pads to throw in a moment, FOLLOW ME to let it react
// to how you play.
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "Widgets.h"

class SongPanel : public juce::Component, private juce::Timer
{
public:
    explicit SongPanel (EditorContext& c);
    ~SongPanel() override;
    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;

private:
    void timerCallback() override;
    void sectionMenu (int s);
    juce::Rectangle<float> sectionRect (int s) const;
    juce::Rectangle<int> gridArea() const;
    int viewSection() const;
    int rowAt (int y) const;
    int barAt (int x) const;
    void refreshRows();

    EditorContext& ctx;
    vesper::SongPlan plan;
    uint32_t lastChanged = 0xffffffffu;
    int viewSec = 0, lastSec = -2, lastBar = -2, lastJump = -2, lastMoment = -1, lastNumber = -1;
    bool lastOn = false;
    juce::String lastStatus;
    std::vector<int> rows;   // the band tracks that are on
    uint32_t rowSig = 0;

    juce::TextButton playBtn { "PLAY SONG" }, prevBtn { "<" }, nextBtn { ">" }, diceBtn { "DICE" };
    juce::TextButton loopBtn { "LOOP SECTION" }, followBtn { "FOLLOW ME" };
    juce::TextButton padBtns[6];
    // playing it live
    juce::TextButton shapeBtn { "SHAPE" }, switchBtn { "PHRASE END" }, soloBtn { "SOLO" }, jamBtn { "JAM" },
                     transBtn { "TRANSITION" }, catchBtn { "CATCH" }, takeBtn { "TAKE" }, keysBtn { "KEYS" }, voiceBtn { "VOICE" },
                     setupBtn { "SETUP" }, keyBtn { "KEY" };
    void openSetup();
    void keyMenu();
    std::unique_ptr<juce::FileChooser> chooser;
    void drawPhraseMeter (juce::Graphics&, const Theme&);
    juce::Slider moodKnob, glideKnob;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
    void shapeMenu();
    void switchMenu();
    void soloMenu();
    void jamMenu();
    void takeMenu();
    void keysMenu();
    void flash (const juce::String& text);
    juce::String flashText;
    double flashUntil = 0;
    uint32_t lastCmdCount = 0, lastPerf = 0;
    bool menuClick = false;   // a right-click on SOLO / JAM opens its menu instead of playing it

    static constexpr int labelW = 112, rowTop = 82;
};
