// The SOUND button's menu (band tracks and the chords): pick an instrument on this computer, open its window,
// choose where it plays, remove it.
#pragma once

#include <juce_gui_basics/juce_gui_basics.h>

class VesperProcessor;

void showSoundMenu (VesperProcessor& p, int slot, juce::Component& target);
juce::String soundButtonText (const VesperProcessor& p, int slot);   // "Omnisphere" / "SOUND" / "MISSING"
