// Lets several VESPERs in the same FL project share one band. The main VESPER (THIS VESPER PLAYS:
// EVERYTHING) publishes its band settings and the chord it's on; a copy set to "Only BASS" (etc.)
// runs the same band engine with the same seeds, so it plays exactly the same bass line, and sends
// it out of its own MIDI port to its own instrument. The main VESPER then leaves that track out.
#pragma once

#include <juce_core/juce_core.h>

#include "Band.h"

#include <array>
#include <atomic>

struct LinkSnapshot
{
    int leaderId = 0;
    double wallMs = 0;                 // when the leader last published
    vesper::BandConfig cfg;
    vesper::Harmony harm;
    double harmBeat = 0;               // leader band-clock beat of the last chord change
    bool running = false;
    uint32_t starts = 0;               // bumps every time the band starts
    bool synced = false;               // following FL's song position
    double origin = 0;                 // band-clock beat of step 0 (free clock)
    int64_t clock = 0;                 // leader sample clock at its block start
    double beat = 0, spb = 22050.0;    // leader band-clock beat at its block start, samples per beat
};

class LinkBus
{
public:
    static LinkBus& get()
    {
        static LinkBus bus;
        return bus;
    }

    int newId() { return nextId.fetch_add (1); }

    // audio thread; never blocks
    void publish (const LinkSnapshot& s)
    {
        const juce::SpinLock::ScopedTryLockType tl (lock);
        if (! tl.isLocked()) return;
        const bool stale = s.wallMs - snap.wallMs > 1000.0;
        const bool takeOver = s.running && ! snap.running;
        if (snap.leaderId == 0 || snap.leaderId == s.leaderId || stale || takeOver)
            snap = s;
    }

    bool read (LinkSnapshot& out)
    {
        const juce::SpinLock::ScopedTryLockType tl (lock);
        if (! tl.isLocked()) return false;
        out = snap;
        return snap.leaderId != 0;
    }

    // a VESPER that's removed (or closed) lets go at once: a copy never follows a band that's gone (its settings point
    // into the removed VESPER), and the next main VESPER takes over straight away
    void leave (int id)
    {
        const juce::SpinLock::ScopedLockType sl (lock);
        if (snap.leaderId == id) snap = LinkSnapshot();
    }

    void claim (int track, double untilMs)   { if (track >= 0 && track < vesper::maxBandTracks) claimed[(size_t) track].store (untilMs); }
    bool isClaimed (int track, double nowMs) { return track >= 0 && track < vesper::maxBandTracks && claimed[(size_t) track].load() > nowMs; }

private:
    LinkBus() { for (auto& c : claimed) c.store (0.0); }

    juce::SpinLock lock;
    LinkSnapshot snap;
    std::array<std::atomic<double>, vesper::maxBandTracks> claimed;
    std::atomic<int> nextId { 1 };
};
