#include "Chrome.h"
#include "EmblemData.h"
#include "Look.h"

namespace troupe
{
namespace
{
juce::Colour c (juce::uint32 argb) { return juce::Colour (argb); }

juce::Path roundRect (juce::Rectangle<float> r, float radius)
{
    juce::Path p;
    p.addRoundedRectangle (r, radius);
    return p;
}

// the signature as one even-odd path, in the drawing's units
const juce::Path& signature()
{
    static const juce::Path path = []
    {
        juce::Path p;
        p.setUsingNonZeroWinding (false);
        int at = 0;
        for (int o = 0; o < sigNumOutlines; ++o)
        {
            const int n = sigOutlineSize[o];
            for (int i = 0; i < n; ++i)
            {
                const float x = sigPoints[(at + i) * 2], y = sigPoints[(at + i) * 2 + 1];
                if (i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
            }
            p.closeSubPath();
            at += n;
        }
        return p;
    }();
    return path;
}

// raised chrome: a dark side wall under it, a bright top edge, the chrome face between
void raisedChrome (juce::Graphics& g, const juce::Path& shape, float lift)
{
    const auto b = shape.getBounds();
    // the shadow it throws on the face, then the side wall you see below its edge
    g.setColour (juce::Colours::black.withAlpha (0.38f));
    g.fillPath (shape, juce::AffineTransform::translation (0.25f * lift, 1.6f * lift));
    g.setColour (juce::Colours::black.withAlpha (0.45f));
    g.fillPath (shape, juce::AffineTransform::translation (0.0f, 0.9f * lift));
    g.setColour (c (0xff4a4f56));
    g.fillPath (shape, juce::AffineTransform::translation (0.0f, 0.5f * lift));
    {
        juce::Graphics::ScopedSaveState s (g);
        g.reduceClipRegion (shape);
        g.setColour (c (0xfffbfcfd));   // the top edge catches the lamp
        g.fillRect (b.expanded (2.0f));
        g.setGradientFill (chromeGradient (b));
        g.fillPath (shape, juce::AffineTransform::translation (0.0f, 0.45f * lift));
    }
}
}

juce::ColourGradient chromeGradient (juce::Rectangle<float> r)
{
    const float tilt = juce::jmin (r.getWidth(), r.getHeight()) * 0.18f;   // the bands lean a touch, whatever the shape
    juce::ColourGradient g (c (0xfff4f6f8), r.getX(), r.getY(), c (0xffa7adb5), r.getX() + tilt, r.getBottom(), false);
    g.addColour (0.10, c (0xffdde1e6));
    g.addColour (0.30, c (0xffa3aab3));
    g.addColour (0.44, c (0xffe3e7eb));
    g.addColour (0.50, c (0xfffafbfc));
    g.addColour (0.55, c (0xff6f7680));   // the horizon: chrome's hard dark line
    g.addColour (0.66, c (0xff8e959e));
    g.addColour (0.84, c (0xffd5d9de));
    g.addColour (0.93, c (0xffeef0f3));
    return g;
}

void drawUnibodyShadow (juce::Graphics& g, juce::Rectangle<float> body, float radius)
{
    for (int i = 6; i >= 1; --i)
    {
        const float k = (float) i;
        g.setColour (juce::Colours::black.withAlpha (0.055f + 0.02f * (6 - k)));
        g.fillRoundedRectangle (body.translated (0.0f, 1.0f + k * 0.7f).expanded (k * 1.1f), radius + k);
    }
}

void drawUnibody (juce::Graphics& g, juce::Rectangle<float> body, juce::Rectangle<float> face, float rb, float rf)
{
    // the chrome: everything between the outside and the cut
    juce::Path ring;
    ring.setUsingNonZeroWinding (false);
    ring.addRoundedRectangle (body, rb);
    ring.addRoundedRectangle (face, rf);
    g.setGradientFill (chromeGradient (body));
    g.fillPath (ring);
    {   // a soft sheen across it, corner to corner
        juce::ColourGradient sheen (juce::Colours::white.withAlpha (0.0f), body.getX(), body.getY(),
                                    juce::Colours::white.withAlpha (0.0f), body.getRight(), body.getBottom(), false);
        sheen.addColour (0.30, juce::Colours::white.withAlpha (0.0f));
        sheen.addColour (0.38, juce::Colours::white.withAlpha (0.30f));
        sheen.addColour (0.46, juce::Colours::white.withAlpha (0.0f));
        sheen.addColour (0.72, juce::Colours::white.withAlpha (0.0f));
        sheen.addColour (0.78, juce::Colours::white.withAlpha (0.16f));
        sheen.addColour (0.84, juce::Colours::white.withAlpha (0.0f));
        g.setGradientFill (sheen);
        g.fillPath (ring);
    }

    // the rounded outer edge: it rolls away from the lamp, bright on top, falling dark underneath
    {
        juce::ColourGradient roll (juce::Colours::white.withAlpha (0.95f), 0.0f, body.getY(),
                                   juce::Colours::black.withAlpha (0.55f), 0.0f, body.getBottom(), false);
        roll.addColour (0.5, juce::Colours::white.withAlpha (0.15f));
        g.setGradientFill (roll);
        g.strokePath (roundRect (body.reduced (1.6f), rb - 1.6f), juce::PathStrokeType (2.2f));
        juce::ColourGradient inner (juce::Colours::black.withAlpha (0.22f), 0.0f, body.getY(),
                                    juce::Colours::white.withAlpha (0.55f), 0.0f, body.getBottom(), false);
        g.setGradientFill (inner);
        g.strokePath (roundRect (body.reduced (3.6f), rb - 3.6f), juce::PathStrokeType (0.9f));
        g.setColour (juce::Colours::black.withAlpha (0.7f));   // where it meets the desk
        g.strokePath (roundRect (body.reduced (0.4f), rb - 0.4f), juce::PathStrokeType (0.9f));
    }

    // the cut: a chamfer dropping into the opening (in shadow on top, catching the lamp at the bottom)
    {
        juce::Path chamfer;
        chamfer.setUsingNonZeroWinding (false);
        const float w = 3.4f;
        chamfer.addRoundedRectangle (face.expanded (w), rf + w);
        chamfer.addRoundedRectangle (face, rf);
        juce::ColourGradient cg (c (0xff40454c), 0.0f, face.getY() - w, c (0xfff2f4f6), 0.0f, face.getBottom() + w, false);
        cg.addColour (0.25, c (0xff6d747d));
        cg.addColour (0.75, c (0xffc3c8ce));
        g.setGradientFill (cg);
        g.fillPath (chamfer);
        // the chamfer's sides: lit from the left, so the left side is brighter than the right
        juce::ColourGradient side (juce::Colours::white.withAlpha (0.28f), face.getX() - w, 0.0f,
                                   juce::Colours::black.withAlpha (0.18f), face.getRight() + w, 0.0f, false);
        side.addColour (0.08, juce::Colours::white.withAlpha (0.0f));
        side.addColour (0.92, juce::Colours::black.withAlpha (0.0f));
        g.setGradientFill (side);
        g.fillPath (chamfer);
        g.setColour (juce::Colours::white.withAlpha (0.55f));   // the cut's top lip, polished
        g.strokePath (roundRect (face.expanded (w), rf + w), juce::PathStrokeType (0.7f));
    }

    // the seam, and the face sitting a little below the chrome (its edges in shadow, the top edge most)
    {
        const auto facePath = roundRect (face, rf);
        juce::Graphics::ScopedSaveState s (g);
        g.reduceClipRegion (facePath);
        for (int i = 0; i < 7; ++i)
        {
            const float k = (float) i;
            g.setColour (juce::Colours::black.withAlpha (0.26f * std::pow (1.0f - k / 7.0f, 2.0f)));
            g.strokePath (roundRect (face.reduced (k * 0.9f + 0.4f), juce::jmax (1.0f, rf - k * 0.9f)), juce::PathStrokeType (1.1f));
        }
        juce::ColourGradient top (juce::Colours::black.withAlpha (0.30f), 0.0f, face.getY(),
                                  juce::Colours::black.withAlpha (0.0f), 0.0f, face.getY() + 12.0f, false);
        g.setGradientFill (top);
        g.fillRect (face.withHeight (12.0f));
    }
    g.setColour (juce::Colours::black.withAlpha (0.85f));
    g.strokePath (roundRect (face, rf), juce::PathStrokeType (1.1f));
}

void drawRim (juce::Graphics& g, juce::Rectangle<float> r, float radius, float strength)
{
    juce::ColourGradient rim (juce::Colours::white.withAlpha (0.62f * strength), 0.0f, r.getY(),
                              juce::Colours::black.withAlpha (0.50f * strength), 0.0f, r.getBottom(), false);
    rim.addColour (0.45, juce::Colour (0xffc9ced4).withAlpha (0.30f * strength));
    rim.addColour (0.55, juce::Colour (0xff5d636b).withAlpha (0.38f * strength));
    g.setGradientFill (rim);
    g.drawRoundedRectangle (r.reduced (0.5f), radius, 1.0f);
}

void drawChromeFace (juce::Graphics& g, juce::Rectangle<float> r, float radius, bool pressed)
{
    g.setColour (juce::Colours::black.withAlpha (0.35f));   // it sits proud of the face
    g.fillRoundedRectangle (r.translated (0.0f, 1.0f), radius);
    // satin chrome: the same metal, a softer horizon, so the writing on it reads
    juce::ColourGradient cg (c (0xfff6f7f9), 0.0f, r.getY(), c (0xffe4e7eb), 0.0f, r.getBottom(), false);
    cg.addColour (0.42, c (0xffdadee3));
    cg.addColour (0.50, c (0xffb4bac2));
    cg.addColour (0.64, c (0xffc9ced4));
    cg.addColour (0.88, c (0xffeef0f3));
    g.setGradientFill (cg);
    g.fillRoundedRectangle (r, radius);
    if (pressed)
    {
        g.setColour (juce::Colours::black.withAlpha (0.14f));
        g.fillRoundedRectangle (r, radius);
    }
    g.setColour (juce::Colours::white.withAlpha (0.85f));   // the polished top edge
    g.drawLine (r.getX() + radius, r.getY() + 0.8f, r.getRight() - radius, r.getY() + 0.8f, 0.8f);
    g.setColour (juce::Colours::black.withAlpha (0.55f));
    g.drawRoundedRectangle (r.reduced (0.4f), radius, 0.8f);
}

void drawEngraved (juce::Graphics& g, const juce::String& text, juce::Rectangle<float> r, float size, juce::Justification j)
{
    const auto f = uiFont (size, true).withExtraKerningFactor (0.34f);
    g.setFont (f);
    g.setColour (juce::Colours::white.withAlpha (0.6f));   // the lower lip of the cut catches the light
    g.drawText (text, r.translated (0.0f, 0.8f), j, false);
    g.setColour (c (0xff3c4148).withAlpha (0.85f));
    g.drawText (text, r, j, false);
}

void drawEmblem (juce::Graphics& g, juce::Rectangle<float> area)
{
    // the drawing's layout: the signature, then CHORD ending just before the p's stem and ENGINE starting just after it
    constexpr float stemX = 718.0f, baseY = 420.0f, capH = 50.0f, gapL = 34.0f, gapR = 30.0f;
    constexpr float unitsW = 1035.0f, unitsH = baseY - sigY0 + 4.0f;
    const float s = juce::jmin (area.getWidth() / unitsW, area.getHeight() / unitsH);
    const auto toPx = juce::AffineTransform::translation (-sigX0, -sigY0).scaled (s).translated (area.getX(), area.getY());

    juce::Path sig (signature());
    sig.applyTransform (toPx);
    const float lift = juce::jlimit (0.6f, 1.6f, s * 7.0f);
    raisedChrome (g, sig, lift);

    // CHORD | ENGINE: small spaced caps, raised a touch less
    const auto font = uiFont (capH * s * 1.18f, true).withExtraKerningFactor (0.36f);
    auto word = [&] (const juce::String& w, float x, bool rightAligned)
    {
        juce::GlyphArrangement ga;
        const float width = juce::GlyphArrangement::getStringWidth (font, w);
        juce::Point<float> at (area.getX() + (x - sigX0) * s, area.getY() + (baseY - sigY0) * s);
        ga.addLineOfText (font, w, rightAligned ? at.x - width : at.x, at.y);
        juce::Path p;
        ga.createPath (p);
        raisedChrome (g, p, lift * 0.6f);
    };
    word ("CHORD", stemX - gapL, true);
    word ("ENGINE", stemX + gapR, false);
}

void drawKnob (juce::Graphics& g, juce::Rectangle<float> bounds, float pos, float startAngle, float endAngle, const Theme& t, bool enabled)
{
    const float side = juce::jmin (bounds.getWidth(), bounds.getHeight());
    const float cx = bounds.getCentreX(), cy = bounds.getCentreY();
    const float dotR = juce::jmax (0.85f, side * 0.034f);
    const float ringR = side * 0.5f - dotR - 0.4f;
    const float R = (ringR - dotR - 1.2f) / 1.33f;          // the round body
    const float tip = R * 0.33f;                             // how far the point stands out
    const float angle = startAngle + juce::jlimit (0.0f, 1.0f, pos) * (endAngle - startAngle);
    const float alpha = enabled ? 1.0f : 0.45f;
    auto at = [&] (float a, float r) { return juce::Point<float> (cx + std::sin (a) * r, cy - std::cos (a) * r); };

    // the dots: the ones up to the value glow
    const int numDots = 11;
    for (int i = 0; i < numDots; ++i)
    {
        const float f = (float) i / (float) (numDots - 1);
        const auto p = at (startAngle + f * (endAngle - startAngle), ringR);
        const bool lit = f <= pos + 0.02f && pos > 0.001f;
        if (lit)
        {
            g.setColour (t.accent.withAlpha (0.22f * alpha));
            g.fillEllipse (p.x - dotR * 2.1f, p.y - dotR * 2.1f, dotR * 4.2f, dotR * 4.2f);
            g.setColour (t.accent.brighter (0.4f).withAlpha (alpha));
        }
        else g.setColour (juce::Colours::black.withAlpha (0.42f * alpha));
        g.fillEllipse (p.x - dotR, p.y - dotR, dotR * 2.0f, dotR * 2.0f);
        if (! lit)
        {
            g.setColour (juce::Colours::white.withAlpha (0.10f * alpha));   // a pit's lower lip
            g.drawEllipse (p.x - dotR, p.y - dotR + 0.4f, dotR * 2.0f, dotR * 2.0f, 0.5f);
        }
    }

    // the body: round, coming to a soft point at the value
    juce::Path body;
    {
        const float d = 0.42f;   // half the point's width at the body, in radians
        const auto a0 = at (angle + d, R), a1 = at (angle - d, R), apex = at (angle, R + tip);
        body.addCentredArc (cx, cy, R, R, 0.0f, angle + d, angle - d + juce::MathConstants<float>::twoPi, true);
        body.quadraticTo (at (angle - d * 0.35f, R + tip * 0.35f), apex);
        body.quadraticTo (at (angle + d * 0.35f, R + tip * 0.35f), a0);
        body.closeSubPath();
        juce::ignoreUnused (a1);
    }
    const auto bb = body.getBounds();
    // its shadow on the face
    g.setColour (juce::Colours::black.withAlpha (0.30f * alpha));
    g.fillPath (body, juce::AffineTransform::translation (0.6f, R * 0.22f + 0.8f));
    g.setColour (juce::Colours::black.withAlpha (0.22f * alpha));
    g.fillPath (body, juce::AffineTransform::scale (1.06f, 1.06f, cx, cy).translated (0.3f, R * 0.12f + 0.4f));

    // the flange: polished chrome, rounder at the bottom right where it turns from the lamp
    {
        juce::Graphics::ScopedSaveState s (g);
        g.setOpacity (alpha);
        g.setGradientFill (chromeGradient (bb.expanded (1.0f)));
        g.fillPath (body);
        juce::ColourGradient turn (juce::Colours::black.withAlpha (0.0f), cx - R * 0.3f, cy - R * 0.4f,
                                   juce::Colours::black.withAlpha (0.38f), cx + R * 0.9f, cy + R * 1.0f, true);
        turn.addColour (0.62, juce::Colours::black.withAlpha (0.0f));
        g.setGradientFill (turn);
        g.fillPath (body);
        // spun metal: the fine bright and dark rings a lathe leaves in polished chrome
        for (int i = 0; i < 3; ++i)
        {
            const float rr = R * (0.86f + 0.045f * (float) i);
            g.setColour ((i % 2 == 0 ? juce::Colours::white : juce::Colours::black).withAlpha (i % 2 == 0 ? 0.22f : 0.16f));
            g.drawEllipse (cx - rr, cy - rr, rr * 2.0f, rr * 2.0f, 0.5f);
        }
        // the point catches the lamp on its lit side
        {
            juce::Path facet;
            facet.startNewSubPath (at (angle - 0.30f, R * 0.98f));
            facet.lineTo (at (angle, R + tip * 0.92f));
            g.setColour (juce::Colours::white.withAlpha (0.55f));
            g.strokePath (facet, juce::PathStrokeType (0.7f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
        g.setColour (juce::Colours::black.withAlpha (0.55f));
        g.strokePath (body, juce::PathStrokeType (0.8f));
        g.setColour (juce::Colours::white.withAlpha (0.7f));   // the flange's top edge
        juce::Path lip;
        lip.addCentredArc (cx, cy, R - 0.7f, R - 0.7f, 0.0f, -2.3f, 0.5f, true);
        g.strokePath (lip, juce::PathStrokeType (0.7f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // the machined step up to the cap
        const float sr = R * 0.80f;
        g.setColour (juce::Colours::black.withAlpha (0.40f));
        g.drawEllipse (cx - sr, cy - sr, sr * 2.0f, sr * 2.0f, 0.9f);
        g.setColour (juce::Colours::white.withAlpha (0.45f));
        g.drawEllipse (cx - sr + 0.8f, cy - sr + 0.9f, sr * 2.0f - 1.6f, sr * 2.0f - 1.6f, 0.6f);

        // the domed cap
        const float cr = R * 0.72f;
        juce::ColourGradient dome (c (0xfffdfdfe), cx - cr * 0.35f, cy - cr * 0.55f, c (0xff858c95), cx + cr * 0.2f, cy + cr * 1.05f, true);
        dome.addColour (0.45, c (0xffd3d7dc));
        dome.addColour (0.78, c (0xff9aa1aa));
        g.setGradientFill (dome);
        g.fillEllipse (cx - cr, cy - cr, cr * 2.0f, cr * 2.0f);
        juce::ColourGradient rim (juce::Colours::white.withAlpha (0.95f), 0.0f, cy - cr, juce::Colours::black.withAlpha (0.45f), 0.0f, cy + cr, false);
        g.setGradientFill (rim);
        g.drawEllipse (cx - cr, cy - cr, cr * 2.0f, cr * 2.0f, 0.9f);

        // the dark polished centre: gunmetal chrome reflecting the dark room, a soft window of light on it
        const float mr = R * 0.40f;
        juce::Path disc;
        disc.addEllipse (cx - mr, cy - mr, mr * 2.0f, mr * 2.0f);
        juce::ColourGradient metal (c (0xff4a4f56), cx - mr, cy - mr, c (0xff8a9099), cx + mr * 0.7f, cy + mr, false);
        metal.addColour (0.38, c (0xff1c1f23));
        metal.addColour (0.62, c (0xff2b2f34));
        g.setGradientFill (metal);
        g.fillPath (disc);
        {
            juce::Graphics::ScopedSaveState ss (g);
            g.reduceClipRegion (disc);
            juce::ColourGradient window (juce::Colours::white.withAlpha (0.42f), cx - mr * 0.35f, cy - mr * 0.45f,
                                         juce::Colours::white.withAlpha (0.0f), cx - mr * 0.35f + mr * 0.75f, cy - mr * 0.45f, true);
            g.setGradientFill (window);
            g.fillPath (disc);
            g.setColour (juce::Colours::black.withAlpha (0.35f));   // the cap's edge throws a little shadow into it
            g.drawEllipse (cx - mr + 0.3f, cy - mr + 0.6f, mr * 2.0f, mr * 2.0f, juce::jmax (0.8f, mr * 0.10f));
        }
        juce::ColourGradient bevel (juce::Colours::black.withAlpha (0.45f), 0.0f, cy - mr, juce::Colours::white.withAlpha (0.75f), 0.0f, cy + mr, false);
        g.setGradientFill (bevel);
        g.drawEllipse (cx - mr, cy - mr, mr * 2.0f, mr * 2.0f, juce::jmax (0.6f, mr * 0.06f));
    }
}
}
