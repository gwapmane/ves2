// VESPER: catching what you played and keeping a performance.
// - MIDI RECALL: everything VESPER sends goes into a ring; CATCH turns the last 16 bars into a take and a file.
// - PERFORMANCE: the sections as you played them and the calls you made; KEEP AS SONG makes that the song.
// - per-track EXT: hold a track's own key and only that track adds the upper extension.
// - MOOD (dark .. bright) and GLIDE: sent to the instruments as CC74 / CC5 + CC65, and used by the built-in keys.
#include "PluginProcessor.h"

using namespace vesper;

//==============================================================================
bool VesperProcessor::catchRecall()
{
    if (recording.load()) return false;   // a take is being recorded: it already has everything
    const int64_t written = recallWrite.load (std::memory_order_acquire);
    const int64_t cap = (int64_t) recall.size();
    if (written <= 0 || cap == 0) return false;
    const int64_t have = std::min (written, cap);
    std::vector<RecEvent> evs;
    evs.reserve ((size_t) have);
    for (int64_t i = written - have; i < written; ++i) evs.push_back (recall[(size_t) (i % cap)]);
    // anything the audio thread wrote over while we copied is the oldest stuff: drop it
    const int64_t after = recallWrite.load (std::memory_order_acquire);
    const int64_t lost = std::max<int64_t> (0, after - written);
    if (lost >= (int64_t) evs.size()) return false;
    evs.erase (evs.begin(), evs.begin() + (std::ptrdiff_t) lost);
    double last = -1e18;
    for (const auto& e : evs) if (e.kind == 0) last = std::max (last, e.beat);
    if (last < -1e17) return false;
    // the last 16 bars, from a bar line
    const double from = std::floor ((last + 1.0 - 64.0) / 4.0) * 4.0;
    int n = 0, ons = 0;
    uint32_t mask = 0;
    for (const auto& e : evs)
    {
        if (e.beat < from - 1e-9 || n >= (int) rec.size()) continue;
        RecEvent r = e;
        r.beat = e.beat - from;
        r.synced = 1;   // keep it on the bar lines (bar 1 = the first caught bar)
        rec[(size_t) n++] = r;
        if (r.kind == 0) { ++ons; mask |= 1u << (r.channel - 1); }
    }
    if (ons == 0) return false;
    recChannelMask.store (mask);
    recordedNoteOns.store (ons);
    takeSynced.store (false);
    recCount.store (n, std::memory_order_release);
    lastCatchFile = exportRecording (0, "Caught");
    return true;
}

//==============================================================================
void VesperProcessor::perfBar (int sec, bool newSection)
{
    int c = perfSegCount.load (std::memory_order_relaxed);
    if (newSection || c == 0)
    {
        if (c >= (int) perfSegSec.size()) return;
        perfSegSec[(size_t) c].store (sec, std::memory_order_relaxed);
        perfSegBars[(size_t) c].store (1, std::memory_order_relaxed);
        perfSegCount.store (c + 1, std::memory_order_release);
    }
    else perfSegBars[(size_t) (c - 1)].fetch_add (1, std::memory_order_relaxed);
}

void VesperProcessor::perfSync() const
{
    const uint32_t starts = perfStarts.load();
    if (starts == perfStartsSeen) return;
    perfStartsSeen = starts;
    perfCalls.clear();
    perfPlan = songPlanCopy();
}

void VesperProcessor::perfLog (int cmd, int arg)
{
    if (! songOn.load()) return;
    const juce::ScopedLock sl (perfLock);
    perfSync();
    const int segs = perfSegCount.load();
    if (perfPlan.sections.empty()) perfPlan = songPlanCopy();
    PerfCall c;
    c.seg = juce::jmax (0, segs - 1);
    c.bar = juce::jmax (0, perfSegBars[(size_t) c.seg].load() - 1);
    c.cmd = cmd;
    c.arg = arg;
    if (perfCalls.size() < 2048) perfCalls.push_back (c);
    perfChanged.fetch_add (1);
}

void VesperProcessor::clearPerformance()
{
    const juce::ScopedLock sl (perfLock);
    perfCalls.clear();
    perfSegCount.store (0);
    perfPlan = songPlanCopy();
    perfChanged.fetch_add (1);
}

juce::String VesperProcessor::performanceText() const
{
    const auto now = songPlanCopy();
    const juce::ScopedLock sl (perfLock);
    perfSync();
    const int segs = perfSegCount.load();
    if (segs == 0) return {};
    const auto& plan = perfPlan.sections.empty() ? now : perfPlan;
    juce::StringArray parts;
    for (int i = 0; i < segs; ++i)
    {
        const int sec = perfSegSec[(size_t) i].load();
        juce::String t = (sec >= 0 && sec < (int) plan.sections.size()) ? juce::String (plan.sections[(size_t) sec].label) : juce::String ("?");
        t << " " << perfSegBars[(size_t) i].load();
        juce::StringArray calls;
        for (const auto& c : perfCalls)
            if (c.seg == i)
            {
                if (c.cmd == CmdMoment) calls.add (songMomentName (c.arg));
                else if (c.cmd == CmdSolo) calls.add ("SOLO");
                else if (c.cmd == CmdJam) calls.add ("JAM");
                else if (c.cmd == CmdTransition) calls.add ("TRANSITION");
            }
        if (! calls.isEmpty()) t << " (" << calls.joinIntoString (", ") << ")";
        parts.add (t);
    }
    return parts.joinIntoString ("  >  ");
}

bool VesperProcessor::keepPerformanceAsSong()
{
    SongPlan out;
    const auto now = songPlanCopy();
    {
        const juce::ScopedLock sl (perfLock);
        perfSync();
        const int segs = perfSegCount.load();
        const auto& src = perfPlan.sections.empty() ? now : perfPlan;
        if (segs == 0 || src.sections.empty()) return false;
        out.genre = src.genre;
        out.number = src.number;
        for (int i = 0; i < segs; ++i)
        {
            const int sec = juce::jlimit (0, (int) src.sections.size() - 1, perfSegSec[(size_t) i].load());
            const int bars = juce::jlimit (1, 256, perfSegBars[(size_t) i].load());
            SongSection s = src.sections[(size_t) sec];
            // as long as it actually played: the bar pattern repeats when it ran longer than written
            std::vector<uint16_t> mask ((size_t) bars);
            std::vector<uint8_t> mom ((size_t) bars, (uint8_t) MomNone);
            for (int b = 0; b < bars; ++b)
            {
                const int k = s.bars > 0 ? b % s.bars : 0;
                mask[(size_t) b] = k < (int) s.mask.size() ? s.mask[(size_t) k] : (uint16_t) 0xffff;
                if (b < s.bars && b < (int) s.moment.size()) mom[(size_t) b] = s.moment[(size_t) b];
            }
            // the moments you called land where you called them
            for (const auto& c : perfCalls)
                if (c.seg == i && c.cmd == CmdMoment && c.arg > 0 && c.arg < numSongMoments)
                    mom[(size_t) juce::jlimit (0, bars - 1, c.bar)] = (uint8_t) c.arg;
            s.bars = bars;
            s.mask = std::move (mask);
            s.moment = std::move (mom);
            out.sections.push_back (std::move (s));
        }
    }
    {
        const juce::SpinLock::ScopedLockType sl (songLock);
        songPlan = std::move (out);
    }
    songPlanChanged.fetch_add (1);
    return true;
}

//==============================================================================
// per-track EXT: the extension of the chord playing, in that track's own register and channel
void VesperProcessor::updateTrackExt (int pos, juce::MidiBuffer& out)
{
    const uint16_t held = trackExtHeld;
    const bool newChord = bandHarm.id != trackExtHarm;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const uint16_t bit = (uint16_t) (1u << t);
        const int si = trackExtSlot (t);
        const bool want = (held & bit) != 0 && bandHarm.valid();
        const bool on = (trackExtOn & bit) != 0;
        if (on && (! want || newChord))
        {
            clearSlotNotes (si, pos, out);
            slots[(size_t) si].active = false;
            trackExtOn = (uint16_t) (trackExtOn & ~bit);
        }
        if (! want || (trackExtOn & bit) != 0) continue;
        const auto& tc = bandCfg.part[(size_t) t];
        if (! tc.on || bandTypeIsDrums (tc.type) || tc.type == BBass) continue;
        Notes e = upperExtension (bandHarm.chord, lastVoicing.empty() ? bandHarm.voicing : lastVoicing, st.extType, cfg.keyRoot, cfg.scale);
        if (e.empty()) continue;
        e.sort();
        auto& s = slots[(size_t) si];
        s = Slot();
        s.active = true;
        s.source = -300 - t;
        const bool oneNote = tc.type == BMelody || tc.type == BCounter;
        const int vel = juce::jlimit (1, 127, juce::roundToInt (96.0f * (0.45f + 0.75f * tc.level)));
        for (int i = oneNote ? e.size() - 1 : 0; i < e.size(); ++i)
        {
            const int n = e[i] + 12 * tc.octave;
            if (n >= 0 && n <= 127) schedule (sampleClock + pos, n, vel, tc.channel, si, -1);
        }
        trackExtOn = (uint16_t) (trackExtOn | bit);
        partHits[(size_t) t].fetch_add (1, std::memory_order_relaxed);
    }
    trackExtHarm = bandHarm.id;
    trackExtLit.store (trackExtOn);
}

//==============================================================================
// MOOD: CC74 (brightness / filter on most synths) on every channel VESPER plays; GLIDE: CC5 time + CC65 on/off
void VesperProcessor::sendMoodGlide (juce::MidiBuffer& out)
{
    const float mood = apvts.getRawParameterValue (ids::mood)->load();     // -1 dark .. +1 bright
    const float glide = apvts.getRawParameterValue (ids::glide)->load();   // 0 .. 1 (seconds)
    synth.setMood (mood);
    synth.setGlide (glide);
    const int moodCC = juce::jlimit (0, 127, juce::roundToInt (64.0f + mood * 63.0f));
    const int glideCC = juce::jlimit (0, 127, juce::roundToInt (std::sqrt (glide) * 127.0f));
    if (moodCC == lastMoodCC && glideCC == lastGlideCC) return;
    uint16_t chans = (uint16_t) (1u << (chordChannel - 1));
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const auto& tc = bandCfg.part[(size_t) t];
        if (tc.on && ! bandTypeIsDrums (tc.type)) chans = (uint16_t) (chans | (1u << (tc.channel - 1)));
    }
    for (int ch = 1; ch <= 16; ++ch)
    {
        if (! ((chans >> (ch - 1)) & 1u)) continue;
        if (moodCC != lastMoodCC) out.addEvent (juce::MidiMessage::controllerEvent (ch, 74, moodCC), 0);
        if (glideCC != lastGlideCC)
        {
            out.addEvent (juce::MidiMessage::controllerEvent (ch, 5, glideCC), 0);
            out.addEvent (juce::MidiMessage::controllerEvent (ch, 65, glideCC > 0 ? 127 : 0), 0);
        }
    }
    lastMoodCC = moodCC;
    lastGlideCC = glideCC;
}

//==============================================================================
// LIKE / SKIP: kept by the line's own text, so it survives new versions of VESPER
namespace
{
juce::File ratingsFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("VESPER").getChildFile ("Phrase Ratings.txt");
}

void saveRatings()
{
    const auto& lib = phraseLibrary();
    juce::StringArray lines;
    for (int i = 0; i < (int) lib.size(); ++i)
        if (lib[(size_t) i].base == i && phraseRating (i) != 0)
            lines.add ((phraseRating (i) > 0 ? "+1|" : "-1|") + juce::String (lib[(size_t) i].text));
    ratingsFile().getParentDirectory().createDirectory();
    ratingsFile().replaceWithText (lines.joinIntoString ("\n") + (lines.isEmpty() ? "" : "\n"));
}
} // namespace

void loadPhraseRatings()
{
    static bool loaded = false;   // once per FL session: every VESPER shares them
    if (loaded) return;
    loaded = true;
    juce::StringArray lines;
    ratingsFile().readLines (lines);
    const auto& lib = phraseLibrary();
    for (const auto& l : lines)
    {
        const int r = l.startsWith ("+1|") ? 1 : (l.startsWith ("-1|") ? -1 : 0);
        if (r == 0) continue;
        const auto text = l.fromFirstOccurrenceOf ("|", false, false);
        for (int i = 0; i < (int) lib.size(); ++i)
            if (lib[(size_t) i].base == i && text == juce::String (lib[(size_t) i].text)) { setPhraseRating (i, r); break; }
    }
}

void VesperProcessor::ratePhrase (int track, int rating)
{
    if (track < 0 || track >= maxBandTracks) return;
    const int id = trackPhraseNow[(size_t) track].load();
    if (id < 0) return;
    setPhraseRating (id, rating);
    saveRatings();
}

void VesperProcessor::forgetPhraseRatings()
{
    clearPhraseRatings();
    saveRatings();
}

int VesperProcessor::likedLines() const
{
    int n = 0;
    const auto& lib = phraseLibrary();
    for (int i = 0; i < (int) lib.size(); ++i) if (lib[(size_t) i].base == i && phraseRating (i) > 0) ++n;
    return n;
}

int VesperProcessor::skippedLines() const
{
    int n = 0;
    const auto& lib = phraseLibrary();
    for (int i = 0; i < (int) lib.size(); ++i) if (lib[(size_t) i].base == i && phraseRating (i) < 0) ++n;
    return n;
}
