// VESPER: MY GROOVES - your own drum grooves, from a folder you keep adding to.
// Documents/VESPER/My Grooves has a folder for every genre (and ANY GENRE, for all of them). Drop drum MIDI files in
// and they show up at the bottom of that genre's GROOVE list on the BAND tab - VESPER looks every couple of seconds,
// so there's nothing to restart. Any drum layout works (MPC, FPC, sample packs): the kick, snare and hats are found and
// moved to the standard notes, the same way as a file dropped on a drum track.
#include "PluginProcessor.h"
#include "../core/Beatbox.h"
#include <juce_audio_formats/juce_audio_formats.h>

#include <map>

using namespace vesper;

bool readMidiParts (const juce::File& f, std::vector<DrumPart>& parts)
{
    juce::FileInputStream in (f);
    juce::MidiFile mf;
    if (! in.openedOk() || ! mf.readFrom (in)) return false;
    const int tpq = mf.getTimeFormat() > 0 ? mf.getTimeFormat() : 960;
    const auto fileName = f.getFileNameWithoutExtension();
    std::vector<DrumPart> mine;
    for (int t = 0; t < mf.getNumTracks(); ++t)
    {
        juce::MidiMessageSequence seq (*mf.getTrack (t));
        seq.updateMatchedPairs();
        DrumPart part;
        juce::String trackName;
        for (int i = 0; i < seq.getNumEvents(); ++i)
        {
            const auto& m = seq.getEventPointer (i)->message;
            if (m.isTrackNameEvent() && trackName.isEmpty()) trackName = m.getTextFromTextMetaEvent().trim();
            if (! m.isNoteOn()) continue;
            ClipNote cn;
            cn.start = (float) (m.getTimeStamp() * 4.0 / tpq);
            const int up = seq.getIndexOfMatchingKeyUp (i);
            const double end = up >= 0 ? seq.getEventPointer (up)->message.getTimeStamp() : m.getTimeStamp() + tpq / 4.0;
            cn.len = (float) juce::jmax (0.1, (end - m.getTimeStamp()) * 4.0 / tpq);
            cn.note = m.getNoteNumber();
            cn.vel = juce::jlimit (1, 127, (int) m.getVelocity());
            part.notes.push_back (cn);
        }
        if (part.notes.empty()) continue;
        // a real name (FL: the channel's), not "Track 3" / "MIDI 01"
        const auto low = trackName.toLowerCase();
        const bool generic = trackName.isEmpty() || low.startsWith ("track") || low.startsWith ("midi") || low.startsWith ("untitled")
                             || low.startsWith ("pattern") || low.containsOnly ("0123456789 ");
        part.name = (generic ? fileName : trackName).toStdString();
        mine.push_back (std::move (part));
    }
    // a file of one part is named after the file (kick.mid), even if its track says "Pattern 1"
    if (mine.size() == 1) mine[0].name = fileName.toStdString();
    else if (! mine.empty())
    {   // several unnamed tracks in one file: keep them apart
        int k = 0;
        for (auto& p : mine) if (p.name == fileName.toStdString()) p.name += " " + std::to_string (++k);
    }
    for (auto& p : mine) parts.push_back (std::move (p));
    return true;
}

namespace
{
const char* anyGenreFolder = "ANY GENRE";

// a groove from drum MIDI: one file (a loop, or an FL export with a track per sound), or the parts of one beat
// (kick.mid, snare.mid, hats.mid... in one folder)
bool readGroove (const juce::Array<juce::File>& files, const juce::String& name, Groove& g)
{
    std::vector<DrumPart> parts;
    for (const auto& f : files) readMidiParts (f, parts);
    if (parts.empty()) return false;
    MidiClip clip;
    if (looksLikeDrumParts (parts)) clip = mergeDrumParts (parts, name.toStdString());
    else
    {
        clip.name = name.toStdString();
        for (const auto& p : parts) clip.notes.insert (clip.notes.end(), p.notes.begin(), p.notes.end());
        finishClip (clip);
        mapDrumRoles (clip);
    }
    if (clip.notes.empty()) return false;
    g = Groove();
    g.name = name.toUpperCase().substring (0, 40).toStdString();
    g.bars = juce::jlimit (1, 8, clip.bars);
    for (const auto& cn : clip.notes)
    {
        if (cn.start < 0.0f || cn.start >= (float) (g.bars * 16)) continue;
        GrooveHit h;
        h.step = (int) std::floor (cn.start);
        h.off = cn.start - (float) h.step;
        h.feel = 0.0f;
        h.len = juce::jmin (cn.len, 1.0f);
        h.note = cn.note;
        h.vel = cn.vel;
        h.piece = drumPieceOf (cn.note);
        g.hits.push_back (h);
    }
    g.busy = (int) g.hits.size();
    g.family = -1;   // a plain loop: the band adds the fills and crashes at the end of the phrase
    return ! g.hits.empty();
}
} // namespace

// ---- BEATBOX: drop a recording of you beatboxing on the drum track (or its MIDI menu > BEATBOX)
juce::File VesperProcessor::beatboxFolder()
{
    return juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER").getChildFile ("Beatbox");
}

bool VesperProcessor::isBeatboxAudio (const juce::File& f)
{
    return f.existsAsFile() && f.hasFileExtension ("wav;wave;aif;aiff;flac;ogg;mp3;m4a;wma;aac");
}

juce::String VesperProcessor::loadBeatbox (int track, const juce::File& audio)
{
    int t = track;   // the drum track: this one, or the first one there is
    if (t < 0 || t >= numTracks.load() || ! bandTypeIsDrums (trackType (t)))
    {
        t = -1;
        for (int i = 0; i < numTracks.load() && t < 0; ++i) if (bandTypeIsDrums (trackType (i))) t = i;
    }
    if (t < 0) return "BEATBOX needs a drum track: add one on the BAND tab (+ TRACK), then drop your recording on it.";
    juce::AudioFormatManager fm;
    fm.registerBasicFormats();
    std::unique_ptr<juce::AudioFormatReader> rd (fm.createReaderFor (audio));
    if (rd == nullptr || rd->sampleRate < 8000 || rd->lengthInSamples <= 0)
        return "BEATBOX can't read " + audio.getFileName() + ". Save it as a WAV (Edison: Save sample as) and drop that.";
    const int n = (int) juce::jmin (rd->lengthInSamples, (juce::int64) (rd->sampleRate * 64.0));
    const int chans = juce::jlimit (1, 2, (int) rd->numChannels);
    juce::AudioBuffer<float> buf (chans, n);
    buf.clear();
    rd->read (&buf, 0, n, 0, true, chans > 1);
    std::vector<float> mono ((size_t) n);
    for (int i = 0; i < n; ++i)
    {
        float s = 0;
        for (int c = 0; c < chans; ++c) s += buf.getSample (c, i);
        mono[(size_t) i] = s / (float) chans;
    }
    const auto res = beatboxToDrums (mono, rd->sampleRate, songBpmNow.load());
    if (! res.ok()) return "BEATBOX: " + juce::String (res.summary) + ". Get closer to the mic and give each hit a clear gap.";
    // the beat as a MIDI file you keep (drag it into FL's piano roll to change a hit)
    const auto dir = beatboxFolder();
    dir.createDirectory();
    const auto out = dir.getNonexistentChildFile ("BEATBOX " + juce::Time::getCurrentTime().formatted ("%Y-%m-%d %H-%M-%S"), ".mid", false);
    {
        juce::MidiMessageSequence seq;
        seq.addEvent (juce::MidiMessage::textMetaEvent (3, "BEATBOX"));
        seq.addEvent (juce::MidiMessage::tempoMetaEvent ((int) std::lround (60000000.0 / juce::jmax (40.0, res.bpm))));
        for (const auto& cn : res.notes)
        {
            auto on = juce::MidiMessage::noteOn (10, cn.note, (juce::uint8) juce::jlimit (1, 127, cn.vel));
            on.setTimeStamp (cn.start * 240.0);
            auto off = juce::MidiMessage::noteOff (10, cn.note);
            off.setTimeStamp ((cn.start + cn.len) * 240.0 - 10.0);
            seq.addEvent (on);
            seq.addEvent (off);
        }
        seq.updateMatchedPairs();
        juce::MidiFile mf;
        mf.setTicksPerQuarterNote (960);
        mf.addTrack (seq);
        juce::FileOutputStream os (out);
        if (! os.openedOk() || ! mf.writeTo (os)) return "BEATBOX couldn't save the beat in " + dir.getFullPathName() + ".";
    }
    loadTrackMidi (t, { out.getFullPathName() });
    setTrackValue (t, TpOn, 1.0f);
    return "BEATBOX heard " + juce::String (res.summary) + ".\nIt's playing on track " + juce::String (t + 1)
           + " now, and it's saved as " + out.getFileName() + " in Documents > VESPER > Beatbox.";
}

juce::File VesperProcessor::myGroovesFolder()
{
    return juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER").getChildFile ("My Grooves");
}

juce::String VesperProcessor::myGrooveGenreFolder (int genre)
{
    return juce::String (genreShort (genre)).replace (" / ", " - ").replace ("/", "-");
}

void VesperProcessor::openMyGroovesFolder()
{
    const auto root = myGroovesFolder();
    if (! root.isDirectory()) scanMyGrooves();
    const auto here = root.getChildFile (myGrooveGenreFolder (bandGenreNow()));
    (here.isDirectory() ? here : root).startAsProcess();
}

void VesperProcessor::scanMyGrooves()
{
    const auto root = myGroovesFolder();
    if (! root.isDirectory())
    {
        if (! root.createDirectory()) { myGroovesSig = 0; return; }
        for (int g = 0; g < numGenres; ++g) root.getChildFile (myGrooveGenreFolder (g)).createDirectory();
        root.getChildFile (anyGenreFolder).createDirectory();
        root.getChildFile ("READ ME.txt").replaceWithText (
            "MY GROOVES - your own drum grooves for TROUPE\r\n\r\n"
            "Drop drum MIDI files into the folder of a genre (TRAP, R&B - SOUL...) and they show up at the bottom of that\r\n"
            "genre's GROOVE list on TROUPE's BAND tab, marked MINE. Files in ANY GENRE show up in every genre.\r\n"
            "No need to restart: TROUPE looks in here every couple of seconds.\r\n\r\n"
            "Any drum layout works (MPC, FPC, sample packs): TROUPE finds the kick, snare and hats and moves them to the\r\n"
            "standard drum notes. One to eight bars; a loop gets TROUPE's fills and crashes at the end of each phrase.\r\n\r\n"
            "Made your beat in FL's channel rack, one MIDI file per sound? Put the files of one beat in a folder of their\r\n"
            "own inside a genre folder (TRAP\\My Beat\\kick.mid, snare.mid, hats.mid...). That folder is ONE groove, and every\r\n"
            "part lands on its drum by its name (kick, snare, clap, hat, open hat, rim, tom, perc, shaker...), even if FL\r\n"
            "exported them all on C5. One FL export with a track per channel works the same way.\r\n");
    }
    auto found = root.findChildFiles (juce::File::findFiles, true, "*.mid;*.midi;*.MID;*.MIDI");
    found.sort();
    int64_t sig = 1469598103934665603LL;
    for (const auto& f : found)
    {
        const auto key = f.getFullPathName() + "|" + juce::String (f.getSize()) + "|" + juce::String (f.getLastModificationTime().toMilliseconds());
        sig = (sig ^ (int64_t) key.hashCode64()) * 1099511628211LL;
    }
    sig &= 0x7fffffffffffffffLL;
    if (sig == myGroovesSig) return;
    myGroovesSig = sig;

    auto set = std::make_unique<MyGrooveSet>();
    // a folder of drum parts (kick, snare, hats... one sound per file) is ONE groove, named after the folder
    juce::Array<juce::File> partDirs;
    {
        std::map<juce::String, juce::Array<juce::File>> byDir;
        for (const auto& f : found) byDir[f.getParentDirectory().getFullPathName()].add (f);
        for (auto& [dirPath, list] : byDir)
        {
            const juce::File dir (dirPath);
            if (list.size() < 2 || list.size() > 24 || dir == root || dir.getParentDirectory() == root) continue;   // (genre folders hold loops)
            std::vector<DrumPart> parts;
            for (const auto& f : list) readMidiParts (f, parts);
            if (looksLikeDrumParts (parts)) partDirs.add (dir);
        }
    }
    struct Item { juce::Array<juce::File> files; juce::String name, rel; juce::File where; };
    std::vector<Item> items;
    for (const auto& d : partDirs)
    {
        Item it;
        for (const auto& f : found) if (f.getParentDirectory() == d) it.files.add (f);
        it.name = d.getFileName();
        it.rel = d.getRelativePathFrom (root);
        it.where = d;
        items.push_back (it);
    }
    for (const auto& f : found)
        if (! partDirs.contains (f.getParentDirectory()))
        {
            Item it;
            it.files.add (f);
            it.name = f.getFileNameWithoutExtension();
            it.rel = f.getRelativePathFrom (root);
            it.where = f;
            items.push_back (it);
        }
    for (const auto& it : items)
    {
        if (set->files[0].size() > 2000) break;
        // which genre: the first folder under My Grooves (ANY GENRE, or a file sitting right in My Grooves = every genre)
        auto dir = it.where.getParentDirectory();
        if (it.where == root) continue;
        while (dir.getParentDirectory() != root && dir != root && dir.getParentDirectory() != dir) dir = dir.getParentDirectory();
        if (it.where.getParentDirectory() == root && it.where.isDirectory()) dir = it.where;
        int genre = -1;
        if (dir != root)
            for (int g = 0; g < numGenres; ++g)
                if (dir.getFileName().equalsIgnoreCase (myGrooveGenreFolder (g)) || dir.getFileName().equalsIgnoreCase (genreShort (g))) genre = g;
        Groove gr;
        if (! readGroove (it.files, it.name, gr)) continue;
        const auto rel = it.rel;
        for (int g = 0; g < numGenres; ++g)
            if (genre < 0 || g == genre)
            {
                set->perGenre[(size_t) g].push_back (gr);
                set->files[(size_t) g].add (rel);
            }
    }
    // the one you picked, found again (it may have moved down the list)
    const int genre = bandGenreNow();
    int sel = -1;
    if (myGrooveFile.isNotEmpty()) sel = set->files[(size_t) genre].indexOf (myGrooveFile);
    myGrooves.store (set.get(), std::memory_order_release);
    myGroovesOwned.push_back (std::move (set));
    // the audio thread only ever holds the newest set for one block: older ones can go
    while (myGroovesOwned.size() > 8) myGroovesOwned.erase (myGroovesOwned.begin());
    myGrooveGenre.store (genre);
    myGrooveSel.store (sel);
    myGroovesChanged.fetch_add (1);
}

int VesperProcessor::numMyGrooves (int genre) const
{
    const auto* mg = myGrooves.load();
    return (mg != nullptr && genre >= 0 && genre < numGenres) ? (int) mg->perGenre[(size_t) genre].size() : 0;
}

juce::String VesperProcessor::myGrooveName (int genre, int index) const
{
    const auto* mg = myGrooves.load();
    if (mg == nullptr || genre < 0 || genre >= numGenres || index < 0 || index >= (int) mg->perGenre[(size_t) genre].size()) return {};
    const auto& g = mg->perGenre[(size_t) genre][(size_t) index];
    return "MINE - " + juce::String (g.name) + " (" + juce::String (g.bars) + (g.bars == 1 ? " BAR)" : " BARS)");
}

void VesperProcessor::setMyGroove (int index)
{
    const auto* mg = myGrooves.load();
    const int genre = bandGenreNow();
    if (mg == nullptr || index < 0 || index >= (int) mg->perGenre[(size_t) genre].size())
    {
        if (myGrooveSel.exchange (-1) != -1) myGroovesChanged.fetch_add (1);
        myGrooveFile.clear();
        return;
    }
    myGrooveFile = mg->files[(size_t) genre][index];
    myGrooveGenre.store (genre);
    myGrooveSel.store (index);
    myGroovesChanged.fetch_add (1);
}
