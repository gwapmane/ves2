// VESPER: MY GROOVES - your own drum grooves, from a folder you keep adding to.
// Documents/VESPER/My Grooves has a folder for every genre (and ANY GENRE, for all of them). Drop drum MIDI files in
// and they show up at the bottom of that genre's GROOVE list on the BAND tab - VESPER looks every couple of seconds,
// so there's nothing to restart. Any drum layout works (MPC, FPC, sample packs): the kick, snare and hats are found and
// moved to the standard notes, the same way as a file dropped on a drum track.
#include "PluginProcessor.h"

using namespace vesper;

namespace
{
const char* anyGenreFolder = "ANY GENRE";

bool readGroove (const juce::File& f, Groove& g)
{
    juce::FileInputStream in (f);
    juce::MidiFile mf;
    if (! in.openedOk() || ! mf.readFrom (in)) return false;
    const int tpq = mf.getTimeFormat() > 0 ? mf.getTimeFormat() : 960;
    MidiClip clip;
    clip.name = f.getFileNameWithoutExtension().toStdString();
    for (int t = 0; t < mf.getNumTracks(); ++t)
    {
        juce::MidiMessageSequence seq (*mf.getTrack (t));
        seq.updateMatchedPairs();
        for (int i = 0; i < seq.getNumEvents(); ++i)
        {
            const auto& m = seq.getEventPointer (i)->message;
            if (! m.isNoteOn()) continue;
            ClipNote cn;
            cn.start = (float) (m.getTimeStamp() * 4.0 / tpq);
            const int up = seq.getIndexOfMatchingKeyUp (i);
            const double end = up >= 0 ? seq.getEventPointer (up)->message.getTimeStamp() : m.getTimeStamp() + tpq / 4.0;
            cn.len = (float) juce::jmax (0.1, (end - m.getTimeStamp()) * 4.0 / tpq);
            cn.note = m.getNoteNumber();
            cn.vel = juce::jlimit (1, 127, (int) m.getVelocity());
            clip.notes.push_back (cn);
        }
    }
    if (clip.notes.empty()) return false;
    finishClip (clip);
    mapDrumRoles (clip);
    g = Groove();
    g.name = f.getFileNameWithoutExtension().toUpperCase().substring (0, 40).toStdString();
    g.bars = juce::jlimit (1, 8, clip.bars);
    for (const auto& cn : clip.notes)
    {
        if (cn.start < 0.0f || cn.start >= (float) (g.bars * 16)) continue;
        GrooveHit h;
        h.step = (int) std::floor (cn.start);
        h.off = cn.start - (float) h.step;
        h.feel = 0.0f;
        h.len = juce::jmin (cn.len, 1.0f);
        h.note = cn.note;
        h.vel = cn.vel;
        h.piece = drumPieceOf (cn.note);
        g.hits.push_back (h);
    }
    g.busy = (int) g.hits.size();
    g.family = -1;   // a plain loop: the band adds the fills and crashes at the end of the phrase
    return ! g.hits.empty();
}
} // namespace

juce::File VesperProcessor::myGroovesFolder()
{
    return juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER").getChildFile ("My Grooves");
}

juce::String VesperProcessor::myGrooveGenreFolder (int genre)
{
    return juce::String (genreShort (genre)).replace (" / ", " - ").replace ("/", "-");
}

void VesperProcessor::openMyGroovesFolder()
{
    const auto root = myGroovesFolder();
    if (! root.isDirectory()) scanMyGrooves();
    const auto here = root.getChildFile (myGrooveGenreFolder (bandGenreNow()));
    (here.isDirectory() ? here : root).startAsProcess();
}

void VesperProcessor::scanMyGrooves()
{
    const auto root = myGroovesFolder();
    if (! root.isDirectory())
    {
        if (! root.createDirectory()) { myGroovesSig = 0; return; }
        for (int g = 0; g < numGenres; ++g) root.getChildFile (myGrooveGenreFolder (g)).createDirectory();
        root.getChildFile (anyGenreFolder).createDirectory();
        root.getChildFile ("READ ME.txt").replaceWithText (
            "MY GROOVES - your own drum grooves for VESPER\r\n\r\n"
            "Drop drum MIDI files into the folder of a genre (TRAP, R&B - SOUL...) and they show up at the bottom of that\r\n"
            "genre's GROOVE list on VESPER's BAND tab, marked MINE. Files in ANY GENRE show up in every genre.\r\n"
            "No need to restart: VESPER looks in here every couple of seconds.\r\n\r\n"
            "Any drum layout works (MPC, FPC, sample packs): VESPER finds the kick, snare and hats and moves them to the\r\n"
            "standard drum notes. One to eight bars; a loop gets VESPER's fills and crashes at the end of each phrase.\r\n");
    }
    auto found = root.findChildFiles (juce::File::findFiles, true, "*.mid;*.midi;*.MID;*.MIDI");
    found.sort();
    int64_t sig = 1469598103934665603LL;
    for (const auto& f : found)
    {
        const auto key = f.getFullPathName() + "|" + juce::String (f.getSize()) + "|" + juce::String (f.getLastModificationTime().toMilliseconds());
        sig = (sig ^ (int64_t) key.hashCode64()) * 1099511628211LL;
    }
    sig &= 0x7fffffffffffffffLL;
    if (sig == myGroovesSig) return;
    myGroovesSig = sig;

    auto set = std::make_unique<MyGrooveSet>();
    for (const auto& f : found)
    {
        if (set->files[0].size() > 2000) break;
        // which genre: the first folder under My Grooves (ANY GENRE, or a file sitting right in My Grooves = every genre)
        auto dir = f.getParentDirectory();
        while (dir.getParentDirectory() != root && dir != root && dir.getParentDirectory() != dir) dir = dir.getParentDirectory();
        int genre = -1;
        if (dir != root)
            for (int g = 0; g < numGenres; ++g)
                if (dir.getFileName().equalsIgnoreCase (myGrooveGenreFolder (g)) || dir.getFileName().equalsIgnoreCase (genreShort (g))) genre = g;
        Groove gr;
        if (! readGroove (f, gr)) continue;
        const auto rel = f.getRelativePathFrom (root);
        for (int g = 0; g < numGenres; ++g)
            if (genre < 0 || g == genre)
            {
                set->perGenre[(size_t) g].push_back (gr);
                set->files[(size_t) g].add (rel);
            }
    }
    // the one you picked, found again (it may have moved down the list)
    const int genre = bandGenreNow();
    int sel = -1;
    if (myGrooveFile.isNotEmpty()) sel = set->files[(size_t) genre].indexOf (myGrooveFile);
    myGrooves.store (set.get(), std::memory_order_release);
    myGroovesOwned.push_back (std::move (set));
    // the audio thread only ever holds the newest set for one block: older ones can go
    while (myGroovesOwned.size() > 8) myGroovesOwned.erase (myGroovesOwned.begin());
    myGrooveGenre.store (genre);
    myGrooveSel.store (sel);
    myGroovesChanged.fetch_add (1);
}

int VesperProcessor::numMyGrooves (int genre) const
{
    const auto* mg = myGrooves.load();
    return (mg != nullptr && genre >= 0 && genre < numGenres) ? (int) mg->perGenre[(size_t) genre].size() : 0;
}

juce::String VesperProcessor::myGrooveName (int genre, int index) const
{
    const auto* mg = myGrooves.load();
    if (mg == nullptr || genre < 0 || genre >= numGenres || index < 0 || index >= (int) mg->perGenre[(size_t) genre].size()) return {};
    const auto& g = mg->perGenre[(size_t) genre][(size_t) index];
    return "MINE - " + juce::String (g.name) + " (" + juce::String (g.bars) + (g.bars == 1 ? " BAR)" : " BARS)");
}

void VesperProcessor::setMyGroove (int index)
{
    const auto* mg = myGrooves.load();
    const int genre = bandGenreNow();
    if (mg == nullptr || index < 0 || index >= (int) mg->perGenre[(size_t) genre].size())
    {
        if (myGrooveSel.exchange (-1) != -1) myGroovesChanged.fetch_add (1);
        myGrooveFile.clear();
        return;
    }
    myGrooveFile = mg->files[(size_t) genre][index];
    myGrooveGenre.store (genre);
    myGrooveSel.store (index);
    myGroovesChanged.fetch_add (1);
}
