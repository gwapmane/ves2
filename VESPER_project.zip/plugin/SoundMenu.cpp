#include "SoundMenu.h"
#include "PluginProcessor.h"

#include <map>

juce::String soundButtonText (const VesperProcessor& p, int slot)
{
    const auto n = p.rack.name (slot);
    if (n.isNotEmpty()) return n;
    if (p.rack.missing (slot).isNotEmpty()) return "MISSING: " + p.rack.missing (slot);
    return "+ SOUND";
}

static void loadInto (VesperProcessor& p, int slot, const juce::File& f)
{
    juce::String err;
    if (p.rack.load (slot, f, err)) p.rack.showWindow (slot, p.slotTitle (slot));   // straight to its window: pick a preset
    else juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon, "VESPER", err);
}

void showSoundMenu (VesperProcessor& p, int slot, juce::Component& target)
{
    juce::PopupMenu m;
    const bool has = p.rack.loaded (slot);
    const auto nm = p.rack.name (slot);
    m.addSectionHeader (p.slotChannelName (slot));
    if (has)
    {
        m.addItem (1, "Open " + nm + " (pick a preset, tweak it)");
        m.addSeparator();
    }
    else if (p.rack.missing (slot).isNotEmpty())
        m.addSectionHeader ("Couldn't find " + p.rack.missing (slot) + " - load it again below");

    const int own = p.rack.ownOutput[(size_t) slot].load();
    m.addItem (2, "Plays on VESPER's MAIN output", true, own == 0);
    m.addItem (3, "Plays on its own output (" + InstrumentRack::outputName (slot) + ") - its own mixer track in FL", true, own != 0);
    m.addSeparator();

    m.addSectionHeader (has ? "SWAP IT FOR..." : "LOAD AN INSTRUMENT");
    const auto files = InstrumentRack::installedInstruments();
    if (files.isEmpty()) m.addItem (-1, "(no VST3 instruments in the usual folder)", false);
    else if (files.size() <= 30)
    {
        for (int i = 0; i < files.size(); ++i) m.addItem (100 + i, files[i].getFileNameWithoutExtension(), true, files[i].getFileNameWithoutExtension() == nm);
    }
    else
    {
        std::map<juce::String, juce::PopupMenu> byLetter;   // lots of plugins: A, B, C...
        for (int i = 0; i < files.size(); ++i)
        {
            const auto name = files[i].getFileNameWithoutExtension();
            const auto c = juce::String::charToString (juce::CharacterFunctions::toUpperCase (name[0]));
            byLetter[juce::CharacterFunctions::isLetter (name[0]) ? c : juce::String ("#")].addItem (100 + i, name, true, name == nm);
        }
        for (auto& kv : byLetter) m.addSubMenu (kv.first, kv.second);
    }
    m.addItem (4, "Find an instrument file (.vst3)...");
    if (has || p.rack.missing (slot).isNotEmpty())
    {
        m.addSeparator();
        m.addItem (5, "Remove the instrument (back to MIDI out)");
    }

    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&target), [&p, slot, files] (int r)
    {
        if (r == 1) p.rack.showWindow (slot, p.slotTitle (slot));
        else if (r == 2 || r == 3) p.rack.ownOutput[(size_t) slot].store (r == 3 ? 1 : 0);
        else if (r == 5) p.rack.unload (slot);
        else if (r >= 100 && r - 100 < files.size()) loadInto (p, slot, files[r - 100]);
        else if (r == 4)
        {
            static std::unique_ptr<juce::FileChooser> chooser;
            chooser = std::make_unique<juce::FileChooser> ("Pick an instrument (.vst3)", juce::File(), "*.vst3");
            chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles
                                      | juce::FileBrowserComponent::canSelectDirectories,
                                  [&p, slot] (const juce::FileChooser& fc)
                                  {
                                      const auto f = fc.getResult();
                                      if (f != juce::File()) loadInto (p, slot, f);
                                  });
        }
        p.rack.changed.fetch_add (1);
    });
}
