#include "PluginEditor.h"
#include "Chrome.h"
#include "SoundMenu.h"

using namespace vesper;

static void writeCards (juce::XmlElement& x, const Palette& pal)
{
    for (const auto& card : pal)
    {
        auto* c = x.createNewChildElement ("CARD");
        c->setAttribute ("valid", card.chord.valid() ? 1 : 0);
        c->setAttribute ("root", card.chord.root);
        c->setAttribute ("type", card.chord.valid() ? toJ (qualities()[(size_t) card.chord.quality].suffix) : juce::String());
        c->setAttribute ("bass", card.chord.bass);
        c->setAttribute ("style", card.style);
        c->setAttribute ("variant", card.variant);
    }
}

static Palette readCards (const juce::XmlElement& x)
{
    Palette pal {};
    int i = 0;
    for (auto* c : x.getChildWithTagNameIterator ("CARD"))
    {
        if (i >= paletteSize) break;
        Card card;
        if (c->getIntAttribute ("valid", 0) != 0)
            card.chord = makeChord (c->getIntAttribute ("root", 0), c->getStringAttribute ("type").toStdString(), c->getIntAttribute ("bass", -1));
        card.style = juce::jlimit (-1, numStyles - 1, c->getIntAttribute ("style", -1));
        card.variant = c->getIntAttribute ("variant", -1);
        pal[(size_t) i++] = card;
    }
    return pal;
}

//==============================================================================
VesperEditor::VesperEditor (VesperProcessor& proc)
    : AudioProcessorEditor (proc), p (proc)
{
    loadSkin();
    look.setTheme (skinnedTheme());
    setLookAndFeel (&look);
    addAndMakeVisible (canvas);
    canvas.setBounds (0, 0, baseW, baseH);
    canvas.painter = [this] (juce::Graphics& g) { paintCanvas (g); };

    // ---- header
    static const char* keyNames[] = { "C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B" };
    for (int i = 0; i < 12; ++i) keyBox.addItem (keyNames[i], i + 1);
    for (int i = 0; i < numScales(); ++i) scaleBox.addItem (toJ (scales()[(size_t) i].name), i + 1);
    fillStyleBox();
    keyBox.onChange = [this] { p.setKeyScaleGenre (keyBox.getSelectedId() - 1, p.ui.scale, p.ui.genre, false); refreshAll(); };
    scaleBox.onChange = [this] { p.setKeyScaleGenre (p.ui.keyRoot, scaleBox.getSelectedId() - 1, p.ui.genre, false); refreshAll(); };
    styleBox.onChange = [this]
    {
        const int id = styleBox.getSelectedId();
        if (id > 1000)
        {   // a VOICE SET: VARY mixes it, starting on its first voicing
            p.ui.voiceSet = id - 1001;
            p.ui.style = voiceSetFor (p.ui.genre, p.ui.voiceSet).styles[0];
        }
        else if (id > 0)
        {   // one style: VARY only re-voices it
            p.ui.voiceSet = -1;
            p.ui.style = id - 1;
        }
        p.applyUiState();
        refreshAll();
    };
    spiceKnob.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    spiceKnob.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    spiceKnob.setRange (0.0, 100.0, 1.0);
    spiceKnob.setDoubleClickReturnValue (true, 50.0);
    spiceKnob.setPopupDisplayEnabled (true, true, nullptr);
    spiceKnob.setTextValueSuffix (" spice");
    spiceKnob.setTooltip ("SPICE: how adventurous the chords get. Below the middle they get plainer (9ths become 7ths, then "
                          "triads) and VARY only picks the smoothest voicings. Above the middle VARY has more to pick from and "
                          "the top note may move further. Right at the top, the whole genre's voicings come in. "
                          "Double-click: the middle");
    spiceKnob.onValueChange = [this] { p.ui.spice = (int) spiceKnob.getValue(); p.applyUiState(); };
    canvas.addAndMakeVisible (spiceKnob);
    chordSetBox.setTooltip ("CHORD SETS: 24 pads as six progressions of four that move and resolve the way this genre does - "
                            "play pads 1-2-3-4, 5-6-7-8... left to right. Different sets for major and minor keys. CLASSIC = "
                            "the genre's own 24 (DICE rolls new ones). LOCKED pads stay. SPICE makes any set plainer");
    chordSetBox.onChange = [this]
    {
        const int idx = chordSetBox.getSelectedId() - 1;
        if (idx < 0 || idx == p.ui.chordSet) return;
        auto pal = buildChordSet (p.ui.keyRoot, p.ui.scale, p.ui.genre, idx);
        for (int i = 0; i < paletteSize; ++i) if ((p.ui.padLocks >> i) & 1u) pal[(size_t) i] = p.ui.palette[(size_t) i];
        p.ui.chordSet = idx;
        p.setPalette (pal);
        paletteEdited();
        refreshAll();
        canvas.repaint();
    };
    canvas.addAndMakeVisible (chordSetBox);
    toLoopsBtn.setTooltip ("TO LOOPS A-D: the rows of pads become your four loops, one chord a bar (A = verse, B = hook, "
                           "C = bridge, D = pre-hook). Then PLAY SONG on the SONG tab and the whole song plays itself - "
                           "no keys needed. The loops play these pads in any KEYS PLAY mode");
    toLoopsBtn.onClick = [this] { showToLoopsMenu(); };
    canvas.addAndMakeVisible (toLoopsBtn);
    keyBox.setTooltip ("The key you're playing in");
    scaleBox.setTooltip ("The scale: SCALE mode gives you every chord that lives in it");
    styleBox.setTooltip ("How chords are stacked. VOICE SETS (made for this genre): what VARY mixes - a few voicings that sound "
                         "right together. ONE STYLE: every chord stacked the same way (pads can override this)");

    for (int g = 0; g < numGenres; ++g) genreBox.addItem (genreName (g), g + 1);
    genreBox.setTooltip ("The chord flavour: changes the pads, the voicing style and the colour chords");
    genreBox.onChange = [this]
    {
        const int g = genreBox.getSelectedId() - 1;
        if (g < 0 || g == p.ui.genre) return;
        p.setKeyScaleGenre (p.ui.keyRoot, p.ui.scale, g, false);
        // the band's grooves and VESPER DRUMS follow this genre too (the BAND tab can still pick its own)
        if (auto* prm = p.apvts.getParameter (ids::bandGenre)) prm->setValueNotifyingHost (prm->convertTo0to1 ((float) g));
        refreshAll();
    };
    canvas.addAndMakeVisible (genreBox);

    // STACK: the whole chord, or one note / octaves / stacked 3rds... per key
    static const char* stackShort[numStackModes] = { "CHORD", "1 NOTE", "OCTAVES", "3RDS", "4THS", "5THS", "6THS", "POWER" };
    for (int m = 0; m < numStackModes; ++m) stackBox.addItem (stackShort[m], m + 1);
    stackBox.setTooltip ("STACK: what each key plays. CHORD = the whole chord. 1 NOTE = just the chord's root, in the octave "
                         "of the key you press (play melodies; HOLD tracks on the BAND tab double it). OCTAVES / 3RDS / 4THS / "
                         "5THS / 6THS = notes stacked that far apart, in your key. POWER = root, 5th, octave");
    stackNotesBox.addItemList ({ "2", "3", "4" }, 1);
    stackNotesBox.setTooltip ("How many notes STACK piles up (octaves, 3rds, 4ths, 5ths, 6ths)");
    stackBox.onChange = [this]
    {
        const int m = stackBox.getSelectedId() - 1;
        stackNotesBox.setEnabled (m >= StackOctaves && m <= Stack6ths);
    };
    canvas.addAndMakeVisible (stackBox);
    canvas.addAndMakeVisible (stackNotesBox);
    varyBtn.setTooltip ("VARY: every chord picks from the VOICE SET in the VOICING box - one of the smoothest ways to get there "
                        "from the last chord, a different one each time, the top note following the way your chords move. Hit "
                        "the same chord again and it always comes back re-voiced. With one style picked, VARY only re-voices "
                        "that style. SPICE: how adventurous");
    diceBtn.setTooltip ("Roll a fresh set of pads for this genre");
    diceBtn.onClick = [this]
    {
        p.ui.diceSeed = (uint32_t) juce::Random::getSystemRandom().nextInt (juce::Range<int> (1, 1 << 30));
        p.ui.chordSet = 0;
        auto pal = buildPalette (p.ui.keyRoot, p.ui.scale, p.ui.genre, p.ui.diceSeed);
        for (int i = 0; i < paletteSize; ++i) if ((p.ui.padLocks >> i) & 1u) pal[(size_t) i] = p.ui.palette[(size_t) i];   // LOCKED pads stay
        p.setPalette (pal);
        paletteEdited();
    };
    menuBtn.onClick = [this] { showMenu(); };
    for (juce::Component* c : { (juce::Component*) &keyBox, (juce::Component*) &scaleBox, (juce::Component*) &styleBox,
                                (juce::Component*) &varyBtn, (juce::Component*) &diceBtn, (juce::Component*) &menuBtn })
        canvas.addAndMakeVisible (c);

    // ---- tabs and modes
    static const char* tabNames[] = { "PALETTE", "SCALE", "LIBRARY", "STYLE", "BAND", "SONG" };
    for (int i = 0; i < numTabs; ++i)
    {
        tabBtns[i].setButtonText (tabNames[i]);
        tabBtns[i].onClick = [this, i] { showTab (i); };
        canvas.addAndMakeVisible (tabBtns[i]);
    }
    tabBtns[0].setTooltip ("24 hand-picked chords for the genre, on keys C4 to B5");
    tabBtns[1].setTooltip ("Every chord in your key: each octave is a chord family, white keys are the chords in the key");
    tabBtns[2].setTooltip ("Every chord type, every voicing, every triad in every octave");
    tabBtns[3].setTooltip ("Playing styles (arpeggios, waterfall, pulsing, strummed...) and the upper extension button");
    tabBtns[4].setTooltip ("A band that plays along with your chords: up to 15 tracks (melody, bass, drums, pads, keys, arps, guitar...), "
                           "each on its own MIDI channel");
    static const char* modeNames[] = { "SCALE", "PADS" };
    for (int i = 0; i < 2; ++i)
    {
        modeBtns[i].setButtonText (modeNames[i]);
        modeBtns[i].onClick = [this, i] { p.ui.keysMode = i; p.applyUiState(); refreshAll(); };
        canvas.addAndMakeVisible (modeBtns[i]);
    }
    modeBtns[0].setTooltip ("Your keyboard plays every chord in the key: one chord per key");
    modeBtns[1].setTooltip ("Your keyboard plays the 24 pads (C4 to B5); other keys pass through for melody");
    // ---- split keyboard
    splitBtn.setClickingTogglesState (false);
    splitBtn.onClick = [this]
    {
        if (p.splitLearnArmed.load()) { p.splitLearnArmed.store (false); updateSplitUi(); return; }
        p.ui.split = ! p.ui.split;
        p.applyUiState();
        updateSplitUi();
        keyboard.repaint();
    };
    splitBtn.setTooltip ("SPLIT: the left side of your keyboard plays chords, the right side plays your own notes. "
                         "SETUP picks where the split is, the right hand's channel and octave, and more.");
    lastSplitLearn = p.splitLearnCount.load();   // only react to learns from now on
    splitMenuBtn.onClick = [this] { showSplitMenu(); };
    splitMenuBtn.setTooltip ("Split point, right-hand channel / octave / snap, and which chords the left hand plays");
    canvas.addAndMakeVisible (splitBtn);
    canvas.addAndMakeVisible (splitMenuBtn);
    undoBtn.onClick = [this] { if (p.undo()) paletteEdited(); };
    redoBtn.onClick = [this] { if (p.redo()) paletteEdited(); };
    canvas.addAndMakeVisible (undoBtn);
    canvas.addAndMakeVisible (redoBtn);
    canvas.addChildComponent (palette);
    canvas.addChildComponent (scaleGrid);
    canvas.addChildComponent (library);
    canvas.addChildComponent (stylePanel);
    canvas.addChildComponent (bandPanel);
    canvas.addChildComponent (songPanel);
    tabBtns[5].setTooltip ("SONG: whole songs for the band's genre. DJ the sections, throw in fills, stops and drops, or let FOLLOW ME react to you");
    tabBtns[5].setVisible (p.ui.songTab);
    logoSpot.onRightClick = [this]
    {
        p.ui.songTab = ! p.ui.songTab;
        tabBtns[5].setVisible (p.ui.songTab);
        showTab (p.ui.songTab ? 5 : (p.ui.tab == 5 ? 4 : p.ui.tab));
    };
    canvas.addAndMakeVisible (logoSpot);

    canvas.addAndMakeVisible (chordPanel);
    canvas.addAndMakeVisible (preview);
    canvas.addAndMakeVisible (nextPanel);

    // ---- controls
    for (auto* k : { &strumKnob, &humanKnob, &heightKnob, &levelKnob })
    {
        k->setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        k->setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        k->onValueChange = [this] { canvas.repaint (0, 596, baseW, 54); };
        canvas.addAndMakeVisible (k);
    }
    strumKnob.setTooltip ("Roll the notes like a strum or a harp. 0 = all at once");
    humanKnob.setTooltip ("Tiny timing and velocity differences so it feels played");
    heightKnob.setTooltip ("Where the chords sit: low and warm or high and bright");
    levelKnob.setTooltip ("Volume of the built-in keys sound");
    strumDirBox.addItemList ({ "Up", "Down", "Up/Down", "Random" }, 1);
    bassBox.addItemList ({ "Off", "Low", "Channel 2" }, 1);
    velBox.addItemList ({ "Played", "Fixed" }, 1);
    bassBox.setTooltip ("Add a bass note under each chord. Channel 2 sends it on its own MIDI channel for a bass synth");
    velBox.setTooltip ("Use how hard you play, or always the same");
    smoothBtn.setTooltip ("SMOOTH: each new chord picks the shape that moves the least from the last one, so changes flow "
                          "(TROUPE resolving the chords for you). It stays near HEIGHT, and the same key again plays the same chord. "
                          "Off = every key always plays its chord the same way, in the same place");
    holdBtn.setTooltip ("Chords keep ringing after you let go, until the next chord");
    keysBtn.setTooltip ("Built-in electric piano. Turn it off once TROUPE is playing your own instrument");
    chordSoundBtn.setTooltip ("CHORD SOUND: load an instrument (Omnisphere, Analog Lab...) and your chords play it right inside "
                              "TROUPE. Each band track has its own SOUND button too");
    chordSoundBtn.onClick = [this] { showSoundMenu (p, InstrumentRack::chordSlot, chordSoundBtn); };
    canvas.addAndMakeVisible (chordSoundBtn);
    panicBtn.onClick = [this] { p.panic(); };
    panicBtn.setTooltip ("Stop all notes");
    for (juce::Component* c : { (juce::Component*) &strumDirBox, (juce::Component*) &bassBox, (juce::Component*) &velBox,
                                (juce::Component*) &smoothBtn, (juce::Component*) &holdBtn, (juce::Component*) &keysBtn,
                                (juce::Component*) &panicBtn, (juce::Component*) &keyboard })
        canvas.addAndMakeVisible (c);

    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    sliderAtt.push_back (std::make_unique<SA> (p.apvts, ids::strum, strumKnob));
    sliderAtt.push_back (std::make_unique<SA> (p.apvts, ids::humanize, humanKnob));
    sliderAtt.push_back (std::make_unique<SA> (p.apvts, ids::height, heightKnob));
    sliderAtt.push_back (std::make_unique<SA> (p.apvts, ids::keysLevel, levelKnob));
    comboAtt.push_back (std::make_unique<CA> (p.apvts, ids::strumDir, strumDirBox));
    comboAtt.push_back (std::make_unique<CA> (p.apvts, ids::bassMode, bassBox));
    comboAtt.push_back (std::make_unique<CA> (p.apvts, ids::velMode, velBox));
    comboAtt.push_back (std::make_unique<CA> (p.apvts, ids::stack, stackBox));
    comboAtt.push_back (std::make_unique<CA> (p.apvts, ids::stackNotes, stackNotesBox));
    stackNotesBox.setEnabled (stackBox.getSelectedId() - 1 >= StackOctaves && stackBox.getSelectedId() - 1 <= Stack6ths);
    buttonAtt.push_back (std::make_unique<BA> (p.apvts, ids::vary, varyBtn));
    buttonAtt.push_back (std::make_unique<BA> (p.apvts, ids::smooth, smoothBtn));
    buttonAtt.push_back (std::make_unique<BA> (p.apvts, ids::hold, holdBtn));
    buttonAtt.push_back (std::make_unique<BA> (p.apvts, ids::keysOn, keysBtn));

    // ---- footer
    recBtn.setClickingTogglesState (true);
    recBtn.onClick = [this] { p.recording.store (recBtn.getToggleState()); };
    autoRecBtn.setToggleState (p.ui.autoRec, juce::dontSendNotification);
    p.autoRec.store (p.ui.autoRec);
    autoRecBtn.onClick = [this] { p.ui.autoRec = autoRecBtn.getToggleState(); p.autoRec.store (p.ui.autoRec); };
    autoRecBtn.setTooltip ("Records TROUPE's chords automatically whenever you record in FL, lined up with your song");
    recBtn.setTooltip ("Record what you play, then drag it into FL");
    clearBtn.onClick = [this] { p.clearRecording(); };
    helpBtn.onClick = [this] { showRoutingHelp(); };
    savePartsBtn.setTooltip ("Saves every part of your take as its own MIDI file (chords, bass, melody, drums...) in "
                             "Documents\\VESPER\\Takes and opens the folder. Drag each file onto its own channel");
    savePartsBtn.onClick = [this]
    {
        const auto dir = p.exportPartsFolder();
        if (dir.isDirectory()) dir.startAsProcess();
    };
    static const char* sizeNames[] = { "S", "M", "L" };
    for (int i = 0; i < 3; ++i)
    {
        sizeBtns[i].setButtonText (sizeNames[i]);
        sizeBtns[i].onClick = [this, i] { p.ui.uiScale = i; applyScale(); updateHeader(); };
        canvas.addAndMakeVisible (sizeBtns[i]);
    }
    for (juce::Component* c : { (juce::Component*) &recBtn, (juce::Component*) &autoRecBtn, (juce::Component*) &clearBtn,
                                (juce::Component*) &helpBtn, (juce::Component*) &dragTile, (juce::Component*) &savePartsBtn })
        canvas.addAndMakeVisible (c);

    lastLoopEvents = p.loopEvents.load();
    layout();
    selectCard (juce::jlimit (0, paletteSize - 1, p.ui.selectedCard));
    showTab (p.ui.tab);
    applyScale();
    refreshAll();
    startTimerHz (30);
}

VesperEditor::~VesperEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

//==============================================================================
void VesperEditor::layout()
{
    // header
    keyBox.setBounds (212, 26, 70, 28);
    scaleBox.setBounds (292, 26, 166, 28);
    genreBox.setBounds (470, 26, 184, 28);
    stackBox.setBounds (662, 26, 84, 28);
    stackNotesBox.setBounds (748, 26, 44, 28);
    styleBox.setBounds (800, 26, 118, 28);
    spiceKnob.setBounds (922, 24, 32, 32);
    varyBtn.setBounds (962, 26, 80, 28);
    diceBtn.setBounds (1050, 26, 56, 28);
    menuBtn.setBounds (1112, 26, 52, 28);

    // main panel
    for (int i = 0; i < numTabs; ++i) tabBtns[i].setBounds (30 + i * 100, 80, 94, 26);
    splitBtn.setBounds (650, 80, 128, 26);
    splitMenuBtn.setBounds (782, 80, 66, 26);
    modeBtns[0].setBounds (868, 80, 70, 26);
    modeBtns[1].setBounds (942, 80, 70, 26);
    undoBtn.setBounds (1030, 80, 60, 26);
    redoBtn.setBounds (1094, 80, 60, 26);
    // MENU > Show panels: with all three lower panels hidden, the main panel takes their room
    const juce::Rectangle<int> content (28, 114, 1124, lowerHidden() ? 466 : 266);
    chordSetBox.setBounds (content.getX(), content.getY(), 300, 24);
    toLoopsBtn.setBounds (content.getX() + 306, content.getY(), 112, 24);
    palette.setBounds (content.withTrimmedTop (30));
    scaleGrid.setBounds (content);
    library.setBounds (content);
    stylePanel.setBounds (content);
    bandPanel.setBounds (content);
    songPanel.setBounds (content);
    logoSpot.setBounds (18, 14, 190, 40);

    // lower panels: the ones showing share the row
    {
        juce::Component* lower[3] = { &chordPanel, &preview, &nextPanel };
        const bool show[3] = { ! p.ui.hideChordPanel, ! p.ui.hidePreview, ! p.ui.hideNext };
        int n = 0;
        for (bool b : show) n += b ? 1 : 0;
        if (n == 3)
        {
            chordPanel.setBounds (16, 400, 372, 190);
            preview.setBounds (400, 400, 376, 190);
            nextPanel.setBounds (788, 400, 376, 190);
        }
        else if (n > 0)
        {
            const int w = (1148 - (n - 1) * 12) / n;
            for (int i = 0, x = 16; i < 3; ++i)
                if (show[i]) { lower[i]->setBounds (x, 400, w, 190); x += w + 12; }
        }
        for (int i = 0; i < 3; ++i) lower[i]->setVisible (show[i]);
    }

    // controls strip
    strumKnob.setBounds (28, 604, 38, 38);
    strumDirBox.setBounds (130, 611, 84, 24);
    humanKnob.setBounds (228, 604, 38, 38);
    heightKnob.setBounds (352, 604, 38, 38);
    smoothBtn.setBounds (462, 611, 92, 24);
    holdBtn.setBounds (560, 611, 74, 24);
    bassBox.setBounds (684, 611, 104, 24);
    velBox.setBounds (832, 611, 84, 24);
    keysBtn.setBounds (930, 611, 112, 24);
    levelKnob.setBounds (1048, 604, 38, 38);
    panicBtn.setBounds (1094, 611, 62, 24);

    keyboard.setBounds (20, 654, 1140, 60);

    // footer
    recBtn.setBounds (16, 722, 74, 30);
    autoRecBtn.setBounds (96, 725, 104, 24);
    dragTile.setBounds (206, 722, 352, 30);
    savePartsBtn.setBounds (564, 722, 94, 30);
    clearBtn.setBounds (666, 722, 70, 30);
    helpBtn.setBounds (744, 722, 150, 30);
    chordSoundBtn.setBounds (900, 722, 160, 30);
    for (int i = 0; i < 3; ++i) sizeBtns[i].setBounds (1066 + i * 34, 722, 30, 30);
}

float VesperEditor::uiScaleNow() const
{
    return p.ui.uiScale == 0 ? 0.8f : (p.ui.uiScale == 2 ? 1.25f : 1.0f);
}

void VesperEditor::applyScale()
{
    const float s = uiScaleNow();
    canvas.setTransform (juce::AffineTransform::scale (s).translated ((float) edge * s, (float) edge * s));
    setSize (juce::roundToInt ((float) (baseW + 2 * edge) * s), juce::roundToInt ((float) (baseH + 2 * edge) * s));
    bodyImage = {};
}

void VesperEditor::paint (juce::Graphics& g)
{
    const float s = uiScaleNow();
    // the desk it sits on, a little lighter under the lamp
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff24272b), 0.0f, 0.0f, juce::Colour (0xff111214), 0.0f, (float) getHeight(), false));
    g.fillAll();
    g.addTransform (juce::AffineTransform::scale (s));
    troupe::drawUnibodyShadow (g, { (float) margin, (float) margin, (float) (baseW + 2 * bezel), (float) (baseH + 2 * bezel) }, 26.0f);
}

void VesperEditor::paintOverChildren (juce::Graphics& g)
{
    const float s = uiScaleNow();
    const float px = juce::jmax (1.0f, g.getInternalContext().getPhysicalPixelScaleFactor());
    if (! bodyImage.isValid() || bodyImageScale != px || bodyImageFor != getLocalBounds())
    {   // the unibody, drawn once at the screen's real resolution
        bodyImageScale = px;
        bodyImageFor = getLocalBounds();
        bodyImage = juce::Image (juce::Image::ARGB, juce::jmax (1, juce::roundToInt ((float) getWidth() * px)),
                                 juce::jmax (1, juce::roundToInt ((float) getHeight() * px)), true);
        juce::Graphics ig (bodyImage);
        ig.addTransform (juce::AffineTransform::scale (s * px));
        const juce::Rectangle<float> body ((float) margin, (float) margin, (float) (baseW + 2 * bezel), (float) (baseH + 2 * bezel));
        const juce::Rectangle<float> face ((float) edge, (float) edge, (float) baseW, (float) baseH);
        troupe::drawUnibody (ig, body, face, 26.0f, 12.0f);
        troupe::drawEngraved (ig, "TROUPE   CHORD ENGINE   V" VESPER_VERSION,
                              { face.getRight() - 420.0f, face.getBottom() + 5.0f, 410.0f, (float) bezel - 9.0f }, 7.5f,
                              juce::Justification::centredRight);
    }
    g.drawImage (bodyImage, getLocalBounds().toFloat());
}

Theme VesperEditor::skinnedTheme() const
{
    Theme th = themeFor (p.ui.theme);
    if (skinImage.isValid())
    {
        th.panel = th.panel.withAlpha (0.74f);
        th.card = th.card.withAlpha (0.86f);
        th.cardDark = th.cardDark.withAlpha (0.82f);
    }
    return th;
}

void VesperEditor::loadSkin()
{
    skinImage = {};
    if (p.ui.skin.isEmpty()) return;
    const auto img = juce::ImageFileFormat::loadFrom (juce::File (p.ui.skin));
    if (! img.isValid()) return;
    // drawn once at 1.25x (the biggest SIZE), filling the window (cropped, never stretched)
    const int w = juce::roundToInt (baseW * 1.25f), h = juce::roundToInt (baseH * 1.25f);
    skinImage = juce::Image (juce::Image::RGB, w, h, true);
    juce::Graphics g (skinImage);
    g.drawImage (img, juce::Rectangle<float> (0.0f, 0.0f, (float) w, (float) h), juce::RectanglePlacement::fillDestination);
}

void VesperEditor::pickSkin()
{
    chooser = std::make_unique<juce::FileChooser> ("Pick a picture for TROUPE's skin",
                                                   juce::File::getSpecialLocation (juce::File::userPicturesDirectory), "*.png;*.jpg;*.jpeg");
    juce::Component::SafePointer<VesperEditor> safe (this);
    chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles, [safe] (const juce::FileChooser& fc)
    {
        if (safe == nullptr) return;
        const auto f = fc.getResult();
        if (! f.existsAsFile()) return;
        // a copy in Documents/VESPER/Skins, so it still works if the picture moves
        auto dir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER").getChildFile ("Skins");
        dir.createDirectory();
        auto keep = dir.getChildFile (f.getFileName());
        if (keep != f) f.copyFileTo (keep);
        safe->p.ui.skin = (keep.existsAsFile() ? keep : f).getFullPathName();
        safe->loadSkin();
        if (! safe->skinImage.isValid())
        {
            safe->p.ui.skin = {};
            juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon, "Skin", "TROUPE couldn't open that picture (use a PNG or JPG).");
        }
        safe->applyTheme();
    });
}

void VesperEditor::applyTheme()
{
    look.setTheme (skinnedTheme());
    sendLookAndFeelChange();
    canvas.repaint();
    refreshAll();
}

void VesperEditor::showTab (int i)
{
    p.ui.tab = juce::jlimit (0, numTabs - 1, i);
    if (p.ui.tab == 5 && ! p.ui.songTab) p.ui.tab = 4;
    songPanel.setVisible (p.ui.tab == 5);
    palette.setVisible (p.ui.tab == 0);
    chordSetBox.setVisible (p.ui.tab == 0);
    toLoopsBtn.setVisible (p.ui.tab == 0);
    scaleGrid.setVisible (p.ui.tab == 1);
    library.setVisible (p.ui.tab == 2);
    stylePanel.setVisible (p.ui.tab == 3);
    bandPanel.setVisible (p.ui.tab == 4);
    if (p.ui.tab == 2) library.syncFromFocus();
    for (int k = 0; k < numTabs; ++k) tabBtns[k].setToggleState (k == p.ui.tab, juce::dontSendNotification);
}

void VesperEditor::fillStyleBox()
{
    if (styleBoxGenre == p.ui.genre && styleBox.getNumItems() > 0) return;
    styleBoxGenre = p.ui.genre;
    styleBox.clear (juce::dontSendNotification);
    styleBox.addSectionHeading ("VOICE SETS FOR " + juce::String (genreShort (p.ui.genre)) + " (VARY mixes one)");
    for (int i = 0; i < numVoiceSets (p.ui.genre); ++i)
        styleBox.addItem (voiceSetFor (p.ui.genre, i).name, 1001 + i);
    styleBox.addSeparator();
    styleBox.addSectionHeading ("ONE STYLE (VARY only re-voices it)");
    for (int s = 0; s < numStyles; ++s) styleBox.addItem (styleName (s), s + 1);
}

void VesperEditor::fillChordSetBox()
{
    const int major = scaleIsMajorType (p.ui.scale) ? 1 : 0;
    if (chordSetGenre == p.ui.genre && chordSetMajor == major && chordSetBox.getNumItems() > 0) return;
    chordSetGenre = p.ui.genre;
    chordSetMajor = major;
    chordSetBox.clear (juce::dontSendNotification);
    const int n = numChordSets (p.ui.genre, p.ui.scale);
    for (int i = 0; i < n; ++i)
        chordSetBox.addItem ("CHORDS: " + juce::String (chordSetName (p.ui.genre, p.ui.scale, i)) + (i == 0 ? " (the genre's 24)" : ""), i + 1);
    if (p.ui.chordSet >= n) p.ui.chordSet = 0;
}

void VesperEditor::updateHeader()
{
    keyBox.setSelectedId (p.ui.keyRoot + 1, juce::dontSendNotification);
    scaleBox.setSelectedId (p.ui.scale + 1, juce::dontSendNotification);
    fillStyleBox();
    styleBox.setSelectedId (p.ui.voiceSet >= 0 ? 1001 + p.ui.voiceSet : p.ui.style + 1, juce::dontSendNotification);
    spiceKnob.setValue (p.ui.spice, juce::dontSendNotification);
    fillChordSetBox();
    chordSetBox.setSelectedId (p.ui.chordSet + 1, juce::dontSendNotification);
    genreBox.setSelectedId (p.ui.genre + 1, juce::dontSendNotification);
    for (int i = 0; i < 2; ++i) modeBtns[i].setToggleState (i == p.ui.keysMode, juce::dontSendNotification);
    for (int i = 0; i < numTabs; ++i) tabBtns[i].setToggleState (i == p.ui.tab, juce::dontSendNotification);
    for (int i = 0; i < 3; ++i) sizeBtns[i].setToggleState (i == p.ui.uiScale, juce::dontSendNotification);
    undoBtn.setEnabled (p.canUndo());
    redoBtn.setEnabled (p.canRedo());
}

void VesperEditor::refreshAll()
{
    updateHeader();
    if (focus_.origin == 0)
    {
        const int i = juce::jlimit (0, paletteSize - 1, p.ui.selectedCard);
        const auto& card = p.ui.palette[(size_t) i];
        focus_.chord = card.chord;
        focus_.style = card.style;
        focus_.variant = card.variant;
        focus_.card = i;
    }
    palette.repaint();
    scaleGrid.repaint();
    if (library.isVisible()) library.rebuild();
    chordPanel.refresh();
    preview.refresh();
    nextPanel.refresh (played_.chord.valid() ? played_.chord : focus_.chord);
    keyboard.repaint();
    updateSplitUi();
    canvas.repaint();
}

//==============================================================================
// split keyboard
void VesperEditor::updateSplitUi()
{
    if (p.splitLearnArmed.load())
    {
        splitBtn.setButtonText ("PRESS A KEY...");
        splitBtn.setToggleState (true, juce::dontSendNotification);
        return;
    }
    splitBtn.setButtonText (p.ui.split ? "SPLIT AT " + toJ (midiName (p.ui.splitNote, p.flats())) : juce::String ("SPLIT OFF"));
    splitBtn.setToggleState (p.ui.split, juce::dontSendNotification);
}

void VesperEditor::showSplitMenu()
{
    auto& u = p.ui;
    const bool flats = p.flats();
    juce::PopupMenu m, points, chan, oct, rows, banks;

    m.addSectionHeader ("SPLIT KEYBOARD");
    m.addItem (1, "Split on", true, u.split);
    m.addItem (2, "Set the split point: click, then press the first key of your right hand");
    for (int note : { 48, 53, 55, 60, 65, 67, 72 })
        points.addItem (100 + note, "Right hand starts at " + toJ (midiName (note, flats)), true, u.splitNote == note);
    m.addSubMenu ("Split point (now " + toJ (midiName (u.splitNote, flats)) + ")", points);

    m.addSectionHeader ("RIGHT HAND");
    chan.addItem (300, "Same channel as the chords", true, u.rightCh == 0);
    for (int c = 1; c <= 16; ++c)
        chan.addItem (300 + c, "Channel " + juce::String (c), true, u.rightCh == c);
    m.addSubMenu (u.rightCh == 0 ? juce::String ("Plays on: the chord channel") : "Plays on: channel " + juce::String (u.rightCh), chan);
    for (int o = -2; o <= 2; ++o)
        oct.addItem (403 + o, o == 0 ? juce::String ("No shift") : (o > 0 ? "+" : "") + juce::String (o) + (std::abs (o) == 1 ? " octave" : " octaves"),
                     true, u.rightOct == o);
    m.addSubMenu ("Octave" + (u.rightOct != 0 ? juce::String (" (") + (u.rightOct > 0 ? "+" : "") + juce::String (u.rightOct) + ")" : juce::String()), oct);
    m.addItem (3, "Snap to the key (wrong notes move to the nearest right one)", true, u.rightSnap);

    m.addSectionHeader ("LEFT HAND");
    if (u.keysMode == 0)
    {
        rows.addItem (500, "Whatever octave I play in", true, u.leftRow < 0);
        for (int r = 0; r < numRows; ++r)
            rows.addItem (501 + r, rowName (r), true, u.leftRow == r);
        m.addSubMenu (juce::String ("Chord family: ") + (u.leftRow < 0 ? juce::String ("by octave") : juce::String (rowName (u.leftRow))), rows);
    }
    else
    {
        banks.addItem (600, "Pads 1-12", true, u.padBank == 0);
        banks.addItem (601, "Pads 13-24", true, u.padBank == 1);
        m.addSubMenu (u.padBank == 0 ? juce::String ("Plays pads 1-12") : juce::String ("Plays pads 13-24"), banks);
    }

    juce::Component::SafePointer<VesperEditor> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&splitMenuBtn), [safe] (int r)
    {
        if (safe == nullptr || r == 0) return;
        auto& ed = *safe;
        auto& ui = ed.p.ui;
        if (r == 1) ui.split = ! ui.split;
        else if (r == 2) { ui.split = true; ed.p.splitLearnArmed.store (true); }
        else if (r == 3) ui.rightSnap = ! ui.rightSnap;
        else if (r >= 100 && r < 300) { ui.splitNote = r - 100; ui.split = true; }
        else if (r >= 300 && r <= 316) ui.rightCh = r - 300;
        else if (r >= 401 && r <= 405) ui.rightOct = r - 403;
        else if (r >= 500 && r < 600) ui.leftRow = r - 501;
        else if (r >= 600 && r < 700) ui.padBank = r - 600;
        ed.p.applyUiState();
        ed.updateSplitUi();
        ed.keyboard.repaint();
    });
}

//==============================================================================
void VesperEditor::setFocus (const Focus& f)
{
    focus_ = f;
    chordPanel.refresh();
    preview.refresh();
    nextPanel.refresh (f.chord);
    palette.repaint();
}

void VesperEditor::selectCard (int index)
{
    if (index < 0 || index >= paletteSize) return;
    p.ui.selectedCard = index;
    const auto& card = p.ui.palette[(size_t) index];
    Focus f;
    f.chord = card.chord;
    f.style = card.style;
    f.variant = card.variant;
    f.origin = 0;
    f.card = index;
    f.key = p.ui.keysMode == 1 ? 48 + index : -1;
    focus_ = f;
    chordPanel.refresh();
    preview.refresh();
    nextPanel.refresh (card.chord);
    palette.repaint();
    if (library.isVisible()) library.rebuild();
}

void VesperEditor::sendToSelectedCard (const Chord& c, int style, int variant)
{
    if (! c.valid()) return;
    auto pal = p.ui.palette;
    pal[(size_t) juce::jlimit (0, paletteSize - 1, p.ui.selectedCard)] = Card { c, style, variant };
    p.setPalette (pal);
    paletteEdited();
}

void VesperEditor::paletteEdited()
{
    if (focus_.origin == 0)
    {
        const int i = juce::jlimit (0, paletteSize - 1, p.ui.selectedCard);
        const auto& card = p.ui.palette[(size_t) i];
        focus_.chord = card.chord;
        focus_.style = card.style;
        focus_.variant = card.variant;
        focus_.card = i;
    }
    palette.repaint();
    chordPanel.refresh();
    preview.refresh();
    updateHeader();
}

void VesperEditor::dragChordOut (const Chord& c, int style, int variant)
{
    const auto f = p.exportChord (c, style, variant);
    if (f.existsAsFile())
        juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
}

void VesperEditor::onPlayed()
{
    const int s = played_.source;
    if (s >= 0 && s < 128)
    {
        if (p.ui.keysMode == 1)
        {
            const int idx = s - 48;
            if (idx >= 0 && idx < paletteSize)
            {
                p.ui.selectedCard = idx;
                const auto& card = p.ui.palette[(size_t) idx];
                Focus f;
                f.chord = card.chord;
                f.style = card.style;
                f.variant = card.variant;
                f.origin = 0;
                f.card = idx;
                f.key = s;
                focus_ = f;
            }
        }
        else
        {
            Focus f;
            f.chord = played_.chord;
            f.origin = 4;
            f.key = s;
            focus_ = f;
        }
        chordPanel.refresh();
        palette.repaint();
    }
    preview.refresh();
    nextPanel.refresh (played_.chord.valid() ? played_.chord : focus_.chord);
}

void VesperEditor::timerCallback()
{
    const auto c = p.playedCounter();
    if (c != lastCounter)
    {
        lastCounter = c;
        p.getLastPlayed (played_);
        onPlayed();
    }

    uint32_t h = 2166136261u;
    for (int n = 0; n < 128; ++n)
        h = (h ^ (uint32_t) ((p.isInputKeyDown (n) ? 1 : 0) | (p.isOutputNoteOn (n) ? 2 : 0) | (n << 2))) * 16777619u;
    if (h != lastLightsHash)
    {
        lastLightsHash = h;
        keyboard.repaint();
        if (palette.isVisible()) palette.repaint();
        if (scaleGrid.isVisible()) scaleGrid.repaint();
    }

    const auto sl = p.splitLearnCount.load();
    if (sl != lastSplitLearn)
    {
        lastSplitLearn = sl;
        const int note = p.splitLearned.load();
        if (note > 0)
        {
            p.ui.splitNote = note;
            p.ui.split = true;
            p.applyUiState();
            keyboard.repaint();
        }
        updateSplitUi();
    }

    const int rc = p.recordedNotes();
    if (rc != lastRecCount)
    {
        lastRecCount = rc;
        dragTile.repaint();
        savePartsBtn.setEnabled (rc > 0);
    }
    if (recBtn.getToggleState() != p.recording.load())
        recBtn.setToggleState (p.recording.load(), juce::dontSendNotification);

    if (p.rack.changed.load() != lastRackSeen)
    {
        lastRackSeen = p.rack.changed.load();
        const auto t = soundButtonText (p, InstrumentRack::chordSlot);
        chordSoundBtn.setButtonText (t == "+ SOUND" ? juce::String ("+ CHORD SOUND") : "CHORDS: " + t);
        chordSoundBtn.setToggleState (p.rack.loaded (InstrumentRack::chordSlot), juce::dontSendNotification);
    }

    // MIDI loop caught by the processor: light up the help button for a while
    const auto le = p.loopEvents.load();
    const auto nowMs = juce::Time::getMillisecondCounter();
    if (le != lastLoopEvents)
    {
        lastLoopEvents = le;
        loopWarnUntil = nowMs + 20000;
        helpBtn.setButtonText ("MIDI LOOP BLOCKED - FIX");
        helpBtn.setToggleState (true, juce::dontSendNotification);
        helpBtn.setTooltip ("TROUPE is hearing its own MIDI. Click for the 10-second fix.");
    }
    else if (loopWarnUntil != 0 && nowMs > loopWarnUntil)
    {
        loopWarnUntil = 0;
        helpBtn.setButtonText ("PLAY MY SOUNDS?");
        helpBtn.setToggleState (false, juce::dontSendNotification);
        helpBtn.setTooltip ({});
    }
}

//==============================================================================
void VesperEditor::showToLoopsMenu()
{
    juce::PopupMenu m, one;
    m.addSectionHeader ("The pads' rows become loops A-D, one chord a bar");
    m.addItem (1, "Rows 1-2-3-4  ->  A verse, B hook, C bridge, D pre-hook");
    m.addItem (2, "Rows 3-4-5-6  ->  A verse, B hook, C bridge, D pre-hook");
    m.addItem (3, "Rows 1 and 2  ->  A verse, B hook (the rest borrow them)");
    for (int r = 0; r < paletteSize / 4; ++r) one.addItem (11 + r, "Row " + juce::String (r + 1) + " (pads " + juce::String (r * 4 + 1) + "-" + juce::String (r * 4 + 4) + ")");
    m.addSubMenu ("One row, the whole song", one);
    m.addSeparator();
    m.addItem (99, "Then: PLAY SONG on the SONG tab - the song plays itself", false);
    juce::Component::SafePointer<VesperEditor> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&toLoopsBtn), [safe] (int r)
    {
        if (safe == nullptr || r <= 0) return;
        std::array<int, 4> rows { -1, -1, -1, -1 };
        juce::String what;
        if (r == 1) { rows = { 0, 1, 2, 3 }; what = "rows 1-4"; }
        else if (r == 2) { rows = { 2, 3, 4, 5 }; what = "rows 3-6"; }
        else if (r == 3) { rows = { 0, 1, -1, -1 }; what = "rows 1 and 2"; }
        else if (r >= 11 && r < 11 + paletteSize / 4) { rows[0] = r - 11; what = "row " + juce::String (r - 10); }
        else return;
        auto& ed = *safe;
        if (! ed.p.chordRowsToLoops (rows)) { ed.toLoopsNote = "one moment - press it again"; }
        else ed.toLoopsNote = juce::String ("loops A-D now play ") + what + " - hit PLAY SONG on the SONG tab";
        ed.toLoopsAt = juce::Time::getMillisecondCounter();
        ed.canvas.repaint();
        juce::Timer::callAfterDelay (9100, [safe] { if (safe != nullptr) safe->canvas.repaint(); });
    });
}

void VesperEditor::paintCanvas (juce::Graphics& g)
{
    const auto& t = theme();
    g.setGradientFill (juce::ColourGradient (t.bgTop, 0.0f, 0.0f, t.bgBottom, 0.0f, (float) baseH, false));
    g.fillAll();
    if (skinImage.isValid())
    {
        g.drawImage (skinImage, juce::Rectangle<float> (0.0f, 0.0f, (float) baseW, (float) baseH));
        g.setColour (t.bgBottom.withAlpha (0.38f));   // a little darker, so the writing stays easy to read
        g.fillAll();
    }

    // the TROUPE emblem: the signature in raised chrome, CHORD | ENGINE either side of the p's stem
    troupe::drawEmblem (g, { 18.0f, 7.0f, 186.0f, 58.0f });

    drawCaption (g, { 212.0f, 12.0f, 70.0f, 12.0f }, "KEY", t);
    drawCaption (g, { 292.0f, 12.0f, 166.0f, 12.0f }, "SCALE", t);
    drawCaption (g, { 470.0f, 12.0f, 184.0f, 12.0f }, "GENRE", t);
    drawCaption (g, { 662.0f, 12.0f, 84.0f, 12.0f }, "STACK", t);
    drawCaption (g, { 748.0f, 12.0f, 44.0f, 12.0f }, "NOTES", t);
    drawCaption (g, { 800.0f, 12.0f, 118.0f, 12.0f }, "VOICING", t);
    drawCaption (g, { 916.0f, 12.0f, 46.0f, 12.0f }, "SPICE", t);
    drawCaption (g, { 962.0f, 12.0f, 84.0f, 12.0f }, "ON REPEAT", t);

    drawPanel (g, { 16.0f, 72.0f, 1148.0f, lowerHidden() ? 518.0f : 318.0f }, t);
    drawCaption (g, { 790.0f, 86.0f, 76.0f, 14.0f }, "KEYS PLAY", t);

    // controls strip
    drawPanel (g, { 16.0f, 598.0f, 1148.0f, 48.0f }, t);
    auto knobLabel = [&] (float x, const juce::String& name, const juce::String& value)
    {
        drawCaption (g, { x, 606.0f, 70.0f, 12.0f }, name, t);
        g.setFont (uiFont (11.5f, true));
        g.setColour (t.text);
        g.drawText (value, juce::Rectangle<float> (x, 620.0f, 70.0f, 16.0f), juce::Justification::centredLeft);
    };
    const int strum = (int) strumKnob.getValue();
    knobLabel (70.0f, "STRUM", strum <= 0 ? juce::String ("off") : juce::String (strum) + " ms");
    knobLabel (270.0f, "HUMANIZE", juce::String (juce::roundToInt (humanKnob.getValue() * 100.0)) + "%");
    knobLabel (394.0f, "HEIGHT", toJ (midiName ((int) heightKnob.getValue(), p.flats())));
    drawCaption (g, { 646.0f, 611.0f, 36.0f, 24.0f }, "BASS", t);
    drawCaption (g, { 798.0f, 611.0f, 32.0f, 24.0f }, "VEL", t);

    // keyboard frame
    g.setColour (t.cardDark);
    g.fillRoundedRectangle (16.0f, 652.0f, 1148.0f, 64.0f, 6.0f);
    troupe::drawRim (g, { 16.0f, 652.0f, 1148.0f, 64.0f }, 6.0f, 0.8f);

    drawCaption (g, { 1030.0f, 722.0f, 34.0f, 30.0f }, "SIZE", t);

    if (p.ui.tab == 0)   // next to the CHORDS box
    {
        g.setFont (uiFont (10.5f));
        g.setColour (t.dim);
        const bool note = toLoopsNote.isNotEmpty() && juce::Time::getMillisecondCounter() - toLoopsAt < 9000;
        if (note) g.setColour (t.accent);
        g.drawText (note ? toLoopsNote
                         : p.ui.chordSet > 0 ? "each row of 4 pads is a progression: play them left to right"
                                             : "pick a CHORD SET: six progressions of four, made for this genre",
                    juce::Rectangle<float> (452.0f, 114.0f, 600.0f, 24.0f), juce::Justification::centredLeft);
    }
}

//==============================================================================
void VesperEditor::showMenu()
{
    juce::PopupMenu m, themes;
    for (int i = 0; i < numThemes(); ++i) themes.addItem (100 + i, themeFor (i).name, true, p.ui.theme == i);
    m.addSubMenu ("Colorway", themes);
    juce::PopupMenu show, skin;
    show.addItem (200, "CURRENT CHORD", true, ! p.ui.hideChordPanel);
    show.addItem (201, "VOICING PREVIEW", true, ! p.ui.hidePreview);
    show.addItem (202, "WHAT SOUNDS GOOD NEXT", true, ! p.ui.hideNext);
    m.addSubMenu ("Show panels", show);
    skin.addItem (210, "Pick a picture...");
    skin.addItem (211, "Remove the picture", p.ui.skin.isNotEmpty());
    m.addSubMenu ("Skin (your own picture)", skin, true, std::unique_ptr<juce::Drawable>(), p.ui.skin.isNotEmpty());
    juce::PopupMenu cableMenu;
    const auto cables = VesperProcessor::cableDevices();
    const auto cableNow = p.cableName();
    cableMenu.addItem (300, "Off (FL's MIDI output port, like before)", true, cableNow.isEmpty());
    for (int i = 0; i < cables.size() && i < 60; ++i) cableMenu.addItem (301 + i, cables[i], true, cables[i] == cableNow);
    if (cables.isEmpty()) cableMenu.addItem (399, "(no cables found: install loopMIDI and add a port)", false, false);
    cableMenu.addSeparator();
    {
        juce::PopupMenu kb;
        for (int ch = 1; ch <= 16; ++ch) kb.addItem (400 + ch, "Channel " + juce::String (ch) + (ch == 1 ? " (most keyboards)" : ""), true, p.keyboardCh.load() == ch);
        cableMenu.addSubMenu ("Your keyboard's channel: " + juce::String (p.keyboardCh.load()), kb);
    }
    if (cableNow.isNotEmpty())
        cableMenu.addItem (397, "Sent " + juce::String ((int) p.cableSent.load()) + " notes  |  ignored " + juce::String ((int) p.cableIgnored.load())
                                + " coming back in", false, false);
    cableMenu.addItem (398, "How to set it up in FL...");
    m.addSubMenu ("Send MIDI through a cable (loopMIDI)", cableMenu, true, std::unique_ptr<juce::Drawable>(), cableNow.isNotEmpty());
    m.addItem (1, "Save pads...");
    m.addItem (2, "Load pads...");
    m.addItem (3, "Reset pads to the " + juce::String (genreShort (p.ui.genre)) + " starter set");
    m.addSeparator();
    m.addItem (4, "How to play my own sounds");
    m.addItem (5, "All notes off (panic)");
    juce::Component::SafePointer<VesperEditor> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&menuBtn), [safe, cables] (int r)
    {
        if (safe == nullptr || r == 0) return;
        auto& ed = *safe;
        if (r >= 300 && r < 397)
        {
            juce::String err;
            if (! ed.p.setCable (r == 300 ? juce::String() : cables[r - 301], err))
                juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon, "MIDI cable", err, "OK", &ed);
            else if (r != 300)
            {
                const auto note = ed.p.keepKeyboardChannelFree();
                juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::InfoIcon, "Sending through " + cables[r - 301],
                    (note.isNotEmpty() ? note + "\n\n" : juce::String())
                    + "Channel " + juce::String (ed.p.keyboardCh.load()) + " is your keyboard's: TROUPE only listens to it and never sends on it, "
                      "so nothing TROUPE plays can loop back. Lock each instrument to the channel shown on TROUPE "
                      "(CHORDS CH and each track's CH on the BAND tab).", "OK", &ed);
            }
            return;
        }
        if (r > 400 && r <= 416)
        {
            ed.p.keyboardCh.store (r - 400);
            if (ed.p.cableName().isNotEmpty())
            {
                const auto note = ed.p.keepKeyboardChannelFree();
                if (note.isNotEmpty()) juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::InfoIcon, "Your keyboard's channel", note, "OK", &ed);
            }
            return;
        }
        if (r == 398) { ed.showCableHelp(); return; }
        if (r >= 200 && r <= 202)
        {
            bool& h = r == 200 ? ed.p.ui.hideChordPanel : (r == 201 ? ed.p.ui.hidePreview : ed.p.ui.hideNext);
            h = ! h;
            ed.resized();
            ed.canvas.repaint();
        }
        else if (r == 210) ed.pickSkin();
        else if (r == 211) { ed.p.ui.skin = {}; ed.loadSkin(); ed.applyTheme(); }
        else if (r >= 100) { ed.p.ui.theme = r - 100; ed.applyTheme(); }
        else if (r == 1) ed.savePalette();
        else if (r == 2) ed.loadPalette();
        else if (r == 3)
        {
            ed.p.ui.diceSeed = 0;
            ed.p.setPalette (buildPalette (ed.p.ui.keyRoot, ed.p.ui.scale, ed.p.ui.genre, 0));
            ed.paletteEdited();
        }
        else if (r == 4) ed.showRoutingHelp();
        else if (r == 5) ed.p.panic();
    });
}

void VesperEditor::showCableHelp()
{
    juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::InfoIcon, "One TROUPE, every instrument on the Channel rack",
        "Every BAND track and the chords play on their own MIDI channel. A free virtual MIDI cable (loopMIDI) carries them into FL, "
        "and each instrument on the Channel rack picks out its own channel.\n\n"
        "ONCE (FL settings stay put)\n"
        "1. loopMIDI: one port is enough (the default \"loopMIDI Port\").\n"
        "2. FL: Options > MIDI Settings. INPUT list: select loopMIDI Port, Enable it, set its Port to a number nothing else uses "
        "(like 123) - and never change it again (FL's locks remember that number). OUTPUT list: loopMIDI Port's Port on ---.\n\n"
        "IN EACH PROJECT\n"
        "3. TROUPE: MENU > Send MIDI through a cable > loopMIDI Port. TROUPE's gear icon: Input port and Output port both --.\n"
        "4. Right-click TROUPE's Channel rack button > Receive notes from > your keyboard > All.\n"
        "5. Each instrument: right-click > Receive notes from > loopMIDI Port > the channel TROUPE shows for it "
        "(CHORDS CH, and each track's CH on the BAND tab). A red CH box means two parts share that channel.\n"
        "6. Turn off band tracks that have no instrument.\n\n"
        "Channel 1 is your keyboard's: TROUPE only listens to it and never sends on it, so nothing can loop. "
        "(Keyboard on another channel? MENU > Send MIDI through a cable > Your keyboard's channel.)\n"
        "A track with a SOUND loaded keeps its notes inside TROUPE. The cable plays live: record the parts before you export.",
        "Got it", this);
}

void VesperEditor::showRoutingHelp()
{
    const bool loop = loopWarnUntil != 0;
    juce::AlertWindow::showMessageBoxAsync (
        juce::MessageBoxIconType::InfoIcon, loop ? "TROUPE was hearing its own MIDI" : "Play TROUPE through your own sounds",
        juce::String (loop ? "TROUPE caught a MIDI loop: its chords were coming back into it as key presses, "
                             "which snowballs into a flood of notes. It's blocking the loop now, but fix the routing:\n"
                             "on TROUPE's gear icon, set MIDI Input port to -- (empty). Only the Output port should be 1. "
                             "On your instrument, set Input port 1 and leave its Output port empty.\n\n"
                           : "")
        + "TROUPE sends its chords out as MIDI, so any instrument in FL can play them.\n\n"
        "1. Click the gear icon at the top-left of TROUPE's window (FL's plugin settings).\n"
        "2. Under MIDI, set Output port to 1 and leave TROUPE's Input port empty (--).\n"
        "3. Open your instrument (Omnisphere, Keyscape, MOTE...), click its gear icon, set its Input port to 1 and leave its Output port empty.\n"
        "4. Play on TROUPE's channel. Turn KEYS SOUND off so you only hear your instrument.\n\n"
        "BAND tab: every track plays on its own MIDI channel (chords 1, bass 2, melody 3, counter 4, strings 5, horns 6, drums 10, "
        "tracks you add get the next free one - change any of them). One multi-part synth (Omnisphere Multi, Kontakt): give each "
        "part the matching channel, never Omni.\n"
        "Separate plugins: add a Patcher to the Channel rack. Right-click From FL Studio > Outputs > Events > MIDI port (TROUPE's "
        "output port), wire it into VFX Color Mapper, right-click the mapper > Outputs > Events > Activate all, then wire output 1 to "
        "your chord synth, 2 to your bass, 10 to FPC... Each track's channel = that Color Mapper output.\n\n"
        "To keep what you played: hit REC, play, then drag the MIDI tile into FL's piano roll or playlist. "
        "You can also drag any pad or scale chord out of TROUPE to drop a single chord.",
        "Got it", this);
}

void VesperEditor::savePalette()
{
    auto dir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER").getChildFile ("Pads");
    dir.createDirectory();
    chooser = std::make_unique<juce::FileChooser> ("Save pads", dir.getChildFile ("My pads.vesperpads"), "*.vesperpads");
    juce::Component::SafePointer<VesperEditor> safe (this);
    chooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
                              | juce::FileBrowserComponent::warnAboutOverwriting,
                          [safe] (const juce::FileChooser& fc)
    {
        if (safe == nullptr) return;
        auto f = fc.getResult();
        if (f == juce::File()) return;
        f = f.withFileExtension (".vesperpads");
        juce::XmlElement x ("VESPER_PADS");
        x.setAttribute ("key", safe->p.ui.keyRoot);
        x.setAttribute ("scale", safe->p.ui.scale);
        x.setAttribute ("genre", safe->p.ui.genre);
        writeCards (x, safe->p.ui.palette);
        x.writeTo (f);
    });
}

void VesperEditor::loadPalette()
{
    auto dir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER").getChildFile ("Pads");
    dir.createDirectory();
    chooser = std::make_unique<juce::FileChooser> ("Load pads", dir, "*.vesperpads");
    juce::Component::SafePointer<VesperEditor> safe (this);
    chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                          [safe] (const juce::FileChooser& fc)
    {
        if (safe == nullptr) return;
        const auto f = fc.getResult();
        if (! f.existsAsFile()) return;
        auto x = juce::parseXML (f);
        if (x == nullptr || ! x->hasTagName ("VESPER_PADS")) return;
        auto& ed = *safe;
        ed.p.ui.keyRoot = juce::jlimit (0, 11, x->getIntAttribute ("key", ed.p.ui.keyRoot));
        ed.p.ui.scale = juce::jlimit (0, numScales() - 1, x->getIntAttribute ("scale", ed.p.ui.scale));
        ed.p.setPalette (readCards (*x));
        ed.refreshAll();
    });
}
